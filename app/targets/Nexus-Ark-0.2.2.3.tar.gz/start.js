module.exports = {
    run: [
        {
            method: "shell.run",
            params: {
                path: "app",
                message: "uv run nexus_ark.py",
            }
        }
    ]
}
