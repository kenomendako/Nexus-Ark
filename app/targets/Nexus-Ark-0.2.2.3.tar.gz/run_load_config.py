import config_manager

if __name__ == "__main__":
    config_manager.load_config()
    print("config_manager.load_config() executed.")
