module.exports = {
    run: [
        {
            method: "shell.run",
            params: {
                message: "uv run nexus_ark.py",
            }
        }
    ]
}
