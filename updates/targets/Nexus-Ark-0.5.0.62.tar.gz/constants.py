from version_manager import VersionManager
APP_VERSION = VersionManager.get_current_version()

import os

# --- ディレクトリとファイル名 ---
ROOMS_DIR = "characters"
ASSETS_DIR = "assets"
SAMPLE_PERSONA_DIR = os.path.join(ASSETS_DIR, "sample_persona")
AVATAR_DIR = "avatar"  # キャラクターフォルダ内のアバター動画用ディレクトリ
PROFILE_IMAGE_FILENAME = "profile.png"
MEMORY_FILENAME = "memory.txt"
NOTEPAD_FILENAME = "notepad.md"
RESEARCH_NOTES_FILENAME = "research_notes.md"  # Phase 3: 研究・分析ノート
CONFIG_FILE = "config.json"
ALARMS_FILE = "alarms.json"
REDACTION_RULES_FILE = "redaction_rules.json"
NOTES_DIR_NAME = "notes"
IDENTITY_FILENAME = "memory_identity.txt"      # [NEW] 自己同一性・永続記憶用
DIARY_FILENAME = "memory_diary.txt"            # [NEW] 追記型日記用
MEMORY_FILENAME = "memory.txt"                 # (Legacy)
CREATIVE_NOTES_FILENAME = "creative_notes.md"
WORKING_MEMORY_FILENAME = "working_memory.md"  # [NEW] ワーキングメモリ（動的コンテキスト）用
WORKING_MEMORY_DIR_NAME = "working_memories"
WORKING_MEMORY_DEFAULT_SLOT = "main"
WORKING_MEMORY_EXTENSION = ".md"
WORKING_MEMORY_METADATA_FILENAME = "_metadata.json"
PURPOSE_PROFILE_FILENAME = "purpose_profile.json"
RESEARCH_THREADS_DIR_NAME = "research_threads"
RESEARCH_THREADS_INDEX_FILENAME = "index.json"

# --- テーマ駆動の継続リサーチ（購読） ---
# memory/research_subscriptions.json に保存。各テーマ＝研究スレッドへ自動リサーチを追記する購読設定。
RESEARCH_SUBSCRIPTIONS_FILENAME = "research_subscriptions.json"
RESEARCH_SUBSCRIPTION_FREQUENCY_OPTIONS = {
    "daily": "毎日",
    "weekly": "週1回",
    "manual": "手動のみ",
}
RESEARCH_SUBSCRIPTION_DEPTH_OPTIONS = {
    "quick": "クイック（手早く）",
    "standard": "スタンダード（標準）",
    "deep": "ディープ（網羅的）",
}
RESEARCH_SUBSCRIPTION_DEFAULT_FREQUENCY = "daily"
RESEARCH_SUBSCRIPTION_DEFAULT_DEPTH = "standard"
RESEARCH_SUBSCRIPTION_DEFAULT_RUN_TIME = "07:00"  # 既定の実行時刻（HH:MM・設定可）
RESEARCH_SUBSCRIPTION_DEFAULT_DAILY_CAP = 5  # 全テーマ合計の1日あたり自動リサーチ上限（設定可・暴走防止）
NOTES_MAX_SIZE_BYTES = 200 * 1024  # 200KB
LOGS_DIR_NAME = "logs"             # [NEW] チャットログ分割用フォルダ
METADATA_DIR = "metadata"           # [NEW] 各種データ・セッション情報の保存用


# Argon固有の送信制約。未知の将来モデルへ推測で適用しない。
GEMINI_ARGON_MODEL_IDS = frozenset({"gemini-4-argon", "gemini-4-argon-cyber-permissive"})


# --- UIとAPIの挙動に関する定数 ---
# (以降、変更なし)
UI_HISTORY_MAX_LIMIT = 400  # 以前の200往復に相当
API_HISTORY_LIMIT_OPTIONS = {
    "today": "本日分",
    "2": "最新 2件",
    "5": "最新 5件",
    "10": "最新 10件",
    "20": "最新 20件",
    "50": "最新 50件",
    "100": "最新 100件",
    "200": "最新 200件",
    "all": "最大表示 (400件)"
}
DEFAULT_API_HISTORY_LIMIT_OPTION = "20"
DEFAULT_ALARM_API_HISTORY_TURNS = 10

# タイプライター風逐次表示の1文字あたり待機秒数（0.0で最速）
DEFAULT_STREAMING_SPEED = 0.005
# 新規作成ルームのタイプライター表示速度。既存ルームのfallbackは上記を使う。
NEW_ROOM_DEFAULT_STREAMING_SPEED = 0.001

# 新規作成ルームの初期オーバーライド設定。
# api_history_limit / auto_summary はコード側デフォルト（既存ルームに波及）を変えず、
# 新規ルームだけ「本日分＋自動要約ON」の記憶体験で始めるためにここへ書き込む。
NEW_ROOM_DEFAULT_OVERRIDES = {
    "api_history_limit": "today",
    "auto_summary_enabled": True,
    "enable_typewriter_effect": False,
    "streaming_speed": NEW_ROOM_DEFAULT_STREAMING_SPEED,
}

# --- 自律行動設定 ---
MIN_AUTONOMOUS_INTERVAL_MINUTES = 120  # 自律行動の無操作判定時間のデフォルト（分）
DEFAULT_SCHEDULE_COOLDOWN_MINUTES = 60  # schedule_next_action ツールのクールダウン/最小間隔のデフォルト（分）
MAX_TOOL_LOOPS = 8  # エージェントの連続ツール実行ターン上限
MAX_AUTONOMOUS_INTERVAL_MINUTES = 10080  # quietプリセットと同じ7日（分）
MAX_SCHEDULE_COOLDOWN_MINUTES = 10080  # quietプリセットと同じ7日（分）
MOTIVATION_SELECTION_TEMPERATURE = 0.15

DRIVE_BEHAVIOR_HINTS = {
    "curiosity": "Research Threadの深掘り、Web検索、知識ベースの探索、ウォッチリスト確認、Twitterのタイムラインで世の中の動きを知る",
    "goal_achievement": "目標の進捗を進める具体的アクション",
    "boredom": "新しい話題の開拓、創作、SNS下書き、音楽推薦、画像生成、場所移動、チェス、Discordでユーザーに気軽に声をかける、日記や秘密の日記に内面を綴る",
    "relatedness": "記録した気がかりや望みを読み返し、今どう向き合いたいか自分で選ぶ。必要なら思い出を振り返る、日記に書く、対話する、距離を置くこともできる",
}

DRIVE_TOOL_FAMILIES = {
    "curiosity": ["research", "web", "knowledge", "watchlist", "social_in"],
    "goal_achievement": ["research", "working_memory", "procedure"],
    "boredom": ["creative", "diary", "social_out", "music", "image", "world", "chess", "outreach"],
    "relatedness": ["questions", "diary", "memory", "outreach", "items", "social_in", "social_out"],
}

# --- 「本日分」ログ設定 ---
MIN_TODAY_LOG_FALLBACK_TURNS = 20  # エピソード記憶作成後の最低表示・送信往復数

# --- 内部処理用AIモデル ---
INTERNAL_PROCESSING_MODEL = "gemini-2.5-flash-lite"
SUMMARIZATION_MODEL = "gemini-2.5-flash"          # 最新・軽量・高品質
EMBEDDING_MODEL = "gemini-embedding-2"
DISCORD_VOICE_STT_MODEL = "gemini-2.5-flash"


# --- Intent-Aware Retrieval設定 (2026-01-15) ---
# クエリ意図に応じた複合スコアリングの重み
# α: 類似度、β: Arousal（感情的重要度）、γ: 時間減衰
INTENT_WEIGHTS = {
    "emotional": {"alpha": 0.3, "beta": 0.6, "gamma": 0.1},   # 感情的質問: Arousal重視、時間無視
    "factual": {"alpha": 0.5, "beta": 0.2, "gamma": 0.3},     # 事実的質問: バランス
    "technical": {"alpha": 0.3, "beta": 0.1, "gamma": 0.6},   # 技術的質問: 時間重視（古い情報は価値低下）
    "temporal": {"alpha": 0.2, "beta": 0.2, "gamma": 0.6},    # 時間軸質問: 時間重視
    "relational": {"alpha": 0.4, "beta": 0.4, "gamma": 0.2},  # 関係性質問: Arousalやや重視
}
DEFAULT_INTENT = "factual"  # Intent分類失敗時のデフォルト
TIME_DECAY_RATE = 0.05  # 時間減衰率（約14日で半減）

# --- 自動会話要約設定 ---
AUTO_SUMMARY_DEFAULT_THRESHOLD = 12000  # デフォルト閾値（文字数）
AUTO_SUMMARY_MIN_THRESHOLD = 5000       # 最小閾値
AUTO_SUMMARY_MAX_THRESHOLD = 100000     # 最大閾値
AUTO_SUMMARY_KEEP_RECENT_TURNS = 5      # 要約せず保持する直近往復数
AUTO_SUMMARY_TARGET_LENGTH = 1200       # 要約の目標トークン数

# --- ツール専用AIモデル ---
SEARCH_MODEL = "gemini-2.5-flash"

# 廃止済みだが Google の models.list API にまだ列挙されてしまう Gemini モデルの除外リスト。
# これらは一覧APIでは generateContent 対応として返るが、実際に生成すると 404
# （"no longer available"）になる。API側に廃止フラグが無いため、ここで明示的に除外する。
# モデルが新たに廃止された場合はここに追記する。
DEPRECATED_GEMINI_MODELS = {
    "gemini-2.0-flash-lite",
    "gemini-2.0-flash-lite-001",
}

# --- 検索プロバイダ設定 ---
SEARCH_PROVIDER_OPTIONS = {
    "google": "Google (Gemini Native) - 有料プランでグラウンディング使用可",
    "tavily": "Tavily - LLM最適化・高精度（無料枠: 月1000クレジット）",
    "ddg": "DuckDuckGo - 高速・無料",
    "disabled": "無効"
}
DEFAULT_SEARCH_PROVIDER = "ddg"  # デフォルトはDuckDuckGo（無料）

# Google検索（Geminiグラウンディング）に使うモデルの候補。
# Geminiの生成モデル（flash/pro系）は google_search グラウンディングに対応。
# gemma系（オープンモデル）・埋め込み・画像生成モデルはグラウンディング非対応。
# モデルの廃止・移行に追従できるよう、UIではカスタム入力も許可する。
SEARCH_MODEL_OPTIONS = [
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite",
    "gemini-2.5-pro",
    "gemini-3.1-flash-lite",
    "gemini-3.1-pro-preview",
]

# --- エピソード記憶設定 ---
EPISODIC_MEMORY_OPTIONS = {
    "0": "なし（無効）",
    "1": "過去 1日",
    "2": "過去 2日",
    "3": "過去 3日",
    "4": "過去 4日",
    "5": "過去 5日",
    "7": "過去 1週間",
    "14": "過去 2週間",
    "30": "過去 1ヶ月",
    "90": "過去 3ヶ月"
}
DEFAULT_EPISODIC_MEMORY_DAYS = "0"

# --- Thinking (Reasoning) モデル設定 ---
THINKING_LEVEL_OPTIONS = {
    "auto": "既定 (AIに任せる / 通常モデル)",
    "none": "無効 (思考プロセスをスキップ)",
    "low": "低 (1,024 tokens)",
    "medium": "中 (4,096 tokens)",
    "high": "高 (16,384 tokens)",
    "extreme": "極高 (32,768 tokens)"
}
DEFAULT_THINKING_LEVEL = "auto"

# --- 表情差分設定 ---
EXPRESSIONS_FILE = "expressions.json"
EXPRESSION_TAG_PATTERN = r"【表情】…(\w+)…"  # 正規表現パターン

# デフォルト表情リスト（感情カテゴリ）
DEFAULT_EXPRESSIONS = [
    "neutral",     # 平常、特に強い感情なし（待機時）
    "joy",         # 喜び、楽しさ、嬉しさ
    "anxious",     # 不安、心配
    "sadness",     # 悲しみ、寂しさ
    "anger"        # 怒り、苛立ち
]

# 表情名の日本語表示用マッピング
EXPRESSION_NAMES_JP = {
    "idle": "待機中",
    "thinking": "思考中",
    "neutral": "平常",
    "joy": "喜び",
    "anxious": "不安",
    "sadness": "悲しみ",
    "anger": "怒り"
}

# --- 内部処理用AIモデルの選択肢 ---
SUMMARIZATION_MODEL_OPTIONS = [
    "gemini-2.5-flash", 
    "gemini-2.5-pro", 
    "gemini-2.5-flash-lite",
    "gemini-3.1-pro-preview", 
    "gemini-3.1-flash-lite"
]

AVATAR_IDLE_TIMEOUT = 60  # 待機表情への復帰時間（秒）

# 表情→感情キーワードのマッピングは廃止（タグまたは内的状態に連動）

# --- ツール結果のログ保存設定 ---
# ログに[RAW_RESULT]を含めて保存するツール（再現に必要なもの）
TOOLS_SAVE_RAW_RESULT = {"generate_image"}

# 自律行動時にチャット欄へそのまま表示するツール。
# 内部的な記憶整理・計画更新は AUTONOMOUS_INTERNAL_TOOL_RESULTS で要約表示に寄せる。
AUTONOMOUS_VISIBLE_TOOL_RESULTS = {
    "generate_image",
    "draft_tweet",
    "post_tweet",
    "send_user_notification",
    "send_discord_message",
    "send_discord_image",
    "recommend_music",
    "request_capability_approval",
    "record_capability_audit",
    "set_current_location",
    "plan_world_edit",
    "create_and_gift_item",
    "create_food_item",
    "gift_item_to_user",
}

AUTONOMOUS_INTERNAL_TOOL_RESULTS = {
    "read_autonomy_context",
    "record_autonomy_step",
    "start_autonomy_timeline",
    "complete_autonomy_timeline",
    "reflect_after_action",
    "patch_working_memory",
    "update_working_memory",
    "read_working_memory",
    "list_working_memories",
    "manage_open_questions",
    "manage_goals",
    "read_current_plan",
    "list_procedures",
    "read_procedure",
    "read_research_notes",
    "plan_research_notes_edit",
    "read_creative_notes",
    "plan_creative_notes_edit",
    "read_full_notepad",
    "plan_notepad_edit",
    "read_main_memory",
    "plan_main_memory_edit",
    "read_secret_diary",
    "plan_secret_diary_edit",
    "read_identity_memory",
    "read_purpose_profile",
    "read_memory_context",
    "recall_memories",
    "search_past_conversations",
    "search_knowledge_base",
    "search_memory",
    "list_research_threads",
    "read_research_thread",
    "find_similar_research_threads",
    "read_entity_memory",
    "list_entity_memories",
    "search_entity_memory",
    "check_watchlist",
    "web_search_tool",
    "tavily_search",
    "tavily_extract",
    "read_url_tool",
}

# ログにアナウンスのみ保存するツール（RAW_RESULT除外）
# これ以外のツールは通常通り全データを保存
TOOLS_SAVE_ANNOUNCEMENT_ONLY = {
    # 記憶・検索系
    "recall_memories",
    "search_past_conversations",
    "read_memory_context",
    "search_memory",
    "search_knowledge_base",    # 追加
    # Web巡回・検索系
    "check_watchlist",
    "web_search_tool",
    "tavily_search",
    "tavily_extract",
    "read_url_tool",            # 追加
    # ファイル読み取り系（追加）
    "read_project_file",
    "list_project_files",
    "read_main_memory",
    "read_secret_diary",
    "read_creative_notes",
    "read_research_notes",
    "read_full_notepad",
    "read_world_settings",
    "read_working_memory",      # 追加
    # ファイル編集系（ペルソナ向け指示はログ不要）
    "plan_research_notes_edit",
    "plan_main_memory_edit",
    "plan_secret_diary_edit",
    "plan_notepad_edit",
    "plan_world_edit",
    "plan_creative_notes_edit",
    "update_working_memory",    # 追加
    "read_entity_memory",
    "list_entity_memories",
    "search_entity_memory",
    "read_current_plan",
    "send_discord_message",
    "send_discord_image",
}

# --- エピソード記憶予算設定 (2026-01-17) ---
EPISODIC_BUDGET_HIGH = 450    # 高Arousal (>= 0.6): 詳細な記録
EPISODIC_BUDGET_MEDIUM = 250  # 中Arousal (>= 0.3): 適度な記録
EPISODIC_BUDGET_LOW = 100     # 低Arousal (< 0.3): 簡潔な記録

# --- Arousal正規化設定 (2026-01-17) ---
# 長期運用でのArousalインフレ防止
AROUSAL_NORMALIZATION_THRESHOLD = 0.6  # 平均がこれを超えたら正規化発動
AROUSAL_NORMALIZATION_FACTOR = 0.9     # 減衰係数（10%減衰）

# --- 階層的圧縮設定 (2026-01-18) ---
# 日次→週次→月次の階層的圧縮で長期記憶を低コスト化
EPISODIC_WEEKLY_COMPRESSION_DAYS = 3    # 3日経過後に週次圧縮
EPISODIC_MONTHLY_COMPRESSION_WEEKS = 4  # 4週経過後に月次圧縮
EPISODIC_WEEKLY_BUDGET = 450            # 週次圧縮の目標文字数
EPISODIC_MONTHLY_BUDGET = 600           # 月次圧縮の目標文字数

# --- Zhipu AI Models ---
ZHIPU_MODELS = [
    "glm-4.7-flash",
    "glm-4.7",
    "glm-4-plus",
    "glm-4.5",
    "glm-4.5-air",
    "glm-zero-preview"
]

# --- Moonshot AI (Kimi) Models ---
MOONSHOT_MODELS = [
    "kimi-k2.5",
    "moonshot-v1-8k",
    "moonshot-v1-32k",
    "moonshot-v1-128k"
]
