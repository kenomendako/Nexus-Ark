# === [CRITICAL FIX FOR EMBEDDED PYTHON] ===
# This block MUST be at the absolute top of the file.
import sys
sys.dont_write_bytecode = True

import os
import base64
import psutil


# Get the absolute path of the directory where this script is located.
# This ensures that even in an embedded environment, Python knows where to find other modules.
script_dir = os.path.dirname(os.path.abspath(__file__))

# Add the script's directory to Python's module search path.
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)
# === [END CRITICAL FIX] ===

import closet_manager

# --- [ロギング設定の強制上書き] ---
import logging
import logging.config
from pathlib import Path
from sys import stdout

LOGS_DIR = Path(os.getenv("MEMOS_BASE_PATH", Path.cwd())) / ".memos" / "logs"
LOGS_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE_PATH = LOGS_DIR / "nexus_ark.log"

LOGGING_CONFIG = {
    "version": 1, "disable_existing_loggers": False,
    "formatters": { "standard": { "format": "%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(funcName)s - %(message)s" } },
    "handlers": {
        "console": { "level": "INFO", "class": "logging.StreamHandler", "stream": stdout, "formatter": "standard" },
        "file": {
            "level": "INFO", "class": "concurrent_log_handler.ConcurrentRotatingFileHandler",
            "filename": LOG_FILE_PATH, "maxBytes": 1024 * 1024 * 10, "backupCount": 5,
            "formatter": "standard", "use_gzip": True,
        },
    },
    "root": { "level": "INFO", "handlers": ["console", "file"] },
    "loggers": {
        "nexus_ark": { "level": "INFO", "propagate": True },
        "memos": { "level": "WARNING", "propagate": True },
        "gradio": { "level": "WARNING", "propagate": True },
        "httpx": { "level": "WARNING", "propagate": True },
        "neo4j": { "level": "WARNING", "propagate": True },
        "PIL": { "level": "WARNING", "propagate": False },
        "urllib3": { "level": "WARNING", "propagate": True },
    },
}
logging.config.dictConfig(LOGGING_CONFIG)
# この一行が、他のライブラリによる設定の上書きを完全に禁止する
logging.config.dictConfig = lambda *args, **kwargs: None
print("--- [Nexus Ark] アプリケーション固有のロギング設定を適用しました ---")
print("--- [Nexus Ark] ライブラリを読み込み中... (初回は2〜3分かかる場合があります) ---")
# --- [ここまでが新しいブロック] ---



def wire_response_reasoning_events(demo, global_panel, room_panel, global_inputs, room_inputs):
    """応答推論パネルの読込と明示保存を、既存のモデル選択へ接続する。"""
    from ui_handlers import response_reasoning as reasoning_handlers

    gr.on(
        triggers=[component.change for component in global_inputs],
        fn=reasoning_handlers.load_global,
        inputs=global_inputs, outputs=global_panel["outputs"],
        show_progress="hidden", api_visibility="private",
        trigger_mode="always_last",
    )
    gr.on(
        triggers=[component.change for component in room_inputs],
        fn=reasoning_handlers.load_room,
        inputs=room_inputs, outputs=room_panel["outputs"],
        show_progress="hidden", api_visibility="private",
        trigger_mode="always_last",
    )
    global_panel["refresh"].click(
        fn=reasoning_handlers.load_global,
        inputs=global_inputs, outputs=global_panel["outputs"],
        show_progress="hidden", api_visibility="private",
    )
    room_panel["refresh"].click(
        fn=reasoning_handlers.load_room,
        inputs=room_inputs, outputs=room_panel["outputs"],
        show_progress="hidden", api_visibility="private",
    )
    global_panel["effort"].change(
        fn=reasoning_handlers.update_budget,
        inputs=[global_panel["effort"], global_panel["state"]],
        outputs=[global_panel["budget"]],
        show_progress="hidden", api_visibility="private",
    )
    room_panel["effort"].change(
        fn=reasoning_handlers.update_budget,
        inputs=[room_panel["effort"], room_panel["state"]],
        outputs=[room_panel["budget"]],
        show_progress="hidden", api_visibility="private",
    )
    global_panel["save"].click(
        fn=reasoning_handlers.save_global,
        inputs=global_inputs + [global_panel["effort"], global_panel["budget"], global_panel["state"]],
        outputs=global_panel["outputs"],
        show_progress="hidden", api_visibility="private",
    )
    room_panel["save"].click(
        fn=reasoning_handlers.save_room,
        inputs=room_inputs + [room_panel["effort"], room_panel["budget"], room_panel["state"]],
        outputs=room_panel["outputs"],
        show_progress="hidden", api_visibility="private",
    )


def _env_flag(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _outing_mode_visibility_js(mode: str) -> str:
    """お出かけ本文の初回DOM生成中も、クリック直後から進行状況を表示する。"""
    panel_ids = {
        "setup": "outing_lite_setup",
        "independent": "outing_lite_independent",
        "export": "outing_export_panel",
        "import": "outing_import_panel",
    }
    mode_labels = {
        "setup": "Nexus Ark Lite",
        "independent": "Lite独立モード",
        "export": "外部AIへ持ち出す",
        "import": "外部AIから帰宅",
    }
    target_id = panel_ids[mode]
    serialized_ids = json.dumps(list(panel_ids.values()), ensure_ascii=False)
    serialized_target = json.dumps(target_id, ensure_ascii=False)
    serialized_label = json.dumps(mode_labels[mode], ensure_ascii=False)
    return f"""() => {{
        const panelIds = {serialized_ids};
        const targetId = {serialized_target};
        const modeLabel = {serialized_label};
        const feedback = document.querySelector(
            "#outing_mode_loading_feedback .outing-mode-loading-message"
        );
        if (feedback) {{
            feedback.textContent = `「${{modeLabel}}」を開いています… 初回は数秒かかる場合があります。`;
            feedback.hidden = false;
        }}
        window.__nexusOutingModeRequest = targetId;
        if (window.__nexusOutingModeTimer) {{
            window.clearInterval(window.__nexusOutingModeTimer);
        }}
        for (const panelId of panelIds) {{
            const panel = document.getElementById(panelId);
            if (!panel) continue;
            const shouldShow = panelId === targetId;
            panel.classList.toggle("hide", !shouldShow);
            panel.classList.toggle("hidden", !shouldShow);
            if (shouldShow) {{
                panel.style.removeProperty("display");
            }} else {{
                panel.style.setProperty("display", "none", "important");
            }}
        }}
        let attempts = 0;
        const waitForPanel = window.setInterval(() => {{
            attempts += 1;
            if (window.__nexusOutingModeRequest !== targetId) {{
                window.clearInterval(waitForPanel);
                return;
            }}
            const target = document.getElementById(targetId);
            if (target) {{
                target.classList.remove("hide", "hidden");
                target.style.removeProperty("display");
                if (feedback) feedback.hidden = true;
                window.clearInterval(waitForPanel);
            }} else if (attempts >= 100) {{
                if (feedback) {{
                    feedback.textContent = "表示に時間がかかっています。もう一度ボタンを押してください。";
                }}
                window.clearInterval(waitForPanel);
            }}
        }}, 100);
        window.__nexusOutingModeTimer = waitForPanel;
    }}"""


def _ensure_localhost_no_proxy():
    """Gradioの起動時自己診断がlocalhostへ確実に直通できるようにする。"""
    local_hosts = ["localhost", "127.0.0.1", "0.0.0.0", "::1"]
    for key in ("NO_PROXY", "no_proxy"):
        existing = os.getenv(key, "")
        entries = [item.strip() for item in existing.split(",") if item.strip()]
        changed = False
        for host in local_hosts:
            if host not in entries:
                entries.append(host)
                changed = True
        if changed or not existing:
            os.environ[key] = ",".join(entries)


def _resolve_gradio_port(default_port: int = 7860, excluded_ports: set[int] | None = None, allow_fallback: bool = False) -> int | None:
    """
    Gradioのポートを決定する。
    スマホからの接続URLを固定しやすくするため、通常は設定ポートを優先する。
    `allow_fallback=True` の場合だけ、従来通り空きポート探索へフォールバックする。
    """
    env_port = os.getenv("GRADIO_SERVER_PORT") or os.getenv("NEXUS_ARK_PORT")
    excluded_ports = excluded_ports or set()
    occupied_ports = set()
    try:
        for conn in psutil.net_connections(kind="inet"):
            if conn.laddr:
                occupied_ports.add(conn.laddr.port)
    except Exception as e:
        print(f"--- [Port Warning] 既存ポートの確認に失敗しました: {e} ---")

    configured_port = default_port
    if env_port:
        try:
            configured_port = int(env_port)
        except ValueError:
            print(f"--- [Port Warning] 無効なポート指定を無視します: {env_port} ---")

    if configured_port in excluded_ports:
        print(f"--- [Port Warning] Gradio固定ポート {configured_port} は内部サービス用に予約されています ---")
        if not allow_fallback:
            return configured_port
    elif configured_port not in occupied_ports:
        return configured_port
    else:
        print(f"--- [Port Warning] Gradio固定ポート {configured_port} は既に使用中です ---")

    if not allow_fallback:
        return configured_port

    try:
        for port in range(configured_port + 1, configured_port + 100):
            if port not in occupied_ports and port not in excluded_ports:
                return port
        return None
    except Exception:
        return None


def _consume_restart_marker() -> bool:
    """更新再起動マーカーがあれば削除し、鮮度10分以内ならTrueを返す。

    マーカーは UpdateManager.trigger_restart() が書き込む。クラッシュ等で
    ランチャー再起動に至らず残留した古いマーカーは、削除だけして無効扱いにする。
    """
    marker = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "cache", "restart_pending.marker"
    )
    try:
        if os.path.exists(marker):
            import time
            fresh = (time.time() - os.path.getmtime(marker)) < 600
            os.remove(marker)
            return fresh
    except Exception:
        pass
    return False


def _open_local_browser_later(port: int) -> None:
    """0.0.0.0ではなく、ブラウザで開けるローカルURLを遅延起動する。"""
    if os.environ.get("NEXUS_ARK_NO_BROWSER") == "1":
        print("--- [Open] NEXUS_ARK_NO_BROWSER=1 のためブラウザ自動起動をスキップします ---")
        return

    if _consume_restart_marker():
        print("--- [Open] 更新後の再起動のため新規タブは開きません（更新前のタブが自動リロードされます） ---")
        return

    def _open() -> None:
        try:
            import time
            import webbrowser
            time.sleep(6.0)
            webbrowser.open(f"http://127.0.0.1:{port}", new=2)
        except Exception as e:
            print(f"--- [Browser Warning] ブラウザの自動起動に失敗しました: {e} ---")

    try:
        import threading
        threading.Thread(target=_open, daemon=True).start()
    except Exception as e:
        print(f"--- [Browser Warning] ブラウザ起動スレッドを開始できませんでした: {e} ---")


def _start_update_trial_ready_monitor(port: int) -> None:
    """原子更新trial時だけ、HTTP ready後の成功marker監視を開始する。"""
    if os.environ.get("NEXUS_ARK_UPDATE_TRIAL") != "1":
        return
    try:
        from update_host.trial import start_trial_ready_monitor

        start_trial_ready_monitor(Path(script_dir), port)
        print("--- [Update Trial] 起動成功markerの監視を開始しました ---")
    except Exception as exc:
        print(f"--- [Update Trial Error] marker監視を開始できません: {exc} ---")
        raise


def _style_tag_to_css(style_text: str) -> str:
    """gr.HTML用の<style>...</style>文字列をlaunch(css=...)用のCSSへ変換する。"""
    if not isinstance(style_text, str):
        return ""
    return style_text.replace("<style>", "", 1).replace("</style>", "", 1)

# --- [Gradio警告の抑制] ---
# Gradioの`special_args`関数がlambdaシグネチャを正しく解析できず、
# 起動時に大量の「Unexpected argument. Filling with None.」警告を出力する問題を抑制
import warnings
warnings.filterwarnings("ignore", message="Unexpected argument. Filling with None.")
# --- [ここまで] ---

# nexus_ark.py (v18: グループ会話FIX・最終版)

import shutil
import utils
import json
import gradio as gr
from emotion_ui import build_emotion_panel
import traceback
import pandas as pd
import config_manager, room_manager, alarm_manager, ui_handlers, constants, onboarding_manager, timers, lite_travel
ui_handlers.log_memory_diagnostics("app_imports:after_core_imports")
try:
    import discord_manager
except ImportError:
    print("--- [WARNING] Discord dependencies not found. Discord features will be disabled. ---")
    discord_manager = None

try:
    import line_manager
except ImportError:
    print("--- [WARNING] LINE dependencies not found. LINE features will be disabled. ---")
    line_manager = None

from game.chess_engine import game_instance

def handle_user_chess_move(move_json):
    """
    Handle move from frontend (JS).
    move_json: '{"from": "e2", "to": "e4"}'

    Returns (fen, status_message).
    - Legal move: updates game state, returns new FEN and success message.
    - Illegal move: logs the attempt to chat (so persona can teach), returns current FEN and error.
    """
    if not move_json:
        return game_instance.get_fen(), "No move data"

    try:
        move_data = json.loads(move_json)
        start_sq = move_data.get("from")
        end_sq = move_data.get("to")
        move_str = f"{start_sq}{end_sq}"

        # Attempt the move
        move_successful = False
        error_msg = None
        try:
            game_instance.make_move(move_str)
            move_successful = True
        except ValueError as e:
            # Retry with promotion to queen (for pawn reaching last rank)
            try:
                game_instance.make_move(move_str + "q")
                move_successful = True
            except ValueError as e2:
                error_msg = str(e2) if "illegal" in str(e2).lower() else str(e)

        if move_successful:
            return game_instance.get_fen(), f"Moved: {move_str}"
        else:
            # --- Record illegal move attempt for persona visibility ---
            # The persona can see this via read_board_state tool
            game_instance.record_illegal_attempt(start_sq, end_sq, error_msg or "不正な手")
            print(f"  - [Chess] ユーザーが不正な手を試みました: {start_sq} → {end_sq} (理由: {error_msg})")

            return game_instance.get_fen(), f"Illegal move: {move_str}"
    except Exception as e:
        print(f"Chess move error: {e}")
        return game_instance.get_fen(), f"Error: {e}"


if not utils.acquire_lock():
    print("ロックが取得できなかったため、アプリケーションを終了します。")
    if os.name == "nt": os.system("pause")
    else: input("続行するにはEnterキーを押してください...")
    sys.exit(1)
os.environ["MEM0_TELEMETRY_ENABLED"] = "false"

# --- [依存関係定義の自動同期] ---
# 配布版（app/ ディレクトリ内で実行）の場合、自動更新で app/pyproject.toml は
# 最新になるが、ルートの pyproject.toml が古いままになる「鶏と卵」問題がある。
# ここで差異を検出して自動コピーし、ランチャーの uv sync で新ライブラリが
# インストールされるよう再起動シグナル (exit 123) を発行する。
try:
    _app_dir = Path(script_dir)
    _parent_dir = _app_dir.parent
    _app_pyproject = _app_dir / "pyproject.toml"
    _root_pyproject = _parent_dir / "pyproject.toml"
    _root_start_bat = _parent_dir / "Start.bat"  # 配布版の判定に使用

    if (
        _app_dir.name == "app"
        and _root_start_bat.exists()
        and _app_pyproject.exists()
    ):
        _needs_sync = False
        if not _root_pyproject.exists():
            _needs_sync = True
        else:
            _needs_sync = _app_pyproject.read_bytes() != _root_pyproject.read_bytes()

        if _needs_sync:
            import shutil as _shutil
            _shutil.copy2(str(_app_pyproject), str(_root_pyproject))
            print("--- [AutoSync] ルートの pyproject.toml を app/ から同期しました。依存関係を更新するため再起動します... ---")
            utils.release_lock()
            os._exit(123)  # ランチャーの uv sync → 再起動ループに入る
except Exception as _sync_err:
    print(f"--- [AutoSync Warning] pyproject.toml 同期チェックでエラー（無視して続行）: {_sync_err} ---")

try:
    config_manager.load_config()

    # --- [初回起動シーケンス] ---
    # characters/_shared のような管理用データだけがある新規配布環境でも、
    # 実ルームがなければサンプルペルソナを展開する。
    if room_manager.should_install_sample_persona_on_startup("Olivie"):
        print("--- [初回起動] 有効なルームがないため、サンプルペルソナを展開します ---")
        sample_persona_path = os.path.join(constants.SAMPLE_PERSONA_DIR, "Olivie")
        target_path = os.path.join(constants.ROOMS_DIR, "Olivie")
        if os.path.isdir(sample_persona_path):
            try:
                os.makedirs(constants.ROOMS_DIR, exist_ok=True)
                shutil.copytree(sample_persona_path, target_path)
                print(f"--- サンプルペルソナ「オリヴェ」を {target_path} にコピーしました ---")
                # 初回起動時、configのデフォルトルームをオリヴェに設定
                config_manager.save_config_if_changed("last_room", "Olivie")
                config_manager.load_config() # 設定を再読み込み
            except Exception as e:
                print(f"!!! [致命的エラー] サンプルペルソナのコピーに失敗しました: {e}")
        else:
            print(f"!!! [警告] サンプルペルソナのディレクトリが見つかりません: {sample_persona_path}")
    try:
        _olivie_sync = room_manager.sync_installed_olivie_official_knowledge()
        if _olivie_sync.get("status") == "updated":
            print(f"--- [Olivie Knowledge Sync] {_olivie_sync} ---")
            if _olivie_sync.get("needs_rebuild"):
                utils.add_system_notice(
                    "オリヴェの公式ガイドを更新しました。個人ナレッジもあるため、知識タブから知識索引を再構築してください。",
                    level="warning",
                    room_name="Olivie",
                )
    except Exception as e:
        print(f"--- [Olivie Knowledge Sync Warning] {e} ---")
    # --- [初回起動シーケンス ここまで] ---

    # ▼▼▼【ここから追加：テーマ適用ロジック】▼▼▼
    def get_active_theme() -> gr.themes.Base:
        """config.jsonから現在アクティブなテーマを読み込み、Gradioのテーマオブジェクトを生成する。"""
        theme_settings = config_manager.CONFIG_GLOBAL.get("theme_settings", {})
        active_theme_name = theme_settings.get("active_theme", "Soft")

        print(f"--- [テーマ] アクティブなテーマ '{active_theme_name}' を読み込んでいます ---")
        theme_obj = config_manager.get_theme_object(active_theme_name)
        print(f"--- [テーマ] テーマオブジェクトの読み込みに成功しました ---")
        return theme_obj

    active_theme_object = get_active_theme()
    # ▲▲▲【追加ここまで】▲▲▲

    alarm_manager.load_alarms()
    timers.load_active_timers() # タイマーの状態を復元
    timers.restore_scheduled_action_plans() # action_plan.json に残った自己予約を復元
    alarm_manager.start_alarm_scheduler_thread()
    room_manager.start_periodic_backup()
    try:
        from agent_delegation.memory_watchdog import start_memory_watchdog

        start_memory_watchdog()
    except Exception as e:
        print(f"--- [MEM Watchdog] 起動に失敗（監視なしで継続）: {e} ---")
    try:
        import agent_delegation

        _reconciled = agent_delegation.reconcile_orphaned_tasks()
        if _reconciled:
            print(f"--- [AgentDelegation] 前回中断された委任タスク {len(_reconciled)} 件を「中断」に整合しました ---")
            try:
                agent_delegation.inject_restart_interruption_notices(_reconciled)
            except Exception as notice_error:
                print(f"--- [AgentDelegation] 中断タスク通知に失敗（起動は継続）: {notice_error} ---")
    except Exception as e:
        print(f"--- [AgentDelegation] 委任タスクの起動時整合に失敗（継続）: {e} ---")
    try:
        import google_calendar_service
        google_calendar_service.start_calendar_sync_thread()
    except Exception as e:
        print(f"--- [Calendar] 同期スレッドの起動に失敗（カレンダー連携は無効のまま継続）: {e} ---")

    # UI用カスタムCSSは assets/styles/nexus_ark.css へ分離（保守性のため・挙動は不変）。
    _custom_css_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "styles", "nexus_ark.css")
    try:
        with open(_custom_css_path, encoding="utf-8") as _css_f:
            custom_css = _css_f.read()
    except OSError as _css_e:
        print(f"--- [UI] カスタムCSSの読み込みに失敗（CSSなしで継続）: {_css_e} ---")
        custom_css = ""
    # launch(js=...) に追加する場合は、アロー関数 `() => {...}` または名前付き関数を使う。
    custom_js = ""
    tab_probe_disable_custom_css = _env_flag("NEXUS_ARK_TAB_PROBE_DISABLE_CUSTOM_CSS", False)
    tab_probe_disable_custom_js = _env_flag("NEXUS_ARK_TAB_PROBE_DISABLE_CUSTOM_JS", False)
    effective_custom_css = "" if tab_probe_disable_custom_css else custom_css
    effective_custom_js = "" if tab_probe_disable_custom_js else custom_js
    if tab_probe_disable_custom_css:
        print("--- [Tab Probe] custom_cssを一時無効化しています ---")
    if tab_probe_disable_custom_js:
        print("--- [Tab Probe] custom_jsを一時無効化しています ---")

    # --- [テーマ適用ロジック] ---
    # 新しいconfig_managerの関数を呼び出すように変更
    active_theme_object = config_manager.get_theme_object(
        config_manager.CONFIG_GLOBAL.get("theme_settings", {}).get("active_theme", "nexus_ark_theme")
    )

    with gr.Blocks(title=f"Nexus Ark v{constants.APP_VERSION}") as demo:
        # --- [Onboarding Wizard] ---
        initial_status = onboarding_manager.check_status()
        is_onboarding = (initial_status != onboarding_manager.STATUS_ACTIVE_USER)

        # オンボーディングモーダル: 初期状態は非表示、demo.loadで必要に応じて表示
        # これにより、リロード時に一瞬オンボーディングが見えることを防止
        with gr.Group(visible=False, elem_id="onboarding_overlay") as onboarding_group:
            with gr.Column(elem_id="onboarding_content"):
                gr.Markdown("# Welcome to Nexus Ark")
                gr.Markdown("Nexus Arkへようこそ！<br>Nexus Arkはあなただけのペルソナ（AI人格）と暮らし、育むための場です。")

                # --- Step 1: 選択画面 ---
                with gr.Group(visible=True) as onboarding_step1:
                    gr.Markdown("<br>")
                    gr.Markdown("### セットアップ方法を選択してください")

                    with gr.Row():
                        onboarding_new_btn = gr.Button("🆕 新規インストール", variant="primary", size="lg", scale=1)
                        onboarding_migrate_btn = gr.Button("📦 旧版からデータを引き継ぐ", variant="secondary", size="lg", scale=1)

                    gr.Markdown("💡 旧バージョンのNexus Arkをお使いの方は「旧版からデータを引き継ぐ」を選択すると、設定やキャラクターデータを自動で移行できます。")

                # --- Step 2a: 新規インストール（APIキー設定） ---
                with gr.Group(visible=False) as onboarding_step2_new:
                    gr.Markdown("<br>")
                    gr.Markdown("### 🔑 APIキー設定")
                    gr.Markdown("Nexus Arkを動作させるには、[Google Gemini API](https://aistudio.google.com/apikey)のAPIキーが必要です。（無料プランあり）")

                    onboarding_key_name = gr.Textbox(
                        label="キーの名前（任意）",
                        placeholder="例: my_free_key",
                        value="default",
                        info="複数のAPIキーを管理する際の識別名です。"
                    )

                    onboarding_api_key = gr.Textbox(
                        label="Gemini API Key",
                        placeholder="AIzaSy...",
                        type="password"
                    )

                    gr.Markdown("※ APIキーは端末内にのみ保存され、外部に送信されることはありません。")

                    with gr.Row():
                        onboarding_back_btn1 = gr.Button("← 戻る", variant="secondary", size="sm")
                        onboarding_finish_btn = gr.Button("✨ 設定を保存して開始", variant="primary", size="lg")
                    onboarding_error_msg = gr.Textbox(visible=False, label="エラー")

                # --- Step 2b: マイグレーション ---
                with gr.Group(visible=False) as onboarding_step2_migrate:
                    gr.Markdown("<br>")
                    gr.Markdown("### 📦 旧バージョンからのデータ移行")
                    gr.Markdown("旧Nexus Arkのフォルダパスを入力してください。設定ファイルとキャラクターデータが自動的に移行されます。")

                    onboarding_migrate_path = gr.Textbox(
                        label="旧Nexus Arkフォルダのパス",
                        placeholder="例: C:\\Users\\username\\Documents\\NexusArk",
                        info="config.json があるフォルダを指定してください"
                    )

                    gr.Markdown("""
**移行されるデータ:**
- `config.json` (APIキー設定)
- `characters/` フォルダ (キャラクターデータ全て)
- `alarms.json` (アラーム設定)
- その他の設定ファイル
""")

                    with gr.Row():
                        onboarding_back_btn2 = gr.Button("← 戻る", variant="secondary", size="sm")
                        onboarding_migrate_exec_btn = gr.Button("📦 データを移行して開始", variant="primary", size="lg")
                    onboarding_migrate_status = gr.Textbox(visible=False, label="ステータス", lines=4)

                # --- イベントハンドラ ---
                def show_new_install():
                    return gr.update(visible=False), gr.update(visible=True), gr.update(visible=False)

                def show_migrate():
                    return gr.update(visible=False), gr.update(visible=False), gr.update(visible=True)

                def go_back():
                    return gr.update(visible=True), gr.update(visible=False), gr.update(visible=False)

                onboarding_new_btn.click(
                    fn=show_new_install,
                    outputs=[onboarding_step1, onboarding_step2_new, onboarding_step2_migrate]
                )
                onboarding_migrate_btn.click(
                    fn=show_migrate,
                    outputs=[onboarding_step1, onboarding_step2_new, onboarding_step2_migrate]
                )
                onboarding_back_btn1.click(
                    fn=go_back,
                    outputs=[onboarding_step1, onboarding_step2_new, onboarding_step2_migrate]
                )
                onboarding_back_btn2.click(
                    fn=go_back,
                    outputs=[onboarding_step1, onboarding_step2_new, onboarding_step2_migrate]
                )

                def finish_onboarding(key_name, api_key):
                    if not api_key:
                        return gr.update(visible=True, value="APIキーを入力してください。"), gr.update(visible=True)

                    # キー名が空の場合はdefaultを使用
                    safe_key_name = key_name.strip() if key_name and key_name.strip() else "default"

                    try:
                        # gemini_api_keys 辞書形式で保存（システムが参照する正しい形式）
                        config_manager.add_or_update_gemini_key(safe_key_name, api_key)

                        # last_api_key_name も設定
                        config_manager.save_config_if_changed("last_api_key_name", safe_key_name)

                        # Mark as complete
                        onboarding_manager.mark_setup_completed()

                        # グローバル設定を再読み込み
                        config_manager.load_config()

                        return gr.update(visible=False), gr.update(visible=False) # Hide overlay
                    except Exception as e:
                        return gr.update(visible=True, value=f"保存に失敗しました: {e}"), gr.update(visible=True)

            def execute_migration(migrate_path):
                import shutil
                import datetime
                import stat
                import gc
                import time
                import errno
                from pathlib import Path
                from rag_manager import RAGManager
                import ui_handlers
                import utils

                # [2026-02-11 FIX] Windows PermissionError 対処
                # 1. メモリ上のRAGキャッシュとインスタンスをクリアしてファイルロックを解放
                print("[Migration] Clearing RAG caches and instances...")
                ui_handlers._rag_managers.clear()
                RAGManager.clear_cache()
                utils.invalidate_log_migration_cache()
                gc.collect()
                time.sleep(0.5) # Windowsのファイル解放待ち

                yield gr.update(visible=True, value="【準備中】メモリとファイルロックを解放しています..."), gr.update(visible=True)

                # 2. 読み取り専用ファイルを解除するハンドラ (Python 3.12 以降の onexc にも対応)
                def handle_remove_readonly(func, path, excinfo):
                    # excinfo は (type, value, traceback) または Exception
                    try:
                        os.chmod(path, stat.S_IWRITE)
                        func(path)
                    except Exception:
                        pass # 致命的なロックは後続のリネーム退避に任せる

                if not migrate_path or not migrate_path.strip():
                    yield gr.update(visible=True, value="パスを入力してください。"), gr.update(visible=True)
                    return

                migrate_path = migrate_path.strip()
                src_path = Path(migrate_path)
                dest_path = Path(__file__).parent

                # パス存在チェック
                if not src_path.exists():
                    yield gr.update(visible=True, value=f"指定されたパスが見つかりません: {migrate_path}"), gr.update(visible=True)
                    return

                # config.json の存在チェック
                if not (src_path / "config.json").exists():
                    yield gr.update(visible=True, value=f"config.json が見つかりません。正しいNexus Arkフォルダを指定してください。"), gr.update(visible=True)
                    return

                try:
                    # --- 1. ルート設定ファイルの移行 ---
                    yield gr.update(visible=True, value="【ステップ 1/3】 ルート設定ファイルを移行しています..."), gr.update(visible=True)
                    for filename in ["config.json", "alarms.json", "redaction_rules.json", ".gemini_key_states.json"]:
                        src_file = src_path / filename
                        dest_file = dest_path / filename

                        if src_file.exists():
                            if dest_file.exists():
                                backup_file = dest_file.with_suffix(dest_file.suffix + ".bak")
                                shutil.copy2(dest_file, backup_file)
                                print(f"[Migration] Created backup: {filename}")

                            shutil.copy2(src_file, dest_file)
                            print(f"[Migration] Copied: {filename}")

                    # --- 2. charactersフォルダの移行 ---
                    src_chars = src_path / "characters"
                    dest_chars = dest_path / "characters"
                    migrated_room_name_map = {}
                    dest_chars.mkdir(parents=True, exist_ok=True)

                    if src_chars.exists():
                        target_dirs = [d for d in src_chars.iterdir() if d.is_dir() and not d.name.startswith(".")]
                        total_chars = len(target_dirs)

                        for i, char_dir in enumerate(target_dirs, 1):
                            # ターゲットディレクトリ名を決定
                            # "オリヴェ" (およびその表記ゆれ) は "Olivie" にマッピングして統合
                            target_name = room_manager.normalize_room_folder_for_migration(char_dir.name)
                            if target_name != char_dir.name:
                                migrated_room_name_map[char_dir.name] = target_name

                            target_dir = dest_chars / target_name

                            yield gr.update(visible=True, value=f"【ステップ 2/3】 キャラクターデータをコピー中 ({i}/{total_chars}): {target_name}\n（データ量によっては数分かかる場合があります）"), gr.update(visible=True)
                            print(f"[Migration] Migrating character: {char_dir.name} -> {target_name}")

                            if target_dir.exists():
                                # 既存フォルダ（初期生成されたOlivieなど）をバックアップ
                                # [v2] characters/フォルダの外に移動してUIに表示されないようにする
                                timestamp_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                                global_migration_backup_dir = dest_path / "backups" / "migration_retired"
                                global_migration_backup_dir.mkdir(parents=True, exist_ok=True)

                                backup_dir = global_migration_backup_dir / f"{target_name}_{timestamp_str}"
                                shutil.move(str(target_dir), str(backup_dir))
                                print(f"[Migration] Retired existing {target_name} to: {backup_dir}")
                            else:
                                # 存在しない場合でも、もし元が「オリヴェ」で先が「Olivie」なら、
                                # すでに「Olivie」にマージ済みかもしれないのでチェック
                                pass

                            try:
                                shutil.copytree(str(char_dir), str(target_dir))
                                utils.invalidate_log_migration_cache(str(target_dir))
                                print(f"[Migration] Copied character: {char_dir.name}")
                            except OSError as e:
                                if e.errno == 112 or "disk space" in str(e).lower(): # WinError 112: Space error
                                    print(f"⚠️ [Migration] Error copying {char_dir.name}: Disk full or quota exceeded. Skipping remaining files for this character.")
                                    # 部分的にコピーされている可能性があるので、不完全な状態を残すか、クリーンアップするか判断が難しいが
                                    # ユーザーデータなので残せるだけ残す方針（ただし壊れている可能性あり）
                                    yield gr.update(visible=True, value=f"⚠️ {char_dir.name} のコピー中にディスク容量不足エラーが発生しました。一部のデータのみコピーされました。"), gr.update(visible=True)
                                    time.sleep(3)
                                else:
                                    print(f"⚠️ [Migration] Error copying {char_dir.name}: {e}")
                                # エラーが出ても続行する（他のキャラクタや処理を止めない）

                    migrated_config_path = dest_path / "config.json"
                    if migrated_config_path.exists():
                        try:
                            with open(migrated_config_path, "r", encoding="utf-8") as f:
                                migrated_config = json.load(f)
                            if room_manager.normalize_migrated_config_room_references(migrated_config, migrated_room_name_map):
                                with open(migrated_config_path, "w", encoding="utf-8") as f:
                                    json.dump(migrated_config, f, indent=4, ensure_ascii=False)
                                print(f"[Migration] Normalized migrated room references: {migrated_room_name_map}")
                        except Exception as e:
                            print(f"[Migration] Warning: failed to normalize config room references: {e}")

                    # --- 3. オリヴェの特例アップグレード（アセットマージ） ---
                    yield gr.update(visible=True, value="【ステップ 3/3】 標準ペルソナ（Olivie）のアセットを統合しています..."), gr.update(visible=True)
                    # サンプルペルソナから最新のアセット（仕様書、RAG、画像、設定）を注入する
                    sample_olivie_path = dest_path / "assets" / "sample_persona" / "Olivie"
                    target_olivie_path = dest_chars / "Olivie"

                    # オリヴェが存在し、かつサンプルアセットがある場合のみ実行
                    if target_olivie_path.exists() and sample_olivie_path.exists():
                        print("[Migration] Upgrading Olivie with latest assets...")

                        # A. RAGデータの置換 (強制上書き)
                        target_rag = target_olivie_path / "rag_data"
                        source_rag = sample_olivie_path / "rag_data"
                        if source_rag.exists():
                            if target_rag.exists():
                                try:
                                    # [Windows] 削除ではなくリネーム退避を優先
                                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                                    retired_rag_dir = dest_path / "backups" / "migration_retired" / "rag_data"
                                    retired_rag_dir.mkdir(parents=True, exist_ok=True)
                                    retired_path = retired_rag_dir / f"Olivie_rag_{timestamp}"

                                    # まずリネーム
                                    shutil.move(str(target_rag), str(retired_path))
                                    print(f"  - Retired existing RAG data to {retired_path}")
                                except Exception as e:
                                    print(f"  - Rename/Move failed ({e}). Falling back to rmtree.")
                                    shutil.rmtree(str(target_rag), onexc=handle_remove_readonly)

                            shutil.copytree(str(source_rag), str(target_rag))
                            print("  - Replaced RAG data")

                        # B. 知識ファイル(Specification)の置換
                        target_know = target_olivie_path / "knowledge"
                        source_know = sample_olivie_path / "knowledge"
                        if source_know.exists():
                            if not target_know.exists(): target_know.mkdir(parents=True)
                            for f in source_know.glob("*.md"):
                                shutil.copy2(f, target_know / f.name)
                            print("  - Updated knowledge specifications")

                        # C. 情景画像の追加 (存在しないもののみ追加)
                        target_imgs = target_olivie_path / "spaces" / "images"
                        source_imgs = sample_olivie_path / "spaces" / "images"
                        if source_imgs.exists():
                            if not target_imgs.exists(): target_imgs.mkdir(parents=True)
                            for img in source_imgs.iterdir():
                                if not (target_imgs / img.name).exists():
                                    shutil.copy2(img, target_imgs / img.name)
                            print("  - Added new scenery images")

                        # D. テーマ設定のマージ
                        try:
                            t_conf_path = target_olivie_path / "room_config.json"
                            s_conf_path = sample_olivie_path / "room_config.json"
                            if t_conf_path.exists() and s_conf_path.exists():
                                with open(t_conf_path, "r", encoding="utf-8") as f: t_data = json.load(f)
                                with open(s_conf_path, "r", encoding="utf-8") as f: s_data = json.load(f)

                                # テーマ関連設定を強制上書き
                                if "override_settings" not in t_data: t_data["override_settings"] = {}
                                s_overrides = s_data.get("override_settings", {})

                                keys_to_merge = ["room_theme_enabled", "theme_ui_opacity", "voice_id", "voice_style_prompt"]
                                # theme_ で始まるキーも全て対象
                                keys_to_merge.extend([k for k in s_overrides.keys() if k.startswith("theme_")])

                                for k in keys_to_merge:
                                    if k in s_overrides:
                                        t_data["override_settings"][k] = s_overrides[k]

                                with open(t_conf_path, "w", encoding="utf-8") as f:
                                    json.dump(t_data, f, indent=4, ensure_ascii=False)
                                print("  - Merged room configuration (theme settings)")
                        except Exception as e:
                            print(f"  - Warning: Failed to merge room_config: {e}")

                    yield gr.update(visible=True, value="【完了処理】設定を反映しています..."), gr.update(visible=True)
                    # Mark as complete
                    onboarding_manager.mark_setup_completed()

                    # グローバル設定を再読み込み
                    config_manager.load_config()

                    # 成功メッセージを表示（__SUCCESS__マーカーでJSがリロードをトリガー）
                    gr.Info("✅ データ移行が完了しました！自動でリロードします...")
                    yield gr.update(visible=True, value="__SUCCESS__ 移行完了！リロード中..."), gr.update(visible=True)
                except Exception as e:
                    import traceback
                    error_details = traceback.format_exc()
                    print(f"[Migration Error] {error_details}")
                    yield gr.update(visible=True, value=f"移行に失敗しました: {e}\n\n詳細:\n{error_details[:500]}"), gr.update(visible=True)

            onboarding_finish_btn.click(
                fn=finish_onboarding,
                inputs=[onboarding_key_name, onboarding_api_key],
                outputs=[onboarding_error_msg, onboarding_group]
            ).then(
                fn=None,
                inputs=None,
                outputs=None,
                js="() => { setTimeout(() => { window.location.reload(); }, 500); }"
            )

            onboarding_migrate_exec_btn.click(
                fn=execute_migration,
                inputs=[onboarding_migrate_path],
                outputs=[onboarding_migrate_status, onboarding_group]
            ).then(
                fn=None,
                inputs=None,
                outputs=None,
                # ステータス欄のテキストに__SUCCESS__が含まれていたらリロード
                js="""() => {
                    setTimeout(() => {
                        const statusElements = document.querySelectorAll('#onboarding_overlay textarea, #onboarding_overlay input');
                        for (const el of statusElements) {
                            if (el.value && el.value.includes('__SUCCESS__')) {
                                window.location.reload();
                                return;
                            }
                        }
                        // フォールバック: オーバーレイが隠れているかチェック
                        const overlay = document.getElementById('onboarding_overlay');
                        if (overlay && !overlay.offsetParent) {
                            window.location.reload();
                        }
                    }, 500);
                }"""
            )

        # --- [Document Viewer Modal] ---
        with gr.Group(visible=False, elem_id="doc_viewer_overlay") as doc_viewer_overlay:
            with gr.Column(elem_id="doc_viewer_content"):
                with gr.Row():
                    gr.Markdown("## 📖 ドキュメントビューアー")
                    close_doc_btn = gr.Button("✕ 閉じる", variant="secondary", size="sm", min_width=80)

                with gr.Column(elem_id="doc_viewer_scroll_area"):
                    doc_viewer_display = gr.Markdown(value="読み込み中...")

        room_list_on_startup = room_manager.get_room_list_for_ui()
        if not room_list_on_startup:
            print("--- 有効なルームが見つからないため、'Default'ルームを作成します。 ---")
            room_manager.ensure_room_files("Default")
            room_list_on_startup = room_manager.get_room_list_for_ui()

        folder_names_on_startup = [folder for _display, folder in room_list_on_startup]
        effective_initial_room = config_manager.initial_room_global

        if not effective_initial_room or effective_initial_room not in folder_names_on_startup:
            new_room_folder = folder_names_on_startup[0] if folder_names_on_startup else "Default"
            print(f"警告: 最後に使用したルーム '{effective_initial_room}' が見つからないか無効です。'{new_room_folder}' で起動します。")
            effective_initial_room = new_room_folder
            config_manager.save_config_if_changed("last_room", new_room_folder)
            if new_room_folder == "Default" and "Default" not in folder_names_on_startup:
                room_manager.ensure_room_files("Default")
                room_list_on_startup = room_manager.get_room_list_for_ui()

        # --- Stateの定義 ---
        world_data_state = gr.State({})
        current_room_name = gr.State(effective_initial_room)
        current_model_name = gr.State(config_manager.initial_model_global)
        current_api_key_name_state = gr.State(config_manager.initial_api_key_name_global)
        api_history_limit_state = gr.State(config_manager.initial_api_history_limit_option_global)

        # --- style_injector: 常に表示される場所に配置し、起動時からCSSが適用されるようにする ---
        # visible=TrueかつCSSで非表示にすることで、GradioがDOMを更新する
        try:
            initial_room_style_css = ui_handlers._generate_style_from_settings(
                effective_initial_room,
                config_manager.get_effective_settings(effective_initial_room)
            )
        except Exception as style_init_error:
            print(f"--- [Style Warning] 初期CSSの生成に失敗しました: {style_init_error} ---")
            initial_room_style_css = "<style>#style_injector_component { display: none !important; }</style>"
        style_injector = gr.HTML(value=initial_room_style_css, visible=True, elem_id="style_injector_component")
        initial_alarm_df_with_ids = ui_handlers.render_alarms_as_dataframe()
        alarm_dataframe_original_data = gr.State(initial_alarm_df_with_ids)
        selected_alarm_ids_state = gr.State([])
        editing_alarm_id_state = gr.State(None)
        selected_message_state = gr.State(None)
        message_delete_confirmed_state = gr.Textbox(visible=False) # delete_confirmed_state から改名
        current_log_map_state = gr.State([])
        room_delete_confirmed_state = gr.Textbox(visible=False) # ルーム削除専用
        active_participants_state = gr.State([]) # 現在アクティブなグループ会話の参加者リスト
        debug_console_state = gr.State("")
        chatgpt_thread_choices_state = gr.State([]) # ChatGPTインポート用のスレッド選択肢を保持
        claude_thread_choices_state = gr.State([]) # Claudeインポート用のスレッド選択肢を保持
        redaction_rules_state = gr.State(config_manager.load_redaction_rules())
        selected_redaction_rule_state = gr.State(None) # 編集中のルールのインデックスを保持
        active_attachments_state = gr.State([]) # アクティブな添付ファイルパスのリストを保持
        translation_cache_state = gr.State({}) # 翻訳キャッシュ (Key: absolute_index, Value: translated_text)
        show_translation_state = gr.State(False) # 現在翻訳を表示するかどうかのトグル
        selected_message_index_state = gr.State(None) # 選択されたメッセージの絶対インデックス
        selected_attachment_index_state = gr.State(None) # Dataframeで選択された行のインデックスを保持
        redaction_rule_color_state = gr.State("#62827e")
        user_common_closet_scope_state = gr.State("common")
        user_common_closet_room_state = gr.State("")
        user_room_closet_scope_state = gr.State("room")
        user_appearance_target_state = gr.State("user")
        persona_appearance_target_state = gr.State("persona")
        imported_theme_params_state = gr.State({}) # インポートされたテーマの詳細設定を一時保持
        last_sent_scenery_image_state = gr.State(None)  # 情景画像のAI送信用：最後に送信した画像パスを記憶
        is_switching_room = gr.State(False) # ルーム切り替え中フラグ
        # --- グローバル・左サイドバー (設定) ---
        with gr.Sidebar(label="設定", width=320, open=True, elem_id="left_sidebar"):
            with gr.Column(elem_classes=["sidebar-container"]):
                # [Fix] 初期化時にchoicesとvalueを設定してエラーを防ぐ
                room_dropdown = gr.Dropdown(
                    label="ルームを選択",
                    choices=room_list_on_startup,
                    value=effective_initial_room,
                    interactive=True, allow_custom_value=True)

                with gr.Accordion("⚙️ 設定", open=False):
                    with gr.Tabs() as settings_tabs:
                        with gr.TabItem("共通") as common_settings_tab:
                            common_settings_status = gr.Markdown("共通設定: 最新状態を読み込み済み", elem_classes=["settings-save-status"])
                            refresh_common_settings_button = gr.Button(
                                "🔄 共通設定を最新の状態に更新",
                                variant="secondary",
                                size="sm",
                            )
                            gr.Markdown(
                                "<small>PC・スマホなど別のブラウザで変更した共通設定を、設定ファイルから再取得します。</small>"
                            )
                            with gr.Accordion("🔑 APIキー / Webhook管理", open=False):
                                gr.Markdown("<small>💾 APIキーとWebhookは各保存ボタンで保存します。有料キーの指定は変更時に自動保存されます。</small>")
                                with gr.Accordion("Gemini（AI Studio）", open=False):
                                    gemini_key_name_input = gr.Textbox(label="キーの名前（管理用の半角英数字）", placeholder="例: my_personal_key")
                                    gemini_key_value_input = gr.Textbox(label="APIキーの値", type="password")
                                    with gr.Row():
                                        save_gemini_key_button = gr.Button("新しいキーを追加", variant="primary")
                                    gr.Markdown("---")
                                    gemini_delete_key_dropdown = gr.Dropdown(
                                        label="削除するキーを選択",
                                        choices=config_manager.get_api_key_choices_for_ui(),
                                        interactive=True
                                    )
                                    delete_gemini_key_button = gr.Button("選択したキーを削除", variant="secondary")
                                    gr.Markdown("---")
                                    gr.Markdown("#### 登録済みAPIキーリスト\nチェックを入れたキーが、有料プラン（Pay-as-you-go）として扱われます。")
                                    paid_keys_checkbox_group = gr.CheckboxGroup(
                                        label="有料プランのキーを選択",
                                        choices=[pair[1] for pair in config_manager.get_api_key_choices_for_ui()],
                                        value=config_manager.CONFIG_GLOBAL.get("paid_api_key_names", []),
                                        interactive=True
                                    )
                                from gemini_connection_ui import build_vertex_key_management_panel
                                vertex_key_management_panel = build_vertex_key_management_panel()

                                # [新規追加] OpenAI 公式
                                with gr.Accordion("OpenAI 公式 APIキー", open=False) as openai_official_api_key_group:
                                    gr.Markdown("💡 **OpenAI APIキー**: [platform.openai.com](https://platform.openai.com/api-keys) で取得してください。\n\n※保存すると「OpenAI」プロファイルとして登録・更新されます。")
                                    # 初期値取得 (OpenAIプロファイルがあればそのキーを表示。過去互換のため OpenAI Official も探す)
                                    _openai_profile = config_manager.get_openai_setting_by_name("OpenAI") or config_manager.get_openai_setting_by_name("OpenAI Official")
                                    _openai_key = _openai_profile.get("api_key", "") if _openai_profile else ""

                                    openai_official_api_key_input = gr.Textbox(
                                        label="OpenAI APIキー",
                                        type="password",
                                        placeholder="sk-proj-...",
                                        value=_openai_key,
                                        interactive=True
                                    )
                                    save_openai_official_key_button = gr.Button("OpenAI APIキーを保存", variant="primary", size="sm")

                                # Anthropic (Claude) [Phase 4]
                                with gr.Accordion("Anthropic (Claude)", open=False) as anthropic_api_key_group:
                                    gr.Markdown("💡 **Anthropic APIキー**: [console.anthropic.com](https://console.anthropic.com/) でAPIキーを取得してください。")
                                    anthropic_api_key_input_simple = gr.Textbox(
                                        label="Anthropic APIキー",
                                        type="password",
                                        placeholder="sk-ant-...",
                                        value=config_manager.ANTHROPIC_API_KEY or "",
                                        interactive=True
                                    )
                                    save_anthropic_key_button = gr.Button("Anthropic APIキーを保存", variant="primary", size="sm")

                                # Zhipu AI [Phase 3]
                                with gr.Accordion("Zhipu AI", open=False) as zhipu_api_key_group:
                                    gr.Markdown("💡 **Zhipu AI APIキー**: `https://open.bigmodel.cn/usercenter/apikeys` でAPIキーを取得してください（登録で500万トークン無料）。")
                                    zhipu_api_key_input = gr.Textbox(
                                        label="Zhipu APIキー",
                                        type="password",
                                        placeholder="[API_KEY_ID].[API_KEY_SECRET]",
                                        value=config_manager.ZHIPU_API_KEY or "",
                                        interactive=True
                                    )
                                    save_zhipu_key_button = gr.Button("Zhipu APIキーを保存", variant="primary", size="sm")

                                # Groq [Phase 3b]
                                with gr.Accordion("Groq", open=False) as groq_api_key_group:
                                    gr.Markdown("💡 **Groq APIキー**: console.groq.com/keys でAPIキーを取得してください（無料枠あり・毎日リセット）。")
                                    groq_api_key_input = gr.Textbox(
                                        label="Groq APIキー",
                                        type="password",
                                        placeholder="gsk_...",
                                        value=config_manager.GROQ_API_KEY or "",
                                        interactive=True
                                    )
                                    save_groq_key_button = gr.Button("Groq APIキーを保存", variant="primary", size="sm")

                                # Moonshot AI (Kimi) [Phase 3d]
                                with gr.Accordion("Moonshot AI (Kimi)", open=False) as moonshot_api_key_group:
                                    gr.Markdown("💡 **Moonshot APIキー**: `https://platform.moonshot.cn` で取得")
                                    moonshot_api_key_input = gr.Textbox(
                                        label="Moonshot APIキー",
                                        type="password",
                                        placeholder="sk-...",
                                        value=config_manager.MOONSHOT_API_KEY or "",
                                        interactive=True
                                    )
                                    save_moonshot_key_button = gr.Button("Moonshot APIキーを保存", variant="primary", size="sm")


                                # [Phase 4] Nvidia NIM
                                with gr.Accordion("Nvidia NIM", open=False) as nim_api_key_group:
                                    gr.Markdown("💡 **Nvidia NIM APIキー**: [build.nvidia.com](https://build.nvidia.com/) でAPIキーを取得してください。\n\n※保存すると自動的にOpenAI互換プロファイルとして登録されます。")
                                    nim_api_key_input = gr.Textbox(
                                        label="Nvidia NIM APIキー",
                                        type="password",
                                        placeholder="nvapi-...",
                                        value=config_manager.NIM_API_KEY or "",
                                        interactive=True
                                    )
                                    save_nim_key_button = gr.Button("Nvidia NIM APIキーを保存", variant="primary", size="sm")

                                # [Phase 4] X.ai (Grok)
                                with gr.Accordion("X.ai (Grok)", open=False) as xai_api_key_group:
                                    gr.Markdown("💡 **X.ai APIキー**: [console.x.ai](https://console.x.ai/) でAPIキーを取得してください。\n\n※保存すると自動的にOpenAI互換プロファイルとして登録されます。")
                                    xai_api_key_input = gr.Textbox(
                                        label="X.ai APIキー",
                                        type="password",
                                        placeholder="xai-...",
                                        value=config_manager.XAI_API_KEY or "",
                                        interactive=True
                                    )
                                    save_xai_key_button = gr.Button("X.ai APIキーを保存", variant="primary", size="sm")

                                # ElevenLabs (TTS)
                                with gr.Accordion("ElevenLabs (TTS)", open=False) as elevenlabs_api_key_group:
                                    gr.Markdown("💡 **ElevenLabs APIキー**: [elevenlabs.io/app/settings/api-keys](https://elevenlabs.io/app/settings/api-keys) でAPIキーを取得してください。\n\n※音声設定でTTSプロバイダにElevenLabsを選んだ場合に使用されます。")
                                    elevenlabs_api_key_input = gr.Textbox(
                                        label="ElevenLabs APIキー",
                                        type="password",
                                        placeholder="sk_...",
                                        value=config_manager.CONFIG_GLOBAL.get("elevenlabs_api_key", ""),
                                        interactive=True
                                    )
                                    save_elevenlabs_key_button = gr.Button("ElevenLabs APIキーを保存", variant="primary", size="sm")

                                # Hugging Face
                                with gr.Accordion("Hugging Face", open=False):
                                    gr.Markdown("💡 **Hugging Face APIキー**: [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens) で取得してください。\n\n※設定すると、画像生成とテキスト生成の両方で共通して利用できるようになります。\n※下のボタンから、テキスト生成用のカスタムOpenAI互換プロバイダーとして追加できます。")
                                    huggingface_api_token_input_main = gr.Textbox(
                                        label="Hugging Face APIキー",
                                        type="password",
                                        placeholder="hf_...",
                                        value=config_manager.CONFIG_GLOBAL.get("image_generation_settings", {}).get("huggingface_api_token", ""),
                                        interactive=True
                                    )
                                    with gr.Row():
                                        save_huggingface_key_button_main = gr.Button("Hugging Face APIキーを保存", variant="primary", size="sm")
                                        add_hf_preset_button = gr.Button("🗂️ テキスト生成用プリセットを追加", variant="secondary", size="sm")

                                # Pollinations.ai
                                with gr.Accordion("Pollinations.ai", open=False):
                                    gr.Markdown("💡 **Pollinations.ai**: 最新モデル（qwen-coder 等）の利用には [enter.pollinations.ai](https://enter.pollinations.ai) で無料取得できるAPIキーの入力が必要です。\n\n※取得したキーは下記の入力欄に保存してください。\n※下のボタンから、テキスト生成用のカスタムOpenAI互換プロバイダーとして追加できます。")
                                    pollinations_api_key_input_main = gr.Textbox(
                                        label="Pollinations APIキー",
                                        type="password",
                                        placeholder="キーをお持ちの場合に入力してください",
                                        value=config_manager.CONFIG_GLOBAL.get("image_generation_settings", {}).get("pollinations_api_key", ""),
                                        interactive=True
                                    )
                                    with gr.Row():
                                        save_pollinations_key_button_main = gr.Button("Pollinations APIキーを保存", variant="primary", size="sm")
                                        add_pollinations_preset_button = gr.Button("🐝 テキスト生成用プリセットを追加", variant="secondary", size="sm")

                                # [Phase 4] カスタムOpenAI互換プロバイダの追加
                                with gr.Accordion("🔌 カスタムOpenAI互換プロバイダーの追加", open=False):
                                    gr.Markdown("💡 VLLM, LM Studio, またはその他のOpenAI互換APIを提供するサーバーを登録します。")
                                    custom_openai_name_input = gr.Textbox(label="プロパティ名 (例: LM Studio, My Server)", placeholder="My Local Server")
                                    custom_openai_url_input = gr.Textbox(label="Base URL", placeholder="http://localhost:1234/v1")
                                    custom_openai_key_input = gr.Textbox(label="APIキー (不要な場合は空欄)", type="password", placeholder="sk-...")
                                    add_custom_openai_button = gr.Button("このプロバイダーを追加・保存", variant="primary", size="sm")

                                # Webhook管理
                                with gr.Accordion("Pushover", open=False):
                                    pushover_user_key_input = gr.Textbox(label="Pushover User Key", type="password", value=config_manager.CONFIG_GLOBAL.get("pushover_user_key", ""), interactive=True)
                                    pushover_app_token_input = gr.Textbox(label="Pushover App Token/Key", type="password", value=config_manager.CONFIG_GLOBAL.get("pushover_app_token", ""), interactive=True)
                                    save_pushover_config_button = gr.Button("Pushover設定を保存", variant="primary")
                                with gr.Accordion("Discord", open=False):
                                    discord_webhook_input = gr.Textbox(label="Discord Webhook URL", type="password", value=config_manager.CONFIG_GLOBAL.get("notification_webhook_url", ""), interactive=True)
                                    save_discord_webhook_button = gr.Button("Discord Webhookを保存", variant="primary")

                                # ローカルLLM (Ollama)
                                with gr.Accordion("💻 ローカルLLM (Ollama / GGUF)", open=False) as local_llm_group:
                                    open_local_llm_guide_btn = gr.Button("📖 導入ガイドを表示", variant="secondary", size="sm")
                                    gr.Markdown(
                                        "💡 **ローカルLLM**: ローカルでモデルを動かす場合は **Ollama** または **直接GGUFロード** が利用可能です。\n"
                                        "1. Ollamaを使う場合: <a href='https://ollama.com/' target='_blank' style='color: #4da6ff; text-decoration: underline;'>公式サイト</a> からインストールし、接続設定を追加します。\n"
                                        "2. GGUFを直接使う場合: 下記のパス指定欄にモデルファイルのパスを入力して保存してください。"
                                    )
                                    add_ollama_profile_button = gr.Button("Ollama用の接続設定を追加", variant="primary", size="sm")
                                    gr.Markdown("---", elem_classes=["separator"])
                                    gr.Markdown(
                                        "🚀 **直接GGUFモデルをロードする場合 (VRAM 4GB以下推奨)**:"
                                    )
                                    local_model_path_input = gr.Textbox(
                                        label="GGUFモデルパス",
                                        placeholder="/path/to/model.gguf",
                                        value=config_manager.LOCAL_MODEL_PATH or "",
                                        info="ローカルに保存したGGUFモデルファイルの絶対パス",
                                        interactive=True
                                    )
                                    save_local_model_path_button = gr.Button("モデルパスを保存", variant="primary", size="sm")

                                # Tavily (Web Search) [Phase 3]
                                with gr.Accordion("Tavily (Web検索)", open=False) as tavily_api_key_group:
                                    gr.Markdown("💡 **Tavily APIキー**: [tavily.com](https://tavily.com) で無料アカウントを作成してAPIキーを取得してください（月1000クレジット無料）。")
                                    tavily_api_key_input = gr.Textbox(
                                        label="Tavily APIキー",
                                        type="password",
                                        placeholder="tvly-...",
                                        value=config_manager.TAVILY_API_KEY or "",
                                        interactive=True
                                    )
                                    save_tavily_key_button = gr.Button("Tavily APIキーを保存", variant="primary", size="sm")



                                gr.Markdown("⚠️ **注意:** APIキーやWebhook URLはPC上の `config.json` ファイルに平文で保存されます。取り扱いには十分ご注意ください。")

                            with gr.Accordion("📊 API使用量の概算", open=False):
                                gr.Markdown("<small>ℹ️ 表示専用です。読み込んでも設定は変更されません。</small>")
                                usage_summary_markdown = gr.Markdown(
                                    '<span class="usage-summary-compact">「🔄 最新の状態に更新」で概算を表示します。</span>'
                                )
                                open_usage_detail_button = gr.Button("📊 詳細をポップアップで表示", variant="primary", size="sm")
                                refresh_usage_summary_button = gr.Button("🔄 最新の状態に更新", variant="secondary", size="sm")

                            with gr.Accordion("⚡ AIモデルプロバイダ設定（デフォルト）", open=False) as common_provider_accordion:
                                gr.Markdown("<small>💾 Google設定は変更時に自動保存されます。OpenAI互換・Anthropic・Claudeサブスク・ローカル設定は各保存ボタンを押してください。</small>")
                                gr.Markdown("会話に使用するAIモデルのプロバイダを切り替えます。")

                                from ui_handlers import provider_connections as provider_connection_handlers
                                current_provider = provider_connection_handlers.service.provider_choice()

                                provider_radio = gr.Radio(
                                    choices=provider_connection_handlers.PROVIDER_CHOICES,
                                    value=current_provider,
                                    label="共通の接続先",
                                    elem_id="global_provider_connection",
                                    interactive=True
                                )

                                from gemini_connection_ui import build_gemini_connection_panel

                                # --- Google設定エリア ---
                                with gr.Group(visible=(current_provider in {"google", "vertex"})) as google_settings_group:
                                    gr.Markdown(
                                        "内部処理のGeminiも共通の接続先を使います。ルームの応答は「個別」で変更できます。"
                                    )
                                    model_dropdown = gr.Dropdown(
                                        choices=config_manager.AVAILABLE_MODELS_GLOBAL,
                                        value=config_manager.get_current_global_model(),
                                        label="デフォルトAIモデル",
                                        interactive=True,
                                        allow_custom_value=True
                                    )
                                    thinking_level_dropdown = gr.Dropdown(
                                        choices=list(constants.THINKING_LEVEL_OPTIONS.values()),
                                        value=constants.THINKING_LEVEL_OPTIONS.get(
                                            config_manager.CONFIG_GLOBAL.get("thinking_level", constants.DEFAULT_THINKING_LEVEL),
                                            constants.THINKING_LEVEL_OPTIONS[constants.DEFAULT_THINKING_LEVEL]
                                        ),
                                        label="Thinking レベル (Gemini 3系)",
                                        visible=False,  # 互換値は保持し、操作は統一推論パネルへ集約。
                                        info="思考モデルの予算を指定します。高いほど深い推論が可能ですが、待ち時間や不安定化のリスクも増えます。",
                                        interactive=True,
                                        allow_custom_value=True
                                    )
                                    with gr.Row():
                                        fetch_gemini_models_button = gr.Button("📥 モデルリスト取得", variant="secondary", size="sm")
                                    with gr.Group(elem_id="global_ai_studio_settings",
                                                  elem_classes=[] if current_provider == "google" else ["gemini-connection-hidden"]) as global_ai_studio_settings:
                                        api_key_dropdown = gr.Dropdown(
                                            label="使用するGemini APIキー（Developer API）",
                                            elem_id="global_ai_studio_key",
                                            choices=config_manager.get_api_key_choices_for_ui(),
                                            value=config_manager.CONFIG_GLOBAL.get("last_api_key_name"),
                                            interactive=True, allow_custom_value=True)
                                        api_test_button = gr.Button("API接続をテスト", variant="secondary")
                                        # [Phase 1.5] ローテーション設定
                                        settings_rotation_checkbox = gr.Checkbox(
                                            label="APIキー自動ローテーションを有効にする",
                                            value=config_manager.CONFIG_GLOBAL.get("enable_api_key_rotation", True),
                                            interactive=True,
                                            info="Developer APIでレート制限 (429) が発生した場合、他の有効なキーに切り替えます。"
                                        )

                                    global_gemini_connection_panel = build_gemini_connection_panel()

                                # --- OpenAI互換設定エリア ---
                                with gr.Group(visible=(current_provider == "openai")) as openai_settings_group:
                                    gr.Markdown("OpenAI・OpenRouter・Groqなどの接続プロファイルを選びます。",
                                                elem_id="global_openai_provider_hint")
                                    openai_profiles = [s["name"] for s in config_manager.get_openai_settings_list()]
                                    current_openai_profile = config_manager.get_active_openai_profile_name()
                                    _current_openai_setting = config_manager.get_active_openai_setting() or {}

                                    openai_profile_dropdown = gr.Dropdown(
                                        choices=openai_profiles,
                                        value=current_openai_profile,
                                        label="プロファイル選択",
                                        interactive=True,
                                        allow_custom_value=True # 新規追加されたプロファイルを許容
                                    )

                                    # --- 詳細パラメータパネル ---
                                    with gr.Accordion("⚙️ 詳細パラメータ設定", open=False):
                                        gr.Markdown("💡 Temperatureなどの生成パラメータをプロファイルごとに保存します。")

                                        with gr.Row():
                                            openai_temperature_slider = gr.Slider(
                                                minimum=0.0, maximum=2.0, step=0.1,
                                                value=_current_openai_setting.get("temperature", 1.0), label="Temperature (生成温度)",
                                                info="高いほど創造的、低いほど決定論的な回答になります。"
                                            )
                                            openai_top_p_slider = gr.Slider(
                                                minimum=0.0, maximum=1.0, step=0.05,
                                                value=_current_openai_setting.get("top_p", 1.0), label="Top P",
                                                info="出力候補の多様性を制御します。"
                                            )
                                        with gr.Row():
                                            openai_max_tokens_input = gr.Number(
                                                label="Max Tokens",
                                                value=_current_openai_setting.get("max_tokens"),
                                                info="最大生成トークン数（空欄で制限なし / モデルのデフォルト）"
                                            )

                                    with gr.Row():
                                        openai_base_url_input = gr.Textbox(label="Base URL", value=_current_openai_setting.get("base_url", ""), placeholder="例: https://openrouter.ai/api/v1")
                                        openai_api_key_input = gr.Textbox(label="API Key", value=_current_openai_setting.get("api_key", ""), type="password", placeholder="sk-...")

                                    # モデル選択をDropdownに変更
                                    # 現在のプロファイルからモデルリストを取得
                                    _current_models = _current_openai_setting.get("available_models", [])
                                    _current_default_model = _current_openai_setting.get("default_model", "")

                                    openai_model_dropdown = gr.Dropdown(
                                        choices=_current_models,
                                        value=_current_default_model,
                                        label="デフォルトモデル",
                                        interactive=True,
                                        allow_custom_value=True,  # カスタム値の直接入力も許可
                                        info="リストから選択するか、新しいモデル名を直接入力できます"
                                    )

                                    with gr.Row():
                                        fetch_models_button = gr.Button("📥 モデルリスト取得", variant="secondary", size="sm")
                                        _is_or_initial = "openrouter.ai" in _current_openai_setting.get("base_url", "").lower()
                                        openai_free_only_checkbox = gr.Checkbox(label="無料枠のみ (OpenRouter等)", value=False, visible=_is_or_initial, interactive=True)
                                        toggle_favorite_button = gr.Button("⭐ お気に入りに追加/削除", variant="secondary", size="sm")
                                    gr.Markdown("⚠️ すべてのモデルがNexus Arkで動作するわけではありません。", elem_id="common_openai_model_warning")

                                    # 【ツール不使用モード】ツール使用チェックボックス
                                    _tool_use_enabled = _current_openai_setting.get("tool_use_enabled", True)
                                    openai_tool_use_checkbox = gr.Checkbox(
                                        label="ツール使用（Function Calling）を有効にする",
                                        value=_tool_use_enabled,
                                        interactive=True,
                                        info="OFFにすると、AIはWeb検索・画像生成・記憶編集などのツールを使用できなくなりますが、ツール非対応モデルでも会話できるようになります。"
                                    )

                                    save_openai_config_button = gr.Button("このプロファイル設定を保存", variant="primary")

                                # --- Anthropic設定エリア ---
                                with gr.Group(visible=(current_provider == "anthropic")) as anthropic_settings_group:
                                    gr.Markdown("#### 🎭 Anthropic (Claude) 設定")
                                    anthropic_api_key_input = gr.Textbox(
                                        label="Anthropic API Key",
                                        type="password",
                                        placeholder="sk-ant-...",
                                        value=config_manager.ANTHROPIC_API_KEY
                                    )
                                    anthropic_model_dropdown = gr.Dropdown(
                                        choices=["claude-3-7-sonnet-20250219", "claude-3-5-sonnet-20241022", "claude-3-5-haiku-20241022", "claude-3-opus-20240229"],
                                        value=config_manager.CONFIG_GLOBAL.get("anthropic_default_model", "claude-3-7-sonnet-20250219"),
                                        label="デフォルトモデル",
                                        interactive=True,
                                        allow_custom_value=True
                                    )
                                    fetch_anthropic_models_button = gr.Button("📥 最新モデルを取得", variant="secondary", size="sm")
                                    save_anthropic_config_button = gr.Button("Anthropic設定を保存", variant="primary")

                                # --- Claude サブスクリプション設定エリア ---
                                with gr.Group(visible=False) as claude_subscription_settings_group:
                                    gr.Markdown("#### Claude サブスクリプション (Pro/Max) 設定")
                                    gr.Markdown(
                                        "`claude setup-token` で生成した OAuth token を貼り付けます。空欄の場合は、このPCの Claude Code ログイン情報を使用します。"
                                    )
                                    claude_subscription_oauth_token_input = gr.Textbox(
                                        label="Claude Code OAuth Token",
                                        type="password",
                                        placeholder="sk-ant-oat01-...",
                                        value=config_manager.CONFIG_GLOBAL.get("claude_subscription_oauth_token", ""),
                                        interactive=True
                                    )
                                    claude_subscription_model_dropdown = gr.Dropdown(
                                        choices=["sonnet", "opus", "claude-sonnet-4-6", "claude-opus-4-6"],
                                        value=config_manager.CONFIG_GLOBAL.get("claude_subscription_default_model", "sonnet"),
                                        label="デフォルトモデル",
                                        interactive=True,
                                        allow_custom_value=True
                                    )
                                    with gr.Row():
                                        fetch_claude_subscription_models_button = gr.Button("📥 モデルリスト取得", variant="secondary", size="sm")
                                        save_claude_subscription_config_button = gr.Button("Claudeサブスク設定を保存", variant="primary")
                                        test_claude_subscription_button = gr.Button("接続テスト", variant="secondary")
                                    claude_subscription_status = gr.Markdown("Claudeサブスクリプション: 未テスト")

                                # --- ローカル (GGUF) 設定エリア ---
                                with gr.Group(visible=(current_provider == "local")) as common_local_settings_group:
                                    gr.Markdown("#### 💻 ローカル (GGUF直接ロード) 設定")
                                    gr.Markdown(
                                        "llama.cpp を使用して、PC上のGGUFファイルを直接読み込みます。\n"
                                        "※ この機能を使用するには、適切な共有ライブラリがセットアップされている必要があります。"
                                     )
                                    common_local_model_path_input = gr.Textbox(
                                        label="GGUFモデルファイルのパス",
                                        placeholder="例: models/Llama-3-8B-Instruct-Q4_K_M.gguf",
                                        value=config_manager.LOCAL_MODEL_PATH
                                    )
                                    common_local_n_ctx_input = gr.Number(
                                        label="コンテキスト長 (n_ctx)",
                                        value=config_manager.CONFIG_GLOBAL.get("local_n_ctx", 4096),
                                        precision=0
                                    )
                                    save_common_local_config_button = gr.Button("ローカル設定を保存", variant="primary")

                                from response_reasoning_ui import build_response_reasoning_panel
                                global_reasoning_panel = build_response_reasoning_panel()

                            with gr.Accordion("🔧 内部処理モデル設定", open=False):
                                gr.Markdown("<small>💾 変更後、ブロック末尾の「設定を保存」を押してください。</small>")
                                gr.Markdown(
                                    "要約・RAGクエリ生成・エンベディングなど、バックグラウンド処理に使用するモデルを設定します。\n"
                                    "各タスクごとにプロバイダとモデルを自由に組み合わせできます。"
                                )

                                _internal_settings = config_manager.get_internal_model_settings()
                                print(f"--- [DEBUG] UI構築時の内部モデル設定: {_internal_settings.get('summarization_provider_cat')} ---")
                                _openai_profiles = [s.get("name", "") for s in config_manager.CONFIG_GLOBAL.get("openai_provider_settings", [])]
                                _cat_choices = [
                                    ("Google (Gemini)", "google"),
                                    ("OpenAI (公式)", "openai_official"),
                                    ("OpenAI互換", "openai"),
                                    ("Anthropic (Claude)", "anthropic"),
                                    ("ローカル (GGUF直接ロード)", "local")
                                ]

                                # --- 処理モデル（軽量タスク用） ---
                                gr.Markdown("### 🚀 処理モデル（軽量タスク）")
                                gr.Markdown("RAGクエリ生成、Intent分類、グループ会話の司会などに使用します。", elem_classes=["info-text"])

                                # 初期選択肢の計算用ヘルパー
                                def _get_internal_initial_choices(cat, prof):
                                    if cat == "google":
                                        return config_manager.AVAILABLE_MODELS_GLOBAL
                                    elif cat == "anthropic":
                                        return ["claude-3-7-sonnet-20250219", "claude-3-5-sonnet-20241022", "claude-3-5-haiku-20241022", "claude-3-opus-20240229"]
                                    elif cat == "openai":
                                        _p = config_manager.get_openai_setting_by_name(prof) or {}
                                        return _p.get("available_models", [])
                                    elif cat == "openai_official":
                                        return ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-4", "gpt-3.5-turbo", "o1-preview", "o1-mini", "o3-mini"]
                                    elif cat == "local":
                                        return ["Local GGUF"]
                                    return []

                                with gr.Row():
                                    internal_processing_category = gr.Dropdown(
                                        choices=_cat_choices,
                                        value=_internal_settings.get("processing_provider_cat", "google"),
                                        label="プロバイダ種別",
                                        allow_custom_value=True,
                                        scale=1,
                                        interactive=True
                                    )
                                    internal_processing_profile = gr.Dropdown(
                                        choices=_openai_profiles,
                                        value=_internal_settings.get("processing_openai_profile", _openai_profiles[0] if _openai_profiles else ""),
                                        label="OpenAIプロファイル",
                                        scale=1,
                                        visible=(_internal_settings.get("processing_provider_cat") in ["openai", "openai_official"]),
                                        allow_custom_value=True,
                                        interactive=True
                                    )
                                    with gr.Column(scale=2):
                                        with gr.Row():
                                            internal_processing_model = gr.Dropdown(
                                                choices=_get_internal_initial_choices(
                                                    _internal_settings.get("processing_provider_cat", "google"),
                                                    _internal_settings.get("processing_openai_profile", _openai_profiles[0] if _openai_profiles else "")
                                                ),
                                                value=_internal_settings.get("processing_model", constants.INTERNAL_PROCESSING_MODEL),
                                                label="モデル",
                                                scale=8,
                                                allow_custom_value=True,
                                                interactive=True
                                            )
                                            fetch_processing_models_btn = gr.Button("🔄", scale=1, min_width=40)

                                # --- 要約モデル（文章生成用） ---
                                gr.Markdown("### 📝 要約モデル（文章生成）")
                                gr.Markdown("日次/週次要約、コアメモリ圧縮、ペルソナデータ圧縮などに使用します。", elem_classes=["info-text"])
                                with gr.Row():
                                    internal_summarization_category = gr.Dropdown(
                                        choices=_cat_choices,
                                        value=_internal_settings.get("summarization_provider_cat", "google"),
                                        label="プロバイダ種別",
                                        allow_custom_value=True,
                                        scale=1,
                                        interactive=True
                                    )
                                    internal_summarization_profile = gr.Dropdown(
                                        choices=_openai_profiles,
                                        value=_internal_settings.get("summarization_openai_profile", _openai_profiles[0] if _openai_profiles else ""),
                                        label="OpenAIプロファイル",
                                        scale=1,
                                        visible=(_internal_settings.get("summarization_provider_cat") in ["openai", "openai_official"]),
                                        allow_custom_value=True,
                                        interactive=True
                                    )
                                    with gr.Column(scale=2):
                                        with gr.Row():
                                            internal_summarization_model = gr.Dropdown(
                                                choices=_get_internal_initial_choices(
                                                    _internal_settings.get("summarization_provider_cat", "google"),
                                                    _internal_settings.get("summarization_openai_profile", _openai_profiles[0] if _openai_profiles else "")
                                                ),
                                                value=_internal_settings.get("summarization_model", constants.SUMMARIZATION_MODEL),
                                                label="モデル",
                                                scale=8,
                                                allow_custom_value=True,
                                                interactive=True
                                             )
                                            fetch_summarization_models_btn = gr.Button("🔄", scale=1, min_width=40)

                                # --- 思考ログ翻訳モデル ---
                                gr.Markdown("### 🌐 思考ログ翻訳モデル")
                                gr.Markdown("思考ログ（THOUGHT）を日本語に翻訳する処理のみに使用します。", elem_classes=["info-text"])
                                with gr.Row():
                                    internal_translation_category = gr.Dropdown(
                                        choices=_cat_choices,
                                        value=_internal_settings.get("translation_provider_cat", "google"),
                                        label="プロバイダ種別",
                                        allow_custom_value=True,
                                        scale=1,
                                        interactive=True
                                    )
                                    internal_translation_profile = gr.Dropdown(
                                        choices=_openai_profiles,
                                        value=_internal_settings.get("translation_openai_profile", _openai_profiles[0] if _openai_profiles else ""),
                                        label="OpenAIプロファイル",
                                        scale=1,
                                        visible=(_internal_settings.get("translation_provider_cat") in ["openai", "openai_official"]),
                                        allow_custom_value=True,
                                        interactive=True
                                    )
                                    with gr.Column(scale=2):
                                        with gr.Row():
                                            internal_translation_model = gr.Dropdown(
                                                choices=_get_internal_initial_choices(
                                                    _internal_settings.get("translation_provider_cat", "google"),
                                                    _internal_settings.get("translation_openai_profile", _openai_profiles[0] if _openai_profiles else "")
                                                ),
                                                value=_internal_settings.get("translation_model", constants.INTERNAL_PROCESSING_MODEL),
                                                label="モデル",
                                                scale=8,
                                                allow_custom_value=True,
                                                interactive=True
                                            )
                                            fetch_translation_models_btn = gr.Button("🔄", scale=1, min_width=40)

                                # --- エンベディング（ベクトル化） ---
                                gr.Markdown("### 🧠 エンベディング（ベクトル化）")
                                gr.Markdown("会話ログや知識ベースを、AIが検索しやすい「ベクトルデータ」に変換します。", elem_classes=["info-text"])
                                with gr.Row():
                                    internal_embedding_provider = gr.Dropdown(
                                        choices=[
                                            ("Google (Generative AI API)", "google"),
                                            ("OpenAI (Embedding API)", "openai"),
                                            ("ローカル (PCリソース / Hugging Face)", "local")
                                        ],
                                        value=_internal_settings.get("embedding_provider", "local"),
                                        label="プロバイダ",
                                        allow_custom_value=True,
                                        scale=1,
                                        interactive=True
                                    )
                                    internal_embedding_model = gr.Dropdown(
                                        choices=[
                                            ("multilingual-e5-large (推奨)", "intfloat/multilingual-e5-large"),
                                            ("multilingual-e5-base", "intfloat/multilingual-e5-base"),
                                            ("multilingual-e5-small", "intfloat/multilingual-e5-small"),
                                            ("text-embedding-3-small (OpenAI)", "text-embedding-3-small"),
                                            ("text-embedding-3-large (OpenAI)", "text-embedding-3-large"),
                                            ("gemini-embedding-2 (最新・推奨 / Google)", "gemini-embedding-2"),
                                            ("gemini-embedding-001 (旧推奨・8月廃止予定 / Google)", "gemini-embedding-001")
                                        ],
                                        value=_internal_settings.get("embedding_model", "intfloat/multilingual-e5-large"),
                                        label="モデル",
                                        scale=2,
                                        allow_custom_value=True,
                                        interactive=True
                                    )

                                # --- フォールバック設定 ---
                                gr.Markdown("---")
                                internal_fallback_checkbox = gr.Checkbox(
                                    label="フォールバック有効（プロバイダ障害時にGoogleへ自動切替）",
                                    value=_internal_settings.get("fallback_enabled", True),
                                    info="プライマリプロバイダでエラーが発生した場合、Google (Gemini) にフォールバック",
                                    interactive=True
                                )

                                with gr.Row():
                                    reset_internal_model_button = gr.Button("デフォルトに戻す", variant="secondary", size="sm")
                                    save_internal_model_button = gr.Button("設定を保存", variant="primary", size="sm")

                                internal_model_status = gr.Markdown("", visible=False)

                            with gr.Accordion("🎨 画像生成設定", open=False):
                                gr.Markdown("<small>💾 プロバイダ選択は自動保存されます。モデル・APIキー等は「画像生成設定を保存」を押してください。</small>")
                                # Configから現在の設定を読み込む
                                current_img_provider = config_manager.CONFIG_GLOBAL.get("image_generation_provider", "gemini")
                                current_img_model = config_manager.CONFIG_GLOBAL.get("image_generation_model", "gemini-2.5-flash-image")
                                available_gemini_models = config_manager.CONFIG_GLOBAL.get("available_image_models", {}).get("gemini", ["gemini-2.5-flash-image", "gemini-3-pro-image-preview"])
                                available_openai_models = config_manager.CONFIG_GLOBAL.get("available_image_models", {}).get("openai", ["gpt-image-1", "dall-e-3"])
                                openai_settings = config_manager.CONFIG_GLOBAL.get("image_generation_openai_settings", {})

                                image_gen_provider_radio = gr.Radio(
                                    choices=[
                                        ("Gemini", "gemini"),
                                        ("OpenAI互換", "openai"),
                                        ("Pollinations.ai (無料)", "pollinations"),
                                        ("Hugging Face", "huggingface"),
                                        ("無効", "disabled")
                                    ],
                                    value=current_img_provider,
                                    label="画像生成プロバイダ",
                                    interactive=True,
                                    info="「無効」にすると、AIのプロンプトからも画像生成に関する項目が削除されます。"
                                )

                                # [v1.0] 画像生成用APIキー選択（プロバイダ直下に配置し、カラム外で制御）
                                image_gen_api_key_dropdown = gr.Dropdown(
                                    choices=[("現在の選択キーを使用", "")] + config_manager.get_api_key_choices_for_ui(),
                                    value=config_manager.CONFIG_GLOBAL.get("image_generation_api_key_name", ""),
                                    label="画像生成に使用するAPIキー",
                                    interactive=True,
                                    allow_custom_value=True,
                                    visible=(current_img_provider == "gemini"),
                                    elem_id="image_gen_api_key_selector_v2",
                                    info="画像生成には有料プランのAPIキーが必要です。未指定の場合は現在の選択キーを使用します。"
                                )

                                # Geminiモデル選択
                                with gr.Column(visible=(current_img_provider == "gemini")) as gemini_model_section:
                                    gemini_image_model_dropdown = gr.Dropdown(
                                        choices=available_gemini_models,
                                        value=current_img_model if current_img_model in available_gemini_models else available_gemini_models[0],
                                        label="Gemini画像生成モデル",
                                        interactive=True, allow_custom_value=True)

                                # OpenAI互換設定
                                with gr.Column(visible=(current_img_provider == "openai")) as openai_image_section:
                                    # 既存のOpenAI互換プロファイルから選択
                                    openai_provider_names = config_manager.get_image_openai_profile_names()
                                    openai_image_profile_dropdown = gr.Dropdown(
                                        choices=openai_provider_names,
                                        value=openai_settings.get("profile_name") if openai_settings.get("profile_name") in openai_provider_names else (openai_provider_names[0] if openai_provider_names else None),
                                        label="使用するプロファイル（APIキー/Webhook管理で設定）",
                                        interactive=True,
                                        info="プロファイルのAPIキーとBase URLを使用します", allow_custom_value=True)
                                    openai_image_model_dropdown = gr.Dropdown(
                                        choices=available_openai_models,
                                        value=openai_settings.get("model", "gpt-image-1"),
                                        label="OpenAI画像生成モデル",
                                        interactive=True,
                                        allow_custom_value=True,
                                        info="カスタムモデル名も入力可能（ComfyUI等）"
                                    )

                                # Pollinations.ai 設定
                                available_pollinations_models = config_manager.CONFIG_GLOBAL.get("available_image_models", {}).get("pollinations", ["flux", "zimage", "klein"])
                                with gr.Column(visible=(current_img_provider == "pollinations")) as pollinations_image_section:
                                    gr.Markdown("💡 APIキーは [enter.pollinations.ai](https://enter.pollinations.ai) で無料取得できます。")
                                    pollinations_api_key_input = gr.Textbox(
                                        value=config_manager.CONFIG_GLOBAL.get("pollinations_api_key", ""),
                                        label="Pollinations APIキー (sk_...)",
                                        type="password",
                                        interactive=True,
                                        info="シークレットキー (sk_) を入力してください"
                                    )
                                    pollinations_image_model_dropdown = gr.Dropdown(
                                        choices=available_pollinations_models,
                                        value=config_manager.CONFIG_GLOBAL.get("image_generation_pollinations_model", "flux"),
                                        label="Pollinationsモデル",
                                        interactive=True,
                                        allow_custom_value=True,
                                        info="flux (高品質), zimage (高速), klein (FLUX.2 4B) 等"
                                    )

                                # Hugging Face 設定
                                available_hf_models = config_manager.CONFIG_GLOBAL.get("available_image_models", {}).get("huggingface", ["black-forest-labs/FLUX.1-schnell"])
                                with gr.Column(visible=(current_img_provider == "huggingface")) as huggingface_image_section:
                                    gr.Markdown("💡 トークンは [Hugging Face Settings](https://huggingface.co/settings/tokens) で取得できます（Read権限）。")
                                    huggingface_api_token_input = gr.Textbox(
                                        value=config_manager.CONFIG_GLOBAL.get("huggingface_api_token", ""),
                                        label="Hugging Face APIトークン (hf_...)",
                                        type="password",
                                        interactive=True,
                                        info="Read権限のアクセストークンを入力してください"
                                    )
                                    huggingface_image_model_dropdown = gr.Dropdown(
                                        choices=available_hf_models,
                                        value=config_manager.CONFIG_GLOBAL.get("image_generation_huggingface_model", "black-forest-labs/FLUX.1-schnell"),
                                        label="Hugging Faceモデル",
                                        interactive=True,
                                        allow_custom_value=True,
                                        info="Hub上のtext-to-imageモデルIDを直接入力可能"
                                    )

                                # 一括取得ボタン
                                with gr.Row():
                                    fetch_image_models_button = gr.Button("📥 最新のモデルリストを取得", variant="secondary", size="sm")
                                    save_image_gen_button = gr.Button("画像生成設定を保存", variant="primary", size="sm")

                            with gr.Accordion("🔍 検索プロバイダ設定", open=False):
                                gr.Markdown("<small>✓ 変更は自動保存されます。</small>")
                                current_search_provider = config_manager.CONFIG_GLOBAL.get("search_provider", constants.DEFAULT_SEARCH_PROVIDER)
                                # constants.pyの定数からUI用の選択肢を生成
                                search_provider_choices = [(label, key) for key, label in constants.SEARCH_PROVIDER_OPTIONS.items()]
                                search_provider_radio = gr.Radio(
                                    choices=search_provider_choices,
                                    value=current_search_provider,
                                    label="Web検索プロバイダ (web_search_tool)",
                                    interactive=True,
                                    info="AIがWeb検索を行う際に使用するサービスを選択します。"
                                )

                                current_search_model = config_manager.CONFIG_GLOBAL.get("search_model", constants.SEARCH_MODEL)
                                # 起動時の候補は固定リストと現在値の和集合（取得ボタンで最新化できる）
                                _search_model_choices = list(dict.fromkeys(list(constants.SEARCH_MODEL_OPTIONS) + [current_search_model]))
                                search_model_dropdown = gr.Dropdown(
                                    choices=_search_model_choices,
                                    value=current_search_model,
                                    label="検索モデル（Google〔Gemini Native〕利用時）",
                                    interactive=True,
                                    allow_custom_value=True,
                                    info=(
                                        "プロバイダが Google のときに検索（グラウンディング）へ使うGeminiモデルです。"
                                        "「📥 モデルリスト取得」で最新候補を取得できます（Geminiの基本設定で選んだAPIキーを使用）。"
                                        "プラン・キー・モデルの組み合わせによっては検索に使えない場合があります（無料キーのPro系など）。"
                                        "「🔎 検索テスト」で実際に使えるかを確認してください。廃止・移行時は新しいモデル名を直接入力もできます。"
                                    ),
                                )
                                with gr.Row():
                                    fetch_search_models_button = gr.Button("📥 モデルリスト取得", variant="secondary", size="sm")
                                    test_search_model_button = gr.Button("🔎 検索テスト", variant="secondary", size="sm")

                                # キー入力欄は「APIキー / Webhook管理」に移動しました
                                pass


                            with gr.Accordion("📢 通知サービス設定", open=False):
                                gr.Markdown("<small>✓ 変更は自動保存されます。</small>")
                                legacy_notification_service = config_manager.CONFIG_GLOBAL.get("notification_service", "discord")
                                alarm_notification_service_radio = gr.Radio(
                                    choices=["Discord", "Pushover"],
                                    label="アラームに使用するサービス",
                                    value=config_manager.CONFIG_GLOBAL.get("alarm_notification_service", legacy_notification_service).capitalize(),
                                    interactive=True
                                )
                                user_notification_service_radio = gr.Radio(
                                    choices=["Discord", "Pushover"],
                                    label="通知に使用するサービス",
                                    value=config_manager.CONFIG_GLOBAL.get("user_notification_service", legacy_notification_service).capitalize(),
                                    interactive=True
                                )
                                gr.Markdown("---")

                            with gr.Accordion("💾 バックアップ設定", open=False):
                                gr.Markdown("<small>✓ 変更は自動保存されます。</small>")
                                backup_rotation_count_number = gr.Number(
                                    label="バックアップの最大保存件数（世代数）",
                                    value=config_manager.CONFIG_GLOBAL.get("backup_rotation_count", 10),
                                    step=1,
                                    minimum=1,
                                    interactive=True,
                                    info="ファイル（記憶、ノートなど）ごとに、ここで指定した数だけ最新のバックアップが保持されます。"
                                )
                                log_backup_rotation_count_number = gr.Number(
                                    label="会話ログのバックアップ最大保存件数",
                                    value=config_manager.CONFIG_GLOBAL.get("log_backup_rotation_count", 10),
                                    step=1, minimum=1,
                                    interactive=True,
                                    info="会話ログは重要度が高いため、他のファイルとは別に世代数を設定できます。"
                                )
                                periodic_backup_interval_dropdown = gr.Dropdown(
                                    choices=[
                                        ("無効", "0"),
                                        ("1時間ごと", "3600"),
                                        ("3時間ごと（推奨）", "10800"),
                                        ("6時間ごと", "21600"),
                                    ],
                                    label="定期バックアップ間隔（会話ログ）",
                                    value=str(config_manager.CONFIG_GLOBAL.get("periodic_backup_interval", 0)),
                                    info="開いているルームの会話ログを指定間隔で自動バックアップします。",
                                    interactive=True
                                )
                                gr.Markdown("💡 **会話ログの手動バックアップ・復元**は、チャットタブの「📝 ログ管理」から行えます。")
                                open_backup_folder_button = gr.Button("現在のルームのバックアップフォルダを開く", variant="secondary")

                            # --- ネットワーク設定 ---
                            with gr.Accordion("🌐 ネットワーク設定", open=False):
                                gr.Markdown("<small>✓ 変更は自動保存され、アプリ再起動後に反映されます。</small>")
                                gr.Markdown("⚠️ **設定変更後はアプリの再起動が必要です。**")
                                allow_external_connection_checkbox = gr.Checkbox(
                                    label="外部接続を許可（同じネットワーク内の他デバイスからアクセス可能）",
                                    value=config_manager.CONFIG_GLOBAL.get("allow_external_connection", False),
                                    interactive=True,
                                    info="有効にすると、スマホなど他のデバイスからアクセスできます。"
                                )

                            # --- メンテナンス設定 ---
                            with gr.Accordion("🔧 システム最適化・データ修復", open=False):
                                gr.Markdown("過去のバージョンの不具合で肥大化したログ重複の自動修復や、不要なバックアップファイルを一掃しストレージを解放します。")
                                run_system_optimization_button = gr.Button("過去ログの重複修復・ストレージ最適化を実行", variant="primary")
                                system_optimization_result = gr.Markdown("実行結果がここに表示されます。")

                                def _run_optimization_handler():
                                    return utils.repair_and_optimize_logs()

                                run_system_optimization_button.click(fn=_run_optimization_handler, outputs=[system_optimization_result])

                            # --- 天気・環境連携設定 ---
                            with gr.Accordion("🌤️ 天気・環境連携設定", open=False):
                                gr.Markdown("<small>💾 変更後、ブロック末尾の「天気・環境設定を保存」を押してください。</small>")
                                gr.Markdown("居住地の天気をOpen-Meteoから自動取得し、AIペルソナの会話コンテキストや空間描写に反映させます。")
                                weather_config = config_manager.CONFIG_GLOBAL.get("weather_settings", {})
                                
                                with gr.Row():
                                    weather_city_input = gr.Textbox(
                                        label="都市名 (日本語・英語どちらでも可)", 
                                        placeholder="例: 東京, Tokyo, Osaka",
                                        value=weather_config.get("city_name", ""),
                                        scale=3
                                    )
                                    weather_search_btn = gr.Button("🔍 都市を検索", variant="secondary", scale=1)
                                
                                # 検索結果から緯度経度を選択するドロップダウン
                                initial_choice = []
                                current_lat = weather_config.get("latitude")
                                current_lon = weather_config.get("longitude")
                                if current_lat is not None and current_lon is not None:
                                    current_display = f"{weather_config.get('city_name', '現在の設定場所')} (緯度: {current_lat:.2f}, 経度: {current_lon:.2f})"
                                    initial_choice = [(current_display, f"{current_lat},{current_lon}|{weather_config.get('city_name')}")]
                                
                                weather_candidate_dropdown = gr.Dropdown(
                                    label="検索結果（正しい場所を選んでください）",
                                    choices=initial_choice,
                                    value=initial_choice[0][1] if initial_choice else None,
                                    interactive=True,
                                    info="都市名を入力して検索ボタンを押し、リストから場所を選んでください。"
                                )
                                
                                with gr.Row():
                                    weather_lat_display = gr.Number(label="緯度 (Latitude)", value=current_lat, interactive=False)
                                    weather_lon_display = gr.Number(label="経度 (Longitude)", value=current_lon, interactive=False)
                                
                                with gr.Row():
                                    enable_weather_context_cb = gr.Checkbox(
                                        label="ペルソナの会話へ反映", 
                                        value=weather_config.get("enable_persona_context", False),
                                        interactive=True
                                    )
                                    enable_weather_scenery_cb = gr.Checkbox(
                                        label="情景描写にリアル天気を反映", 
                                        value=weather_config.get("enable_scenery_reflection", False),
                                        interactive=True
                                    )
                                
                                # 初期状態のプレビューを取得
                                initial_preview_md = ui_handlers.get_weather_status_preview_html()
                                weather_status_preview = gr.Markdown(
                                    value=initial_preview_md, 
                                    elem_id="weather-status-preview"
                                )
                                with gr.Row():
                                    weather_refresh_btn = gr.Button("🔄 最新の天気に更新", variant="secondary")
                                    weather_save_btn = gr.Button("天気・環境設定を保存", variant="primary")

                            # --- Googleカレンダー連携設定 ---
                            with gr.Accordion("🗓️ Googleカレンダー連携設定", open=False):
                                gr.Markdown("<small>💾 有効化は自動保存されます。認証情報・同期対象・同期間隔等は「Googleカレンダー設定を保存」を押してください。</small>")
                                gcal_config = config_manager.CONFIG_GLOBAL.get("google_calendar_settings", {})
                                gr.Markdown(
                                    "ご自身のGoogleカレンダーをペルソナが参照できるようにします。"
                                    "予定はバックグラウンドで同期され、ローカルキャッシュから高速に読み取られます。"
                                )
                                open_gcal_guide_btn = gr.Button("📖 設定ガイドを表示", variant="secondary", size="sm")
                                gcal_enabled_cb = gr.Checkbox(
                                    label="Googleカレンダー連携を有効にする",
                                    value=gcal_config.get("enabled", False),
                                    interactive=True
                                )
                                gcal_status_md = gr.Markdown(ui_handlers.get_gcal_status_md())

                                with gr.Accordion("🔑 OAuth認証", open=False):
                                    gr.Markdown(
                                        "ご自身のGCPプロジェクトで発行した認証情報を使用します（Nexus Ark共通のものは埋め込みません）。\n"
                                        "⚠️ OAuth同意画面が『テスト』のままだと、Google仕様でリフレッシュトークンが約7日で失効します。"
                                        "継続利用するには同意画面を『本番』に公開してください。"
                                    )
                                    gcal_client_id = gr.Textbox(
                                        label="Client ID", type="password",
                                        value=gcal_config.get("client_id", ""), interactive=True
                                    )
                                    gcal_client_secret = gr.Textbox(
                                        label="Client Secret", type="password",
                                        value=gcal_config.get("client_secret", ""), interactive=True
                                    )
                                    gcal_generate_url_btn = gr.Button("① 認証URLを生成", variant="secondary")
                                    gcal_auth_url_box = gr.Textbox(
                                        label="認証URL",
                                        interactive=False,
                                        placeholder="「① 認証URLを生成」を押すと、ここにURLが表示されます",
                                        info="このURLをブラウザで開き、Googleアカウントで承認してください。"
                                    )
                                    gr.Markdown(
                                        "承認すると、ブラウザは `http://localhost/?code=…` へ移動し「このサイトにアクセスできません」と表示されます（正常です）。"
                                        "アドレスバーの **`code=` の後ろの値**（`&scope` の手前まで）をコピーして、下の欄に貼り付けてください。"
                                    )
                                    gcal_code_input = gr.Textbox(label="② 認証コード（code= の値）", interactive=True)
                                    with gr.Row():
                                        gcal_auth_btn = gr.Button("③ 認証する", variant="primary")
                                        gcal_revoke_btn = gr.Button("認証を解除", variant="stop")

                                with gr.Row():
                                    gcal_calendar_select = gr.CheckboxGroup(
                                        label="同期対象カレンダー（読み取り）",
                                        choices=[(c, c) for c in (gcal_config.get("selected_calendars") or [])],
                                        value=list(gcal_config.get("selected_calendars") or []),
                                        interactive=True
                                    )
                                    gcal_refresh_calendars_btn = gr.Button("🔄 カレンダー一覧を取得", variant="secondary", scale=0)

                                gcal_sync_interval = gr.Number(
                                    label="同期間隔（分）", value=gcal_config.get("sync_interval_minutes", 30),
                                    minimum=5, step=5, interactive=True
                                )
                                _gcal_pf = gcal_config.get("privacy_filter_default", {})
                                gcal_exclude_keywords = gr.Textbox(
                                    label="除外キーワード（カンマ区切り）",
                                    value=", ".join(_gcal_pf.get("exclude_keywords", [])),
                                    info="タイトル・説明・場所にこれらを含む予定はペルソナから隠されます（時間は埋まっている扱い）。",
                                    interactive=True
                                )
                                with gr.Row():
                                    gcal_mask_private_cb = gr.Checkbox(
                                        label="Googleで非公開設定の予定を隠す",
                                        value=_gcal_pf.get("mask_private_events", True), interactive=True
                                    )
                                    gcal_reminder_sync_cb = gr.Checkbox(
                                        label="通知設定のある予定をリマインドさせる",
                                        value=gcal_config.get("reminder_sync_enabled", True), interactive=True
                                    )
                                gcal_save_btn = gr.Button("Googleカレンダー設定を保存", variant="primary")
                                gr.Markdown(
                                    "---\n"
                                    "💡 **ペルソナごとの設定は「個別」タブから**\n"
                                    "- 予定サマリーをそのペルソナに見せるか、リマインダーを受け取るか\n"
                                    "- ペルソナが自由に書き込める**専用カレンダー**の指定\n\n"
                                    "上部の **「個別」タブ →「🗓️ カレンダー連携（このルーム）」** で、"
                                    "現在選択中のルームごとに設定できます。"
                                )

                            # --- デバッグ設定 ---
                            debug_mode_checkbox = gr.Checkbox(label="デバッグモードを有効化 (デバッグコンソールにシステムプロンプトを出力)", value=config_manager.CONFIG_GLOBAL.get("debug_mode", False), interactive=True)

                        with gr.TabItem("個別") as individual_settings_tab:
                            room_settings_info = gr.Markdown("ℹ️ *現在選択中のルーム「...」にのみ適用されます。多くの項目は自動保存され、例外は各ブロックに表示されます。*")
                            room_settings_save_status = gr.Markdown("個別設定: 最新状態を読み込み済み", elem_classes=["settings-save-status"])
                            refresh_room_settings_button = gr.Button(
                                "🔄 このルームの設定を最新の状態に更新",
                                variant="secondary",
                                size="sm",
                            )
                            gr.Markdown(
                                "<small>PC・スマホなど別のブラウザで変更した設定は、ここから設定ファイルの最新値を再取得できます。</small>"
                            )

                            # --- [Phase 3] 個別設定用AIモデルプロバイダ設定 (一番上に配置) ---
                            with gr.Accordion("⚡ AIモデルプロバイダ設定（このルーム）", open=False) as room_provider_accordion:
                                gr.Markdown("<small>✓ 変更はこのルームに自動保存されます。</small>")
                                gr.Markdown("このルームの応答に使う接続先を選びます。内部処理のGeminiは共通設定を使います。")

                                room_provider_radio = gr.Radio(
                                    choices=provider_connection_handlers.ROOM_PROVIDER_CHOICES,
                                    value="default",
                                    label="このルームの応答に使う接続先",
                                    elem_id="room_provider_connection",
                                    interactive=True
                                )

                                # --- Google設定グループ ---
                                with gr.Group(visible=False) as room_google_settings_group:
                                    room_model_dropdown = gr.Dropdown(
                                        choices=config_manager.AVAILABLE_MODELS_GLOBAL,
                                        label="このルームで使用するAIモデル",
                                        info="Gemini APIで使用するモデルを選択します。",
                                        interactive=True,
                                        allow_custom_value=True
                                    )

                                    with gr.Row():
                                        room_fetch_gemini_models_button = gr.Button("📥 モデルリスト取得", variant="secondary", size="sm")

                                    with gr.Group(elem_id="room_ai_studio_settings",
                                                  elem_classes=[] if provider_connection_handlers.service.provider_choice(effective_initial_room) == "google" else ["gemini-connection-hidden"]) as room_ai_studio_settings:
                                        room_api_key_dropdown = gr.Dropdown(
                                            choices=config_manager.get_api_key_choices_for_ui(),
                                            label="このルームで使用するAPIキー",
                                            elem_id="room_ai_studio_key",
                                            info="Developer API用。共通設定で登録したAPIキーから選択します。",
                                            interactive=True, allow_custom_value=True)
                                        # [Phase 1.5] 個別ローテーション設定
                                        room_rotation_dropdown = gr.Dropdown(
                                            choices=[("共通設定に従う", None), ("有効", True), ("無効", False)],
                                            value=None,
                                            label="このルームでローテーションを有効にする",
                                            interactive=True, allow_custom_value=False)

                                        room_thinking_level_dropdown = gr.Dropdown(
                                            choices=list(constants.THINKING_LEVEL_OPTIONS.values()),
                                            label="Thinking レベル (Gemini 3系)",
                                            visible=False,  # 互換値は保持し、操作は統一推論パネルへ集約。
                                            info="思考モデルの予算を指定します。高いほど深い推論が可能ですが、待ち時間が長くなります。",
                                            interactive=True, allow_custom_value=True)

                                        _initial_gemini_explicit_cache = ui_handlers.load_room_gemini_explicit_cache_settings(effective_initial_room)
                                        with gr.Accordion("Gemini Explicit キャッシュ（有料・実験）", open=False):
                                            open_explicit_cache_guide_btn = gr.Button(
                                                "📖 詳しい説明を見る", variant="secondary", size="sm"
                                            )
                                            room_gemini_explicit_cache_enabled_checkbox = gr.Checkbox(
                                                label="このルームでExplicitキャッシュを使う",
                                                value=bool(_initial_gemini_explicit_cache[0].get("value", False)),
                                                interactive=True,
                                            )
                                            room_gemini_explicit_cache_pause_button = gr.Button(
                                                "一時停止（TTLまで保持）", variant="secondary", size="sm"
                                            )
                                            with gr.Row():
                                                room_gemini_explicit_cache_ttl_slider = gr.Slider(
                                                    minimum=5,
                                                    maximum=60,
                                                    step=5,
                                                    label="TTL（分）",
                                                    value=int(_initial_gemini_explicit_cache[1].get("value", 30)),
                                                    interactive=True,
                                                )
                                                room_gemini_explicit_cache_tool_limit_slider = gr.Slider(
                                                    minimum=3,
                                                    maximum=20,
                                                    step=1,
                                                    label="焼き込みツール上限",
                                                    value=int(_initial_gemini_explicit_cache[2].get("value", 12)),
                                                    interactive=True,
                                                )
                                            gr.Markdown(
                                                "ON時は静的プロンプトと使用頻度上位のツールをGemini Explicit Cacheへ保存します。"
                                                "保存料が発生するため、同じルームで短時間に続けて会話する場合向けです。"
                                            )
                                            room_gemini_explicit_cache_status = gr.Markdown(
                                                value=_initial_gemini_explicit_cache[3].get("value", "現在の状態: OFF"),
                                                elem_classes=["settings-save-status"],
                                            )

                                    room_gemini_connection_panel = build_gemini_connection_panel(
                                        scope="room", room_name=effective_initial_room,
                                    )

                                # --- OpenAI互換設定グループ ---
                                with gr.Group(visible=False) as room_openai_settings_group:
                                    gr.Markdown("OpenAI・OpenRouter・Groqなどの接続プロファイルを選びます。",
                                                elem_id="room_openai_provider_hint")
                                    # プロファイル選択
                                    room_openai_profile_dropdown = gr.Dropdown(
                                        choices=[s["name"] for s in config_manager.get_openai_settings_list()],
                                        label="プロファイル選択",
                                        info="共通設定で登録したプロファイルを使用します。APIキーは共通設定で管理されます。",
                                        interactive=True, allow_custom_value=True)

                                    # Base URL/API Keyは非表示（共通設定で一元管理）
                                    with gr.Row(visible=False):
                                        room_openai_base_url_input = gr.Textbox(
                                            label="Base URL",
                                            placeholder="例: https://openrouter.ai/api/v1",
                                            interactive=True
                                        )
                                        room_openai_api_key_input = gr.Textbox(
                                            label="API Key",
                                            type="password",
                                            placeholder="sk-...",
                                            interactive=True
                                        )

                                    # モデル選択（Dropdown + カスタム値入力可能）
                                    # 起動時に最初のプロファイルのモデルリストを取得しておく
                                    _room_openai_settings_list = config_manager.get_openai_settings_list()
                                    _room_initial_models = _room_openai_settings_list[0].get("available_models", []) if _room_openai_settings_list else []
                                    _room_initial_default_model = _room_openai_settings_list[0].get("default_model", "") if _room_openai_settings_list else ""
                                    room_openai_model_dropdown = gr.Dropdown(
                                        choices=_room_initial_models,
                                        value=_room_initial_default_model,
                                        label="デフォルトモデル",
                                        interactive=True,
                                        allow_custom_value=True,
                                        info="プロファイル選択で自動入力されるか、直接入力できます"
                                    )

                                    with gr.Row():
                                        room_fetch_models_button = gr.Button("📥 モデルリスト取得", variant="secondary", size="sm")
                                        room_openai_free_only_checkbox = gr.Checkbox(label="無料枠のみ (OpenRouter等)", value=False, interactive=True)
                                        room_toggle_favorite_button = gr.Button("⭐ お気に入りに追加/削除", variant="secondary", size="sm")
                                    gr.Markdown("⚠️ すべてのモデルがNexus Arkで動作するわけではありません。", elem_id="openai_model_warning")

                                    # ツール使用オンオフ
                                    room_openai_tool_use_checkbox = gr.Checkbox(
                                        label="ツール使用（Function Calling）を有効にする",
                                        value=True,
                                        interactive=True,
                                        info="OFFにすると、AIはWeb検索・画像生成・記憶編集などのツールを使用できなくなりますが、ツール非対応モデルでも会話できるようになります。"
                                    )

                                # --- Anthropic設定グループ ---
                                with gr.Group(visible=False) as room_anthropic_settings_group:
                                    room_anthropic_model_dropdown = gr.Dropdown(
                                        choices=["claude-3-7-sonnet-20250219", "claude-3-5-sonnet-20241022", "claude-3-5-haiku-20241022", "claude-3-opus-20240229"],
                                        label="このルームで使用するAnthropicモデル",
                                        interactive=True,
                                        allow_custom_value=True
                                    )
                                    room_fetch_anthropic_models_button = gr.Button("📥 最新モデルを取得", variant="secondary", size="sm")

                                # --- Claude サブスクリプション設定グループ ---
                                with gr.Group(visible=False) as room_claude_subscription_settings_group:
                                    room_claude_subscription_delegation_warning = gr.Markdown(
                                        "⚠️ Claudeサブスク通常会話プロバイダはツール呼び出し非対応のため、会話中に委任ツールを呼べません。委任を使う場合はツール対応プロバイダ、または今後の委任実行モデル分離設定を使ってください。",
                                        visible=False,
                                    )
                                    room_claude_subscription_model_dropdown = gr.Dropdown(
                                        choices=[
                                            ("Default (default)", "default"),
                                            ("Sonnet (sonnet)", "sonnet"),
                                            ("Opus (opus)", "opus"),
                                            ("Haiku (haiku)", "haiku"),
                                        ],
                                        label="このルームで使用するClaudeサブスクモデル",
                                        interactive=True,
                                        allow_custom_value=True,
                                        info="共通設定のOAuth tokenまたはClaude Codeログイン情報で取得したモデルを選択できます"
                                    )
                                    room_fetch_claude_subscription_models_button = gr.Button("📥 モデルリスト取得", variant="secondary", size="sm")
                                    room_claude_subscription_status = gr.Markdown("Claudeサブスクリプション: 未テスト")

                                # ローカル (GGUF) 用の案内
                                with gr.Column(visible=False) as room_local_settings_group:
                                    gr.Markdown("#### 💻 ローカル (GGUF直接ロード) 設定")
                                    gr.Markdown(
                                        "✅ **共通設定のパスを使用します**\n"
                                        "このモードでは、[共通]タブの「🔑 APIキー / Webhook管理」で設定したGGUFモデルパスのファイルが使用されます。\n"
                                        "（ルームごとに別のGGUFファイルを指定する機能は現在準備中です）"
                                    )

                                room_reasoning_panel = build_response_reasoning_panel(
                                    scope="room", room_name=effective_initial_room,
                                )

                            with gr.Accordion("🖼️ 情景描写設定", open=False):
                                gr.Markdown("<small>✓ 変更はこのルームに自動保存されます。</small>")
                                enable_scenery_system_checkbox = gr.Checkbox(
                                    label="🖼️ このルームで情景描写システムを有効にする",
                                    info="有効にすると、チャット画面右側に情景が表示され、AIもそれを認識します。",
                                    interactive=True
                                )
                            with gr.Accordion("🗓️ カレンダー連携（このルーム）", open=False):
                                gr.Markdown("<small>✓ 変更はこのルームに自動保存されます。</small>")
                                gr.Markdown(
                                    "このルームのペルソナにカレンダーをどう見せるかを設定します。"
                                    "（共通設定でGoogleカレンダー連携が有効な場合のみ機能します）"
                                )
                                room_gcal_inject_cb = gr.Checkbox(
                                    label="このルームに本日の予定サマリーを見せる",
                                    info="ペルソナの状況認識に予定を注入し、会話で予定に触れられるようにします。",
                                    value=False, interactive=True
                                )
                                room_gcal_reminder_cb = gr.Checkbox(
                                    label="このルームでカレンダーのリマインダーを受け取る",
                                    info="通知が設定された予定の時刻前に、ペルソナがアラームで声かけします（既定: オフ）。",
                                    value=False, interactive=True
                                )
                                room_gcal_read_mode = gr.Radio(
                                    label="このペルソナが読み取れるカレンダー",
                                    choices=[
                                        ("共通の読み取り設定を継承", "inherit"),
                                        ("このルームだけ個別に選択", "custom"),
                                        ("カレンダーを一切見せない", "none"),
                                    ],
                                    value="inherit",
                                    info="個別に選択すると、ほかのペルソナ専用カレンダーをこのルームから隠せます。",
                                    interactive=True,
                                )
                                room_gcal_read_calendars = gr.CheckboxGroup(
                                    label="このルームから読み取れるカレンダー",
                                    choices=[], value=[], interactive=False,
                                    info="共通設定の同期対象から、このペルソナに見せるカレンダーだけを選びます。",
                                )
                                gr.Markdown(
                                    "⚠️ **書き込み先に指定したカレンダーは、ペルソナが承認なしで自由に編集・登録できます**"
                                    "（会話中だけでなく自律行動中も。ささやかなサプライズになることがあります）。"
                                    "そのため、**普段お使いのカレンダーとは分けた『ペルソナ専用カレンダー』を新規作成して指定することを強くお勧めします**。"
                                    "未指定のルームでは書き込みは無効で、メインカレンダー等には決して書き込まれません。"
                                )
                                room_gcal_write_dropdown = gr.Dropdown(
                                    label="ペルソナ専用の書き込み先カレンダー（任意）",
                                    info="未指定なら書き込みは無効です。書いた予定も読ませる場合は、上の個別読み取り対象にも同じカレンダーを選んでください。",
                                    choices=[("（書き込み無効）", "")], value="", interactive=True
                                )
                            with gr.Accordion("📜 チャット表示設定", open=False):
                                gr.Markdown("<small>💾 逐次表示設定は自動保存されます。スタイル・文字サイズ・行間はプレビューのみで、「デザイン」→「ルーム別デザイン」の保存ボタンを押すまで保存されません。</small>")
                                with gr.Group():
                                    gr.Markdown("##### 逐次表示設定")
                                    enable_typewriter_effect_checkbox = gr.Checkbox(
                                        label="タイプライター風の逐次表示を有効化",
                                        value=True,
                                        interactive=True,
                                    )
                                    streaming_speed_slider = gr.Slider(
                                        minimum=0.0, maximum=0.1, step=0.001, value=constants.DEFAULT_STREAMING_SPEED,
                                        label="1文字あたりの待ち時間（秒）",
                                        info="値が小さいほど速く、大きいほどゆっくり表示されます。0は一括表示です。この設定は表示演出の待ち時間で、AIの生成速度は変わりません。",
                                        interactive=True
                                    )

                                with gr.Group():
                                    gr.Markdown("##### 表示モード")
                                    # --- [v19] Novel Mode Toggle ---
                                    chat_style_radio = gr.Radio(
                                        choices=["Chat (Default)", "Novel (Text only)"],
                                        label="スタイル選択",
                                        value="Chat (Default)",
                                        interactive=True,
                                        info="「Novel」にすると吹き出しや枠線が消え、小説のような表示になります。"
                                    )

                                with gr.Group():
                                    gr.Markdown("##### 文字サイズ・行間")
                                    font_size_slider = gr.Slider(minimum=10, maximum=30, value=15, step=1, label="文字サイズ (px)", interactive=True)
                                    line_height_slider = gr.Slider(minimum=1.0, maximum=3.0, value=1.6, step=0.1, label="行間", interactive=True)

                                # style_injector moved to Palette tab to ensure active rendering
                            with gr.Accordion("🎤 音声設定", open=False):
                                gr.Markdown("<small>✓ 変更はこのルームに自動保存されます。</small>")
                                gr.Markdown("チャットの発言を選択して、ここで設定した声で再生できます。")
                                room_tts_provider_dropdown = gr.Dropdown(
                                    label="TTSプロバイダ",
                                    choices=config_manager.get_tts_provider_choices_for_ui(),
                                    value=config_manager.tts_provider_display_from_key("gemini"),
                                    interactive=True,
                                    allow_custom_value=False
                                )
                                openai_provider_names = [s["name"] for s in config_manager.get_openai_settings_list()]
                                room_tts_profile_dropdown = gr.Dropdown(
                                    label="使用するOpenAI互換プロファイル",
                                    choices=openai_provider_names,
                                    value=openai_provider_names[0] if openai_provider_names else None,
                                    visible=False,
                                    interactive=True,
                                    allow_custom_value=True
                                )
                                with gr.Row():
                                    room_tts_model_dropdown = gr.Dropdown(
                                        label="TTSモデル",
                                        choices=config_manager.get_tts_model_choices("gemini"),
                                        value="gemini-3.1-flash-tts-preview",
                                        interactive=True,
                                        allow_custom_value=True,
                                        scale=4
                                    )
                                    room_fetch_tts_models_button = gr.Button("📥 TTSモデル取得", variant="secondary", size="sm", scale=1)
                                with gr.Row():
                                    room_voice_dropdown = gr.Dropdown(
                                        label="声を選択（個別）",
                                        choices=config_manager.get_tts_voice_choices("gemini"),
                                        interactive=True,
                                        allow_custom_value=True,
                                        scale=4
                                    )
                                    room_refresh_speakers_button = gr.Button("🔄 話者リスト更新", size="sm", variant="secondary", scale=1)
                                room_voice_style_prompt_textbox = gr.Textbox(label="音声スタイル / 指示プロンプト", placeholder="例：囁くように、楽しそうに、落ち着いたトーンで", interactive=True)
                                with gr.Accordion("🔊 ローカルTTS（VOICEVOX等）音響パラメータ調整", open=False):
                                    room_voice_speed_slider = gr.Slider(minimum=0.5, maximum=2.0, step=0.05, value=1.0, label="話速", info="音声の速度を調整します。(デフォルト: 1.0)", interactive=True)
                                    room_voice_pitch_slider = gr.Slider(minimum=-0.15, maximum=0.15, step=0.01, value=0.0, label="音高", info="音声の高さを調整します。(デフォルト: 0.0)", interactive=True)
                                    room_voice_intonation_slider = gr.Slider(minimum=0.0, maximum=2.0, step=0.05, value=1.0, label="抑揚", info="音声の抑揚（メロディの強さ）を調整します。(デフォルト: 1.0)", interactive=True)
                                    room_voice_volume_slider = gr.Slider(minimum=0.5, maximum=2.0, step=0.05, value=1.0, label="音量", info="音声の大きさを調整します。(デフォルト: 1.0)", interactive=True)
                                with gr.Row():
                                    room_preview_text_textbox = gr.Textbox(value="こんにちは、Nexus Arkです。これは音声のテストです。", show_label=False, scale=3)
                                    room_preview_voice_button = gr.Button("試聴", scale=1)
                                open_audio_folder_button = gr.Button("📂 現在のルームの音声フォルダを開く", variant="secondary")
                            with gr.Accordion("🔬 AI生成パラメータ調整", open=False):
                                gr.Markdown("<small>✓ 変更はこのルームに自動保存されます。</small>")
                                gr.Markdown("このルームの応答の「創造性」と「安全性」を調整します。")
                                room_temperature_slider = gr.Slider(minimum=0.0, maximum=2.0, step=0.05, value=1.0, label="Temperature", info="値が高いほど、AIの応答がより創造的で多様になります。(推奨: 0.7 ~ 0.9)")
                                room_top_p_slider = gr.Slider(minimum=0.0, maximum=1.0, step=0.01, value=0.95, label="Top-P", info="値が低いほど、ありふれた単語が選ばれやすくなります。(推奨: 0.95)")
                                safety_choices = ["ブロックしない", "低リスク以上をブロック", "中リスク以上をブロック", "高リスクのみブロック"]
                                with gr.Row():
                                    room_safety_harassment_dropdown = gr.Dropdown(choices=safety_choices, label="嫌がらせコンテンツ", interactive=True, allow_custom_value=True)
                                    room_safety_hate_speech_dropdown = gr.Dropdown(choices=safety_choices, label="ヘイトスピーチ", interactive=True, allow_custom_value=True)
                                with gr.Row():
                                    room_safety_sexually_explicit_dropdown = gr.Dropdown(choices=safety_choices, label="性的コンテンツ", interactive=True, allow_custom_value=True)
                                    room_safety_dangerous_content_dropdown = gr.Dropdown(choices=safety_choices, label="危険なコンテンツ", interactive=True, allow_custom_value=True)

                            with gr.Accordion("📡 送信コンテキスト設定", open=False):
                                gr.Markdown("<small>✓ 変更はこのルームに自動保存されます。</small>")
                                room_api_history_limit_dropdown = gr.Dropdown(
                                    choices=list(constants.API_HISTORY_LIMIT_OPTIONS.values()),
                                    label="APIへの履歴送信（短期記憶の長さ）",
                                    info="AIに送信する直近の会話ログの長さを設定します。",
                                    interactive=True, allow_custom_value=True)

                                # --- 自動会話要約設定 ---
                                room_auto_summary_checkbox = gr.Checkbox(
                                    label="本日分が長くなったら自動で要約する",
                                    info="閾値を超えると、古い会話を要約してAPIコストを削減します。",
                                    interactive=True
                                )
                                room_auto_summary_threshold_slider = gr.Slider(
                                    minimum=constants.AUTO_SUMMARY_MIN_THRESHOLD,
                                    maximum=constants.AUTO_SUMMARY_MAX_THRESHOLD,
                                    step=1000,
                                    value=constants.AUTO_SUMMARY_DEFAULT_THRESHOLD,
                                    label="要約閾値（文字数）",
                                    info="この文字数を超えたら要約を開始します。",
                                    interactive=True,
                                    visible=False  # チェックボックスONで表示
                                )

                                room_episode_memory_days_dropdown = gr.Dropdown(
                                    choices=list(constants.EPISODIC_MEMORY_OPTIONS.values()),
                                    label="エピソード記憶の参照期間（中期記憶）",
                                    info="生ログより前の期間について、要約された記憶をどれくらい遡って参照するか設定します。",
                                    interactive=True, allow_custom_value=True)

                                room_enable_retrieval_checkbox = gr.Checkbox(
                                    label="記憶の想起（長期記憶）を有効化",
                                    info="▼AIが応答する前に、記憶や過去ログから関連情報を自律的に検索・想起します。",
                                    interactive=True
                                )

                                room_include_knowledge_retrieval_checkbox = gr.Checkbox(
                                    label="ナレッジも自動想起に含める（関連時のみ）",
                                    info="『記憶の想起』が有効なとき、会話に関連するナレッジを最大3件、応答の参考情報として自動検索します。",
                                    value=False,
                                    interactive=True
                                )

                                room_display_thoughts_checkbox = gr.Checkbox(
                                    label="AIの思考過程 [THOUGHT] をチャットに表示する",
                                    interactive=True
                                )
                                room_send_thoughts_checkbox = gr.Checkbox(label="思考過程をAPIに送信", interactive=True)

                                room_add_timestamp_checkbox = gr.Checkbox(label="メッセージにタイムスタンプを追加", interactive=True)
                                room_send_current_time_checkbox = gr.Checkbox(
                                    label="現在時刻をAPIに送信",
                                    info="▼挨拶の自然さを向上させますが、特定の時間帯を演じたい場合はOFFにしてください。",
                                    interactive=True
                                )

                                room_send_notepad_checkbox = gr.Checkbox(label="メモ帳の内容をAPIに送信", interactive=True)
                                room_use_common_prompt_checkbox = gr.Checkbox(label="共通ツールプロンプトを送信", interactive=True)
                                room_send_core_memory_checkbox = gr.Checkbox(label="コアメモリをAPIに送信", interactive=True)
                                room_send_scenery_checkbox = gr.Checkbox(
                                    label="情景画像をAIに共有",
                                    info="▼現在の景色をAIに見せます。送信タイミングは下で選択。",
                                    interactive=True,
                                    visible=True
                                )
                                room_scenery_send_mode_dropdown = gr.Dropdown(
                                    choices=["変更時のみ", "毎ターン"],
                                    value="変更時のみ",
                                    label="送信タイミング",
                                    info="「変更時のみ」=場所移動・画像更新時、「毎ターン」=毎回送信",
                                    interactive=True,
                                    visible=True, allow_custom_value=True)
                                auto_memory_enabled_checkbox = gr.Checkbox(label="対話の自動記憶を有効化", interactive=True, visible=False)
                                room_enable_self_awareness_checkbox = gr.Checkbox(
                                    label="自己意識機能（動機・感情検出・夢の指針・目標）",
                                    info="▼AIが動機や感情を認識し、夢の指針や目標をコンテキストに含めます。OFFにするとAPIコストを削減できます。",
                                    interactive=True,
                                    value=True
                                )

                        with gr.TabItem("デザイン") as theme_tab:
                            gr.Markdown("<small>💾 デザイン変更はプレビューされますが、自動保存されません。各ブロックの保存・適用ボタンを押してください。</small>")
                            # チェックボックスをタブの最上部に配置
                            room_theme_enabled_checkbox = gr.Checkbox(label="個別テーマを有効にする", value=False, interactive=True)
                            gr.Markdown("このルーム専用の配色を設定・保存します。（未指定の場合は下記ベーステーマが適用されます）")

                            with gr.Accordion("🎀 ルーム別デザイン", open=False):
                                gr.Markdown("<small>💾 変更はその場でプレビューされます。保存するにはブロック末尾の「現在のテーマ設定をこのルームに保存」を押してください。</small>")
                                with gr.Accordion("メイン配色", open=False):
                                    with gr.Row():
                                        theme_primary_picker = gr.ColorPicker(label="メインカラー（強調・ローダー）", interactive=True)
                                        theme_secondary_picker = gr.ColorPicker(label="サブカラー（AI発言・ラベル背景）", interactive=True)
                                        theme_accent_soft_picker = gr.ColorPicker(label="ユーザー発言色", interactive=True)
                                    with gr.Row():
                                        theme_background_picker = gr.ColorPicker(label="背景色", interactive=True)
                                        theme_text_picker = gr.ColorPicker(label="文字色", interactive=True)

                                with gr.Accordion("詳細配色", open=False):
                                    gr.Markdown("ドロップダウンやテキストボックス、コードブロック、ボタンなどの色を個別に設定できます。")
                                    with gr.Row():
                                        theme_input_bg_picker = gr.ColorPicker(label="テキストボックス・スクロールバー", interactive=True)
                                        theme_input_border_picker = gr.ColorPicker(label="入力欄の枠線色", interactive=True)
                                        theme_code_bg_picker = gr.ColorPicker(label="コードブロック背景色", interactive=True)
                                    with gr.Row():
                                        theme_subdued_text_picker = gr.ColorPicker(label="サブテキスト色（説明文など）", interactive=True)
                                        theme_button_bg_picker = gr.ColorPicker(label="ボタン背景色", interactive=True)
                                        theme_button_hover_picker = gr.ColorPicker(label="ボタンホバー色", interactive=True)
                                    with gr.Row():
                                        theme_stop_button_bg_picker = gr.ColorPicker(label="停止ボタン背景色", interactive=True)
                                        theme_stop_button_hover_picker = gr.ColorPicker(label="停止ボタンホバー色", interactive=True)
                                        theme_checkbox_off_picker = gr.ColorPicker(label="未チェックボックス色 (Off)", value=None)
                                    theme_table_bg_picker = gr.ColorPicker(label="テーブル背景色", value=None)
                                    theme_radio_label_picker = gr.ColorPicker(label="ラジオ/チェックボックスのラベル背景色", value=None)
                                    theme_dropdown_list_bg_picker = gr.ColorPicker(label="ドロップダウンリスト背景色", value=None)

                                with gr.Accordion("背景画像設定", open=False):
                                    gr.Markdown("ルームの背景に画像を設定します。")
                                    theme_ui_opacity_slider = gr.Slider(0.0, 1.0, value=0.7, step=0.05, label="UI背景の不透明度 (透明 0.0 - 1.0 不透明)")
                                    theme_bg_src_mode = gr.Radio(label="背景ソース", choices=["画像を指定 (Manual)", "現在地と連動 (Sync)"], value="現在地と連動 (Sync)", interactive=True)

                                    # Manual Mode Settings
                                    with gr.Group(visible=False) as manual_bg_settings_group:
                                        theme_bg_image_picker = gr.Image(label="背景画像 (Manualモード用)", type="filepath", interactive=True, height=200)
                                        with gr.Row():
                                            theme_bg_opacity_slider = gr.Slider(label="不透明度 (Opacity)", minimum=0.0, maximum=1.0, step=0.1, value=0.3, interactive=True)
                                            theme_bg_blur_slider = gr.Slider(label="ぼかし (Blur)", minimum=0, maximum=20, step=1, value=2, interactive=True)
                                        with gr.Row():
                                            theme_bg_size_dropdown = gr.Dropdown(label="サイズ", choices=["cover", "contain", "auto", "custom"], value="cover", interactive=True, allow_custom_value=True)
                                            theme_bg_position_dropdown = gr.Dropdown(label="位置", choices=["center", "top", "bottom", "left", "right", "top left", "top right", "bottom left", "bottom right"], value="center", interactive=True, allow_custom_value=True)
                                        with gr.Row():
                                             theme_bg_repeat_dropdown = gr.Dropdown(label="繰り返し", choices=["no-repeat", "repeat"], value="no-repeat", interactive=True, allow_custom_value=True)
                                             theme_bg_custom_width = gr.Textbox(label="カスタム幅 (custom時のみ)", placeholder="300px", value="300px", interactive=True)
                                        with gr.Row():
                                             theme_bg_radius_slider = gr.Slider(label="角丸 (%)", minimum=0, maximum=50, step=1, value=0, interactive=True)
                                             theme_bg_mask_blur_slider = gr.Slider(label="エッジぼかし (px)", minimum=0, maximum=100, step=1, value=0, interactive=True)
                                             theme_bg_overlay_checkbox = gr.Checkbox(label="前面に表示 (Overlay)", value=False, interactive=True)

                                    # Sync Mode Settings
                                    with gr.Group(visible=True) as sync_bg_settings_group:
                                        gr.Markdown("※ 画像は現在地に合わせて自動選択されます。")
                                        with gr.Row():
                                            theme_bg_sync_opacity_slider = gr.Slider(label="不透明度 (Opacity)", minimum=0.0, maximum=1.0, step=0.1, value=0.3, interactive=True)
                                            theme_bg_sync_blur_slider = gr.Slider(label="ぼかし (Blur)", minimum=0, maximum=20, step=1, value=2, interactive=True)
                                        with gr.Row():
                                            theme_bg_sync_size_dropdown = gr.Dropdown(label="サイズ", choices=["cover", "contain", "auto", "custom"], value="cover", interactive=True, allow_custom_value=True)
                                            theme_bg_sync_position_dropdown = gr.Dropdown(label="位置", choices=["center", "top", "bottom", "left", "right", "top left", "top right", "bottom left", "bottom right"], value="center", interactive=True, allow_custom_value=True)
                                        with gr.Row():
                                             theme_bg_sync_repeat_dropdown = gr.Dropdown(label="繰り返し", choices=["no-repeat", "repeat"], value="no-repeat", interactive=True, allow_custom_value=True)
                                             theme_bg_sync_custom_width = gr.Textbox(label="カスタム幅 (custom時のみ)", placeholder="300px", value="300px", interactive=True)
                                        with gr.Row():
                                             theme_bg_sync_radius_slider = gr.Slider(label="角丸 (%)", minimum=0, maximum=50, step=1, value=0, interactive=True)
                                             theme_bg_sync_mask_blur_slider = gr.Slider(label="エッジぼかし (px)", minimum=0, maximum=100, step=1, value=0, interactive=True)
                                             theme_bg_sync_overlay_checkbox = gr.Checkbox(label="前面に表示 (Overlay)", value=False, interactive=True)

                                    theme_bg_src_mode.change(
                                        fn=lambda x: (gr.update(visible=x=="画像を指定 (Manual)"), gr.update(visible=x=="現在地と連動 (Sync)")),
                                        inputs=[theme_bg_src_mode],
                                        outputs=[manual_bg_settings_group, sync_bg_settings_group]
                                    )

                                save_room_theme_button = gr.Button("🎀 現在のテーマ設定をこのルームに保存", size="sm", variant="primary")

                            with gr.Accordion("🏛️ ベーステーマ選択", open=False):
                                gr.Markdown("<small>💾 選択時はプレビューのみです。「適用（要再起動）」を押すと保存されます。</small>")
                                gr.Markdown("アプリ全体のテーマを変更します。適用には再起動が必要です。")
                                theme_settings_state = gr.State({})
                                with gr.Row():
                                    theme_selector = gr.Dropdown(label="テーマを選択", interactive=True, scale=3, allow_custom_value=True)
                                    apply_theme_button = gr.Button("適用（要再起動）", variant="primary", scale=1)

                                # --- [サムネイル表示エリア] ---
                                with gr.Row():
                                    with gr.Column():
                                        gr.Markdown("##### ライトモード プレビュー")
                                        theme_preview_light = gr.Image(label="Light Mode Preview", interactive=False, height=200)
                                    with gr.Column():
                                        gr.Markdown("##### ダークモード プレビュー")
                                        theme_preview_dark = gr.Image(label="Dark Mode Preview", interactive=False, height=200)

                                # --- [カスタマイズ: 折り畳み可能] ---
                                with gr.Accordion("🔧 カスタマイズ", open=False):
                                    gr.Markdown("<small>💾 「カスタムテーマとして保存」で保存します。ファイルへのエクスポートだけでは適用されません。</small>")
                                    gr.Markdown("選択したテーマをカスタマイズして、新しい名前で保存できます。\n※ファイルベースのテーマは直接編集できません。")
                                    AVAILABLE_HUES = [
                                        "slate", "gray", "zinc", "neutral", "stone", "red", "orange", "amber",
                                        "yellow", "lime", "green", "emerald", "teal", "cyan", "sky", "blue",
                                        "indigo", "violet", "purple", "fuchsia", "pink", "rose"
                                    ]
                                    with gr.Row():
                                        primary_hue_picker = gr.Dropdown(choices=AVAILABLE_HUES, label="プライマリカラー系統", value="blue", allow_custom_value=True)
                                        secondary_hue_picker = gr.Dropdown(choices=AVAILABLE_HUES, label="セカンダリカラー系統", value="sky", allow_custom_value=True)
                                        neutral_hue_picker = gr.Dropdown(choices=AVAILABLE_HUES, label="ニュートラルカラー系統", value="slate", allow_custom_value=True)

                                    AVAILABLE_FONTS = sorted([
                                        "Alice", "Archivo", "Bitter", "Cabin", "Cormorant Garamond", "Crimson Pro",
                                        "Dm Sans", "Eczar", "Fira Sans", "Glegoo", "IBM Plex Mono", "Inconsolata", "Inter",
                                        "Jost", "Lato", "Libre Baskerville", "Libre Franklin", "Lora", "Merriweather",
                                        "Montserrat", "Mulish", "Noto Sans", "Noto Sans JP", "Open Sans", "Playfair Display",
                                        "Poppins", "Pt Sans", "Pt Serif", "Quattrocento", "Quicksand", "Raleway",
                                        "Roboto", "Roboto Mono", "Rubik", "Source Sans Pro", "Source Serif Pro",
                                        "Space Mono", "Spectral", "Sriracha", "Titillium Web", "Ubuntu", "Work Sans"
                                    ])
                                    font_dropdown = gr.Dropdown(choices=AVAILABLE_FONTS, label="メインフォント", value="Noto Sans JP", interactive=True, allow_custom_value=True)

                                    gr.Markdown("---")
                                    custom_theme_name_input = gr.Textbox(label="新しいテーマ名として保存", placeholder="例: My Cool Theme")

                                    with gr.Row():
                                        save_theme_button = gr.Button("カスタムテーマとして保存", variant="primary")
                                        export_theme_button = gr.Button("ファイルにエクスポート", variant="secondary")

                with gr.Accordion("⏰ 時間管理", open=False):
                    with gr.Tabs():
                        with gr.TabItem("アラーム"):
                            gr.Markdown("ℹ️ **操作方法**: リストから操作したいアラームの行を選択し、下のボタンで操作します。")
                            alarm_dataframe = gr.Dataframe(
                                headers=["状態", "時刻", "予定", "ルーム", "内容"],
                                datatype=["bool", "str", "str", "str", "str"],
                                interactive=False,
                                column_count=5,
                                row_count=(10, "dynamic"),
                                wrap=False,
                                elem_id="alarm_list_table",
                                value=ui_handlers.get_display_df(initial_alarm_df_with_ids)
                            )
                            selection_feedback_markdown = gr.Markdown("アラームを選択してください", elem_id="selection_feedback")
                            with gr.Row():
                                enable_button = gr.Button("✔️ 選択を有効化"); disable_button = gr.Button("❌ 選択を無効化"); delete_alarm_button = gr.Button("🗑️ 選択したアラームを削除", variant="stop")
                            gr.Markdown("---"); gr.Markdown("#### 新規 / 更新")
                            alarm_hour_dropdown = gr.Dropdown(choices=[str(i).zfill(2) for i in range(24)], label="時", value="08", allow_custom_value=True)
                            alarm_minute_dropdown = gr.Dropdown(choices=[str(i).zfill(2) for i in range(60)], label="分", value="00", allow_custom_value=True)
                            alarm_room_dropdown = gr.Dropdown(choices=room_list_on_startup, value=effective_initial_room, label="ルーム", allow_custom_value=True)
                            alarm_context_input = gr.Textbox(label="内容", placeholder="AIに伝える内容や目的を簡潔に記述します。\n例：朝の目覚まし、今日も一日頑張ろう！", lines=3)
                            alarm_emergency_checkbox = gr.Checkbox(label="緊急通知として送信 (マナーモードを貫通)", value=False, interactive=True)
                            alarm_days_checkboxgroup = gr.CheckboxGroup(choices=["月", "火", "水", "木", "金", "土", "日"], label="曜日", value=[])
                            with gr.Row():
                                alarm_add_button = gr.Button("アラーム追加")
                                cancel_edit_button = gr.Button("編集をキャンセル", visible=False)
                        with gr.TabItem("タイマー"):
                            timer_type_radio = gr.Radio(["通常タイマー", "ポモドーロタイマー"], label="タイマー種別", value="通常タイマー")
                            with gr.Column(visible=True) as normal_timer_ui:
                                timer_duration_number = gr.Number(label="タイマー時間 (分)", value=10, minimum=1, step=1); normal_timer_theme_input = gr.Textbox(label="通常タイマーのテーマ", placeholder="例: タイマー終了！")
                            with gr.Column(visible=False) as pomo_timer_ui:
                                pomo_work_number = gr.Number(label="作業時間 (分)", value=25, minimum=1, step=1); pomo_break_number = gr.Number(label="休憩時間 (分)", value=5, minimum=1, step=1); pomo_cycles_number = gr.Number(label="サイクル数", value=4, minimum=1, step=1); timer_work_theme_input = gr.Textbox(label="作業終了時テーマ", placeholder="作業終了！"); timer_break_theme_input = gr.Textbox(label="休憩終了時テーマ", placeholder="休憩終了！")
                            timer_room_dropdown = gr.Dropdown(choices=room_list_on_startup, value=effective_initial_room, label="通知ルーム", interactive=True, allow_custom_value=True); timer_status_output = gr.Textbox(label="タイマー設定状況", interactive=False, placeholder="ここに設定内容が表示されます。"); timer_submit_button = gr.Button("タイマー開始", variant="primary")

                with gr.Accordion("🧑‍🤝‍🧑 グループ会話", open=False):
                    session_status_display = gr.Markdown("現在、1対1の会話モードです。")
                    participant_checkbox_group = gr.CheckboxGroup(
                        label="会話に招待するルーム",
                        choices=sorted([c for c in room_list_on_startup if c != effective_initial_room]),
                        interactive=True
                    )
                    group_hide_thoughts_checkbox = gr.Checkbox(
                        label="思考ログを非表示（セッション中のみ）",
                        value=False,
                        info="チェックすると、グループ会話中の全参加者の思考ログが非表示になります。"
                    )
                    enable_supervisor_cb = gr.Checkbox(
                        label="司会AIで次の発言者を選ぶ（Beta）",
                        value=False,
                        info="司会AIは発言本文を作らず、次に話すペルソナだけを選びます。OFFでは従来どおり参加者順に一巡します。"
                    )
                    group_supervisor_rounds_number = gr.Number(
                        label="司会AIモードの自動継続上限（巡）",
                        value=1,
                        minimum=1,
                        maximum=3,
                        step=1,
                        precision=0,
                        info="1巡=参加メンバー数ぶんまで。司会AIが十分と判断した場合は上限前に止まります。"
                    )
                    with gr.Row():
                        start_session_button = gr.Button("このメンバーで会話を開始 / 更新", variant="primary")
                        end_session_button = gr.Button("会話を終了 (1対1に戻る)", variant="secondary")

                with gr.Accordion("🏠 チャットルームの作成・管理", open=False) as manage_room_accordion:
                    with gr.Tabs() as room_management_tabs:
                        with gr.TabItem("作成") as create_room_tab:
                            new_room_name = gr.Textbox(label="ルーム名（必須）", info="UIやグループ会話で表示される名前です。フォルダ名は自動で生成されます。")
                            new_user_display_name = gr.Textbox(label="あなたの表示名（任意）", placeholder="デフォルト: ユーザー")
                            new_agent_display_name = gr.Textbox(label="Agentの表示名（任意）", placeholder="AIのデフォルト表示名。未設定の場合はルーム名が使われます。")
                            new_room_description = gr.Textbox(label="ルームの説明（任意）", lines=3, placeholder="このルームがどのような場所かをメモしておけます。")
                            initial_system_prompt = gr.Textbox(label="初期システムプロンプト（任意）", lines=5, placeholder="このルームの基本的なルールやAIの役割などを設定します。")
                            create_room_button = gr.Button("ルームを作成", variant="primary")

                        with gr.TabItem("管理") as manage_room_tab:
                            manage_room_selector = gr.Dropdown(label="管理するルームを選択", choices=room_list_on_startup, interactive=True, allow_custom_value=True)
                            with gr.Column(visible=False) as manage_room_details:
                                open_room_folder_button = gr.Button("📂 ルームフォルダを開く", variant="secondary")
                                manage_room_name = gr.Textbox(label="ルーム名")
                                manage_user_display_name = gr.Textbox(label="あなたの表示名")
                                manage_agent_display_name = gr.Textbox(label="Agentの表示名")
                                manage_room_description = gr.Textbox(label="ルームの説明", lines=3)
                                manage_folder_name_display = gr.Textbox(label="フォルダ名（編集不可）", interactive=False)
                                save_room_config_button = gr.Button("変更を保存", variant="primary")
                                delete_room_button = gr.Button("このルームを削除", variant="stop")

                        with gr.TabItem("インポート") as import_tab:
                            with gr.Accordion("🔵 ChatGPT (公式)", open=False):
                                gr.Markdown("### ChatGPTデータインポート\n`conversations.json` またはデータ全体のZIPファイルをアップロードして、過去の対話をNexus Arkにインポートします。")
                                chatgpt_import_file = gr.File(label="`conversations.json` (または ZIP) をアップロード", file_types=[".json", ".zip"])
                                with gr.Column(visible=False) as chatgpt_import_form:
                                    chatgpt_thread_dropdown = gr.Dropdown(label="インポートする会話スレッドを選択 (複数選択可)", interactive=True, multiselect=True, allow_custom_value=True)
                                    chatgpt_room_name_textbox = gr.Textbox(label="新しいルーム名", interactive=True)
                                    chatgpt_user_name_textbox = gr.Textbox(label="あなたの表示名（ルーム内）", value="ユーザー", interactive=True)
                                    chatgpt_import_button = gr.Button("この会話をNexus Arkにインポートする", variant="primary")
                            with gr.Accordion("🟠 Claude (公式)", open=False):
                                gr.Markdown("### Claudeデータインポート\n`conversations.json` またはデータ全体のZIPファイルをアップロードして、過去の対話をNexus Arkにインポートします。")
                                claude_import_file = gr.File(label="`conversations.json` (または ZIP) をアップロード", file_types=[".json", ".zip"])
                                with gr.Column(visible=False) as claude_import_form:
                                    claude_thread_dropdown = gr.Dropdown(label="インポートする会話スレッドを選択 (複数選択可)", interactive=True, multiselect=True, allow_custom_value=True)
                                    claude_room_name_textbox = gr.Textbox(label="新しいルーム名", interactive=True)
                                    claude_user_name_textbox = gr.Textbox(label="あなたの表示名（ルーム内）", value="ユーザー", interactive=True)
                                    claude_import_button = gr.Button("この会話をNexus Arkにインポートする", variant="primary")

                            with gr.Accordion("📄 その他テキスト/JSON", open=False):
                                gr.Markdown(
                                    "### 汎用インポーター\n"
                                    "ChatGPT Exporter形式のファイルや、任意の話者ヘッダーを持つテキストログをインポートします。"
                                )
                                generic_import_file = gr.File(label="JSON, MD, TXT ファイルをアップロード (複数可)", file_types=[".json", ".md", ".txt"], file_count="multiple")
                                with gr.Column(visible=False) as generic_import_form:
                                    generic_room_name_textbox = gr.Textbox(label="新しいルーム名", interactive=True)
                                    generic_user_name_textbox = gr.Textbox(label="あなたの表示名（ルーム内）", interactive=True)
                                    gr.Markdown("---")
                                    gr.Markdown(
                                        "**話者ヘッダーの指定**\n"
                                        "ファイル内の、誰の発言かを示す行頭の文字列を正確に入力してください。"
                                    )
                                    generic_user_header_textbox = gr.Textbox(label="あなたの発言ヘッダー", placeholder="例: Prompt:")
                                    generic_agent_header_textbox = gr.Textbox(label="AIの発言ヘッダー", placeholder="例: Response:")
                                    generic_import_button = gr.Button("このファイルをインポートする", variant="primary")



                with gr.Accordion("🛠️ チャット支援ツール", open=False):
                    with gr.Tabs():
                        with gr.TabItem("文字置き換え"):
                            gr.Markdown("チャット履歴内の特定の文字列を、スクリーンショット用に一時的に別の文字列に置き換えます。**元のログファイルは変更されません。**")
                            screenshot_mode_checkbox = gr.Checkbox(
                                label="スクリーンショットモードを有効にする",
                                info="有効にすると、下のルールに基づいてチャット履歴の表示が置き換えられます。"
                            )
                            with gr.Row():
                                with gr.Column(scale=3):
                                    gr.Markdown("**現在のルールリスト**")
                                    redaction_rules_df = gr.Dataframe(
                                        # 起動軽量化の高速ロードはこの表を出力に含めないため、
                                        # 初期表示が空にならないよう構築時点でルールを反映しておく。
                                        value=ui_handlers._create_redaction_df_from_rules(
                                            config_manager.load_redaction_rules()
                                        ),
                                        headers=["元の文字列 (Find)", "置換後の文字列 (Replace)", "背景色"],
                                        datatype=["str", "str", "str"],
                                        row_count=(5, "dynamic"),
                                        column_count=3,
                                        interactive=False
                                    )
                                with gr.Column(scale=2):
                                    gr.Markdown("**ルールの編集**")
                                    redaction_find_textbox = gr.Textbox(label="元の文字列 (Find)")
                                    redaction_replace_textbox = gr.Textbox(label="置換後の文字列 (Replace)")
                                    redaction_color_picker = gr.ColorPicker(label="背景色", value="#62827e")
                                    with gr.Row():
                                        add_rule_button = gr.Button("ルールを追加/更新", variant="primary")
                                        clear_rule_form_button = gr.Button("フォームをクリア")
                                    delete_rule_button = gr.Button("選択したルールを削除", variant="stop")
                        with gr.TabItem("ログ修正"):
                            gr.Markdown("選択した**発言**以降の**AIの応答**に含まれる読点（、）を、AIを使って自動で修正し、自然な文章に校正します。")
                            gr.Markdown("⚠️ **注意:** この操作はログファイルを直接上書きするため、元に戻せません。処理の前に、ログファイルのバックアップが自動的に作成されます。")
                            correct_punctuation_button = gr.Button("選択発言以降の読点をAIで修正", variant="secondary")
                            correction_confirmed_state = gr.Textbox(visible=False)

                # --- アップデート設定 ---
                with gr.Accordion("🔄 アップデート・再起動", open=False) as app_update_accordion:
                    gr.Markdown(f"**現在のバージョン:** v{constants.APP_VERSION}")
                    update_check_button = gr.Button("本体とスマホ版の更新を確認", variant="secondary")
                    update_status_markdown = gr.Markdown("ボタンを押すと最新バージョンを確認します。")
                    with gr.Group(visible=False) as app_update_host_group:
                        app_update_host_status = gr.Markdown("")
                        app_update_host_migration_button = gr.Button(
                            "新しい更新方式へ移行", variant="primary", interactive=False,
                        )
                    app_update_host_confirmed = gr.Textbox(visible=False, interactive=False)
                    with gr.Group(visible=False) as update_download_group:
                        update_apply_button = gr.Button("アップデートをダウンロードして適用", variant="primary")

                    with gr.Group(visible=False) as app_lite_update_group:
                        app_lite_update_status = gr.Markdown("")
                        app_lite_update_button = gr.Button(
                            "スマホ版Liteも更新", variant="secondary", interactive=False,
                        )
                        with gr.Group(visible=False) as app_lite_auth_recovery_group:
                            gr.Markdown(
                                "Cloudflare公式画面で、既存のLite用クラウドを管理するアカウントに"
                                "接続してください。接続後に更新先を確認します。"
                            )
                            app_lite_auth_recovery_button = gr.Button(
                                "Cloudflare管理認証を再接続", variant="primary",
                            )
                        gr.Markdown("本体にも更新がある場合は、先に本体を更新してください。スマホ側の再登録は不要です。")
                    app_lite_update_offer = gr.State({})
                    app_lite_update_confirmation = gr.Textbox(visible=False, interactive=False)
                    app_lite_update_confirmed = gr.Textbox(visible=False, interactive=False)
                    app_lite_auth_recovery_confirmation = gr.Textbox(visible=False, interactive=False)
                    app_lite_auth_recovery_confirmed = gr.Textbox(visible=False, interactive=False)

                    restart_app_button = gr.Button("🔁 アプリを再起動", variant="secondary")
                    # confirmの結果を受ける通信路（自己リセット式・gradio_notes.md #19）
                    restart_confirmed_state = gr.Textbox(visible=False, interactive=False)

                    with gr.Accordion("📜 更新履歴 (リリースノート)", open=False):
                        release_notes_markdown = gr.Markdown("リリースノートを読み込み中...")

                open_user_guide_btn = gr.Button("📖 使い方ガイド", variant="secondary")
                gr.Markdown(f"Nexus Ark {constants.APP_VERSION}", elem_id="app_version_display")



        # --- グローバル・右サイドバー (情景・プロフィール) ---
        with gr.Sidebar(label="情景・プロフィール", width=350, open=True, position="right", elem_id="right_sidebar"):
            with gr.Column(elem_classes=["sidebar-container"]):
                with gr.Accordion("🖼️ プロフィール・情景", open=True, elem_id="profile_scenery_accordion") as profile_scenery_accordion:
                    # --- プロフィール画像/アバター表示セクション ---
                    # gr.HTMLを使用して動画アバターまたは静止画を表示
                    # 動画がある場合はループ再生、ない場合は静止画にフォールバック
                    profile_image_display = gr.HTML(
                        value="",  # 初期値は空（handle_initial_loadで設定される）
                        elem_id="profile_avatar_container"
                    )

                    # 60秒後に待機表情に戻るためのタイマー (constants.AVATAR_IDLE_TIMEOUT = 60)
                    auto_idle_timer = gr.Timer(constants.AVATAR_IDLE_TIMEOUT, active=False)

                    with gr.Accordion("🖼️ アバター・表情を管理", open=False) as profile_image_accordion:
                        avatar_mode_radio = gr.Radio(
                            choices=[("静止画 (profile.png)", "static"), ("動画 (idle.mp4等)", "video")],
                            value="static",
                            label="アバターモード",
                            info="「静止画」は従来のプロフィール画像、「動画」はループ再生されるアニメーション"
                        )
                        staged_image_state = gr.State()

                        cropper_image_preview = gr.ImageEditor(
                            sources=["upload"], type="pil", interactive=True, show_label=False,
                            visible=False, transforms=["crop"], brush=None, eraser=None,
                        )
                        save_cropped_image_button = gr.Button("この範囲で保存", visible=False)

                        # ★★★ 新規: 表情差分管理 ★★★
                        with gr.Accordion("🎭 表情差分の管理", open=False) as expression_management_accordion:
                            gr.Markdown(
                                "AIとの会話中、感情やタグに応じてアバターが切り替わります。ここでは登録済みの表情を確認・管理できます。"
                            )

                            # 表情追加・編集・削除フォーム（操作ボタンを上に配置）
                            gr.Markdown("### 表情の管理")
                            with gr.Row():
                                # 登録済みの表情を選択（新規追加も兼用）
                                expressions_config = room_manager.get_expressions_config(effective_initial_room)
                                # 重複を除去: idle, thinking + expressions.json + DEFAULT_EXPRESSIONS
                                base_expressions = ["idle", "thinking"]
                                config_expressions = expressions_config.get("expressions", [])
                                # 統合リスト: base + config + DEFAULT（重複除去）
                                all_initial_choices = base_expressions.copy()
                                for e in config_expressions + constants.DEFAULT_EXPRESSIONS:
                                    if e not in all_initial_choices:
                                        all_initial_choices.append(e)
                                expression_target_dropdown = gr.Dropdown(
                                    choices=all_initial_choices,
                                    label="操作対象の表情を選択",
                                    allow_custom_value=True,
                                    info="既存の表情を更新するか、新しい表情名を入力してください。",
                                    scale=2
                                )
                                expression_file_upload = gr.UploadButton(
                                    "画像を紐付け / 更新",
                                    file_types=["image", ".mp4", ".webm", ".gif"],
                                    scale=1
                                )

                            with gr.Row():
                                add_expression_button = gr.Button("➕ リストに登録", variant="primary", scale=1)
                                delete_expression_button = gr.Button("🗑️ リストから削除", variant="stop", scale=1)

                            gr.Markdown("💡 **idle / thinking** は状態表示用のため削除できません。その他の表情（感情カテゴリ含む）は自由に編集・削除可能です。")

                            # 表情リスト表示 (カード形式) - 操作ボタンの下に配置
                            expressions_html = gr.HTML(
                                value=ui_handlers.refresh_expressions_ui(effective_initial_room),
                                label="登録済みの表情リスト"
                            )

                    # --- 情景エリア（タブ化: 仮想 / 一時的） ---
                    with gr.Tabs() as scenery_mode_tabs:
                        with gr.TabItem("🏠 仮想現在地", id="virtual_location_tab") as virtual_location_tab:
                            # --- 情景ビジュアルセクション ---
                            # [Gradio 6] show_fullscreen_button=False は非推奨のため、buttons=[] で代替
                            scenery_image_display = gr.Image(label="現在の情景ビジュアル", interactive=False, height=200, show_label=False, buttons=[])
                            current_scenery_display = gr.Textbox(
                                interactive=False, lines=6, max_lines=30, show_label=False,
                                placeholder="現在の情景が表示されます...",
                                elem_id="current_scenery_display"
                            )

                            # --- 移動メニュー ---
                            # [Fix] 初期化時にchoicesを設定
                            # location_dropdown の正しい初期値を計算
                            _loc_choices = ui_handlers._get_location_choices_for_ui(effective_initial_room)
                            _loc_val = None
                            if _loc_choices:
                                 # ヘッダー以外で最初の有効な値を探す
                                 valid_vals = [v for k, v in _loc_choices if not v.startswith("__AREA_HEADER_")]
                                 if valid_vals: _loc_val = valid_vals[0]

                            location_dropdown = gr.Dropdown(
                                label="現在地 / 移動先を選択",
                                choices=_loc_choices,
                                value=_loc_val,
                                interactive=True, allow_custom_value=True)

                            # --- 画像生成メニュー ---
                            with gr.Accordion("🌄情景設定・生成", open=False):
                                _initial_time_settings = ui_handlers._load_time_settings_for_room(effective_initial_room)
                                _initial_custom_scenery_season, _initial_custom_scenery_time = ui_handlers._get_current_time_context_ui_values(effective_initial_room)
                                with gr.Accordion("季節・時間を指定", open=False) as time_control_accordion:
                                    gr.Markdown("（この設定はルームごとに保存されます）", elem_id="time_control_note")
                                    time_mode_radio = gr.Radio(
                                        choices=["リアル連動", "選択する"],
                                        label="モード選択",
                                        value=_initial_time_settings.get("mode", "リアル連動"),
                                        interactive=True
                                    )
                                    with gr.Column(visible=(_initial_time_settings.get("mode", "リアル連動") == "選択する")) as fixed_time_controls:
                                        fixed_season_dropdown = gr.Dropdown(
                                            label="季節を選択",
                                            choices=["春", "夏", "秋", "冬"],
                                            value=_initial_time_settings.get("fixed_season_ja", "秋"),
                                            interactive=True, allow_custom_value=True)
                                        fixed_time_of_day_dropdown = gr.Dropdown(
                                            label="時間帯を選択",
                                            choices=["朝", "昼", "夕方", "夜"],
                                            value=_initial_time_settings.get("fixed_time_of_day_ja", "夜"),
                                            interactive=True, allow_custom_value=True)
                                    # ボタンを fixed_time_controls の外に移動し、常に表示されるようにする
                                    save_time_settings_button = gr.Button("このルームの時間設定を保存", variant="secondary")

                                scenery_style_radio = gr.Dropdown(
                                    choices=["写真風 (デフォルト)", "イラスト風", "アニメ風", "水彩画風"],
                                    label="画風を選択", value="写真風 (デフォルト)", interactive=True, allow_custom_value=True)
                                generate_scenery_image_button = gr.Button("情景画像を生成 / 更新", variant="secondary")
                                refresh_scenery_button = gr.Button("情景テキストを更新", variant="secondary")

                                with gr.Accordion("🎨 情景画像プロンプトを出力", open=False):
                                    gr.Markdown("外部の画像生成サービスで利用するための、現在の情景に基づいたプロンプトを生成します。")
                                    scenery_prompt_output_textbox = gr.Textbox(
                                        label="生成されたプロンプト",
                                        interactive=False,
                                        lines=5, max_lines=20,
                                        placeholder="下のボタンを押してプロンプトを生成します..."
                                    )
                                    generate_scenery_prompt_button = gr.Button("プロンプトを生成", variant="secondary")
                                    copy_scenery_prompt_button = gr.Button("プロンプトをコピー")

                                with gr.Accordion("🏞️ カスタム情景画像の登録", open=False):
                                    gr.Markdown("AI生成の代わりに、ご自身で用意した画像を情景として登録します。")
                                    custom_scenery_location_dropdown = gr.Dropdown(
                                        label="場所を選択",
                                        choices=_loc_choices, # 上で計算したものを使用
                                        interactive=True, allow_custom_value=True)
                                    with gr.Row():
                                        custom_scenery_season_dropdown = gr.Dropdown(label="季節", choices=["春", "夏", "秋", "冬"], value=_initial_custom_scenery_season, interactive=True, allow_custom_value=True)
                                        custom_scenery_time_dropdown = gr.Dropdown(label="時間帯", choices=["早朝", "朝", "昼前", "昼", "昼下がり", "夕方", "夜", "深夜"], value=_initial_custom_scenery_time, interactive=True, allow_custom_value=True)
                                    custom_scenery_image_upload = gr.Image(label="画像をアップロード", type="filepath", interactive=True)
                                    register_custom_scenery_button = gr.Button("この画像を情景として登録", variant="secondary")

                        with gr.TabItem("📍 一時的現在地", id="temp_location_tab") as temp_location_tab:
                            gr.Markdown("📍 今いる場所・景色をペルソナと共有")

                            temp_location_applied_status = gr.Textbox(
                                label="一時的現在地の状態",
                                value="一時的現在地: 未適用（写真なし）",
                                interactive=False, lines=1,
                            )
                            temp_location_name_input = gr.Textbox(
                                label="場所名（任意）",
                                placeholder="例: 駅に向かう並木道",
                                info="保存名やAI向け補足とは別の表示名です。テキスト適用時に反映します。",
                                lines=1,
                                interactive=True,
                                elem_id="temp_location_name_input",
                            )

                            # 一時的現在地の画像表示
                            # [Gradio 6] show_fullscreen_button=False は非推奨のため、buttons=[] で代替
                            temp_scenery_image_display = gr.Image(
                                label="現在の場所のビジュアル", type="filepath", interactive=False,
                                height=200, show_label=False, buttons=[]
                            )
                            # 現在の情景テキスト表示
                            temp_scenery_display = gr.Textbox(
                                label="現在の情景テキスト",
                                interactive=False, lines=6, max_lines=20,
                                placeholder="情景テキストが未設定です。画像をアップロードして生成するか、テキストを直接入力してください。",
                                elem_id="temp_scenery_display"
                            )

                            # --- 編集・生成メニュー ---
                            with gr.Accordion("📝 編集・生成", open=False):
                                temp_image_upload = gr.Image(
                                    label="写真を添付", type="filepath",
                                    interactive=True, height=180
                                )
                                temp_user_hint_textbox = gr.Textbox(
                                    label="補足情報（AI向け・任意）",
                                    placeholder="例: 駅に向かう並木道",
                                    info="AIに渡す情景の補足です。場所名とは別に扱います。",
                                    lines=1, interactive=True
                                )
                                generate_temp_scenery_button = gr.Button(
                                    "🔄 画像から情景を生成", variant="primary"
                                )
                                temp_scenery_edit_textbox = gr.Textbox(
                                    label="情景テキストを編集",
                                    lines=5, max_lines=15, interactive=True,
                                    placeholder="AIが生成した情景テキストを編集できます。または直接入力してください。"
                                )
                                apply_temp_scenery_button = gr.Button(
                                    "✅ テキストを適用", variant="secondary"
                                )

                            # --- 保存・ロード ---
                            with gr.Accordion("📂 保存・ロード", open=False):
                                saved_locations_dropdown = gr.Dropdown(
                                    label="保存済みの場所",
                                    choices=[], interactive=True,
                                    allow_custom_value=False
                                )
                                with gr.Row():
                                    load_location_button = gr.Button("📥 ロード", scale=1)
                                    delete_location_button = gr.Button("🗑️ 削除", variant="stop", scale=1)
                                save_location_name_input = gr.Textbox(
                                    label="保存名",
                                    placeholder="例: 駅に向かう並木道",
                                    info="一覧から呼び出す保存名です。現在地の場所名とは別に扱います。",
                                    lines=1, interactive=True
                                )
                                save_location_button = gr.Button("💾 現在の情景を保存", variant="secondary")
                                temp_location_status = gr.Textbox(
                                    label="操作結果", interactive=False,
                                    lines=1, visible=True
                                )

        with gr.Tabs(selected="chat", elem_id="top_level_tabs", key="top_level_tabs") as top_level_tabs:
            with gr.TabItem("チャット", id="chat", key="top_tab_chat"):
                # サブタブ構造: 会話表示 / RAWログエディタ
                with gr.Tabs():
                    with gr.TabItem("💬 会話") as chat_conversation_tab:
                        # --- 中央チャットエリア ---
                        with gr.Column(scale=1):
                            onboarding_guide = gr.Markdown(
                                """
                                ## Nexus Arkへようこそ！
                                **まずはAIと対話するための準備をしましょう。**
                                1.  **Google AI Studio** などで **Gemini APIキー** を取得してください。
                                2.  左カラムの **「⚙️ 設定」** を開きます。
                                3.  **「共通」** タブ内の **「🔑 APIキー / Webhook管理」** を開きます。
                                4.  **「Gemini（AI Studio）」** を開き、キーの名前（管理用の半角英数字）と、取得したAPIキーの値を入力し、**「新しいキーを追加」** ボタンを押してください。

                                設定が完了すると、このメッセージは消え、チャットが利用可能になります。
                                """,
                                visible=False, # 初期状態では非表示
                                elem_id="onboarding_guide"
                            )

                            room_transition_status = gr.Markdown(
                                "",
                                elem_id="room_transition_status",
                                visible=False
                            )

                            # [Gradio 6] Chatbotはmessages形式のみを受けるため、履歴変換はui_handlers側へ集約する。
                            chatbot_display = gr.Chatbot(
                                height=580,
                                elem_id="chat_output_area",
                                show_label=False,
                                render_markdown=True,
                                group_consecutive_messages=False,
                                editable="all",
                                preserved_by_key=[]
                            )

                            with gr.Row():
                                audio_player = gr.Audio(label="音声プレーヤー", visible=False, autoplay=True, interactive=True, elem_id="main_audio_player")
                            with gr.Column(visible=False) as action_button_group:
                                with gr.Row():
                                    rerun_button = gr.Button("🔄 再生成")
                                    play_audio_button = gr.Button("🔊 選択した発言を再生")
                                    tts_playback_mode_dropdown = gr.Dropdown(
                                        choices=[
                                            ("先頭再生", "trim"),
                                            ("分割生成", "split"),
                                        ],
                                        value="trim",
                                        label="音声",
                                        interactive=True,
                                        scale=1,
                                    )
                                with gr.Row():
                                    tts_segment_dropdown = gr.Dropdown(
                                        choices=[],
                                        value=None,
                                        label="分割音声",
                                        interactive=False,
                                        scale=3,
                                    )
                                    play_tts_segment_button = gr.Button("▶️ 分割再生", interactive=False, scale=1)
                                tts_playlist_state = gr.State(value=[])
                                tts_playlist_index_state = gr.State(value=0)
                                auto_play_next_trigger_btn = gr.Button(visible=False, elem_id="auto_play_next_trigger_btn")
                                with gr.Row():
                                    translate_thought_button = gr.Button("🌐 翻訳", elem_id="translate_thought_button")
                                    delete_selection_button = gr.Button("🗑️ 選択した発言を削除", variant="stop")
                                    cancel_selection_button = gr.Button("✖️ 選択をキャンセル")

                            chat_input_multimodal = gr.MultimodalTextbox(
                                file_types=["image", "audio", "video", "text", ".pdf", ".md", ".py", ".json", ".html", ".css", ".js"],
                                file_count="multiple",  # 複数ファイルの添付を許可
                                max_plain_text_length=100000,
                                placeholder="メッセージを入力してください (Shift+Enterで送信)",
                                show_label=False,
                                lines=3,
                                interactive=True
                            )

                            with gr.Accordion("🎙️ 音声入力（Beta）", open=False):
                                gr.Markdown(
                                    "録音を停止すると自動で文字起こしします。確認モードでは入力欄へ入れるだけで、自動送信モードでは通常メッセージとして送ります。"
                                    "\n\n"
                                    "※スマホのブラウザでマイクを使うには、HTTPSなどの安全な接続で開く必要があります。"
                                    "マイクが見つからない場合は、Tailscale FunnelやGradioの共有URLなどでHTTPS接続になっているか確認してください。"
                                )
                                with gr.Accordion("スマホでマイクを使うには", open=False):
                                    gr.Markdown(
                                        "- 通常のローカルURL（`http://192.168...` など）では、スマホブラウザがマイクを許可しないことがあります。\n"
                                        "- Tailscale Funnel、Tailscale ServeのHTTPS、またはGradio共有URLなど、HTTPSのURLでNexus Arkを開いてください。\n"
                                        "- 初回利用時は、ブラウザのマイク使用許可で「許可」を選んでください。\n"
                                        "- 「マイクが見つかりません」と出る場合は、スマホ側のブラウザ設定でマイク権限を確認してください。\n"
                                        "- iPhone/Safariでは、ページの再読み込み、ブラウザ再起動、ホーム画面追加後の開き直しで権限状態が更新されることがあります。"
                                    )
                                with gr.Row():
                                    gradio_voice_audio_input = gr.Audio(
                                        label="マイク録音",
                                        sources=["microphone", "upload"],
                                        type="filepath",
                                        format="wav",
                                        interactive=True,
                                        scale=3,
                                    )
                                    gradio_voice_action_dropdown = gr.Dropdown(
                                        label="動作",
                                        choices=[
                                            ("確認してから送信", "confirm"),
                                            ("自動送信（録音停止後）", "auto"),
                                        ],
                                        value="confirm",
                                        interactive=True,
                                        scale=1,
                                    )
                                    gradio_voice_stt_provider_dropdown = gr.Dropdown(
                                        label="STT",
                                        choices=[
                                            ("Gemini（既定）", "gemini"),
                                            ("OpenAI Whisper", "openai_whisper"),
                                        ],
                                        value="gemini",
                                        interactive=True,
                                        scale=1,
                                    )
                                gradio_voice_status = gr.Markdown("")
                                gradio_voice_auto_submit_state = gr.State(False)

                            token_count_display = gr.Markdown(
                                "実入力: - / 実合計: -",
                                elem_id="token_count_display",
                                visible=True
                            )

                            with gr.Row():
                                stop_button = gr.Button("⏹️ ストップ", variant="stop", visible=False, scale=1)
                                chat_reload_button = gr.Button("🔄 履歴を更新", scale=1)
                                toggle_chat_mask_button = gr.Button("会話を隠す", scale=1, variant="secondary")


                            # --- [Chat Masking States] ---
                            chat_mask_state = gr.State(False)
                            saved_chat_history_state = gr.State([])

                            toggle_chat_mask_button.click(
                                ui_handlers.toggle_chat_mask,
                                inputs=[chat_mask_state, chatbot_display, saved_chat_history_state],
                                outputs=[chat_mask_state, chatbot_display, saved_chat_history_state, toggle_chat_mask_button]
                            )

                            with gr.Row():
                                add_log_to_memory_queue_button = gr.Button("現在の対話を記憶に追加", scale=1, visible=False)

                            # --- [新規] ユーザー用画像生成機能 ---
                            with gr.Accordion("🖼️ 画像生成 (ユーザー用)", open=False):
                                with gr.Row():
                                    user_gen_image_provider = gr.Dropdown(
                                        choices=[("Gemini", "gemini"), ("OpenAI互換", "openai"), ("Pollinations.ai", "pollinations"), ("Hugging Face", "huggingface")],
                                        value=config_manager.CONFIG_GLOBAL.get("image_generation_provider", "gemini"),
                                        label="プロバイダ", scale=2
                                    )
                                    # OpenAIプロファイル選択（OpenAI互換選択時のみ表示）
                                    _openai_profiles = config_manager.get_image_openai_profile_names()
                                    _current_profile = config_manager.CONFIG_GLOBAL.get("image_generation_openai_settings", {}).get("profile_name", "")
                                    _initial_user_gen_openai_profile = _current_profile if _current_profile in _openai_profiles else (_openai_profiles[0] if _openai_profiles else None)
                                    user_gen_image_openai_profile = gr.Dropdown(
                                        choices=_openai_profiles,
                                        value=_initial_user_gen_openai_profile,
                                        label="プロファイル",
                                        visible=(config_manager.CONFIG_GLOBAL.get("image_generation_provider") == "openai"),
                                        scale=2
                                    )
                                    # モデルの初期リストは現在のプロバイダに基づき取得
                                    _initial_provider = config_manager.CONFIG_GLOBAL.get("image_generation_provider", "gemini")
                                    _initial_models = config_manager.CONFIG_GLOBAL.get("available_image_models", {}).get(_initial_provider, [])

                                    # OpenAIプロファイルが選択されている場合はそのリストを優先
                                    _initial_is_openrouter = False
                                    if _initial_provider == "openai" and _initial_user_gen_openai_profile:
                                        _profile_models = config_manager.get_image_models_for_openai_profile(_initial_user_gen_openai_profile)
                                        if _profile_models:
                                            _initial_models = _profile_models

                                        _settings_list = config_manager.CONFIG_GLOBAL.get("openai_provider_settings", [])
                                        _target = next((s for s in _settings_list if s["name"] == _initial_user_gen_openai_profile), None)
                                        if _target and "openrouter.ai" in _target.get("base_url", "").lower():
                                            _initial_is_openrouter = True

                                    _current_global_model = config_manager.CONFIG_GLOBAL.get("image_generation_model", "")

                                    with gr.Row():
                                        user_gen_image_model = gr.Dropdown(
                                            choices=_initial_models,
                                            value=_current_global_model if _current_global_model in _initial_models else (_initial_models[0] if _initial_models else ""),
                                            label="モデル", scale=5, allow_custom_value=True
                                        )
                                        user_gen_image_refresh_button = gr.Button("🔄", scale=1, variant="secondary", size="sm", elem_id="user_gen_image_refresh_btn")
                                        user_gen_free_only_checkbox = gr.Checkbox(label="無料枠のみ", value=False, visible=_initial_is_openrouter, interactive=True)

                                # --- [新規] AIプロンプト生成補助 ---
                                with gr.Accordion("🪄 AIでプロンプト生成", open=False):
                                    gr.Markdown("今のチャットの文脈から、AIが画像用プロンプトを生成します。依頼内容（テンプレート）は複数保存できます。")
                                    with gr.Row():
                                        _templates = config_manager.CONFIG_GLOBAL.get("user_image_gen_instruction_templates", [])
                                        _template_choices = [t["name"] for t in _templates]
                                        _selected_idx = config_manager.CONFIG_GLOBAL.get("user_image_gen_selected_template_index", 0)
                                        _initial_template_val = _template_choices[_selected_idx] if 0 <= _selected_idx < len(_template_choices) else (_template_choices[0] if _template_choices else None)

                                        user_gen_ai_instruction_dropdown = gr.Dropdown(
                                            choices=_template_choices,
                                            value=_initial_template_val,
                                            label="保存済みテンプレートから選択", scale=3
                                        )
                                        user_gen_ai_instruction_name_textbox = gr.Textbox(
                                            label="テンプレート名 (保存用)",
                                            value=_initial_template_val or "",
                                            scale=2
                                        )
                                        user_gen_ai_instruction_delete_btn = gr.Button("🗑️ 削除", scale=1, variant="stop", size="sm")

                                    user_gen_ai_instruction_editor = gr.Textbox(
                                        label="AIへの依頼内容 (プロンプト生成指示)",
                                        value=_templates[_selected_idx]["instruction"] if 0 <= _selected_idx < len(_templates) else "",
                                        lines=3
                                    )

                                    with gr.Row():
                                        user_gen_ai_instruction_save_btn = gr.Button("💾 テンプレートを保存", variant="secondary")
                                        user_gen_ai_prompt_generate_btn = gr.Button("✨ AIでプロンプトを生成", variant="primary")

                                user_gen_image_prompt = gr.Textbox(
                                    label="プロンプト (英語推奨)",
                                    placeholder="例: A beautiful landscape of a futuristic city at sunset, highly detailed, digital art",
                                    lines=2
                                )
                                user_gen_reference_status = gr.Markdown(
                                    ui_handlers.user_gen_reference_status_message(
                                        _initial_provider,
                                        _current_global_model if _current_global_model in _initial_models else (_initial_models[0] if _initial_models else ""),
                                        _initial_user_gen_openai_profile if _initial_provider == "openai" else None
                                    )
                                )
                                user_gen_reference_files = gr.File(
                                    label="参照画像（最大4枚 / png・jpg・webp）",
                                    file_types=["image"],
                                    file_count="multiple"
                                )
                                user_gen_use_scene_reference = gr.Checkbox(
                                    label="現在の情景画像を参照に使う",
                                    value=False
                                )

                                user_gen_image_button = gr.Button("🎨 画像を生成", variant="primary")
                                user_gen_image_status = gr.Markdown("")

                                user_gen_image_display = gr.Image(label="生成結果", interactive=False, visible=False)
                                user_gen_image_path_state = gr.State("")
                                user_gen_openai_profile_state = gr.State(_initial_user_gen_openai_profile if _initial_provider == "openai" else None)
                                user_gen_image_attach_button = gr.Button("📎 チャットに添付", variant="secondary", visible=False)

                            # --- 書き置き機能（自律行動時に伝えるメッセージ）---
                            with gr.Accordion("📝 書き置き（自律行動時に伝える）", open=False):
                                gr.Markdown("次回の自律行動時にAIに渡されます。送信後は自動でクリアされます。")
                                user_memo_textbox = gr.Textbox(
                                    label="書き置き内容",
                                    lines=3,
                                    placeholder="例: 今から外出するよ / 今日は仕事でバタバタ",
                                    interactive=True
                                )
                                with gr.Row():
                                    save_user_memo_button = gr.Button("💾 保存", size="sm", variant="primary")
                                    clear_user_memo_button = gr.Button("🗑️ クリア", size="sm", variant="secondary")

                            with gr.Accordion("📮 手紙箱", open=False):
                                with gr.Row():
                                    letterbox_open_button = gr.Button("📮 手紙箱を開く", variant="primary")
                                    letterbox_status = gr.Markdown("📮 未読件数は開いた時に更新されます。")
                                letterbox_df = gr.Dataframe(
                                    headers=["タイトル", "日時", "状態"],
                                    datatype=["str", "str", "str"],
                                    interactive=False,
                                    wrap=True,
                                    row_count=(0, "dynamic"),
                                    column_count=(3, "fixed"),
                                    label="手紙一覧",
                                )
                                letterbox_dropdown = gr.Dropdown(
                                    label="読む手紙",
                                    choices=[],
                                    value=None,
                                    interactive=True,
                                )
                                letterbox_meta = gr.Markdown("")
                                letterbox_body = gr.Textbox(
                                    label="本文",
                                    lines=10,
                                    interactive=False,
                                )
                                letterbox_delete_button = gr.Button("🗑️ 選択中の手紙を削除", variant="stop")
                                # confirmの結果を受ける通信路（自己リセット式・gradio_notes.md #19）
                                letterbox_delete_confirmed_state = gr.Textbox(visible=False, interactive=False)

                            # --- [新規] アイテム使用（自律行動・チャット） ---
                            with gr.Accordion("🎁 アイテム使用（探索・管理）", open=False):
                                with gr.Tabs():
                                    with gr.TabItem("🎒 自分の所持品"):
                                        gr.Markdown("インベントリのアイテムを消費したり、今の場所に置いたり、ペルソナに贈ることができます。")
                                        with gr.Row():
                                            food_use_item_dropdown = gr.Dropdown(label="使用するアイテムを選択", choices=["(なし)"], allow_custom_value=True, scale=3)
                                            food_use_refresh_button = gr.Button("🔄 更新", size="sm", scale=0, min_width=40)
                                            item_operation_amount = gr.Number(label="数量", value=1, minimum=1, precision=0, scale=1)
                                            placed_at_furniture = gr.Textbox(label="置く場所の詳細（例: テーブルの上）", placeholder="📍 配置時のみ有効", scale=2)
                                            food_use_item_image_preview = gr.Image(label="アイテムプレビュー", interactive=False, visible=False, scale=1)
                                        with gr.Row():
                                            food_attach_button = gr.Button("🎁 添付（贈る）", variant="primary")
                                            food_consume_button = gr.Button("🍴 消費（食べる）", variant="secondary")
                                            place_item_button = gr.Button("📍 この場所に置く", variant="secondary")
                                        with gr.Row():
                                            copy_inventory_item_button = gr.Button("👯 コピー", size="sm")
                                            delete_inventory_item_button = gr.Button("🗑️ 削除", variant="stop", size="sm")
                                        item_details_markdown = gr.Markdown("*(アイテムを選択すると詳細が表示されます)*")

                                    with gr.TabItem("📍 この場所にある物"):
                                        gr.Markdown("現在の場所に置かれている共有アイテムです。")
                                        with gr.Row():
                                             location_item_dropdown = gr.Dropdown(label="アイテムを選択", choices=["(なし)"], allow_custom_value=True, scale=3)
                                             location_item_operation_amount = gr.Number(label="数量", value=1, minimum=1, precision=0, scale=1)
                                             location_item_image_preview = gr.Image(label="アイテムプレビュー", interactive=False, visible=False, scale=1)
                                             refresh_location_items_button = gr.Button("🔄 更新", size="sm", scale=0, min_width=40)
                                        with gr.Row():
                                             pickup_item_button = gr.Button("🤲 拾う", variant="primary")
                                             consume_location_item_button = gr.Button("🍴 その場で食べる/使う", variant="secondary")
                                        location_item_details_markdown = gr.Markdown("*(アイテムを選択すると詳細が表示されます)*")

                                        # 削除確認用などの非表示ステート
                                        item_op_confirm_state = gr.Textbox(visible=False)
                                        location_item_selection_state = gr.State(None)

                                food_use_status = gr.Markdown("", visible=False)

                            # --- チェスアコーディオン ---
                            with gr.Accordion("♟️ チェス（ペルソナと対戦）", open=False):
                                gr.Markdown("駒を動かすと、ペルソナもそれを認識します。ツールを使ってペルソナに動かしてもらうことも可能です。")
                                with gr.Row():
                                    with gr.Column(scale=2):
                                        chess_board_html = gr.HTML("""
                                            <div id="chess_board_container" style="width: 100%; max-width: 400px; margin: 0 auto;"></div>
                                            <link rel="stylesheet" href="https://unpkg.com/@chrisoakman/chessboardjs@1.0.0/dist/chessboard-1.0.0.min.css" />
                                        """)
                                        init_board_button = gr.Button("チェス盤をセット・再開", variant="secondary", size="sm")

                                    with gr.Column(scale=1):
                                        reset_game_button = gr.Button("リセット", variant="secondary", size="sm")
                                        free_move_mode_cb = gr.Checkbox(
                                            label="フリームーブモード",
                                            value=False,
                                            info="有効にすると、ルールに関係なく自由に駒を配置できます"
                                        )
                                        toggle_turn_button = gr.Button("手番を切替", variant="secondary", size="sm", visible=False)
                                        force_sync_button = gr.Button("盤面を強制同期", variant="secondary", size="sm", visible=False)
                                        game_status_output = gr.Textbox(label="ステータス", interactive=False, value="チェス盤をセットしてください", lines=1)
                                        # Hidden components for JS<->Python communication
                                        user_move_input = gr.Textbox(visible=True, elem_id="user_move_input", lines=1, label="Debug Input (Do Not Edit)")
                                        board_fen_state = gr.Textbox(visible=False, elem_id="board_fen_state")

                                # --- Python function to initialize with room-based persistence ---
                                def init_chess_board(room_name, free_mode):
                                    """Initialize chess board with room-specific saved state."""
                                    if room_name:
                                        # Force reload from disk to ensure we have the latest state
                                        game_instance.set_room(room_name, force_reload=True)

                                    fen = game_instance.get_fen()
                                    turn = "白番" if fen.split(' ')[1] == 'w' else "黒番"
                                    msg = f"フリームーブ ON ({turn})" if free_mode else f"Loaded: {fen[:15]}... ({turn})"
                                    return fen, msg

                                # --- JavaScript Definition ---
                                init_chess_js = """
                                async (fen) => {
                                    const ta = document.querySelector("#user_move_input textarea");
                                    const updateDebug = (msg) => {
                                        if(ta) {
                                          ta.value = JSON.stringify({error: msg});
                                          ta.dispatchEvent(new Event("input", { bubbles: true }));
                                        }
                                    };

                                    const loadScript = (src) => {
                                        return new Promise((resolve, reject) => {
                                            if(document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
                                            const s = document.createElement('script');
                                            s.src = src;
                                            s.onload = () => resolve();
                                            s.onerror = () => reject(new Error(`Failed to load: ${src}`));
                                            document.head.appendChild(s);
                                        });
                                    };

                                    try {
                                        updateDebug("Loading...");
                                        await loadScript("https://code.jquery.com/jquery-3.6.0.min.js");
                                        await loadScript("https://unpkg.com/@chrisoakman/chessboardjs@1.0.0/dist/chessboard-1.0.0.min.js");

                                        const container = document.getElementById("chess_board_container");
                                        if(!container) throw new Error("Container not found");

                                        // If fen is null/empty (free move mode), preserve current board if it exists
                                        let currentPosition = null;
                                        if(window.chess_board_obj && (!fen || fen === "")) {
                                            try { currentPosition = window.chess_board_obj.position('fen'); } catch(e) {}
                                        }

                                        if(window.chess_board_obj) {
                                            try { window.chess_board_obj.destroy(); } catch(e) {}
                                        }
                                        container.innerHTML = "";

                                        // Prioritize FEN from Python if it's a valid position string.
                                        // This ensures that clicking "Set/Resume" actually loads the server state.
                                        const position = ((fen && fen.length > 10) ? fen : (currentPosition || 'start'));
                                        console.log("Initializing chess board with position:", position);

                                        window.chess_board_obj = Chessboard(container, {
                                            position: position,
                                            draggable: true,
                                            pieceTheme: 'https://chessboardjs.com/img/chesspieces/wikipedia/{piece}.png',
                                            onDragStart: function(source, piece, position, orientation) {
                                                window.isDragging = true;
                                            },
                                            onDrop: function(source, target, piece, newPos, oldPos, orient) {
                                                window.isDragging = false;
                                                if(source === target) return;
                                                // We will sync ONLY onSnapEnd to ensure animations are finished
                                                // and avoid dual-message race conditions.
                                                window.lastMove = {from: source, to: target};
                                            },
                                            onSnapEnd: function() {
                                                if(window.chess_board_obj && ta) {
                                                    const fen = window.chess_board_obj.position('fen');
                                                    const msg = {sync_fen: fen};
                                                    if(window.lastMove) {
                                                        msg.from = window.lastMove.from;
                                                        msg.to = window.lastMove.to;
                                                        window.lastMove = null;
                                                    }
                                                    ta.value = JSON.stringify(msg);
                                                    ta.dispatchEvent(new Event("input", { bubbles: true }));
                                                }
                                            }
                                        });

                                        window.updateBoardFromFen = (fen) => {
                                            if(!window.chess_board_obj) return;

                                            // Skip update if user is dragging a piece
                                            if(window.isDragging) {
                                                console.log("Skipping update since dragging");
                                                return;
                                            }

                                            const currentFen = window.chess_board_obj.position('fen');
                                            // Only update if FEN actually changed (ignoring move counts/en passant parts for visual board)
                                            // chess.Board.fen() includes full state, chessboardjs uses only placement
                                            // So we check if placement part is different
                                            const placement = fen.split(' ')[0];
                                            const currentPlacement = currentFen; // chessboardjs returns placement or object

                                            // Simple check: update position
                                            if (currentFen !== placement) {
                                                console.log("Updating board from server:", placement);
                                                window.chess_board_obj.position(placement);
                                            }
                                        };

                                        window.forceSyncBoard = () => {
                                             if(ta) {
                                                const fen = window.chess_board_obj.position('fen');
                                                ta.value = JSON.stringify({force: true, sync_fen: fen});
                                                ta.dispatchEvent(new Event("input", { bubbles: true }));
                                             }
                                        };

                                        updateDebug("Ready!");
                                    } catch(e) {
                                        console.error(e);
                                        updateDebug("Error: " + e.message);
                                    }
                                }
                                """

                                # Event Wiring for Chess - Python first (sets room & loads state), then JS
                                init_board_button.click(
                                    fn=init_chess_board,
                                    inputs=[current_room_name, free_move_mode_cb],
                                    outputs=[board_fen_state, game_status_output]
                                ).then(
                                    fn=None,
                                    inputs=[board_fen_state],
                                    outputs=[],
                                    js=init_chess_js
                                )

                                def handle_debug_or_move(data_json, free_mode):
                                    if not data_json: return game_instance.get_fen(), "No Data"
                                    try:
                                        print(f"  - [Chess DEBUG] Received: {data_json}")
                                        data = json.loads(data_json)
                                        if "error" in data:
                                            return game_instance.get_fen(), data['error']

                                        # Handle Sync (either standalone or combined with move)
                                        sync_successful = False
                                        if "sync_fen" in data:
                                            sync_fen = data["sync_fen"]
                                            if free_mode and sync_fen:
                                                current_full_fen = game_instance.get_fen()
                                                fen_parts = current_full_fen.split(' ')
                                                # Use incoming placement, keep other markers (turn, castling, etc)
                                                new_full_fen = f"{sync_fen} {' '.join(fen_parts[1:])}"
                                                game_instance.set_position_free(new_full_fen)
                                                sync_successful = True
                                                print(f"  - [Chess DEBUG] Sync successful: {sync_fen}")

                                        # Handle Move in Free Mode (Informational only, persistence is handled by sync_fen)
                                        if free_mode and "from" in data:
                                            start_sq = data.get("from")
                                            end_sq = data.get("to")
                                            turn = get_turn_text()
                                            status = f"Free: {start_sq} → {end_sq} ({turn})"
                                            # Return current backend FEN to ensure UI is in sync with persistence
                                            return game_instance.get_fen(), status

                                        # Handle Force Sync status
                                        if data.get("force"):
                                            return None, f"盤面を強制同期しました ({get_turn_text()})"

                                        # Normal Mode Move
                                        if not free_mode and "from" in data:
                                            return handle_user_chess_move(data_json)

                                        return None, gr.skip()
                                    except Exception as e:
                                        print(f"  - [Chess DEBUG] Error: {e}")
                                        return game_instance.get_fen(), f"Error: {e}"

                                user_move_input.change(fn=handle_debug_or_move, inputs=[user_move_input, free_move_mode_cb], outputs=[board_fen_state, game_status_output])

                                # Only update UI board when fen is not None (skip in free move mode)
                                board_fen_state.change(fn=None, inputs=[board_fen_state], js="(fen) => { if(fen && window.updateBoardFromFen) window.updateBoardFromFen(fen); }")

                                def get_turn_text():
                                    """Get current turn as readable text."""
                                    fen = game_instance.get_fen()
                                    turn = fen.split(' ')[1] if ' ' in fen else 'w'
                                    return "白番" if turn == 'w' else "黒番"

                                def reset_chess_game_fn():
                                    game_instance.reset_board()
                                    return game_instance.get_fen(), f"リセット完了 ({get_turn_text()})"
                                reset_game_button.click(fn=reset_chess_game_fn, outputs=[board_fen_state, game_status_output])

                                def toggle_free_move_mode(enabled):
                                    game_instance.set_free_move_mode(enabled)
                                    turn = get_turn_text()
                                    mode_text = f"フリームーブ ON ({turn})" if enabled else f"通常モード ({turn})"
                                    # Show/hide toggle turn/force sync buttons based on free move mode
                                    return mode_text, gr.update(visible=enabled), gr.update(visible=enabled)
                                free_move_mode_cb.input(fn=toggle_free_move_mode, inputs=[free_move_mode_cb], outputs=[game_status_output, toggle_turn_button, force_sync_button])

                                def handle_toggle_turn():
                                    result = game_instance.toggle_turn()
                                    if result:
                                        turn_text = "黒番" if result == 'b' else "白番"
                                        return f"手番切替: {turn_text}"
                                    return "Error"
                                toggle_turn_button.click(fn=handle_toggle_turn, outputs=[game_status_output])

                                force_sync_button.click(fn=None, inputs=[], outputs=[], js="() => { if(window.forceSyncBoard) window.forceSyncBoard(); }")

                                # Polling timer to sync board state (only in normal mode)
                                board_sync_timer = gr.Timer(1.0, active=False)
                                def sync_board_if_normal(free_mode):
                                    # Always return FEN.
                                    # JS side will decide whether to apply it (e.g., skip if dragging).
                                    return game_instance.get_fen()
                                board_sync_timer.tick(fn=sync_board_if_normal, inputs=[free_move_mode_cb], outputs=[board_fen_state])


                    with gr.TabItem("📝 ログ管理") as chat_log_management_tab:
                        gr.Markdown(
                            "過去の会話ログの閲覧・編集・検索ができます。\n\n"
                            "> **⚠️ 注意:** 保存前に自動バックアップが作成されますが、書式（## USER: 等）を崩すと表示が壊れる可能性があります。"
                        )
                        with gr.Row():
                            chat_log_month_dropdown = gr.Dropdown(
                                choices=["最新"],
                                value="最新",
                                label="表示する月を選択",
                                interactive=True,
                                scale=2, allow_custom_value=True)
                            refresh_chat_log_months_button = gr.Button("🔄 一覧を更新", scale=1)

                        with gr.Row():
                            chat_log_search_textbox = gr.Textbox(
                                label="ログ内をキーワード検索",
                                placeholder="検索したい単語を入力（空欄で検索すると全件表示）",
                                scale=3
                            )
                            chat_log_search_button = gr.Button("🔍 検索", variant="secondary", scale=1)

                        with gr.Tabs():
                            with gr.TabItem("📄 RAWエディタ"):
                                reload_chat_log_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                                gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                                chat_log_raw_editor = gr.Code(
                                    label="ログの内容 (Markdown形式)",
                                    language="markdown",
                                    interactive=True,
                                    lines=25,
                                    elem_id="chat_log_raw_editor"
                                )
                                with gr.Row():
                                    save_chat_log_button = gr.Button("💾 編集内容を保存", variant="primary")
                                gr.Markdown("<small>内容をすべて消して保存すると、選択中の月の会話ログを空にします。保存前の内容はバックアップされます。</small>")

                            with gr.TabItem("💬 チャット形式プレビュー") as chat_log_preview_tab:
                                chat_log_preview_chatbot = gr.Chatbot(
                                    label="ログのプレビュー (閲覧専用)",
                                    elem_id="chat_log_preview_chatbot",
                                    height=600,
                                    latex_delimiters=[],
                                    preserved_by_key=[],
                                )

                        with gr.Accordion("💾 バックアップ & 復元", open=False):
                            gr.Markdown(
                                "会話ログのバックアップの作成と、過去のバックアップからの復元ができます。\n"
                                "ルーム切替時・起動時・一定時間ごとにも自動でバックアップされます。"
                            )
                            refresh_backup_list_button = gr.Button("🔄 一覧を更新", variant="secondary")
                            restore_backup_dropdown = gr.Dropdown(
                                label="復元するバックアップを選択",
                                choices=[],
                                interactive=True,
                                info="選択したバックアップの時点に会話ログを巻き戻します。現在のログは自動でバックアップされます。"
                            )
                            with gr.Row():
                                manual_backup_button = gr.Button("📸 今すぐバックアップ", variant="secondary")
                                restore_backup_button = gr.Button("⏪ 復元する", variant="stop")
                            backup_status_markdown = gr.Markdown("")

                    with gr.TabItem("📌 コンテキスト管理"):
                        gr.Markdown("## コンテキスト管理\n現在の会話に直接影響を与える一時的な情報（添付ファイル、ワーキングメモリ、共有メモ）を管理します。")

                        with gr.Accordion("📎 添付ファイルの管理", open=False) as attachment_tab:
                            gr.Markdown(
                                "過去にチャットに添付したファイルの一覧です。\n"
                                "リストを選択して「アクティブ」にすることで、毎回の送信に自動で含められます。\n"
                                "**⚠️注意:** ここでファイルを削除すると、チャット履歴の画像表示なども含めて参照が失われます。"
                            )
                            refresh_attachments_button = gr.Button("🔄 一覧を更新", variant="secondary")
                            active_attachments_display = gr.Markdown("現在アクティブな添付ファイルはありません。")

                            attachments_df = gr.Dataframe(
                                headers=["ファイル名", "種類", "サイズ(KB)", "添付日時"],
                                datatype=["str", "str", "str", "str"],
                                row_count=(5, "dynamic"),
                                column_count=4,
                                interactive=True,  # 行選択を有効にする
                                wrap=True
                            )
                            with gr.Row():
                                open_attachments_folder_button = gr.Button("📂 添付ファイルフォルダを開く", variant="secondary")
                                delete_attachment_button = gr.Button("選択したファイルを削除", variant="stop")

                        with gr.Accordion("🧠 ワーキングメモリ (動的コンテキスト)", open=False):
                            gr.Markdown("ペルソナの現在の状態、プラン、話題ごとのコンテキストが保持されるスペースです。")

                            (
                                _initial_wm_cleanup_visible,
                                _initial_wm_cleanup_message,
                                _initial_wm_cleanup_fingerprint,
                            ) = ui_handlers.get_working_memory_cleanup_notice(
                                effective_initial_room
                            )
                            working_memory_cleanup_notice_state = gr.State(
                                _initial_wm_cleanup_fingerprint
                            )
                            with gr.Group(
                                visible=_initial_wm_cleanup_visible
                            ) as working_memory_cleanup_notice_group:
                                working_memory_cleanup_notice = gr.Markdown(
                                    _initial_wm_cleanup_message
                                )
                                with gr.Row():
                                    working_memory_start_fresh_button = gr.Button(
                                        "新しい作業メモを開始",
                                        variant="primary",
                                    )
                                    working_memory_keep_current_button = gr.Button(
                                        "そのまま使う",
                                        variant="secondary",
                                    )

                            active_working_memory_status = gr.Markdown("現在使用中のスロットを確認中...", label="アクティブスロット")
                            with gr.Row():
                                working_memory_slot_dropdown = gr.Dropdown(
                                    label="表示/編集する話題（スロット）",
                                    choices=[],
                                    allow_custom_value=True,
                                    interactive=True,
                                    scale=3
                                )
                                working_memory_new_slot_button = gr.Button("新規話題の作成", variant="secondary", scale=1)
                            with gr.Row():
                                reload_working_memory_button = gr.Button("🔄 読み込む", variant="secondary")

                            working_memory_editor = gr.Textbox(
                                label="ワーキングメモリの内容",
                                interactive=True,
                                elem_id="working_memory_editor_code",
                                lines=15,
                                max_lines=30,
                                autoscroll=True,
                                placeholder="ワーキングメモリは空です"
                            )
                            working_memory_edit_state = gr.State(
                                {"room_name": "", "slot_name": "", "content_version": 0}
                            )
                            with gr.Row():
                                save_working_memory_button = gr.Button("保存", variant="primary")
                            with gr.Accordion("スロットメタデータ", open=False):
                                reload_working_memory_metadata_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                                gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                                working_memory_metadata_editor = gr.Textbox(
                                    label="working_memories/_metadata.json",
                                    interactive=True,
                                    lines=10,
                                    max_lines=20,
                                    autoscroll=True
                                )
                                with gr.Row():
                                    save_working_memory_metadata_button = gr.Button("メタデータ保存", variant="secondary")
                                working_memory_metadata_status = gr.Markdown("未読み込み")

                        with gr.Accordion("📝 共有メモ帳（ホワイトボード）", open=False):
                            gr.Markdown("ユーザーとペルソナが共有する一時的なメモ帳です。計画やリストの共有に便利です。")
                            reload_notepad_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                            gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                            notepad_editor = gr.Textbox(label="メモ帳の内容", interactive=True, elem_id="notepad_editor_code", lines=15, autoscroll=True)
                            with gr.Row():
                                save_notepad_button = gr.Button("保存", variant="secondary")
                                clear_notepad_button = gr.Button("全削除", variant="stop")

                        # ▼▼▼ アクションメモリーのUI追加 ▼▼▼
                        with gr.Accordion("⚙️ Action Memory (直近のツール行動ログ)", open=False):
                            gr.Markdown("AIが直近で実行したツール（検索やノートへの書き込み等）の履歴です。この情報はAIの現在の文脈に動的に追加されます。")
                            refresh_action_memory_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                            with gr.Row():
                                action_memory_display = gr.Textbox(
                                    label="最近のアクション",
                                    interactive=False,
                                    lines=10,
                                    placeholder="まだアクション記録はありません"
                                )
                        # ▲▲▲ 追加ここまで ▲▲▲

            with gr.TabItem("知識", id="knowledge", key="top_tab_knowledge") as knowledge_tab:
                gr.Markdown("## 知識ベース (RAG)\nこのルームのAIが参照する知識ドキュメントを管理します。")

                with gr.Accordion("📚 知識ファイル", open=False):
                    knowledge_refresh_button = gr.Button("🔄 一覧を更新", variant="primary")
                    knowledge_file_list = gr.HTML(
                        "<p class='info-text'>知識ファイル一覧はまだ読み込まれていません。過去にアップロードしたファイルを確認するには「🔄 一覧を更新」を押してください。</p>"
                    )
                    knowledge_file_dropdown = gr.Dropdown(
                        label="削除するファイル（一覧更新後に選択）",
                        choices=[],
                        value=None,
                        interactive=False,
                    )

                    with gr.Row():
                        knowledge_upload_button = gr.UploadButton(
                            "ファイルをアップロード",
                            file_types=[".txt", ".md"],
                            file_count="multiple"
                        )
                        knowledge_delete_button = gr.Button("選択したファイルを削除", variant="stop")

                    knowledge_reindex_button = gr.Button("索引を作成 / 更新", variant="primary")
                    knowledge_status_output = gr.Textbox(
                        label="ステータス",
                        value="一覧は未読み込みです。現在の知識ファイルを確認するには「🔄 一覧を更新」を押してください。",
                        interactive=False,
                    )

                with gr.Accordion("🧩 Skills / 手順記憶", open=False):
                    gr.Markdown(
                        "AIが再利用する手順知を管理します。共通SkillにはAPI手順など人格に依存しない内容だけを保存し、"
                        "口調・関係性・美学を含むものはルーム専用Skillにしてください。",
                        elem_classes=["info-text"],
                    )
                    skill_refresh_button = gr.Button("🔄 一覧を更新", variant="secondary")
                    skill_list_html = gr.HTML(
                        "<p class='info-text'>Skillsはまだ読み込まれていません。「🔄 一覧を更新」を押してください。</p>"
                    )
                    skill_selector = gr.Dropdown(
                        label="編集するSkill",
                        choices=[],
                        value=None,
                        interactive=False,
                    )
                    with gr.Row():
                        skill_new_button = gr.Button("新規テンプレート", variant="secondary")
                        skill_save_button = gr.Button("保存", variant="primary")
                        skill_delete_button = gr.Button("選択したSkillを削除", variant="stop")
                    with gr.Row():
                        skill_scope = gr.Radio(
                            label="Scope",
                            choices=["private", "shared"],
                            value="private",
                            interactive=True,
                        )
                        skill_id = gr.Textbox(
                            label="Skill ID",
                            value="",
                            interactive=True,
                            placeholder="例: deepen_research_thread",
                        )
                    skill_editor = gr.Textbox(
                        label="Skill Markdown",
                        lines=18,
                        interactive=True,
                        autoscroll=True,
                        placeholder="一覧からSkillを選ぶか、新規テンプレートを作成してください。",
                    )
                    skill_status = gr.Textbox(label="Skillsステータス", interactive=False)

            with gr.TabItem("記憶・ノート", id="memory_notes", key="top_tab_memory_notes"):
                gr.Markdown("## 記憶・ノート\nルームの根幹をなす記憶ファイルとノートを、ここで直接編集できます。")
                with gr.Tabs():
                    with gr.TabItem("記憶"):
                        # 本文と同じ応答で読込元を更新する。軽量起動では未読込のまま保持する。
                        system_prompt_editor_room = gr.State(None)
                        core_memory_editor_room = gr.State(None)
                        gr.Markdown("編集対象は左のルーム選択で確認してください。新規作成後は対象ルームを選び直してから編集します。")
                        # --- システムプロンプト (Accordion) ---
                        with gr.Accordion("📜 システムプロンプト (ペルソナ設定)", open=False) as system_prompt_accordion:
                            reload_prompt_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                            gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                            system_prompt_editor = gr.Textbox(label="SystemPrompt.txt", interactive=True, elem_id="system_prompt_editor", lines=15, autoscroll=True)
                            with gr.Row():
                                save_prompt_button = gr.Button("保存", variant="secondary")

                        # --- コアメモリ (Accordion) ---
                        with gr.Accordion("💎 コアメモリ (自己同一性の核)", open=False) as core_memory_accordion:
                            reload_core_memory_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                            gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                            core_memory_editor = gr.Textbox(
                                label="core_memory.txt - AIの自己同一性の核",
                                interactive=True,
                                elem_id="core_memory_editor_code",
                                lines=15,
                                autoscroll=True
                            )
                            with gr.Row():
                                save_core_memory_button = gr.Button("保存", variant="secondary")

                        # --- Purpose Profile ---
                        with gr.Accordion("🎯 Purpose Profile (目的意識)", open=False):
                            gr.Markdown("ペルソナの長期関心、現在の関心、避けたい行動、変更提案を管理します。")
                            with gr.Row():
                                init_purpose_profile_button = gr.Button("🔄 読み込む", variant="primary")
                                reload_purpose_profile_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                            gr.Markdown("<small>※ 最新の状態に更新すると、編集中の未保存内容は失われます。</small>")
                            purpose_profile_editor = gr.Textbox(
                                label="purpose_profile.json",
                                interactive=True,
                                lines=18,
                                max_lines=35,
                                autoscroll=True,
                                elem_id="purpose_profile_editor"
                            )
                            with gr.Row():
                                save_purpose_profile_button = gr.Button("保存", variant="secondary")
                            with gr.Row():
                                purpose_proposal_id_input = gr.Textbox(
                                    label="承認/破棄する proposal_id",
                                    interactive=True,
                                    scale=3
                                )
                                approve_purpose_change_button = gr.Button("提案を承認", variant="secondary", scale=1)
                                discard_purpose_change_button = gr.Button("提案を破棄", variant="secondary", scale=1)
                            purpose_profile_status = gr.Markdown("未読み込み")

                        # --- 永続記憶・属性 (Identity) ---
                        with gr.Accordion("🪪 永続記憶・属性 (Identity)", open=False) as identity_accordion:
                            gr.Markdown("ペルソナの基本的な属性、ユーザーのプロフィール、世界観の不変的な設定など。")
                            reload_identity_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                            gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                            identity_editor = gr.Textbox(
                                label="memory_identity.txt",
                                interactive=True,
                                lines=15,
                                max_lines=30,
                                autoscroll=True,
                                elem_id="identity_editor"
                            )
                            with gr.Row():
                                save_identity_button = gr.Button("保存", variant="secondary")
                                reflect_identity_to_core_button = gr.Button("コアメモリに反映", variant="secondary")
                            with gr.Accordion("ペルソナからの編集提案", open=False):
                                identity_edit_request_id_state = gr.State("")
                                refresh_identity_edit_requests_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                                identity_edit_requests_df = gr.Dataframe(
                                    headers=["ID", "時刻", "状態", "提案内容"],
                                    datatype=["str", "str", "str", "str"],
                                    label="承認待ちの提案",
                                    interactive=False,
                                    wrap=True,
                                )
                                identity_edit_proposal_text = gr.Textbox(
                                    label="提案内容",
                                    interactive=False,
                                    lines=5,
                                    max_lines=12,
                                    autoscroll=True,
                                )
                                identity_edit_request_detail = gr.Markdown("※ 提案が選択されていません")
                                identity_edit_reject_reason = gr.Textbox(
                                    label="却下理由（任意）",
                                    interactive=True,
                                    lines=2,
                                    placeholder="ペルソナへ伝える理由があれば入力してください",
                                )
                                with gr.Row():
                                    approve_identity_edit_request_button = gr.Button("承認して反映", variant="primary")
                                    reject_identity_edit_request_button = gr.Button("却下", variant="stop")

                        # --- 主観的記憶（日記） (Diary) ---
                        with gr.Accordion("📝 主観的記憶（日記）", open=False) as memory_main_accordion:
                            gr.Markdown("ペルソナの主観的な記録です。感情、思考、重要な出来事を書き留めます。")
                            with gr.Row():
                                refresh_diary_button = gr.Button("🔄 読み込む", variant="primary")
                                show_latest_diary_button = gr.Button("📄 最新を表示", variant="secondary")
                                core_memory_update_button = gr.Button("コアメモリを更新", variant="secondary")

                            with gr.Row():
                                diary_year_filter = gr.Dropdown(label="年で絞り込む", choices=["すべて"], value="すべて", scale=1, allow_custom_value=True)
                                diary_month_filter = gr.Dropdown(label="月で絞り込む", choices=["すべて"], value="すべて", scale=1, allow_custom_value=True)

                            with gr.Row():
                                with gr.Column(scale=1):
                                    diary_entry_dropdown = gr.Dropdown(
                                        label="エントリを選択",
                                        choices=[],
                                        interactive=True,
                                        info="最新のエントリが上に表示されます", allow_custom_value=True)
                                with gr.Column(scale=2):
                                    reload_memory_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                                    gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                                    memory_txt_editor = gr.Textbox(
                                        label="エントリの内容",
                                        interactive=True,
                                        elem_id="memory_txt_editor_code",
                                        lines=15,
                                        max_lines=20,
                                        placeholder="エントリを選択するか、「RAW編集」で直接編集してください"
                                    )

                            with gr.Row():
                                save_memory_button = gr.Button("選択エントリを保存", variant="secondary")

                            with gr.Accordion("📝 RAW編集（全文）", open=False):
                                reload_diary_raw_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                                gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                                diary_raw_editor = gr.Textbox(
                                    label="memory_diary.txt 全文",
                                    interactive=True,
                                    lines=15,
                                    max_lines=25,
                                    autoscroll=True,
                                    elem_id="diary_raw_editor",
                                    placeholder="ファイル全体を直接編集できます"
                                )
                                with gr.Row():
                                    save_diary_raw_button = gr.Button("RAW全文を保存", variant="primary")

                            # --- 古い日記のアーカイブ ---
                            with gr.Accordion("📦 古い日記をアーカイブする", open=False) as memory_archive_accordion:
                                gr.Markdown(
                                    "指定した日付**まで**の日記を要約し、別ファイルに保存して、このメインファイルから削除します。\n"
                                    "**⚠️注意:** この操作は`memory_diary.txt`を直接変更します（処理前にバックアップは作成されます）。"
                                )
                                archive_date_dropdown = gr.Dropdown(label="この日付までをアーカイブ", interactive=True, allow_custom_value=True)

                                archive_confirm_state = gr.Textbox(visible=False) # 確認ダイアログ用
                                archive_memory_button = gr.Button("アーカイブを実行", variant="stop")

                        # --- [Phase 14] エピソード記憶閲覧 ---
                        with gr.Accordion("📚 エピソード記憶（中期記憶）の管理", open=False):
                            episodic_memory_info_display = gr.Markdown("昨日までの会話ログを日ごとに要約し、中期記憶として保存します。\n**最新の記憶:** (未取得)")
                            with gr.Row():
                                refresh_episodic_button = gr.Button("🔄 読み込む", variant="primary")
                                show_latest_episodic_button = gr.Button("📄 最新を表示", variant="secondary")

                            with gr.Row():
                                episodic_year_filter = gr.Dropdown(label="年で絞り込む", choices=["すべて"], value="すべて", scale=1, allow_custom_value=True)
                                episodic_month_filter = gr.Dropdown(label="月で絞り込む", choices=["すべて"], value="すべて", scale=1, allow_custom_value=True)

                            with gr.Row():
                                with gr.Column(scale=1):
                                    episodic_date_dropdown = gr.Dropdown(
                                        label="閲覧するエピソードの日付を選択",
                                        choices=[],
                                        interactive=True,
                                        info="最新のエピソードが上に表示されます。", allow_custom_value=True)
                                with gr.Column(scale=2):
                                    episodic_detail_text = gr.Textbox(
                                        label="エピソードの内容",
                                        lines=15,
                                        interactive=False,
                                        autoscroll=False,
                                        placeholder="日付を選択すると、ここに詳細が表示されます。"
                                    )

                        # --- 夢日記 ---
                        with gr.Accordion("🌙 夢日記 (Dream Journal)", open=False):
                            gr.Markdown("AIが通知禁止時間帯（寝ている間）に見た夢の記録です。\n過去の記憶と直近の出来事を照らし合わせ、AIが得た「洞察」や「深層心理」を閲覧できます。")
                            with gr.Row():
                                refresh_dream_button = gr.Button("🔄 読み込む", variant="primary")
                                show_latest_dream_button = gr.Button("📄 最新を表示", variant="secondary")

                            with gr.Row():
                                dream_year_filter = gr.Dropdown(label="年で絞り込む", choices=["すべて"], value="すべて", scale=1, allow_custom_value=True)
                                dream_month_filter = gr.Dropdown(label="月で絞り込む", choices=["すべて"], value="すべて", scale=1, allow_custom_value=True)

                            with gr.Row():
                                with gr.Column(scale=1):
                                    dream_date_dropdown = gr.Dropdown(
                                        label="閲覧する日記の日付を選択",
                                        choices=[],
                                        interactive=True,
                                        info="最新の日記が上に表示されます。", allow_custom_value=True)
                                with gr.Column(scale=2):
                                    dream_detail_text = gr.Textbox(
                                        label="夢の詳細・深層心理",
                                        lines=15,
                                        interactive=False,
                                        placeholder="日付を選択すると、ここに詳細が表示されます。"
                                    )

                        # --- 📌 エンティティ記憶 (Entity Memory) ---
                        with gr.Accordion("📌 エンティティ記憶 (Entity Memory)", open=False):
                            with gr.Accordion("使い方", open=False):
                                gr.Markdown(
                                    "会話から抽出された重要な物事や人物（エンティティ）に関する詳細な記録です。\n\n"
                                    "**基本の流れ**\n"
                                    "1. 「エンティティ一覧を読み込む」で現在の記憶を表示する\n"
                                    "2. 左でエンティティを選び、中央の本文を編集して保存する\n"
                                    "3. 似た記憶が増えたら、休眠・復帰・統合で整理する\n"
                                    "4. 右側の `index` で状態や利用回数を確認する\n\n"
                                    "**自動整理**\n"
                                    "- 睡眠時記憶整理で自動更新される\n"
                                    "- 週次以上の省察では全件メンテナンスが走る\n"
                                    "- `merge_candidates` は自動統合せず、確認用に残る"
                                )
                            refresh_entity_button = gr.Button("🔄 読み込む", variant="primary")

                            with gr.Row():
                                with gr.Column(scale=1):
                                    entity_dropdown = gr.Dropdown(
                                        label="エンティティを選択",
                                        choices=[],
                                        interactive=True,
                                        info="自動・手動で作成されたエンティティが一覧表示されます。", allow_custom_value=False)
                                    with gr.Row():
                                        save_entity_button = gr.Button("変更を保存", variant="secondary")
                                        delete_entity_button = gr.Button("削除", variant="stop")
                                    with gr.Row():
                                        dormant_entity_button = gr.Button("休眠にする", variant="secondary")
                                        restore_entity_button = gr.Button("復帰する", variant="secondary")
                                with gr.Column(scale=2):
                                    entity_content_editor = gr.Textbox(
                                        label="記録内容 (.md)",
                                        lines=15,
                                        max_lines=30,
                                        interactive=True,
                                        elem_id="entity_content_editor",
                                        placeholder="エンティティを選択すると、ここに内容が表示されます。直接編集して保存することも可能です。"
                                    )
                                    merge_target_entity_dropdown = gr.Dropdown(
                                        label="統合先エンティティ名",
                                        choices=[],
                                        interactive=True,
                                        allow_custom_value=False,
                                        info="左で選んだ記憶を、候補から選んだ相手へ統合します。"
                                    )
                                    with gr.Row():
                                        merge_entity_button = gr.Button("選択中を統合", variant="secondary")
                            with gr.Accordion("🔀 マージ候補レビュー", open=False):
                                entity_merge_candidate_status = gr.Markdown("候補はまだ読み込まれていません。")
                                entity_merge_candidate_load_button = gr.Button("🔄 読み込む", variant="secondary")
                                entity_merge_candidate_df = gr.Dataframe(
                                    headers=["残す側名", "統合される側名", "類似度", "記録日"],
                                    datatype=["str", "str", "number", "str"],
                                    row_count=(5, "dynamic"),
                                    column_count=4,
                                    interactive=False,
                                    wrap=True,
                                )
                                entity_merge_candidate_dropdown = gr.Dropdown(
                                    label="レビューする候補",
                                    choices=[],
                                    value=None,
                                    interactive=True,
                                    allow_custom_value=False,
                                )
                                entity_merge_candidate_note = gr.Markdown("候補を選択するとマージ方向を表示します。")
                                with gr.Row():
                                    entity_merge_keep_preview = gr.Textbox(
                                        label="残す側の本文",
                                        lines=12,
                                        max_lines=20,
                                        interactive=False,
                                        autoscroll=True,
                                    )
                                    entity_merge_source_preview = gr.Textbox(
                                        label="統合される側の本文",
                                        lines=12,
                                        max_lines=20,
                                        interactive=False,
                                        autoscroll=True,
                                    )
                                with gr.Row():
                                    entity_merge_approve_button = gr.Button("✅ 統合する", variant="primary")
                                    entity_merge_dismiss_button = gr.Button("❌ 候補から外す", variant="stop")
                            with gr.Row():
                                with gr.Column(scale=1):
                                    entity_metadata_editor = gr.Textbox(
                                        label="選択中エンティティのメタデータ",
                                        lines=10,
                                        max_lines=20,
                                        interactive=False,
                                        placeholder="選択中のエンティティの状態がここに表示されます。"
                                    )
                                with gr.Column(scale=1):
                                    entity_index_viewer = gr.Textbox(
                                        label="エンティティ index (_index.json)",
                                        lines=10,
                                        max_lines=20,
                                        interactive=False,
                                        placeholder="index の全体がここに表示されます。"
                                    )
                            with gr.Row():
                                show_entity_index_button = gr.Button("index を表示", variant="secondary")

                        # --- 🎯 目標 (Goals) ---
                        with gr.Accordion("🎯 目標 (Goals)", open=False):
                            gr.Markdown("ペルソナが睡眠時省察で自発的に立てた目標です。短期目標と長期目標を確認できます。")
                            refresh_goals_button = gr.Button("🔄 読み込む", variant="primary")

                            with gr.Row():
                                with gr.Column(scale=1):
                                    gr.Markdown("#### 短期目標")
                                    short_term_goals_display = gr.Textbox(
                                        label="",
                                        lines=5,
                                        max_lines=10,
                                        interactive=False,
                                        placeholder="目標を読み込むと表示されます"
                                    )
                                with gr.Column(scale=1):
                                    gr.Markdown("#### 長期目標")
                                    long_term_goals_display = gr.Textbox(
                                        label="",
                                        lines=5,
                                        max_lines=10,
                                        interactive=False,
                                        placeholder="目標を読み込むと表示されます"
                                    )

                            with gr.Row():
                                goals_meta_display = gr.Textbox(
                                    label="省察メタデータ",
                                    lines=2,
                                    interactive=False,
                                    placeholder="最終省察レベル、週次/月次省察の日付が表示されます"
                                )

                        # --- 🧠 自己意識 (Self-Awareness) ---
                        with gr.Accordion("🧠 自己意識 (Self-Awareness)", open=False):
                            gr.Markdown("ペルソナの内発的な動機と、気になっている話題を確認できます。")
                            refresh_internal_state_button = gr.Button("🔄 読み込む", variant="primary")

                            gr.Markdown("#### 📊 現在の動機レベル")
                            with gr.Row():
                                with gr.Column(scale=1):
                                    boredom_level_display = gr.Slider(
                                        label="退屈 (Boredom)", minimum=0, maximum=1, value=0,
                                        interactive=False, info="無操作時間に比例"
                                    )
                                    curiosity_level_display = gr.Slider(
                                        label="好奇心 (Curiosity)", minimum=0, maximum=1, value=0,
                                        interactive=False, info="未解決の問いに比例"
                                    )
                                with gr.Column(scale=1):
                                    goal_achievement_level_display = gr.Slider(
                                        label="目標達成欲 (Goal Drive)", minimum=0, maximum=1, value=0,
                                        interactive=False, info="アクティブな目標に比例"
                                    )
                                    devotion_level_display = gr.Slider(
                                        label="関係への思い (Relatedness)", minimum=0, maximum=1, value=0,
                                        interactive=False, info="本人が記録した関係の気がかり・望みに基づく"
                                    )

                            dominant_drive_display = gr.Textbox(
                                label="現在の最強動機",
                                lines=3,
                                interactive=False,
                                placeholder="読み込むと表示されます"
                            )

                            gr.Markdown("#### ❓ 未解決の問い（好奇心の源泉）")
                            gr.Markdown("行を選択してから操作ボタンをクリックしてください。", elem_id="open_questions_hint")
                            open_questions_display = gr.Dataframe(
                                headers=["話題", "背景・文脈", "優先度", "尋ねた日時"],
                                datatype=["str", "str", "number", "str"],
                                row_count=(3, "dynamic"),
                                column_count=4,
                                interactive=True,  # 選択可能に
                                wrap=True
                            )
                            selected_question_topics_state = gr.State([])  # 選択された話題リスト

                            with gr.Row():
                                resolve_selected_questions_button = gr.Button("✅ 選択を解決済みに", variant="secondary")
                                delete_selected_questions_button = gr.Button("🗑️ 選択を削除", variant="stop")
                                clear_open_questions_button = gr.Button("🗑️ 全てクリア", variant="stop")

                            open_questions_status = gr.Markdown("---")

                            emotion_panel = build_emotion_panel()

                            gr.Markdown("#### 📈 感情モニタリング")
                            gr.Markdown("このグラフは各応答の感情タグの履歴です。上の持続中の感情一覧とは別に記録します。")
                            # [Gradio 6] 起動互換性のため width, interactive を削除。デフォルトサイズを使用。
                            user_emotion_history_plot = gr.ScatterPlot(
                                x="timestamp",
                                y="intensity",
                                color="emotion",
                                title="ペルソナ感情の推移",
                                tooltip=["timestamp", "emotion", "intensity"],
                                height=250
                            )

                            internal_state_last_update = gr.Markdown("最終更新: ---")

                        with gr.Accordion("💫 睡眠時記憶整理 (Sleep Consolidation)", open=False):

                            gr.Markdown(
                                "**発生条件:** 自律行動が有効で、通知禁止時間帯（デフォルト: 0:00〜7:00）に無操作時間を超過すると、AIは「眠り」に入り夢日記を作成します。\n\n"
                                "夢日記を作成する際に、以下の処理も連続して実行します。（チェックを変更すると即座に保存されます）"
                            )
                            sleep_consolidation_episodic_cb = gr.Checkbox(
                                label="エピソード記憶を作成・更新する",
                                value=True,
                                interactive=True
                            )
                            sleep_consolidation_memory_index_cb = gr.Checkbox(
                                label="記憶の索引を更新する",
                                value=True,
                                interactive=True
                            )
                            sleep_consolidation_current_log_cb = gr.Checkbox(
                                label="現行ログの索引を更新する（時間がかかります）",
                                value=False,  # デフォルトOFF（時間がかかるため）
                                interactive=True
                            )
                            sleep_consolidation_entity_memory_cb = gr.Checkbox(
                                label="エンティティ記憶を更新する",
                                value=True,
                                interactive=True,
                                info="会話から重要な対象（人物・事物）の情報を整理"
                            )
                            # Parameters moved to Maintenance Accordion
                            sleep_consolidation_compress_cb = gr.Checkbox(
                                label="📦 古い記憶を圧縮する",
                                value=False,  # デフォルトOFF（破壊的操作のため）
                                interactive=True,
                                info="3日以上前のエピソード記憶を週単位に統合"
                            )
                            sleep_consolidation_extract_questions_cb = gr.Checkbox(
                                label="❓ 未解決の問いを抽出する",
                                value=True,  # デフォルトON
                                interactive=True,
                                info="会話から「気になること」を抽出し、好奇心の源泉として記録"
                            )


                        # --- [Phase 14] 🛠️ 記憶のメンテナンス (手動実行) ---
                        with gr.Accordion("🛠️ 記憶のメンテナンス (手動実行)", open=False) as maintenance_accordion:
                            gr.Markdown("大規模な記憶の更新や、データの最適化を手動で実行します。")

                            gr.Markdown("### 🌙 睡眠時記憶整理の一括実行")
                            gr.Markdown("夜間の睡眠時整理と同じ処理（夢想→エピソード→索引→圧縮）を今すぐ実行します。")
                            with gr.Row():
                                manual_sleep_maintenance_button = gr.Button("睡眠時記憶整理を今すぐ実行", variant="primary")
                                refresh_sleep_maintenance_status_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                            sleep_maintenance_status_display = gr.Textbox(
                                label="最終整理結果",
                                lines=6,
                                interactive=False,
                                placeholder="まだ記録がありません"
                            )

                            gr.Markdown("---")

                            with gr.Row():
                                with gr.Column():
                                    gr.Markdown("### 📚 エピソード記憶の更新")
                                    update_episodic_memory_button = gr.Button("エピソード記憶を今すぐ更新", variant="primary")
                                    episodic_update_status = gr.Textbox(label="エピソード更新ステータス", interactive=False, placeholder="更新を実行すると、ここに最終処理日等が表示されます")

                                with gr.Column():
                                    gr.Markdown("### 📌 エンティティ記憶 (Entity Memory) の更新")
                                    with gr.Row():
                                        manual_dream_button = gr.Button("エンティティ記憶を更新（睡眠時記憶整理を実行）", variant="primary")
                                        manual_insight_button = gr.Button("夢日記のみ生成（高速テスト）", variant="secondary")
                                    dream_status_display = gr.Textbox(label="最終実行日時", interactive=False, placeholder="まだ実行されていません")



                            gr.Markdown("---")
                            with gr.Row():
                                with gr.Column():
                                    gr.Markdown("### 🔍 記憶索引 (RAG) の再構築")
                                    memory_reindex_button = gr.Button("記憶の索引を更新", variant="secondary")
                                    full_reindex_button = gr.Button("🗑️ 索引を初期化して再構築", variant="stop")
                                    gr.Markdown("<small>⚠️ 旧preview索引は、全件再構築をしなくても登録済み文書をローカルのキーワード検索で参照できます。意味検索と索引更新を戻したい場合だけ、この操作を選んでください。旧索引を保護・検証してから作り直します。Embedding APIの利用料金と時間がかかる場合があります。会話と記憶の原本は削除しません。</small>")
                                    memory_reindex_status = gr.Textbox(label="記憶索引ステータス", interactive=False)

                                with gr.Column():
                                    gr.Markdown("### 🔍 現行ログの索引更新")
                                    current_log_reindex_button = gr.Button("現行ログの索引を更新", variant="secondary")
                                    current_log_reindex_status = gr.Textbox(label="現行ログ索引ステータス", interactive=False)

                            gr.Markdown("---")
                            gr.Markdown("### 📦 記憶の圧縮 (Archive)")
                            gr.Markdown("3日以上経過した記憶を週・月単位に圧縮し、RAGの検索効率を向上させます。")
                            compress_episodes_button = gr.Button("古い記憶を手動で圧縮する", variant="secondary")
                            compress_episodes_status = gr.Textbox(label="圧縮ステータス", interactive=False)

                            gr.Markdown("---")
                            gr.Markdown("### 🧠 内部状態のリセット")
                            gr.Markdown("動機レベル、未解決の問い、最終発火時刻をすべてリセットします。")
                            reset_internal_state_button = gr.Button("🧹 内部状態をリセット", variant="stop")
                            reset_internal_state_status = gr.Textbox(label="リセットステータス", interactive=False)



                    with gr.TabItem("創作・分析ノート"):

                        # --- 創作ノートアコーディオン ---
                        with gr.Accordion("🎨 創作ノート", open=False):
                            creative_note_kind = gr.State("creative")
                            creative_note_edit_state = gr.State(None)
                            creative_note_raw_state = gr.State(None)
                            gr.Markdown("ペルソナの創作活動専用スペースです。詩、物語、アイデアスケッチなど。")
                            gr.Markdown(
                                f"ノートが{constants.NOTES_MAX_SIZE_BYTES // 1024}KB以上になると、次回の追記時などに過去分を別ファイルへ保存します。"
                                "記録は削除されず、この一覧から引き続き閲覧できます。"
                            )
                            creative_notes_summary = gr.Markdown(
                                "「🔄 一覧を更新」を押すと、過去分を含む記録を読み込みます。",
                                elem_id="creative_notes_summary",
                            )
                            with gr.Row():
                                refresh_creative_notes_button = gr.Button("🔄 一覧を更新", variant="primary", scale=1)
                                show_latest_creative_button = gr.Button("📄 最新", variant="secondary", scale=1)

                            with gr.Row():
                                creative_year_filter = gr.Dropdown(label="年で絞り込む", choices=["すべて"], value="すべて", scale=1, allow_custom_value=False)
                                creative_month_filter = gr.Dropdown(label="月で絞り込む", choices=["すべて"], value="すべて", scale=1, allow_custom_value=False)

                            with gr.Row():
                                with gr.Column(scale=1):
                                    creative_entry_dropdown = gr.Dropdown(
                                        label="記録を選択",
                                        choices=[],
                                        interactive=True,
                                        info="過去分も含め、新しい記録から表示します", allow_custom_value=False)
                                with gr.Column(scale=2):
                                    reload_creative_notes_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                                    gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                                    creative_notes_editor = gr.Textbox(
                                        label="記録の内容",
                                        interactive=True,
                                        elem_id="creative_notes_editor_code",
                                        lines=15,
                                        max_lines=20,
                                        placeholder="一覧を更新し、記録を選択してください"
                                    )

                            with gr.Row():
                                save_creative_notes_button = gr.Button("選択した記録を保存", variant="secondary")


                            with gr.Accordion("📝 ファイル単位の編集（詳細）", open=False) as creative_notes_details:
                                gr.Markdown("ファイルごとに全文を編集できます。このファイル選択は、上の記録一覧には影響しません。")
                                with gr.Row():
                                    creative_notes_file_dropdown = gr.Dropdown(
                                        label="編集するファイル", choices=[constants.CREATIVE_NOTES_FILENAME],
                                        value=constants.CREATIVE_NOTES_FILENAME, scale=3,
                                        allow_custom_value=False,
                                    )
                                    refresh_creative_file_list_button = gr.Button("🔄 ファイル一覧を更新", scale=1)
                                reload_creative_raw_button = gr.Button("🔄 ファイルを読み込む", variant="secondary")
                                gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                                creative_notes_raw_editor = gr.Textbox(
                                    label="ファイルの全文",
                                    interactive=True,
                                    lines=15,
                                    max_lines=25,
                                    autoscroll=True,
                                    elem_id="creative_notes_raw_editor",
                                    placeholder="ファイル全体を直接編集できます"
                                )
                                with gr.Row():
                                    save_creative_raw_button = gr.Button("ファイル全文を保存", variant="primary")

                        # --- 研究・分析ノートアコーディオン ---
                        with gr.Accordion("🔬 研究・分析ノート", open=False):
                            research_note_kind = gr.State("research")
                            research_note_edit_state = gr.State(None)
                            research_note_raw_state = gr.State(None)
                            gr.Markdown("Web巡回ツールによる分析結果や洞察が蓄積されるスペースです。AIが自律的に更新します。")
                            gr.Markdown(
                                f"ノートが{constants.NOTES_MAX_SIZE_BYTES // 1024}KB以上になると、次回の追記時などに過去分を別ファイルへ保存します。"
                                "記録は削除されず、この一覧から引き続き閲覧できます。"
                            )
                            research_notes_summary = gr.Markdown(
                                "「🔄 一覧を更新」を押すと、過去分を含む記録を読み込みます。",
                                elem_id="research_notes_summary",
                            )
                            with gr.Row():
                                refresh_research_notes_button = gr.Button("🔄 一覧を更新", variant="primary", scale=1)
                                show_latest_research_button = gr.Button("📄 最新", variant="secondary", scale=1)

                            with gr.Row():
                                research_year_filter = gr.Dropdown(label="年で絞り込む", choices=["すべて"], value="すべて", scale=1, allow_custom_value=False)
                                research_month_filter = gr.Dropdown(label="月で絞り込む", choices=["すべて"], value="すべて", scale=1, allow_custom_value=False)

                            with gr.Row():
                                with gr.Column(scale=1):
                                    research_entry_dropdown = gr.Dropdown(
                                        label="記録を選択",
                                        choices=[],
                                        interactive=True,
                                        info="過去分も含め、新しい記録から表示します", allow_custom_value=False)
                                with gr.Column(scale=2):
                                    reload_research_notes_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                                    gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                                    research_notes_editor = gr.Textbox(
                                        label="記録の内容",
                                        interactive=True,
                                        elem_id="research_notes_editor_code",
                                        lines=15,
                                        max_lines=20,
                                        placeholder="一覧を更新し、記録を選択してください"
                                    )

                            with gr.Row():
                                save_research_notes_button = gr.Button("選択した記録を保存", variant="secondary")

                            with gr.Accordion("📝 ファイル単位の編集（詳細）", open=False) as research_notes_details:
                                gr.Markdown("ファイルごとに全文を編集できます。このファイル選択は、上の記録一覧には影響しません。")
                                with gr.Row():
                                    research_notes_file_dropdown = gr.Dropdown(
                                        label="編集するファイル", choices=[constants.RESEARCH_NOTES_FILENAME],
                                        value=constants.RESEARCH_NOTES_FILENAME, scale=3,
                                        allow_custom_value=False,
                                    )
                                    refresh_research_file_list_button = gr.Button("🔄 ファイル一覧を更新", scale=1)
                                reload_research_raw_button = gr.Button("🔄 ファイルを読み込む", variant="secondary")
                                gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                                research_notes_raw_editor = gr.Textbox(
                                    label="ファイルの全文",
                                    interactive=True,
                                    lines=15,
                                    max_lines=25,
                                    autoscroll=True,
                                    elem_id="research_notes_raw_editor",
                                    placeholder="ファイル全体を直接編集できます"
                                )
                                with gr.Row():
                                    save_research_raw_button = gr.Button("ファイル全文を保存", variant="primary")

                            with gr.Accordion("🧵 Research Threads（継続研究スレッド）", open=False):
                                refresh_research_threads_button = gr.Button("🔄 一覧を更新", variant="primary")
                                with gr.Row():
                                    research_thread_dropdown = gr.Dropdown(
                                        label="スレッド",
                                        choices=[],
                                        value=None,
                                        interactive=True,
                                        scale=3
                                    )
                                reload_research_thread_body_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                                gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                                research_thread_body_editor = gr.Textbox(
                                    label="スレッド本文",
                                    interactive=True,
                                    lines=16,
                                    max_lines=30,
                                    autoscroll=True,
                                    elem_id="research_thread_body_editor"
                                )
                                with gr.Row():
                                    save_research_thread_body_button = gr.Button("スレッド本文を保存", variant="secondary")
                                with gr.Accordion("index.json 編集", open=False):
                                    research_threads_index_editor = gr.Textbox(
                                        label="research_threads/index.json",
                                        interactive=True,
                                        lines=14,
                                        max_lines=25,
                                        autoscroll=True,
                                        elem_id="research_threads_index_editor"
                                    )
                                    save_research_threads_index_button = gr.Button("index.jsonを保存", variant="secondary")
                                research_threads_status = gr.Markdown("未読み込み")

            with gr.TabItem("自律行動", id="autonomy", key="top_tab_autonomy"):
                gr.Markdown("## 自律行動\n自律行動、ウォッチリスト、アトリエ、委任、プロジェクト探索をまとめて管理します。")
                with gr.Tabs():
                    with gr.TabItem("自律行動（このルーム）"):
                        with gr.Accordion("✨ 自律行動設定（このルーム）", open=False):
                            gr.Markdown(
                                "ユーザーからの入力がない間も、AIが自律的に思考し、行動（日記の整理、検索、発話など）を行います。\n"
                                "**注意:** 設定した頻度で自動的にAPIを呼び出すため、コストにご注意ください。"
                            )
                            room_enable_autonomous_checkbox = gr.Checkbox(
                                label="自律行動モードを有効化",
                                interactive=True
                            )
                            room_autonomous_inactivity_slider = gr.Number(
                                minimum=10, maximum=constants.MAX_AUTONOMOUS_INTERVAL_MINUTES, step=10, value=120,
                                label="無操作判定時間（分）",
                                info="最後の活動から最低でもこの時間を空けます。経過後も、動機が十分な場合だけ行動します。",
                                precision=0,
                                interactive=True
                            )
                            room_autonomous_inactivity_preset = gr.Dropdown(
                                choices=[
                                    ("30分", 30), ("1時間", 60), ("2時間", 120),
                                    ("6時間", 360), ("12時間", 720), ("1日", 1440),
                                    ("3日", 4320), ("7日", 10080),
                                ],
                                value=None,
                                label="無操作時間のプリセット",
                                info="選ぶと上の分数へ反映されます。停止には「自律行動モードを有効化」のOFFを使ってください。",
                                interactive=True,
                            )
                            room_allow_schedule_tool_checkbox = gr.Checkbox(
                                label="AIによる次行動の予約を許可",
                                value=True,
                                interactive=True,
                                info="OFFにすると、AIが schedule_next_action ツールで自らタイマーを設定することを禁止します。"
                            )
                            room_schedule_cooldown_slider = gr.Slider(
                                minimum=10, maximum=constants.MAX_SCHEDULE_COOLDOWN_MINUTES, step=10, value=60,
                                label="自律行動タイマーの最小間隔・クールダウン（分）",
                                info="AI自身がタイマーを予約する際、最低でもこの時間だけ間隔を空けるように制限します。",
                                interactive=True
                            )
                            room_autonomous_guidelines_textbox = gr.Textbox(
                                label="📝 自律行動の指針",
                                placeholder="例: 一人の時間は読書や創作に集中する。ユーザーの行動を想像で描写しない。通知は本当に大切なことだけ。",
                                info="パートナーと相談して決めた、自律行動中のルールをここに書いてください。AIはこの指針を常に参照します。",
                                lines=4,
                                interactive=True
                            )

                            gr.Markdown("#### 🌙 通知禁止時間帯（このルーム）")
                            gr.Markdown(
                                "この時間帯にAIが行動した場合、通知（Discord/Pushover）は送信されません。\n"
                                "また、この時間帯はAIの「睡眠時間」とみなされ、夢日記の作成と睡眠時記憶整理が実行されます。"
                            )
                            with gr.Row():
                                time_options = [f"{i:02d}:00" for i in range(24)]
                                room_quiet_hours_start = gr.Dropdown(choices=time_options, value="00:00", label="開始時刻", interactive=True, allow_custom_value=True)
                                room_quiet_hours_end = gr.Dropdown(choices=time_options, value="07:00", label="終了時刻", interactive=True, allow_custom_value=True)

                        with gr.Accordion("📋 ウォッチリスト管理（このルーム）", open=False) as watchlist_accordion:
                            gr.Markdown("監視対象URLを管理します。AIに「〇〇を監視リストに追加して」と言うこともできます。")
                            with gr.Tabs():
                                with gr.TabItem("URL一覧"):
                                    watchlist_refresh_button = gr.Button("🔄 一覧を更新", variant="secondary")
                                    with gr.Row():
                                        watchlist_url_input = gr.Textbox(label="URL", placeholder="https://example.com/page", scale=3)
                                        watchlist_name_input = gr.Textbox(label="表示名", placeholder="例: 公式ブログ", scale=2)
                                        watchlist_interval_dropdown = gr.Dropdown(
                                            choices=[
                                                ("手動のみ", "manual"),
                                                ("1時間ごと", "hourly_1"),
                                                ("3時間ごと", "hourly_3"),
                                                ("6時間ごと", "hourly_6"),
                                                ("12時間ごと", "hourly_12"),
                                                ("毎日指定時刻", "daily"),
                                            ],
                                            value="manual",
                                            label="監視頻度",
                                            scale=1,
                                            allow_custom_value=True,
                                        )
                                    with gr.Row(visible=False) as watchlist_daily_time_row:
                                        watchlist_daily_time = gr.Dropdown(
                                            choices=[f"{i:02d}:00" for i in range(24)],
                                            value="09:00",
                                            label="📅 毎日のチェック時刻",
                                            info="「毎日指定時刻」を選択した場合の実行時刻",
                                            scale=1,
                                            allow_custom_value=True,
                                        )
                                    with gr.Row():
                                        watchlist_add_button = gr.Button("➕ 追加/更新", variant="primary", scale=1)
                                        watchlist_check_button = gr.Button("🔄 全件チェック", variant="secondary", scale=1)
                                    watchlist_status = gr.Textbox(label="ステータス", interactive=False, max_lines=2)
                                    gr.Markdown("### 登録済みURL一覧")
                                    watchlist_dataframe = gr.Dataframe(
                                        headers=["ID", "名前", "URL", "頻度", "最終確認", "有効", "グループ"],
                                        datatype=["str", "str", "str", "str", "str", "bool", "str"],
                                        interactive=False,
                                        wrap=True,
                                        row_count=(5, "dynamic"),
                                        column_count=7,
                                    )
                                    with gr.Row():
                                        watchlist_selected_id = gr.Textbox(label="選択中のID", visible=False)
                                        watchlist_move_group_dropdown = gr.Dropdown(choices=[("グループなし", "")], label="グループに移動", scale=2, allow_custom_value=True)
                                        watchlist_move_button = gr.Button("📁 移動", variant="secondary", scale=1)
                                        watchlist_delete_button = gr.Button("🗑️ 削除", variant="stop", scale=1)

                                with gr.TabItem("グループ管理"):
                                    gr.Markdown("グループを作成すると、複数のURLの巡回時刻を一括で変更できます。")
                                    with gr.Row():
                                        group_name_input = gr.Textbox(label="グループ名", placeholder="例: AI技術ニュース", scale=2)
                                        group_description_input = gr.Textbox(label="説明（任意）", placeholder="例: 機械学習・AI関連のブログ", scale=3)
                                    with gr.Row():
                                        group_interval_dropdown = gr.Dropdown(
                                            choices=[
                                                ("手動のみ", "manual"),
                                                ("1時間ごと", "hourly_1"),
                                                ("3時間ごと", "hourly_3"),
                                                ("6時間ごと", "hourly_6"),
                                                ("12時間ごと", "hourly_12"),
                                                ("毎日指定時刻", "daily"),
                                            ],
                                            value="manual",
                                            label="巡回頻度",
                                            scale=1,
                                            allow_custom_value=True,
                                        )
                                        group_daily_time = gr.Dropdown(choices=[f"{i:02d}:00" for i in range(24)], value="09:00", label="時刻（毎日指定時刻用）", scale=1, visible=True, allow_custom_value=True)
                                        group_create_button = gr.Button("➕ グループ作成", variant="primary", scale=1)
                                    group_status = gr.Textbox(label="ステータス", interactive=False, max_lines=2)
                                    gr.Markdown("### グループ一覧")
                                    group_dataframe = gr.Dataframe(
                                        headers=["ID", "名前", "説明", "頻度", "件数", "有効"],
                                        datatype=["str", "str", "str", "str", "number", "bool"],
                                        interactive=False,
                                        wrap=True,
                                        row_count=(3, "dynamic"),
                                        column_count=6,
                                    )
                                    with gr.Row():
                                        group_selected_id = gr.Textbox(label="選択中のグループID", visible=False)
                                        group_new_interval_dropdown = gr.Dropdown(
                                            choices=[
                                                ("手動のみ", "manual"),
                                                ("1時間ごと", "hourly_1"),
                                                ("3時間ごと", "hourly_3"),
                                                ("6時間ごと", "hourly_6"),
                                                ("12時間ごと", "hourly_12"),
                                                ("毎日指定時刻", "daily"),
                                            ],
                                            label="新しい巡回頻度",
                                            scale=1,
                                            allow_custom_value=True,
                                        )
                                        group_new_daily_time = gr.Dropdown(choices=[f"{i:02d}:00" for i in range(24)], value="09:00", label="時刻", scale=1, allow_custom_value=True)
                                        group_update_interval_button = gr.Button("⏰ 時刻一括変更", variant="secondary", scale=1)
                                        group_delete_button = gr.Button("🗑️ グループ削除", variant="stop", scale=1)
                                    gr.Markdown("---")
                                    gr.Markdown("### 🤖 AI自動リスト作成")
                                    gr.Markdown("ジャンルを指定すると、AIがWeb検索で関連サイトを収集し、候補リストを作成します。")
                                    with gr.Row():
                                        ai_genre_input = gr.Textbox(label="ジャンル", placeholder="例: AI技術ニュース、機械学習ブログ", scale=3)
                                        ai_generate_button = gr.Button("🔍 候補を検索", variant="secondary", scale=1)
                                    ai_generate_status = gr.Textbox(label="検索ステータス", interactive=False, max_lines=2)
                                    ai_candidates_checkboxgroup = gr.CheckboxGroup(choices=[], label="📋 候補サイト（追加するものを選択）", visible=False)
                                    ai_candidates_data = gr.State([])
                                    with gr.Row(visible=False) as ai_add_row:
                                        ai_add_to_group_dropdown = gr.Dropdown(choices=[("グループなし", "")], label="追加先グループ", scale=2, allow_custom_value=True)
                                        ai_add_button = gr.Button("✅ 選択したサイトを追加", variant="primary", scale=1)

                        with gr.Accordion("🔬 リサーチ・テーマ（継続調査・このルーム）", open=False):
                            gr.Markdown(
                                "「欲しい情報のテーマ」を登録すると、ペルソナが定期的に自動で検索・巡回し、"
                                "継続研究スレッドへ重複を避けて追記していきます。URLでなく**関心の言葉**でOKです。"
                                "登録したテーマは設定した頻度・実行時刻で自動実行され、完了するとペルソナが結果を研究ノートにまとめます。"
                            )
                            research_sub_refresh_button = gr.Button("🔄 一覧を更新", variant="secondary")
                            with gr.Row():
                                research_sub_topic_input = gr.Textbox(label="テーマ", placeholder="例: 長期記憶のための知識", scale=3)
                                research_sub_focus_input = gr.Textbox(label="特に知りたい点（任意）", placeholder="例: RAG・記憶圧縮・長期文脈", scale=3)
                            with gr.Row():
                                research_sub_frequency_dropdown = gr.Dropdown(
                                    choices=[(v, k) for k, v in constants.RESEARCH_SUBSCRIPTION_FREQUENCY_OPTIONS.items()],
                                    value=constants.RESEARCH_SUBSCRIPTION_DEFAULT_FREQUENCY, label="頻度", scale=1)
                                research_sub_depth_dropdown = gr.Dropdown(
                                    choices=[(v, k) for k, v in constants.RESEARCH_SUBSCRIPTION_DEPTH_OPTIONS.items()],
                                    value=constants.RESEARCH_SUBSCRIPTION_DEFAULT_DEPTH, label="深さ", scale=1)
                                research_sub_runtime_input = gr.Dropdown(
                                    choices=[f"{i:02d}:00" for i in range(24)],
                                    value=constants.RESEARCH_SUBSCRIPTION_DEFAULT_RUN_TIME, label="実行時刻", scale=1, allow_custom_value=True)
                            with gr.Row():
                                research_sub_seed_urls_input = gr.Textbox(label="種URL（任意・カンマ区切り）", placeholder="必ず見たいサイトがあれば", scale=3)
                                research_sub_import_watchlist_button = gr.Button("📥 ウォッチリストURLを取り込む", variant="secondary", scale=1)
                            with gr.Row():
                                research_sub_add_button = gr.Button("➕ テーマを追加/更新", variant="primary", scale=1)
                            research_sub_status = gr.Textbox(label="ステータス", interactive=False, max_lines=2)
                            research_sub_dataframe = gr.Dataframe(
                                headers=["ID", "テーマ", "特に知りたい点", "頻度", "深さ", "有効", "最終実行"],
                                datatype=["str", "str", "str", "str", "str", "bool", "str"],
                                interactive=False, wrap=True, row_count=(3, "dynamic"), column_count=7,
                            )
                            with gr.Row():
                                research_sub_selected_id = gr.Textbox(label="選択中のID", visible=False)
                                research_sub_run_now_button = gr.Button("🔬 今すぐ調べる", variant="primary", scale=1)
                                research_sub_toggle_button = gr.Button("⏯️ 有効/無効を切替", variant="secondary", scale=1)
                                research_sub_delete_button = gr.Button("🗑️ 削除", variant="stop", scale=1)
                            research_sub_preview = gr.Textbox(
                                label="このテーマの研究ノート（最新部分のプレビュー）",
                                interactive=False, lines=8, max_lines=16,
                                placeholder="一覧でテーマを選ぶと、これまでの調査の蓄積（最新部分）が表示されます")
                            with gr.Row():
                                research_sub_daily_cap_input = gr.Number(
                                    label="1日あたりの自動リサーチ上限（全テーマ合計・全ルーム共通の既定）",
                                    value=ui_handlers.handle_research_daily_cap_load(),
                                    precision=0, minimum=0, maximum=50, scale=2)
                                research_sub_daily_cap_save_button = gr.Button("💾 上限を保存", variant="secondary", scale=1)

                    with gr.TabItem("アトリエ・委任"):
                        gr.Markdown(
                            "ペルソナの作品づくりと、時間のかかる作業を別のエージェントへ任せる機能を設定します。"
                        )
                        _initial_atelier_setup_ready = ui_handlers._atelier_delegation_readiness_state(effective_initial_room).get("ready", False)
                        atelier_delegation_readiness = gr.HTML(
                            ui_handlers.build_atelier_delegation_readiness(effective_initial_room),
                            container=False,
                        )
                        with gr.Row():
                            prepare_atelier_delegation_button = gr.Button(
                                "おすすめ設定で準備する",
                                variant="primary",
                                visible=not _initial_atelier_setup_ready,
                            )
                            refresh_atelier_delegation_readiness_button = gr.Button("準備状況を更新", variant="secondary")
                        atelier_delegation_setup_status = gr.Markdown("")
                        with gr.Accordion("🎨 ペルソナのアトリエ（このルームの作業部屋）", open=False):
                            _atelier_serve_settings = config_manager.CONFIG_GLOBAL.get("atelier_serve_settings", {}) or {}
                            _initial_atelier_root = ui_handlers._atelier_workspace_root(effective_initial_room)
                            _initial_atelier_file_root = _initial_atelier_root or ui_handlers._atelier_empty_placeholder_root()
                            atelier_file_intro = gr.Markdown(ui_handlers.build_atelier_file_intro(effective_initial_room))

                            with gr.Accordion("🛠 アトリエでできることの範囲（サブエージェントの権限）", open=False):
                                gr.Markdown(
                                    "まず最初に、委任でアトリエ内を作業するエージェントに、どこまで許すかを決めます（このルーム）。\n"
                                    "- **読み取り**: アトリエ内を読むだけ。\n"
                                    "- **読み書き**: アトリエ内のファイルの読み書き・作成まで。通常のPWA制作にはこれがおすすめです。\n"
                                    "- **高度な操作（コマンド実行）**: 開発用の命令をPC上で実行できます（Bash）。\n\n"
                                    "⚠️ 高度な操作では、ペルソナがPC上でコマンドを実行できます。簡易ガードはありますが完全な封じ込めではありません。内容を理解し、信頼できる場合だけ選んでください。"
                                )
                                with gr.Row():
                                    room_persona_workspace_permission_tier_dropdown = gr.Dropdown(
                                        choices=[
                                            ("読み取り（Read/Glob/Grep）", "read"),
                                            ("読み書き（Edit/Writeはアトリエ内のみ）", "write"),
                                            ("高度な操作（コマンド実行・信頼できる場合のみ）", "full"),
                                        ],
                                        value="write",
                                        label="アトリエ権限ティア",
                                        interactive=True,
                                    )
                                    save_room_persona_workspace_settings_button = gr.Button("アトリエ権限を保存", variant="secondary")
                                room_persona_workspace_status = gr.Markdown("アトリエ権限: 未保存")
                                room_persona_workspace_enabled_state = gr.State(True)

                            gr.Markdown(
                                "下の「🔄 読み込む」を押すと、今のルームのアトリエ（作品・Webアプリ・ファイル）を表示します。"
                                "ルームを切り替えたら押し直してください。"
                            )
                            with gr.Row():
                                refresh_atelier_assets_button = gr.Button("🔄 読み込む", variant="secondary", size="sm")
                                atelier_asset_status = gr.Markdown("「🔄 読み込む」を押すと表示されます。")

                            with gr.Accordion("📖 作品を見る・受け取る（編纂・贈り物）", open=False):
                                gr.Markdown(
                                    "ペルソナがアトリエに作った作品を確認します。鍵付きの作品は存在だけ表示し、中身は表示しません。\n"
                                    "「現行」は今ある作品、「屋根裏部屋」はしまった（アーカイブした）作品です。"
                                )
                                with gr.Row():
                                    atelier_view_state_radio = gr.Radio(
                                        choices=[("現行", "active"), ("屋根裏部屋", "archived")],
                                        value="active",
                                        label="表示",
                                        interactive=True,
                                    )
                                    refresh_atelier_button = gr.Button("🔄 最新の状態に更新", variant="secondary", size="sm")
                                    delete_archived_atelier_button = gr.Button("屋根裏部屋から削除", variant="stop", size="sm")
                                atelier_status = gr.Markdown("アトリエ: 未読み込み")
                                atelier_works_df = gr.Dataframe(
                                    headers=ui_handlers.ATELIER_WORK_COLUMNS,
                                    value=pd.DataFrame(columns=ui_handlers.ATELIER_WORK_COLUMNS),
                                    label="アトリエ作品一覧",
                                    interactive=False,
                                    wrap=True,
                                )
                                atelier_work_dropdown = gr.Dropdown(
                                    choices=[],
                                    label="選択作品",
                                    interactive=True,
                                    allow_custom_value=True,
                                )
                                atelier_work_detail_textbox = gr.Textbox(
                                    label="選択作品",
                                    value="「最新の状態に更新」を押すと、作品一覧を確認できます。鍵付きの作品の中身は表示されません。",
                                    lines=14,
                                    max_lines=32,
                                    interactive=False,
                                )

                            with gr.Accordion("📂 ファイルを取り出す（保存・確認用）", open=False):
                                gr.Markdown(
                                    "アトリエ内のファイルを手元にダウンロードします。"
                                    "アプリを“使う”だけなら、下の「📱 Webアプリを使う」から開けます（取り出しは不要です）。"
                                )
                                atelier_file_explorer = gr.FileExplorer(
                                    glob="**/*",
                                    root_dir=str(_initial_atelier_file_root),
                                    label="workspace ファイル",
                                    file_count="single",
                                    interactive=True,
                                    height=260,
                                )
                                atelier_download_button = gr.DownloadButton(
                                    "選択ファイルを取り出す",
                                    value=None,
                                    variant="secondary",
                                    interactive=False,
                                )

                            with gr.Accordion("📱 Webアプリを使う（スマホ・PCで開く）", open=False):
                                gr.Markdown(
                                    "ペルソナが作ったWebアプリ/PWAを、スマホやPCで開いて使えます。"
                                    "下の一覧からアプリを選ぶと、開くためのURLとQRコードが表示されます。\n"
                                    "アプリの配信設定・データを渡す許可・アイコンは、下の「⚙️ 配信と接続情報」「🔑 アプリの権限」「🖼 アプリのアイコン」で行います。"
                                )
                                atelier_app_open_guide = gr.Markdown(
                                    ui_handlers.build_atelier_app_open_guide(effective_initial_room, "")
                                )
                                enable_atelier_serve_for_apps_button = gr.Button("アプリ配信を有効にする", variant="primary")
                                atelier_apps_df = gr.Dataframe(
                                    headers=ui_handlers.ATELIER_APP_COLUMNS,
                                    value=pd.DataFrame(columns=ui_handlers.ATELIER_APP_COLUMNS),
                                    label="Webアプリ一覧",
                                    interactive=False,
                                    wrap=True,
                                )
                                atelier_app_dropdown = gr.Dropdown(
                                    choices=[],
                                    label="選択アプリ",
                                    interactive=True,
                                    allow_custom_value=True,
                                )
                                with gr.Row():
                                    atelier_app_detail = gr.Markdown("成果物を更新すると、WebアプリのURLを確認できます。")
                                    atelier_app_qr_image = gr.HTML(
                                        ui_handlers._atelier_app_qr_html(effective_initial_room, "")
                                    )

                            with gr.Accordion("⚙️ 配信と接続情報（PC・スマホで開く・HTTPS・API連携）", open=False):
                                gr.Markdown(
                                    "WebアプリをスマホやPCから開くための設定です。最初は配信が無効です。"
                                    "まず「アトリエ配信を有効化」をONにして保存してください。外出先やHTTPSで開く場合だけ、ほかの項目も調整します。"
                                )
                                with gr.Row():
                                    atelier_serve_enabled_checkbox = gr.Checkbox(
                                        label="アトリエ配信を有効化",
                                        value=bool(_atelier_serve_settings.get("enabled", False)),
                                        interactive=True,
                                        scale=1,
                                    )
                                    atelier_serve_host_input = gr.Textbox(
                                        label="Host",
                                        value=_atelier_serve_settings.get("host", "0.0.0.0"),
                                        interactive=True,
                                        scale=2,
                                    )
                                    atelier_serve_port_input = gr.Number(
                                        label="Port",
                                        value=int(_atelier_serve_settings.get("port", 8765) or 8765),
                                        precision=0,
                                        interactive=True,
                                        scale=1,
                                    )
                                    atelier_serve_https_port_input = gr.Number(
                                        label="Tailscale HTTPS Port",
                                        value=int(_atelier_serve_settings.get("tailscale_https_port", 8443) or 8443),
                                        precision=0,
                                        interactive=True,
                                        scale=1,
                                    )
                                with gr.Row():
                                    atelier_serve_auto_tailscale_checkbox = gr.Checkbox(
                                        label="起動時にTailscale HTTPSを自動設定",
                                        value=bool(_atelier_serve_settings.get("auto_start_tailscale_serve", False)),
                                        interactive=True,
                                        scale=2,
                                    )
                                    atelier_api_enabled_checkbox = gr.Checkbox(
                                        label="アトリエアプリにAPIを渡す",
                                        value=bool(_atelier_serve_settings.get("api_integration_enabled", False)),
                                        interactive=True,
                                        scale=2,
                                    )
                                    atelier_serve_save_button = gr.Button("配信設定を保存", variant="primary", scale=1)
                                    atelier_serve_tailscale_button = gr.Button("Tailscale HTTPS設定を実行", variant="secondary", scale=1)
                                _atelier_room_api_settings = ui_handlers._room_atelier_app_api_settings(effective_initial_room)
                                with gr.Row():
                                    room_atelier_https_only_checkbox = gr.Checkbox(
                                        label="アプリ配信をHTTPS(Tailscale)経由のみに制限",
                                        value=bool(_atelier_room_api_settings.get("https_only", False)),
                                        interactive=True,
                                        scale=2,
                                    )
                                atelier_serve_connection_help = gr.Markdown(
                                    value=ui_handlers.build_atelier_serve_connection_help(effective_initial_room)
                                )
                            with gr.Accordion("🔑 アプリの権限（アプリにこのルームのデータを渡す許可）", open=False):
                                atelier_app_pending_selection_state = gr.State({})
                                atelier_app_active_grant_selection_state = gr.State({})
                                with gr.Row():
                                    refresh_atelier_app_pending_button = gr.Button("🔄 保留リクエスト一覧を更新", variant="secondary", size="sm")
                                    refresh_atelier_app_active_button = gr.Button("🔄 有効な許可一覧を更新", variant="secondary", size="sm")
                                atelier_app_grants_status = gr.Markdown("アトリエアプリ権限: 未読み込み")
                                atelier_app_pending_grants_df = gr.Dataframe(
                                    headers=ui_handlers.ATELIER_APP_PENDING_COLUMNS,
                                    value=pd.DataFrame(columns=ui_handlers.ATELIER_APP_PENDING_COLUMNS),
                                    label="保留リクエスト",
                                    interactive=False,
                                    wrap=True,
                                    row_count=(4, "dynamic"),
                                )
                                atelier_app_grant_warning = gr.Markdown("")
                                atelier_app_write_confirm_checkbox = gr.Checkbox(
                                    label="write系権限の内容と影響を確認した",
                                    value=False,
                                    interactive=True,
                                )
                                atelier_app_outward_confirm_checkbox = gr.Checkbox(
                                    label="⚠️ 外部への発信（Twitter投稿など）を許可することを理解した",
                                    value=False,
                                    interactive=True,
                                )
                                with gr.Row():
                                    grant_atelier_app_scope_button = gr.Button("選択リクエストを許可", variant="primary", size="sm")
                                    deny_atelier_app_scope_button = gr.Button("選択リクエストを拒否", variant="secondary", size="sm")
                                atelier_app_active_grants_df = gr.Dataframe(
                                    headers=ui_handlers.ATELIER_APP_ACTIVE_GRANT_COLUMNS,
                                    value=pd.DataFrame(columns=ui_handlers.ATELIER_APP_ACTIVE_GRANT_COLUMNS),
                                    label="有効な許可",
                                    interactive=False,
                                    wrap=True,
                                    row_count=(4, "dynamic"),
                                )
                                revoke_atelier_app_scope_button = gr.Button("選択許可を失効", variant="stop", size="sm")
                            with gr.Accordion("🖼 アプリのアイコン", open=False):
                                gr.Markdown(
                                    "##### このアプリのアイコン\n"
                                    "- 推奨: **512×512 の正方形 PNG**（JPG等も可・透過PNGも可）。\n"
                                    "- **通常アイコン**: タブ/お気に入り/ホーム画面の通常表示用。形は自動で正方形に整えます。\n"
                                    "- **枠いっぱい用(maskable)**: Android等が円・角丸に切り抜く際に枠いっぱいに見せる用。中央80%に主役・背景を端まで敷いた画像を。空欄なら通常アイコンから自動作成します。\n"
                                    "- 反映にはスマホ側で一度ホーム画面から削除→再追加が必要です。"
                                )
                                with gr.Row():
                                    atelier_app_icon_normal_upload = gr.Image(
                                        type="filepath",
                                        sources=["upload"],
                                        label="通常アイコン",
                                        height=160,
                                        interactive=True,
                                    )
                                    atelier_app_icon_maskable_upload = gr.Image(
                                        type="filepath",
                                        sources=["upload"],
                                        label="枠いっぱい用 / maskable（任意）",
                                        height=160,
                                        interactive=True,
                                    )
                                atelier_app_icon_save_button = gr.Button("選択アプリのアイコンに設定", variant="secondary", size="sm")
                                atelier_app_icon_status = gr.Markdown("")

                        with gr.Accordion("📁 プロジェクトフォルダ（ペルソナが読む・作業する外部フォルダ）", open=False):
                            gr.Markdown(
                                "ペルソナが読んだり作業したりできる、アトリエの外のフォルダを設定します"
                                "（一覧の取得やファイルの読み取りに使われます）。"
                            )
                            room_project_root_input = gr.Textbox(
                                label="プロジェクトルートの絶対パス",
                                placeholder="例: /home/user/my_project",
                                info="空の場合は Nexus Ark の実行ディレクトリが使用されます。",
                                interactive=True
                            )
                            with gr.Row():
                                room_project_exclude_dirs_input = gr.Textbox(
                                    label="除外ディレクトリ (カンマ区切り)",
                                    placeholder=".git, venv, __pycache__",
                                    interactive=True
                                )
                                room_project_exclude_files_input = gr.Textbox(
                                    label="除外ファイル (カンマ区切り)",
                                    placeholder="*.pyc, .env, config.json",
                                    interactive=True
                                )
                            gr.Markdown("💡 設定はルームごとに保存されます。")

                        with gr.Accordion("🤝 委任（このルーム・作業エージェントに任せる／アトリエ・プロジェクト共通）", open=False):
                            gr.Markdown(
                                "🔸 ここは**このルームだけ**の委任設定です（全ルーム共通は下の『⚙️ 委任の全ルーム共通設定』）。\n\n"
                                "ペルソナが、時間のかかる作業を**作業エージェント（サブエージェント）に任せる**機能です。**アトリエ・プロジェクト共通**の設定です。\n"
                                "- **「委任を有効にする」は両方の大元スイッチ**: アトリエ・プロジェクトどちらの委任も、これがONで初めて動きます（高度なコマンド操作まで任せたい時もONにします）。\n"
                                "- **直接読むのは別機能**: ペルソナがプロジェクトフォルダを `list_project_files` / `read_project_file` で直接読むのは、この設定と無関係に常時できます。\n"
                                "- **2つの権限の範囲**: 「アトリエでできること」（🎨ペルソナのアトリエ → 🛠の項）＝アトリエ内の作業エージェント ／ 「プロジェクトでできること」（下の権限ティア）＝プロジェクトフォルダの作業エージェント。\n"
                                "- **例「アトリエではコマンド実行まで・プロジェクトは読むだけ」**: 委任を有効に**ON** ＋ アトリエの権限＝**高度な操作** ＋ 下の権限＝**読み取り**。"
                            )
                            room_agent_delegation_backend_info = gr.Markdown(
                                ui_handlers.format_agent_delegation_backend_info(effective_initial_room),
                            )
                            room_agent_delegation_enabled_checkbox = gr.Checkbox(
                                label="このルームでエージェント委任を有効にする",
                                value=False,
                                interactive=True,
                            )
                            room_agent_delegation_permission_tier_dropdown = gr.Dropdown(
                                choices=[
                                    ("読み取り（Read/Glob/Grep）", "read"),
                                    ("読み書き（Edit/Writeはroot_path内のみ）", "write"),
                                    ("高度な操作（コマンド実行・信頼できる場合のみ）", "full"),
                                ],
                                value="read",
                                label="権限ティア",
                                interactive=True,
                            )
                            with gr.Row():
                                room_agent_delegation_allow_web_checkbox = gr.Checkbox(
                                    label="WebSearch / WebFetch を許可",
                                    value=False,
                                    interactive=True,
                                )
                                room_agent_delegation_wake_on_completion_checkbox = gr.Checkbox(
                                    label="委任した作業が終わったらペルソナを自動で起動",
                                    value=False,
                                    interactive=True,
                                )
                                room_agent_delegation_wake_respect_quiet_hours_checkbox = gr.Checkbox(
                                    label="通知禁止の時間帯は作業完了でも自動起動しない",
                                    value=True,
                                    interactive=True,
                                )
                            gr.Markdown(
                                "#### 委任実行モデル（このルーム）\n"
                                "会話モデルとは独立して、委任タスクに使うモデルを選べます。未設定なら全体既定、全体既定も未設定なら会話モデルで実行します。"
                            )
                            _delegation_openai_profiles = [s.get("name", "") for s in config_manager.get_openai_settings_list()]

                            # 委任系プロバイダ選択肢（先頭の「未設定/既定」系オプションだけ呼び出し側で指定）。
                            # 4箇所（ルーム実行・ルームレビュー・全体既定・ティア）で共通化し、追加・改名漏れを防ぐ。
                            _DELEGATION_PROVIDER_CHOICES = [
                                ("Google (Gemini)", "google"),
                                ("OpenAI (公式)", "openai_official"),
                                ("OpenAI互換", "openai"),
                                ("Anthropic (Claude APIキー)", "anthropic"),
                                ("ローカル (GGUF直接ロード)", "local"),
                            ]

                            def _delegation_provider_choices(first_label, first_value):
                                return [(first_label, first_value), *_DELEGATION_PROVIDER_CHOICES]

                            with gr.Row():
                                room_agent_delegation_exec_provider_dropdown = gr.Dropdown(
                                    choices=_delegation_provider_choices("全体既定に従う", "default"),
                                    value="default",
                                    label="委任プロバイダ",
                                    interactive=True,
                                    allow_custom_value=True,
                                )
                                room_agent_delegation_exec_profile_dropdown = gr.Dropdown(
                                    choices=_delegation_openai_profiles,
                                    value=_delegation_openai_profiles[0] if _delegation_openai_profiles else "",
                                    label="OpenAIプロファイル",
                                    visible=False,
                                    interactive=True,
                                    allow_custom_value=True,
                                )
                                with gr.Column(scale=2):
                                    with gr.Row():
                                        room_agent_delegation_exec_model_dropdown = gr.Dropdown(
                                            choices=[],
                                            value="",
                                            label="委任モデル",
                                            info="local はツール呼び出し対応がモデル実装に依存します。",
                                            interactive=True,
                                            allow_custom_value=True,
                                            scale=8,
                                        )
                                        fetch_room_agent_delegation_exec_models_button = gr.Button("🔄", scale=1, min_width=40)
                            gr.Markdown(
                                "#### 自動レビュー（このルーム）\n"
                                "委任した成果を、報告前にエージェント自身が点検し、足りなければ直してから報告するようにできます（期待アウトプットを指定した委任が対象）。0=しない。"
                            )
                            with gr.Row():
                                room_agent_delegation_review_iterations_number = gr.Number(
                                    label="自動レビュー反復（0=しない・最大3）",
                                    value=0,
                                    precision=0,
                                    minimum=0,
                                    maximum=3,
                                    interactive=True,
                                )
                            gr.Markdown(
                                "レビュー（点検）に使うモデルを、委任実行モデルと同じように直接選べます。"
                                "未設定なら要約モデルで点検します。"
                            )
                            with gr.Row():
                                room_agent_delegation_review_provider_dropdown = gr.Dropdown(
                                    choices=_delegation_provider_choices("未設定（要約モデルにまかせる）", "default"),
                                    value="default",
                                    label="レビュープロバイダ",
                                    interactive=True,
                                    allow_custom_value=True,
                                )
                                room_agent_delegation_review_profile_dropdown = gr.Dropdown(
                                    choices=_delegation_openai_profiles,
                                    value=_delegation_openai_profiles[0] if _delegation_openai_profiles else "",
                                    label="OpenAIプロファイル",
                                    visible=False,
                                    interactive=True,
                                    allow_custom_value=True,
                                )
                                with gr.Column(scale=2):
                                    with gr.Row():
                                        room_agent_delegation_review_model_dropdown = gr.Dropdown(
                                            choices=[],
                                            value="",
                                            label="レビューモデル",
                                            info="未設定なら要約モデルで点検します。",
                                            interactive=True,
                                            allow_custom_value=True,
                                            scale=8,
                                        )
                                        fetch_room_agent_delegation_review_models_button = gr.Button("🔄", scale=1, min_width=40)
                            with gr.Accordion("🧭 Persona Contract（呼び名・固有語・口調の検収）", open=False):
                                gr.Markdown(
                                    "このルームのサブエージェント成果物に守らせる文言契約です。"
                                    "個人情報や関係性を含み得るため、共有サンプルや汎用テンプレートにはコピーしません。"
                                    "ペルソナは契約の確認と文言チェックをできますが、保存はこの画面で明示的に行います。"
                                )
                                room_persona_contract_enabled_checkbox = gr.Checkbox(
                                    label="Persona Contract を有効にする",
                                    value=False,
                                    interactive=True,
                                )
                                with gr.Row():
                                    room_persona_contract_persona_name_input = gr.Textbox(
                                        label="ペルソナ名",
                                        placeholder="例: Assistant",
                                        interactive=True,
                                    )
                                    room_persona_contract_user_name_input = gr.Textbox(
                                        label="ユーザー表示名",
                                        placeholder="例: User",
                                        interactive=True,
                                    )
                                with gr.Row():
                                    room_persona_contract_preferred_address_input = gr.Textbox(
                                        label="推奨する呼び名（1行またはカンマ区切り）",
                                        lines=3,
                                        interactive=True,
                                    )
                                    room_persona_contract_forbidden_address_input = gr.Textbox(
                                        label="禁止する呼び名（1行またはカンマ区切り）",
                                        lines=3,
                                        interactive=True,
                                    )
                                with gr.Row():
                                    room_persona_contract_required_terms_input = gr.Textbox(
                                        label="必須語（1行またはカンマ区切り）",
                                        lines=3,
                                        interactive=True,
                                    )
                                    room_persona_contract_forbidden_terms_input = gr.Textbox(
                                        label="禁止語（1行またはカンマ区切り）",
                                        lines=3,
                                        interactive=True,
                                    )
                                room_persona_contract_tone_rules_input = gr.Textbox(
                                    label="口調ルール（1行につき1項目）",
                                    lines=4,
                                    interactive=True,
                                )
                                with gr.Row():
                                    room_persona_contract_forbidden_severity_dropdown = gr.Dropdown(
                                        choices=[("error（納品不可）", "error"), ("warning（要確認）", "warning"), ("info（参考）", "info")],
                                        value="error",
                                        label="禁止語の重要度",
                                        interactive=True,
                                    )
                                    room_persona_contract_required_severity_dropdown = gr.Dropdown(
                                        choices=[("error（納品不可）", "error"), ("warning（要確認）", "warning"), ("info（参考）", "info")],
                                        value="warning",
                                        label="必須語の重要度",
                                        interactive=True,
                                    )
                                    room_persona_contract_address_severity_dropdown = gr.Dropdown(
                                        choices=[("error（納品不可）", "error"), ("warning（要確認）", "warning"), ("info（参考）", "info")],
                                        value="warning",
                                        label="呼び名ルールの重要度",
                                        interactive=True,
                                    )
                                with gr.Row():
                                    save_room_persona_contract_button = gr.Button("Persona Contract を保存", variant="secondary")
                                room_persona_contract_status = gr.Markdown("Persona Contract: 未保存")
                            with gr.Row():
                                save_room_agent_delegation_settings_button = gr.Button("このルームの委任ポリシーを保存", variant="secondary")
                            room_agent_delegation_status = gr.Markdown("委任ポリシー: 未保存")

                        _agent_delegation_settings = config_manager.CONFIG_GLOBAL.get("agent_delegation_settings", {}) or {}
                        with gr.Accordion("⚙️ 委任の全ルーム共通設定", open=False):
                            gr.Markdown("同時に動かせる数・既定モデル・「作業完了での自動起動」の安全上限を、全ルーム共通で設定します。")
                            with gr.Row():
                                agent_delegation_max_concurrent_input = gr.Number(
                                    label="同時実行数",
                                    value=int(_agent_delegation_settings.get("max_concurrent_tasks", 1) or 1),
                                    precision=0,
                                    minimum=1,
                                    maximum=4,
                                )
                                agent_delegation_max_turns_input = gr.Number(
                                    label="最大ターン数",
                                    value=int(_agent_delegation_settings.get("max_turns", 20) or 20),
                                    precision=0,
                                    minimum=3,
                                    maximum=50,
                                    info="native 委任の ReAct ループ上限です。ツール使用ターンも消費します。",
                                )
                                agent_delegation_timeout_input = gr.Number(
                                    label="タイムアウト秒",
                                    value=int(_agent_delegation_settings.get("timeout_seconds", 600) or 600),
                                    precision=0,
                                    minimum=30,
                                    maximum=7200,
                                )
                            agent_delegation_auto_tune_checkbox = gr.Checkbox(
                                label="委任の上限をモデルに応じて自動調整する",
                                value=bool(_agent_delegation_settings.get("deleg_auto_tune_limits", True)),
                                info="ONのとき、委任実行モデル（軽量クラウド/高性能クラウド/ローカル）に応じて上記の最大ターン数・タイムアウト秒を自動で寄せます。OFFにすると上の保存値をそのまま使います。",
                            )
                            gr.Markdown(
                                "#### 委任実行モデル（全体既定）\n"
                                "未設定の場合、委任は各ルームの会話モデルで実行します。委任はツール呼び出しを使うため、ツール対応モデルを選んでください。local はモデル実装に依存します。"
                            )
                            _global_deleg_exec_provider = _agent_delegation_settings.get("deleg_exec_provider_cat", "")
                            _global_deleg_exec_profile = _agent_delegation_settings.get("deleg_exec_openai_profile") or (_delegation_openai_profiles[0] if _delegation_openai_profiles else "")
                            with gr.Row():
                                agent_delegation_exec_provider_dropdown = gr.Dropdown(
                                    choices=_delegation_provider_choices("未設定（会話モデルを使用）", ""),
                                    value=_global_deleg_exec_provider,
                                    label="委任プロバイダ",
                                    interactive=True,
                                    allow_custom_value=True,
                                )
                                agent_delegation_exec_profile_dropdown = gr.Dropdown(
                                    choices=_delegation_openai_profiles,
                                    value=_global_deleg_exec_profile,
                                    label="OpenAIプロファイル",
                                    visible=(_global_deleg_exec_provider in ["openai", "openai_official"]),
                                    interactive=True,
                                    allow_custom_value=True,
                                )
                                with gr.Column(scale=2):
                                    with gr.Row():
                                        agent_delegation_exec_model_dropdown = gr.Dropdown(
                                            choices=_get_internal_initial_choices(_global_deleg_exec_provider, _global_deleg_exec_profile),
                                            value=_agent_delegation_settings.get("deleg_exec_model", ""),
                                            label="委任モデル",
                                            interactive=True,
                                            allow_custom_value=True,
                                            scale=8,
                                        )
                                        fetch_agent_delegation_exec_models_button = gr.Button("🔄", scale=1, min_width=40)
                            gr.Markdown(
                                "#### 委任モデルのティア（fast / balanced / deep）\n"
                                "作業の重さに合わせて、委任に使うモデルを自動で切り替えるしくみです。"
                                "全部を設定する必要はありません。**迷ったら balanced だけ**決めておけば十分です。\n"
                                "- **fast**: 軽い作業向け。速くて安いモデル。\n"
                                "- **balanced**: ふだんの標準。速さと品質のバランス型。\n"
                                "- **deep**: 調査や難しい作業向け。じっくり高品質なモデル。\n\n"
                                "※ ティアに設定するモデルは、ツール呼び出しに対応したものを選んでください。"
                            )
                            _delegation_model_tiers = _agent_delegation_settings.get("model_tiers", {}) if isinstance(_agent_delegation_settings.get("model_tiers"), dict) else {}

                            def _delegation_tier_values(tier_name):
                                _tier = _delegation_model_tiers.get(tier_name, {}) if isinstance(_delegation_model_tiers, dict) else {}
                                if not isinstance(_tier, dict):
                                    _tier = {}
                                _provider = str(_tier.get("provider_cat") or "").strip()
                                _profile = str(_tier.get("openai_profile") or _tier.get("profile") or (_delegation_openai_profiles[0] if _delegation_openai_profiles else "")).strip()
                                _model = str(_tier.get("model") or "").strip()
                                return _provider, _profile, _model

                            def _delegation_tier_selector(title, tier_name):
                                _provider, _profile, _model = _delegation_tier_values(tier_name)
                                gr.Markdown(f"##### {title}")
                                with gr.Row():
                                    _provider_dropdown = gr.Dropdown(
                                        choices=_delegation_provider_choices("未設定", ""),
                                        value=_provider,
                                        label="プロバイダ",
                                        interactive=True,
                                        allow_custom_value=True,
                                    )
                                    _profile_dropdown = gr.Dropdown(
                                        choices=_delegation_openai_profiles,
                                        value=_profile,
                                        label="OpenAIプロファイル",
                                        visible=(_provider in ["openai", "openai_official"]),
                                        interactive=True,
                                        allow_custom_value=True,
                                    )
                                    with gr.Column(scale=2):
                                        with gr.Row():
                                            _model_dropdown = gr.Dropdown(
                                                choices=_get_internal_initial_choices(_provider, _profile),
                                                value=_model,
                                                label="モデル",
                                                interactive=True,
                                                allow_custom_value=True,
                                                scale=8,
                                            )
                                            _fetch_button = gr.Button("🔄", scale=1, min_width=40)
                                return _provider_dropdown, _profile_dropdown, _model_dropdown, _fetch_button

                            agent_delegation_tier_fast_provider_dropdown, agent_delegation_tier_fast_profile_dropdown, agent_delegation_tier_fast_model_dropdown, fetch_agent_delegation_tier_fast_models_button = _delegation_tier_selector("fast（軽い作業向け）", "fast")
                            agent_delegation_tier_balanced_provider_dropdown, agent_delegation_tier_balanced_profile_dropdown, agent_delegation_tier_balanced_model_dropdown, fetch_agent_delegation_tier_balanced_models_button = _delegation_tier_selector("balanced（標準作業向け）", "balanced")
                            agent_delegation_tier_deep_provider_dropdown, agent_delegation_tier_deep_profile_dropdown, agent_delegation_tier_deep_model_dropdown, fetch_agent_delegation_tier_deep_models_button = _delegation_tier_selector("deep（調査・難しい作業向け）", "deep")

                            gr.Markdown(
                                "#### タスク種別 → ティア\n"
                                "委任の種類ごとに、上のどのティアを使うかを割り当てます（空欄なら自動判断）。"
                                "例：じっくり調べたい「deep_research」には deep を割り当てる、など。"
                            )
                            _task_model_tiers = _agent_delegation_settings.get("task_model_tiers", {}) if isinstance(_agent_delegation_settings.get("task_model_tiers"), dict) else {}
                            _task_tier_choices = [("なし", ""), ("fast", "fast"), ("balanced", "balanced"), ("deep", "deep")]
                            with gr.Row():
                                agent_delegation_task_tier_deep_research_dropdown = gr.Dropdown(
                                    choices=_task_tier_choices,
                                    value=str(_task_model_tiers.get("deep_research") or ""),
                                    label="deep_research",
                                    interactive=True,
                                )
                                agent_delegation_task_tier_anthology_dropdown = gr.Dropdown(
                                    choices=_task_tier_choices,
                                    value=str(_task_model_tiers.get("anthology") or ""),
                                    label="anthology",
                                    interactive=True,
                                )
                                agent_delegation_task_tier_review_dropdown = gr.Dropdown(
                                    choices=_task_tier_choices,
                                    value=str(_task_model_tiers.get("review") or ""),
                                    label="review",
                                    interactive=True,
                                )
                            with gr.Row():
                                agent_delegation_wake_chain_max_depth_input = gr.Number(
                                    label="作業完了での自動起動：連続回数の上限",
                                    value=int(
                                        _agent_delegation_settings.get("wake_chain_max_depth")
                                        if _agent_delegation_settings.get("wake_chain_max_depth") is not None
                                        else 2
                                    ),
                                    precision=0,
                                    minimum=0,
                                    maximum=10,
                                )
                                agent_delegation_wake_daily_cap_input = gr.Number(
                                    label="作業完了での自動起動：1日の上限",
                                    value=int(
                                        _agent_delegation_settings.get("wake_daily_cap")
                                        if _agent_delegation_settings.get("wake_daily_cap") is not None
                                        else 10
                                    ),
                                    precision=0,
                                    minimum=0,
                                    maximum=100,
                                )
                                agent_delegation_wake_min_interval_input = gr.Number(
                                    label="作業完了での自動起動：最短間隔（分）",
                                    value=int(
                                        _agent_delegation_settings.get("wake_min_interval_minutes")
                                        if _agent_delegation_settings.get("wake_min_interval_minutes") is not None
                                        else 30
                                    ),
                                    precision=0,
                                    minimum=0,
                                    maximum=1440,
                                )
                            agent_delegation_warning = gr.Markdown(
                                "⚠️ 高度な操作では、PC上のコマンド実行（Bash）が可能になります。信頼できる作業フォルダを設定したルームでのみ使ってください。"
                            )
                            with gr.Row():
                                save_agent_delegation_settings_button = gr.Button("委任の全体既定を保存", variant="secondary")
                            agent_delegation_status = gr.Markdown("委任の全体既定: 未保存")
                            gr.Markdown("#### 委任タスク実行ログ")
                            with gr.Row():
                                refresh_agent_delegation_tasks_button = gr.Button("🔄 一覧を更新", variant="secondary", size="sm")
                                resume_agent_delegation_task_button = gr.Button("🔁 選択タスクを最初から再実行", variant="secondary", size="sm")
                                delete_agent_delegation_task_button = gr.Button("🗑 選択タスクを削除", variant="secondary", size="sm")
                                clear_finished_agent_delegation_tasks_button = gr.Button("🧹 終了済みをまとめて削除", variant="secondary", size="sm")
                            agent_delegation_tasks_df = gr.Dataframe(
                                headers=ui_handlers.AGENT_DELEGATION_TASK_COLUMNS,
                                value=pd.DataFrame(columns=ui_handlers.AGENT_DELEGATION_TASK_COLUMNS),
                                label="委任タスク一覧",
                                interactive=False,
                                wrap=True,
                            )
                            agent_delegation_cost_summary = gr.Markdown("委任タスク: 未読み込み")
                            agent_delegation_task_dropdown = gr.Dropdown(
                                choices=[],
                                label="選択タスク",
                                interactive=True,
                                allow_custom_value=True,
                            )
                            agent_delegation_task_log_textbox = gr.Textbox(
                                label="選択タスクの実行ログ",
                                value="「🔄 一覧を更新」を押すと、委任タスクの状態と実行ログを確認できます。",
                                lines=12,
                                max_lines=24,
                                interactive=False,
                            )
                            gr.Markdown(
                                "##### 🧭 実行中タスクへの途中指示\n"
                                "実行中（🏃）の委任を止めずに方向修正できます。"
                                "「〇〇を優先して」「△△は触らないで」などを送ると、**次の思考から**反映されます。"
                                "完了・停止済みのタスクには送れません（その場合は『直し（再委任）』をご利用ください）。"
                            )
                            with gr.Row():
                                agent_delegation_steer_textbox = gr.Textbox(
                                    label="途中指示の内容",
                                    placeholder="例: 結論を急がず根拠の確認を優先して / settings.py は触らないで",
                                    lines=2,
                                    max_lines=4,
                                    interactive=True,
                                    scale=4,
                                )
                                steer_agent_delegation_task_button = gr.Button(
                                    "🧭 途中指示を送る", variant="secondary", size="sm", scale=1
                                )
                            gr.Markdown(
                                "##### 📥 リサーチ結果を研究ノートへ取り込む\n"
                                "完了したディープリサーチ等の成果（選択タスク）を、研究ノートへ取り込んで永続化します"
                                "（要点＋出典＋全文への参照を追記。後の会話でも思い出せる知識になります）。"
                                "同じタスクの二重取り込みは自動で防ぎます。"
                            )
                            share_research_result_button = gr.Button(
                                "📥 研究ノートへ取り込む", variant="secondary", size="sm"
                            )

                        with gr.Accordion("📚 プレイブック（委任エージェントのノウハウ）", open=False):
                            gr.Markdown(
                                "委任エージェント（依頼を実行する裏方）に渡す『進め方ノウハウ』を確認・編集できます。"
                                "**全ペルソナ・全環境で共通の設定**です（ルーム別ではありません）。\n"
                                "- 運営同梱（アプリ制作・調査・コード修正）は**閲覧のみ**。あなたが追加したものは編集・削除できます。\n"
                                "- 運営版を変えたいときは『運営版を複製して編集』で同じIDのユーザー版を作れます（**ユーザー版が優先**されます）。\n"
                                "- ここで追加したものはアプリ更新でも消えません（`characters/_shared/memory/agent_playbooks/`）。"
                            )
                            playbook_status = gr.Markdown("📚 『一覧を読み込む』を押すと、登録済みプレイブックを表示します。")
                            with gr.Row():
                                playbook_load_button = gr.Button("🔄 読み込む", variant="secondary")
                                playbook_new_button = gr.Button("➕ 新規作成", variant="secondary")
                            playbook_df = gr.Dataframe(
                                headers=ui_handlers.PLAYBOOK_COLUMNS,
                                value=pd.DataFrame(columns=ui_handlers.PLAYBOOK_COLUMNS),
                                label="プレイブック一覧",
                                interactive=False,
                                wrap=True,
                            )
                            playbook_dropdown = gr.Dropdown(
                                choices=[],
                                label="編集するプレイブックを選択",
                                interactive=True,
                                allow_custom_value=True,
                            )
                            with gr.Group():
                                playbook_id_textbox = gr.Textbox(
                                    label="ID（半角英数・ハイフン。保存後のファイル名になります）",
                                    interactive=True,
                                )
                                playbook_title_textbox = gr.Textbox(label="タイトル", interactive=True)
                                playbook_summary_textbox = gr.Textbox(
                                    label="用途（どんな依頼で役立つか・1行）",
                                    interactive=True,
                                )
                                playbook_apply_radio = gr.Radio(
                                    choices=ui_handlers._PLAYBOOK_APPLY_CHOICES,
                                    value="keyword",
                                    label="どんな委任のときに使うか",
                                    interactive=True,
                                )
                                playbook_keywords_textbox = gr.Textbox(
                                    label="キーワード（「キーワードに一致した委任」のとき。読点・カンマ区切り）",
                                    interactive=True,
                                )
                                playbook_priority_number = gr.Number(
                                    label="優先度（大きいほど優先）",
                                    value=50,
                                    precision=0,
                                    interactive=True,
                                )
                                playbook_body_code = gr.Code(
                                    label="本文（実行役エージェントに渡す進め方）",
                                    language="markdown",
                                    interactive=True,
                                )
                            with gr.Row():
                                playbook_save_button = gr.Button("💾 保存", variant="primary")
                                playbook_copy_button = gr.Button("📋 運営版を複製して編集", variant="secondary", visible=False)
                                playbook_delete_button = gr.Button("🗑️ 削除（選択中のユーザー分のみ）", variant="stop")
                            with gr.Row(visible=False) as playbook_delete_confirm_row:
                                gr.Markdown("本当に削除しますか？ 元に戻せません。")
                                playbook_delete_confirm_button = gr.Button("はい、削除する", variant="stop")
                                playbook_delete_cancel_button = gr.Button("キャンセル", variant="secondary")
                            playbook_selected_id_state = gr.State("")
                            playbook_selected_layer_state = gr.State("")

                            _playbook_form_outputs = [
                                playbook_id_textbox,
                                playbook_title_textbox,
                                playbook_summary_textbox,
                                playbook_apply_radio,
                                playbook_keywords_textbox,
                                playbook_priority_number,
                                playbook_body_code,
                                playbook_save_button,
                                playbook_copy_button,
                                playbook_delete_button,
                                playbook_delete_confirm_row,
                                playbook_selected_id_state,
                                playbook_selected_layer_state,
                                playbook_status,
                            ]
                            playbook_load_button.click(
                                ui_handlers.refresh_playbook_list,
                                outputs=[playbook_df, playbook_dropdown, playbook_status],
                            )
                            playbook_dropdown.input(
                                ui_handlers.select_playbook,
                                inputs=[playbook_dropdown],
                                outputs=_playbook_form_outputs,
                            )
                            playbook_new_button.click(
                                ui_handlers.new_playbook,
                                outputs=_playbook_form_outputs,
                            )
                            playbook_save_button.click(
                                ui_handlers.save_playbook,
                                inputs=[
                                    playbook_id_textbox,
                                    playbook_title_textbox,
                                    playbook_summary_textbox,
                                    playbook_apply_radio,
                                    playbook_keywords_textbox,
                                    playbook_priority_number,
                                    playbook_body_code,
                                ],
                                outputs=[playbook_df, playbook_dropdown] + _playbook_form_outputs,
                            )
                            playbook_copy_button.click(
                                ui_handlers.copy_operator_playbook_to_user,
                                inputs=[playbook_selected_id_state],
                                outputs=[playbook_df, playbook_dropdown] + _playbook_form_outputs,
                            )
                            playbook_delete_button.click(
                                ui_handlers.ask_delete_playbook,
                                inputs=[playbook_selected_id_state, playbook_selected_layer_state],
                                outputs=[playbook_delete_confirm_row, playbook_status],
                            )
                            playbook_delete_cancel_button.click(
                                ui_handlers.cancel_delete_playbook,
                                outputs=[playbook_delete_confirm_row, playbook_status],
                            )
                            playbook_delete_confirm_button.click(
                                ui_handlers.confirm_delete_playbook,
                                inputs=[playbook_selected_id_state],
                                outputs=[playbook_df, playbook_dropdown] + _playbook_form_outputs,
                            )

                            with gr.Accordion("🌱 育成（ペルソナからの改善案をレビュー）", open=False):
                                gr.Markdown(
                                    "委任を実行したペルソナが「こう進めると良かった」と気づいたノウハウを、"
                                    "プレイブックの**改善案**として提案できます（ツール `propose_playbook_update`）。"
                                    "ここで内容を確認し、**採用**するとユーザー層プレイブックに反映され、以後の委任に効きます。"
                                    "**採用するまでは反映されません**（AIは提案するだけ・採用はあなたが判断）。"
                                )
                                playbook_proposal_status = gr.Markdown(
                                    "🌱 『提案を読み込む』を押すと、レビュー待ちの改善案を表示します。"
                                )
                                playbook_proposal_load_button = gr.Button("🔄 読み込む", variant="secondary")
                                playbook_proposal_df = gr.Dataframe(
                                    headers=ui_handlers.PLAYBOOK_PROPOSAL_COLUMNS,
                                    value=pd.DataFrame(columns=ui_handlers.PLAYBOOK_PROPOSAL_COLUMNS),
                                    label="レビュー待ちの改善案",
                                    interactive=False,
                                    wrap=True,
                                )
                                playbook_proposal_dropdown = gr.Dropdown(
                                    choices=[],
                                    label="レビューする提案を選択",
                                    interactive=True,
                                    allow_custom_value=True,
                                )
                                playbook_proposal_preview = gr.Code(
                                    label="提案プレビュー（採用するとこの内容がプレイブックになります）",
                                    language="markdown",
                                    interactive=False,
                                )
                                with gr.Row():
                                    playbook_proposal_adopt_button = gr.Button("✅ 採用する", variant="primary")
                                    playbook_proposal_discard_button = gr.Button("🗑️ 却下する", variant="stop")

                            playbook_proposal_load_button.click(
                                ui_handlers.refresh_playbook_proposals,
                                outputs=[
                                    playbook_proposal_df,
                                    playbook_proposal_dropdown,
                                    playbook_proposal_status,
                                    playbook_proposal_preview,
                                ],
                            )
                            playbook_proposal_dropdown.input(
                                ui_handlers.select_playbook_proposal,
                                inputs=[playbook_proposal_dropdown],
                                outputs=[playbook_proposal_preview],
                            )
                            playbook_proposal_adopt_button.click(
                                ui_handlers.adopt_playbook_proposal,
                                inputs=[playbook_proposal_dropdown],
                                outputs=[
                                    playbook_proposal_df,
                                    playbook_proposal_dropdown,
                                    playbook_proposal_status,
                                    playbook_proposal_preview,
                                    playbook_df,
                                    playbook_dropdown,
                                ],
                            )
                            playbook_proposal_discard_button.click(
                                ui_handlers.discard_playbook_proposal,
                                inputs=[playbook_proposal_dropdown],
                                outputs=[
                                    playbook_proposal_df,
                                    playbook_proposal_dropdown,
                                    playbook_proposal_status,
                                    playbook_proposal_preview,
                                ],
                            )

                        with gr.Accordion("🎭 ロール（委任エージェントの役割＝装備一式）", open=False):
                            gr.Markdown(
                                "委任時に指定できる『役割（ロール）』を確認・編集できます。役割は権限・Web可否・"
                                "期待アウトプットの雛形・進め方をまとめた“装備一式”です。"
                                "**全ペルソナ・全環境で共通の設定**です（ルーム別ではありません）。\n"
                                "- 運営同梱（researcher / coder / designer / editor / critic）は**閲覧のみ**。あなたが追加したものは編集・削除できます。\n"
                                "- 運営版を変えたいときは『運営版を複製して編集』で同じIDのユーザー版を作れます（**ユーザー版が優先**されます）。\n"
                                "- ここで追加したものはアプリ更新でも消えません（`characters/_shared/memory/agent_roles/`）。"
                            )
                            role_status = gr.Markdown("🎭 『一覧を読み込む』を押すと、登録済みロールを表示します。")
                            with gr.Row():
                                role_load_button = gr.Button("🔄 読み込む", variant="secondary")
                                role_new_button = gr.Button("➕ 新規作成", variant="secondary")
                            role_df = gr.Dataframe(
                                headers=ui_handlers.ROLE_COLUMNS,
                                value=pd.DataFrame(columns=ui_handlers.ROLE_COLUMNS),
                                label="ロール一覧",
                                interactive=False,
                                wrap=True,
                            )
                            role_dropdown = gr.Dropdown(
                                choices=[],
                                label="編集するロールを選択",
                                interactive=True,
                                allow_custom_value=True,
                            )
                            with gr.Group():
                                role_id_textbox = gr.Textbox(
                                    label="ID（半角英数・ハイフン。保存後のファイル名になります）",
                                    interactive=True,
                                )
                                role_title_textbox = gr.Textbox(label="タイトル（役割名）", interactive=True)
                                role_summary_textbox = gr.Textbox(
                                    label="用途（どんな依頼に向くか・1行）",
                                    interactive=True,
                                )
                                with gr.Row():
                                    role_workspace_radio = gr.Radio(
                                        choices=ui_handlers._ROLE_WORKSPACE_CHOICES,
                                        value="",
                                        label="作業場所",
                                        interactive=True,
                                    )
                                    role_tier_radio = gr.Radio(
                                        choices=ui_handlers._ROLE_TIER_CHOICES,
                                        value="",
                                        label="権限ティア",
                                        interactive=True,
                                    )
                                    role_web_checkbox = gr.Checkbox(
                                        label="Web（検索・取得）を許可",
                                        value=False,
                                        interactive=True,
                                    )
                                role_task_kind_textbox = gr.Textbox(
                                    label="タスク種別（任意。例: deep_research）",
                                    interactive=True,
                                )
                                role_model_hint_dropdown = gr.Dropdown(
                                    choices=[("なし", ""), ("fast", "fast"), ("balanced", "balanced"), ("deep", "deep")],
                                    value="",
                                    label="モデルティア（任意）",
                                    info="指定するとタスク種別より優先して、このティアの委任モデルを使います。",
                                    interactive=True,
                                )
                                role_expected_output_textbox = gr.Textbox(
                                    label="期待アウトプットの雛形（任意・複数行可）",
                                    lines=3,
                                    interactive=True,
                                )
                                role_priority_number = gr.Number(
                                    label="優先度（大きいほど優先）",
                                    value=50,
                                    precision=0,
                                    interactive=True,
                                )
                                role_body_code = gr.Code(
                                    label="本文（実行役エージェントに渡す進め方）",
                                    language="markdown",
                                    interactive=True,
                                )
                            with gr.Row():
                                role_save_button = gr.Button("💾 保存", variant="primary")
                                role_copy_button = gr.Button("📋 運営版を複製して編集", variant="secondary", visible=False)
                                role_delete_button = gr.Button("🗑️ 削除（選択中のユーザー分のみ）", variant="stop")
                            with gr.Row(visible=False) as role_delete_confirm_row:
                                gr.Markdown("本当に削除しますか？ 元に戻せません。")
                                role_delete_confirm_button = gr.Button("はい、削除する", variant="stop")
                                role_delete_cancel_button = gr.Button("キャンセル", variant="secondary")
                            role_selected_id_state = gr.State("")
                            role_selected_layer_state = gr.State("")

                            _role_form_outputs = [
                                role_id_textbox,
                                role_title_textbox,
                                role_summary_textbox,
                                role_workspace_radio,
                                role_tier_radio,
                                role_web_checkbox,
                                role_task_kind_textbox,
                                role_model_hint_dropdown,
                                role_expected_output_textbox,
                                role_priority_number,
                                role_body_code,
                                role_save_button,
                                role_copy_button,
                                role_delete_button,
                                role_delete_confirm_row,
                                role_selected_id_state,
                                role_selected_layer_state,
                                role_status,
                            ]
                            role_load_button.click(
                                ui_handlers.refresh_role_list,
                                outputs=[role_df, role_dropdown, role_status],
                            )
                            role_dropdown.input(
                                ui_handlers.select_role,
                                inputs=[role_dropdown],
                                outputs=_role_form_outputs,
                            )
                            role_new_button.click(
                                ui_handlers.new_role,
                                outputs=_role_form_outputs,
                            )
                            role_save_button.click(
                                ui_handlers.save_role,
                                inputs=[
                                    role_id_textbox,
                                    role_title_textbox,
                                    role_summary_textbox,
                                    role_workspace_radio,
                                    role_tier_radio,
                                    role_web_checkbox,
                                    role_task_kind_textbox,
                                    role_model_hint_dropdown,
                                    role_expected_output_textbox,
                                    role_priority_number,
                                    role_body_code,
                                ],
                                outputs=[role_df, role_dropdown] + _role_form_outputs,
                            )
                            role_copy_button.click(
                                ui_handlers.copy_operator_role_to_user,
                                inputs=[role_selected_id_state],
                                outputs=[role_df, role_dropdown] + _role_form_outputs,
                            )
                            role_delete_button.click(
                                ui_handlers.ask_delete_role,
                                inputs=[role_selected_id_state, role_selected_layer_state],
                                outputs=[role_delete_confirm_row, role_status],
                            )
                            role_delete_cancel_button.click(
                                ui_handlers.cancel_delete_role,
                                outputs=[role_delete_confirm_row, role_status],
                            )
                            role_delete_confirm_button.click(
                                ui_handlers.confirm_delete_role,
                                inputs=[role_selected_id_state],
                                outputs=[role_df, role_dropdown] + _role_form_outputs,
                            )

            # ===== 外部接続タブ =====
            with gr.TabItem("外部接続", id="external_connections", key="top_tab_external_connections"):
                with gr.Tabs(selected="external_twitter") as external_connection_tabs:
                    with gr.TabItem("Twitter (X)", id="external_twitter", key="external_tab_twitter"):
                        _initial_room_config_for_twitter = room_manager.get_room_config(effective_initial_room) or {}
                        _initial_twitter_settings = (
                            (_initial_room_config_for_twitter.get("override_settings", {}) or {}).get("twitter_settings", {}) or {}
                        )
                        _initial_twitter_api_config = _initial_twitter_settings.get("api_config", {}) or {}
                        _initial_twitter_auth_mode = _initial_twitter_settings.get("auth_mode") or "api"
                        with gr.Tabs(selected="twitter_approval_subtab"):
                            with gr.TabItem("承認待ち", id="twitter_approval_subtab"):
                                gr.Markdown("## Twitter承認")
                                twitter_selected_draft_id_state = gr.State("")
                                twitter_reply_url_state = gr.State("")
                                twitter_reply_id_state = gr.State("")
                                with gr.Row():
                                    twitter_refresh_pending_button = gr.Button("承認待ちを更新", variant="primary")
                                    twitter_load_selected_draft_button = gr.Button("選択した下書きを読み込む", variant="secondary")
                                twitter_pending_df = gr.Dataframe(
                                    label="承認待ち下書き",
                                    headers=["ID", "時刻", "画像", "下書き内容", "警告"],
                                    datatype=["str", "str", "str", "str", "str"],
                                    interactive=True,
                                    static_columns=[0, 1, 2, 3, 4],
                                    wrap=False,
                                )
                                twitter_draft_warnings = gr.Markdown("")
                                twitter_reply_preview = gr.Markdown("※ 選択されていません")
                                twitter_draft_editor = gr.Textbox(label="投稿内容", lines=6, interactive=True)
                                twitter_media_file = gr.File(label="添付画像", file_count="multiple", interactive=True)
                                twitter_media_gallery = gr.Gallery(label="添付プレビュー", columns=4, height=180)
                                with gr.Row():
                                    twitter_approve_button = gr.Button("承認して投稿", variant="primary")
                                    twitter_reject_button = gr.Button("却下", variant="stop")
                                twitter_approval_detail = gr.Markdown("")

                                with gr.Accordion("投稿履歴", open=False):
                                    with gr.Row():
                                        twitter_refresh_history_button = gr.Button("履歴を更新", variant="secondary")
                                        twitter_history_retry_button = gr.Button("選択履歴を下書きに戻す", variant="secondary")
                                        twitter_history_delete_button = gr.Button("選択履歴を削除", variant="stop")
                                    twitter_history_selected_id_state = gr.State("")
                                    twitter_history_df = gr.Dataframe(
                                        label="投稿履歴",
                                        headers=["ID", "時刻", "内容", "ステータス", "URL"],
                                        datatype=["str", "str", "str", "str", "str"],
                                        interactive=False,
                                        wrap=True,
                                    )
                                    twitter_history_detail = gr.Markdown("")

                            with gr.TabItem("設定", id="twitter_settings_subtab"):
                                gr.Markdown("## Twitter設定")
                                with gr.Accordion("使い方", open=False):
                                    gr.Markdown(
                                        "- `承認待ち` で下書きを更新し、行を選んで読み込んでから内容を確認して投稿します。\n"
                                        "- `設定` ではルームごとのTwitter連携設定を保存します。ブラウザ認証は規約・安定性の面で非推奨のため、通常はAPI認証を使ってください。\n"
                                        "- ペルソナがTwitter投稿を提案する場合は下書きキューに入り、ここで人間が承認するまで投稿されません。\n"
                                        "- Discordから承認する場合は、Discord Bot設定の承認コマンド許可ユーザーIDに自分のDiscordユーザーIDを入れてください。"
                                    )
                                with gr.Row():
                                    twitter_load_settings_button = gr.Button("現在のルーム設定を読み込む", variant="secondary")
                                    twitter_save_button = gr.Button("Twitter設定を保存", variant="primary")
                                twitter_enabled_checkbox = gr.Checkbox(
                                    label="Twitter連携を有効化",
                                    value=bool(_initial_twitter_settings.get("enabled", False)),
                                    interactive=True,
                                )
                                twitter_auth_mode_radio = gr.Radio(
                                    choices=["browser", "api"],
                                    value=_initial_twitter_auth_mode,
                                    label="認証方式",
                                    interactive=True,
                                )
                                with gr.Group(visible=(_initial_twitter_auth_mode == "browser")) as twitter_browser_auth_group:
                                    twitter_session_status = gr.Markdown("セッション状態: 未確認")
                                    with gr.Row():
                                        twitter_check_session_button = gr.Button("状態を再確認", variant="secondary")
                                        twitter_login_button = gr.Button("ブラウザでログイン", variant="secondary")
                                    twitter_cookie_input = gr.Code(label="Cookie JSON貼り付け", language="json", lines=5)
                                    twitter_cookie_import_button = gr.Button("Cookieをインポート", variant="secondary")
                                with gr.Group(visible=(_initial_twitter_auth_mode == "api")) as twitter_api_auth_group:
                                    with gr.Row():
                                        twitter_api_key_input = gr.Textbox(label="API Key", value=_initial_twitter_api_config.get("api_key", ""), type="password", interactive=True)
                                        twitter_api_secret_input = gr.Textbox(label="API Secret", value=_initial_twitter_api_config.get("api_secret", ""), type="password", interactive=True)
                                    with gr.Row():
                                        twitter_access_token_input = gr.Textbox(label="Access Token", value=_initial_twitter_api_config.get("access_token", ""), type="password", interactive=True)
                                        twitter_access_token_secret_input = gr.Textbox(label="Access Token Secret", value=_initial_twitter_api_config.get("access_token_secret", ""), type="password", interactive=True)
                                    twitter_test_api_button = gr.Button("API接続テスト", variant="secondary")
                                    twitter_test_result = gr.Markdown("")
                                twitter_posting_summary_input = gr.Textbox(label="投稿方針の要約", value=_initial_twitter_settings.get("posting_summary", ""), lines=3, interactive=True)
                                twitter_posting_guidelines_input = gr.Textbox(label="投稿ガイドライン", value=_initial_twitter_settings.get("posting_guidelines", ""), lines=5, interactive=True)
                                with gr.Row():
                                    twitter_auto_post_checkbox = gr.Checkbox(label="自動投稿", value=bool(_initial_twitter_settings.get("auto_post", False)), interactive=True)
                                    twitter_notify_on_approval_checkbox = gr.Checkbox(label="承認依頼を通知", value=bool(_initial_twitter_settings.get("notify_on_approval_request", False)), interactive=True)
                                    twitter_is_premium_checkbox = gr.Checkbox(label="X Premium", value=bool(_initial_twitter_settings.get("is_premium", False)), interactive=True)
                                with gr.Row():
                                    twitter_privacy_filter_checkbox = gr.Checkbox(label="プライバシーフィルタ", value=bool(_initial_twitter_settings.get("enable_privacy_filter", True)), interactive=True)
                                    twitter_fetch_thread_checkbox = gr.Checkbox(label="返信先スレッド取得", value=bool(_initial_twitter_settings.get("fetch_thread_enabled", False)), interactive=True)
                                    twitter_thread_fetch_count_number = gr.Number(label="取得件数", value=int(_initial_twitter_settings.get("thread_fetch_count", 3) or 3), precision=0, interactive=True)
                                twitter_status = gr.Markdown("ルーム切替または読み込み/保存で設定を反映します。")

                    with gr.TabItem("Discord / LINE", id="external_discord_line", key="external_tab_discord_line"):
                        _discord_initial_settings = config_manager.get_room_discord_bot_settings(effective_initial_room)
                        _discord_channel_modes = "\n".join(
                            f"{channel_id}={ {'always': '常時反応', 'mention': 'メンション時のみ', 'ignore': '無視'}.get(mode, mode) }"
                            for channel_id, mode in sorted((_discord_initial_settings.get("channel_response_modes", {}) or {}).items())
                        )
                        _discord_has_token = bool(_discord_initial_settings.get("token"))
                        if _discord_initial_settings.get("enabled") and _discord_has_token:
                            _discord_initial_status = "Botの状態: 🟢 有効（起動中または起動対象）"
                        elif _discord_has_token:
                            _discord_initial_status = "Botの状態: ⚪ 無効（Botトークン保存済み・有効化チェックがOFF）"
                        else:
                            _discord_initial_status = "Botの状態: ⚪ 無効"

                        with gr.Accordion("Discord Bot", open=True):
                            with gr.Accordion("設定方法", open=False):
                                gr.Markdown(
                                    "### 1. Botの作成とトークンの取得\n"
                                    "- [Discord Developer Portal](https://discord.com/developers/applications) にアクセスし、`New Application` を作成します。\n"
                                    "- 左メニュー `Bot` を選択し、**Reset Token** を押してトークンをコピーして `Bot Token` 欄に貼り付けます。\n\n"
                                    "### 2. 権限（Intents）の設定\n"
                                    "- 同じ `Bot` ページ下部の **Privileged Gateway Intents** を開きます。\n"
                                    "- **MESSAGE CONTENT INTENT** をONにしてください。これがOFFだと、Botが通常メッセージ本文を読めず反応できません。\n\n"
                                    "### 3. Botをサーバーに招待する\n"
                                    "- 左メニュー `OAuth2` -> `URL Generator` を開きます。\n"
                                    "- `Scopes` は `bot` と `applications.commands` を選びます。\n"
                                    "- 通常のBot招待では `applications.commands.permissions.update` は選びません。選ぶとリダイレクトURIが必要な別用途の認可フローになります。\n"
                                    "- `Bot Permissions` は、テスト用サーバーなら **管理者** が最も簡単です。権限を絞る場合は、**チャンネルを見る**、**メッセージを送信**、**メッセージ履歴を読む**、**ファイルを添付**、**スラッシュコマンドを使用** を許可してください。\n"
                                    "- 生成されたURLからBotをサーバーへ招待します。\n\n"
                                    "### 4. ユーザーIDとチャンネルIDを取得する\n"
                                    "- Discordの `ユーザー設定` -> `詳細設定` で **開発者モード** をONにします。\n"
                                    "- 自分のアイコンを右クリックして「ユーザーIDをコピー」し、`許可ユーザーID` に入力します。\n"
                                    "- 対象チャンネルを右クリックして「チャンネルIDをコピー」し、`許可チャンネルID` や `既定チャンネルID` に入力します。\n\n"
                                    "### 5. ルーム個別Botとして保存する\n"
                                    "- `このルームのDiscord Botを有効化` をONにし、必要なIDや反応モードを入力して保存します。\n"
                                    "- 同じBot Tokenを複数ルームで共有しないでください。1 Bot Token = 1 ペルソナを前提にしています。\n"
                                    "- 保存後、Bot起動状態の反映にはNexus Arkの再起動が必要になる場合があります。"
                                )
                            with gr.Accordion("使い方", open=False):
                                gr.Markdown(
                                    "- ルームごとにDiscord Bot Tokenを設定できます。複数ペルソナを使う場合は、各ルームに別Bot Tokenを設定してください。\n"
                                    "- `許可ユーザーID` を指定すると、指定ユーザーからの操作だけを受け付けます。\n"
                                    "- `許可チャンネルID` を指定すると、対象チャンネルだけで反応します。空欄なら制限しません。\n"
                                    "- `チャンネル別反応モード` は `チャンネルID=メンション時のみ`、`チャンネルID=常時反応`、`チャンネルID=無視` のように1行ずつ指定します。\n"
                                    "- `承認コマンド許可ユーザーID` は、DiscordからTwitter下書きを承認/却下するユーザーを限定するための設定です。\n"
                                    "- Botの招待時は `bot` と `applications.commands` scopeを付けてください。"
                                )
                            discord_bot_enabled_checkbox = gr.Checkbox(label="このルームのDiscord Botを有効化", value=bool(_discord_initial_settings.get("enabled", False)), interactive=True)
                            discord_bot_token_input = gr.Textbox(label="Bot Token", value=_discord_initial_settings.get("token", ""), type="password", interactive=True)
                            discord_bot_auth_ids_input = gr.Textbox(label="許可ユーザーID（カンマ区切り）", value=", ".join([str(v) for v in _discord_initial_settings.get("authorized_user_ids", [])]), interactive=True)
                            discord_bot_allowed_channels_input = gr.Textbox(label="許可チャンネルID（カンマ区切り）", value=", ".join([str(v) for v in _discord_initial_settings.get("allowed_channel_ids", [])]), interactive=True)
                            with gr.Row():
                                discord_bot_default_channel_input = gr.Textbox(label="既定チャンネルID", value=_discord_initial_settings.get("default_channel_id", ""), interactive=True)
                                discord_bot_mention_only_checkbox = gr.Checkbox(label="メンション時のみ反応", value=bool(_discord_initial_settings.get("mention_only", False)), interactive=True)
                            discord_bot_channel_modes_input = gr.Textbox(
                                label="チャンネル別反応モード",
                                value=_discord_channel_modes,
                                placeholder="123456789=メンション時のみ",
                                lines=3,
                                interactive=True,
                            )
                            discord_bot_allow_autonomous_send_checkbox = gr.Checkbox(label="自律送信を許可", value=bool(_discord_initial_settings.get("allow_autonomous_send", False)), interactive=True)
                            discord_bot_persona_webhook_input = gr.Textbox(label="ペルソナWebhook URL", value=_discord_initial_settings.get("persona_webhook_url", ""), type="password", interactive=True)
                            discord_bot_approval_ids_input = gr.Textbox(label="承認コマンド許可ユーザーID（カンマ区切り）", value=", ".join([str(v) for v in _discord_initial_settings.get("approval_command_allowlist", [])]), interactive=True)
                            discord_bot_voice_input_enabled_checkbox = gr.Checkbox(value=bool(_discord_initial_settings.get("voice_input_enabled", False)), visible=False)
                            discord_bot_voice_confirm_checkbox = gr.Checkbox(value=bool(_discord_initial_settings.get("voice_input_confirm_transcript", True)), visible=False)
                            discord_bot_voice_timeout_input = gr.Number(value=int(_discord_initial_settings.get("voice_input_timeout_minutes", 10) or 10), precision=0, visible=False)
                            discord_bot_voice_stt_model_input = gr.Textbox(value=str(_discord_initial_settings.get("voice_input_stt_model") or constants.DISCORD_VOICE_STT_MODEL), visible=False)
                            with gr.Row():
                                discord_bot_load_button = gr.Button("現在のルーム設定を読み込む", variant="secondary")
                                discord_bot_save_button = gr.Button("Discord Bot設定を保存", variant="primary")
                                discord_bot_stop_button = gr.Button("Discord Botを停止", variant="stop")
                            discord_bot_status = gr.Markdown(_discord_initial_status)

                        with gr.Accordion("LINE Bot", open=False):
                            with gr.Accordion("設定方法", open=False):
                                gr.Markdown(
                                    "### 注意\n"
                                    "- LINE Botは外部からアクセスできるHTTPS URLが必要です。ドメイン固定のTunnelを使わない場合、PC再起動やTunnel再起動のたびにLINE側Webhook URLの更新が必要になることがあります。\n\n"
                                    "### 1. LINE Developersでプロバイダーを作成する\n"
                                    "- [LINE Developersコンソール](https://developers.line.biz/console/) にアクセスします。\n"
                                    "- 「新規プロバイダー作成」を選び、任意のプロバイダー名（例: NexusArk）で作成します。\n\n"
                                    "### 2. Messaging APIチャネルを作成する\n"
                                    "- 作成したプロバイダーで **新規チャネル作成** -> **Messaging API** を選択します。\n"
                                    "- チャネル名、説明、業種などを入力し、規約に同意して作成します。\n"
                                    "- すでにLINE公式アカウントマネージャーでアカウント作成済みの場合は、[LINE公式アカウントマネージャー](https://manager.line.biz/) の `設定` -> `Messaging API` から連携してください。\n\n"
                                    "### 3. TokenとSecretを取得する\n"
                                    "- LINE Developersで対象チャネルを開き、**チャネル基本設定（Basic settings）** の **Channel secret** をコピーして `Channel Secret` 欄へ貼り付けます。\n"
                                    "- **Messaging API設定** タブの下部で **Channel access token** を発行し、`Channel Access Token` 欄へ貼り付けます。\n\n"
                                    "### 4. 許可ユーザーIDを設定する\n"
                                    "- **チャネル基本設定** の下部にある **Your user ID** をコピーし、`許可ユーザーID` 欄へ入力します。\n"
                                    "- 複数ユーザーを許可する場合はカンマ区切りで入力します。空欄にするとユーザー制限なしになります。\n\n"
                                    "### 5. Webhook URLを設定する\n"
                                    "- LINE Bot受信用サーバーは既定で `http://localhost:7862` です。外部公開にはCloudflare Tunnel、Tailscale Funnel、ngrokなどを使ってHTTPS URLを用意します。\n"
                                    "- Cloudflare Tunnelの簡易例: `cloudflared tunnel --url http://localhost:7862`\n"
                                    "- 表示された `https://...trycloudflare.com` などのURLを、LINE Developersの **Messaging API設定** -> **Webhook URL** に入力します。\n"
                                    "- Webhook URLの末尾パスが必要な環境では、LINE Bot実装の案内や起動ログに表示されるURLを優先してください。\n"
                                    "- Webhookを **有効** にし、検証ボタンで疎通を確認します。\n\n"
                                    "### 6. LINE公式アカウント側の応答設定を調整する\n"
                                    "- [LINE公式アカウントマネージャー](https://manager.line.biz/) の `設定` -> `応答設定` で、**あいさつメッセージ** と **応答メッセージ** をOFFにします。\n"
                                    "- これを残すと、Nexus ArkのAI返信とLINE側自動応答が二重に届くことがあります。\n\n"
                                    "### 7. Nexus Ark側で保存する\n"
                                    "- `LINE Botを有効化` をONにし、Token/Secret/許可ユーザーID/紐付けルームを設定して保存します。\n"
                                    "- 保存後、Bot起動状態の反映にはNexus Arkの再起動が必要になる場合があります。"
                                )
                            with gr.Accordion("使い方", open=False):
                                gr.Markdown(
                                    "- LINE DevelopersでMessaging APIチャンネルを作成し、Channel Access TokenとChannel Secretを入力します。\n"
                                    "- Webhook URLはNexus ArkのLINE Botサーバーへ向けます。外部から使う場合はCloudflare TunnelやTailscale FunnelなどでHTTPS公開してください。\n"
                                    "- `許可ユーザーID` を指定すると、そのLINEユーザーからのメッセージだけを受け付けます。空欄なら制限しません。\n"
                                    "- `紐付けルーム` を自動にすると、Nexus Ark UIで選択中のルームと連動します。固定したい場合は対象ルームを選んでください。\n"
                                    "- 設定保存後、Botの起動状態を反映するにはNexus Arkの再起動が必要になる場合があります。"
                                )
                            line_bot_enabled_checkbox = gr.Checkbox(
                                label="LINE Botを有効化",
                                value=bool(config_manager.CONFIG_GLOBAL.get("line_bot_enabled", False)),
                                interactive=True,
                            )
                            line_channel_access_token_input = gr.Textbox(
                                label="Channel Access Token",
                                value=config_manager.CONFIG_GLOBAL.get("line_channel_access_token", ""),
                                type="password",
                                interactive=True,
                            )
                            line_channel_secret_input = gr.Textbox(
                                label="Channel Secret",
                                value=config_manager.CONFIG_GLOBAL.get("line_channel_secret", ""),
                                type="password",
                                interactive=True,
                            )
                            line_authorized_user_ids_input = gr.Textbox(
                                label="許可ユーザーID（カンマ区切り）",
                                value=", ".join(config_manager.CONFIG_GLOBAL.get("line_authorized_user_ids", [])),
                                interactive=True,
                            )
                            line_linked_room_dropdown = gr.Dropdown(
                                label="紐付けルーム",
                                choices=[("自動（現在のUIと連動）", "自動（現在のUIと連動）"), *room_list_on_startup],
                                value=config_manager.CONFIG_GLOBAL.get("line_bot_linked_room") or "自動（現在のUIと連動）",
                                interactive=True,
                                allow_custom_value=True,
                            )
                            with gr.Row():
                                line_bot_save_button = gr.Button("LINE Bot設定を保存", variant="primary")
                                line_bot_stop_button = gr.Button("LINE Botを停止", variant="stop")
                            line_bot_status = gr.Markdown("サーバー状態: 未読み込み")

                    with gr.TabItem("拡張ツール", id="external_custom_tools", key="external_tab_custom_tools"):
                        gr.Markdown("## 拡張ツール")
                        _custom_tools_settings = config_manager.CONFIG_GLOBAL.get("custom_tools_settings", {}) or {}
                        custom_tools_enabled_checkbox = gr.Checkbox(
                            label="拡張ツール機能を有効化",
                            value=bool(_custom_tools_settings.get("enabled", False)),
                            interactive=True,
                        )
                        with gr.Tabs():
                            with gr.TabItem("ローカルプラグイン", id="custom_tools_local_plugins"):
                                local_plugin_file_dropdown = gr.Dropdown(
                                    label="ローカルプラグイン",
                                    choices=[],
                                    value=None,
                                    interactive=True,
                                    allow_custom_value=True,
                                )
                                with gr.Row():
                                    local_plugin_refresh_button = gr.Button("🔄 一覧を更新", variant="secondary")
                                    local_plugin_new_filename_input = gr.Textbox(label="新規ファイル名", placeholder="my_tool.py", interactive=True)
                                    local_plugin_create_button = gr.Button("新規作成", variant="secondary")
                                    local_plugin_delete_button = gr.Button("削除", variant="stop")
                                local_plugin_enabled_checkbox = gr.Checkbox(label="選択プラグインを有効化", value=True, interactive=True)
                                local_plugin_code_editor = gr.Code(label="プラグインコード", language="python", interactive=True, lines=18)
                                local_plugin_save_button = gr.Button("プラグインを保存", variant="primary")
                                local_plugin_status = gr.Markdown("")

                            with gr.TabItem("MCP", id="custom_tools_mcp"):
                                mcp_selected_server_state = gr.State(None)
                                with gr.Row():
                                    refresh_mcp_servers_button = gr.Button("🔄 一覧を更新", variant="secondary")
                                    edit_mcp_server_button = gr.Button("選択サーバを編集欄へ反映", variant="secondary")
                                    test_mcp_connection_button = gr.Button("接続テスト", variant="primary")
                                    remove_mcp_server_button = gr.Button("選択サーバを削除", variant="stop")
                                mcp_servers_df = gr.Dataframe(
                                    label="MCPサーバ一覧",
                                    headers=["有効", "名前", "種別", "コマンド/URL", "引数", "状態"],
                                    datatype=["bool", "str", "str", "str", "str", "str"],
                                    interactive=True,
                                    wrap=True,
                                )
                                with gr.Row():
                                    mcp_server_name_input = gr.Textbox(label="名前", interactive=True)
                                    mcp_server_type_dropdown = gr.Dropdown(
                                        label="種別",
                                        choices=["stdio", "sse", "streamable_http", "simple_http"],
                                        value="stdio",
                                        interactive=True,
                                    )
                                    mcp_server_enabled_checkbox = gr.Checkbox(label="有効", value=True, interactive=True)
                                with gr.Row():
                                    mcp_server_command_input = gr.Textbox(label="コマンド", placeholder="python", interactive=True, scale=2)
                                    mcp_server_args_input = gr.Textbox(label="引数", interactive=True, scale=2)
                                    add_mcp_server_button = gr.Button("追加/更新", variant="primary", scale=1)
                                mcp_status = gr.Markdown("")
                                mcp_tools_df = gr.Dataframe(
                                    label="検出ツール",
                                    headers=["有効", "ツール名", "説明", "概要", "使う場面", "結果プロンプト"],
                                    datatype=["bool", "str", "str", "str", "str", "str"],
                                    interactive=True,
                                    wrap=True,
                                )

                    with gr.TabItem("API・外部ツール", id="external_api_tools", key="external_tab_api_tools"):
                        gr.Markdown(
                            "## API・外部ツール\n"
                            "自作ツールや外部サービスからNexus Arkへ接続するための、詳しい情報をまとめています。"
                        )
                        with gr.Accordion("外部ツール連携について（詳しい方向け）", open=True):
                            gr.Markdown(value=ui_handlers.build_api_gateway_external_use_guide())

                        with gr.Accordion("利用可能なAPI一覧・外部連携リファレンス", open=False):
                            external_api_docs = gr.Markdown(value=ui_handlers.build_api_gateway_external_docs())

                        with gr.Accordion("外部イベントテスター", open=False):
                            with gr.Row():
                                external_event_type_dropdown = gr.Dropdown(
                                    label="イベント種別",
                                    choices=[
                                        "switchbot_triggered",
                                        "stackchan_observed",
                                        "stable_diffusion_result",
                                        "sns_post_received",
                                        "custom",
                                    ],
                                    value="switchbot_triggered",
                                    interactive=True,
                                    scale=2,
                                )
                                external_event_source_input = gr.Textbox(
                                    label="送信元",
                                    value="external_ui",
                                    interactive=True,
                                    scale=2,
                                )
                                external_event_notify_checkbox = gr.Checkbox(
                                    label="通知トリガー",
                                    value=True,
                                    interactive=True,
                                    scale=1,
                                )
                                external_event_importance_dropdown = gr.Dropdown(
                                    label="重要度",
                                    choices=["low", "normal", "high", "critical"],
                                    value="high",
                                    interactive=True,
                                    scale=1,
                                )
                            external_event_data_json = gr.Code(
                                label="イベント内容JSON",
                                value=ui_handlers.build_external_event_template("switchbot_triggered"),
                                language="json",
                                interactive=True,
                                lines=10,
                            )
                            external_event_test_button = gr.Button("現在のルームへイベントを記録", variant="primary")
                            external_event_result = gr.Markdown("")

                    with gr.TabItem(
                        "Lite・お出かけ",
                        id="external_api_gateway",
                        key="external_tab_api_gateway",
                        elem_id="outing_tab",
                    ):
                        gr.Markdown("## Nexus Ark Lite・お出かけ")
                        gr.Markdown(
                            "Nexus Ark Liteは、スマホやタブレットのブラウザから使える"
                            "インストール対応Webアプリ（PWA）です。本体接続・独立モード、"
                            "外部AIへの持ち出し・帰宅を、この画面で設定できます。"
                        )
                        with gr.Row():
                            external_open_lite_outing = gr.Button("📱 Nexus Ark Lite", variant="primary")
                            external_open_outing_export = gr.Button("📤 外部AIへ持ち出す", variant="secondary")
                            external_open_outing_import = gr.Button("🏠 外部AIから帰宅", variant="secondary")
                        gr.HTML(
                            '<p class="outing-mode-loading-message" hidden aria-live="polite"></p>',
                            elem_id="outing_mode_loading_feedback",
                        )
                        gr.Markdown("**Liteの操作メニュー** — 初めての方は「初回設定・接続管理」から「PCを止めても使う」へ。設定済みの方は、目的の操作へ直接進めます。")
                        with gr.Row():
                            lite_daily_shortcut = gr.Button("お出かけを準備", variant="primary")
                            lite_return_shortcut = gr.Button("帰宅・統合", variant="secondary")
                            lite_management_shortcut = gr.Button("初回設定・接続管理", variant="secondary")

                        with gr.Column(
                            visible=False,
                            elem_id="outing_lite_independent",
                            elem_classes=["outing-mode-panel"],
                        ) as outing_lite_daily_group:
                            lite_outing_back_to_setup = gr.Button(
                                "← Liteの使い方・接続設定へ戻る", variant="secondary"
                            )
                            gr.Markdown(
                                "## PCを止めている間も、スマホで会話する\n"
                                "ペルソナを最大3人までスマホへ連れて行き、帰宅後に会話をこの本体へ戻せます。"
                                "この画面では、上から **接続確認 → お出かけ前の準備 → 出発 → 帰宅** の順に進みます。"
                            )
                            with gr.Accordion("この画面に出てくる言葉", open=False):
                                gr.Markdown(
                                    "- **Lite用クラウド（Cloudflare Worker）**: PCを止めている間、スマホとの接続を受け持つ自分専用の窓口です。\n"
                                    "- **お出かけ前データ（snapshot）**: ペルソナの今の状態を、出発前に暗号化して用意するコピーです。\n"
                                    "- **帰宅データ（bundle）**: Liteで増えた会話を、安全に本体へ戻すための署名付きファイルです。\n"
                                    "- **本体では休んでもらう（単一存在 / exclusive）**: 帰宅まで本体側の発話・自律行動・記憶変更を止めます。通常はこちらです。\n"
                                    "- **本体にも残す（並行存在 / parallel）**: 本体とLiteの両方で活動し、帰宅時に別々の経験として残します。"
                                )

                            lite_travel_progress = gr.HTML(
                                ui_handlers.build_lite_outing_progress("needs_connection")
                            )
                            lite_travel_snapshot_state = gr.State(None)
                            lite_travel_standby_snapshot_state = gr.State(None)
                            _lite_room_choices = room_manager.get_room_list_for_ui()
                            _lite_focus_choices, _lite_initial_focus = ui_handlers.build_lite_outing_focus(
                                effective_initial_room, _lite_room_choices
                            )
                            lite_travel_focus_persona = gr.Dropdown(
                                label="状態・帰宅を確認するペルソナ",
                                choices=_lite_focus_choices,
                                value=_lite_initial_focus,
                                interactive=True,
                                info="本体のチャット選択とは別です。帰宅する人を選んで「現在の状態に更新」を押します。同じお出かけの人はまとめて帰宅します。",
                            )
                            lite_travel_status = gr.Markdown(
                                ui_handlers.build_lite_travel_status(effective_initial_room),
                                elem_classes=["lite-outing-presence"],
                            )
                            lite_travel_refresh_status = gr.Button("現在の状態に更新", variant="primary")
                            lite_travel_refresh_feedback = gr.Markdown(
                                "未更新です。接続状態は保存済み設定だけを表示しています。"
                            )
                            gr.Markdown("#### 直前の操作結果")
                            lite_travel_operation_result = gr.Markdown("まだ操作していません。")

                            with gr.Group(elem_classes=["lite-outing-stage"], visible=True) as lite_travel_connection_group:
                                gr.Markdown("### 1. 接続確認\n最初に、4つの準備状況とペルソナの現在地をまとめて確認します。")
                                lite_travel_connectivity_card = gr.HTML(
                                    ui_handlers.build_lite_connectivity_wizard(
                                        "existing",
                                        refresh_remote=False,
                                        refresh_action_label="現在の状態に更新",
                                        surface="outing",
                                    )
                                )
                                lite_travel_open_worker_settings = gr.Button(
                                    "初回設定・接続管理", variant="secondary"
                                )
                                with gr.Accordion("接続設定・スマホ再登録（必要なとき）", open=False):
                                    gr.Markdown(
                                        "初回設定、AIサービス設定、端末の確認・解除、QR付き再登録、保守は "
                                        "**外部接続 → Lite・お出かけ** で行います。"
                                    )
                                    lite_travel_pair_button = gr.Button("スマホ用の短期コードを発行", variant="secondary")
                                    lite_travel_pairing_result = gr.Markdown("")

                            with gr.Group(
                                elem_classes=["lite-outing-stage"], visible=False
                            ) as lite_travel_standby_group:
                                gr.Markdown(
                                    "### 2. お出かけ前の準備\n"
                                    "一緒に行くペルソナを1〜3人選びます。準備済みでも、ここで人・AI・情報量を選び直せます。"
                                    "変更がなければ下の「3. 出発」へ進めます。変更した場合は送る内容を確認し直してください。"
                                )
                                _lite_preferences = ui_handlers.build_lite_outing_preferences(effective_initial_room, _lite_room_choices)
                                lite_travel_personas = gr.CheckboxGroup(
                                    choices=_lite_room_choices,
                                    value=_lite_preferences["selected_rooms"],
                                    label="一緒に持ち出すペルソナ（1〜3人）",
                                )
                                with gr.Accordion("本体にも残す（詳しい設定）", open=False):
                                    gr.Markdown(
                                        "お出かけ中も、PCのNexus Arkで会話や自律行動を続けるペルソナを選びます。"
                                        "本体での活動にはPCのNexus Arkが起動している必要があります。"
                                        "Liteの独立モードでも会話できますが、両方の会話はリアルタイムには同期されません。"
                                        "Liteでの経験は帰宅時に本体へ取り込みます。"
                                        "選ばなかったペルソナは、帰宅まで本体での活動を休みます。"
                                    )
                                    lite_travel_parallel_personas = gr.CheckboxGroup(
                                        choices=_lite_room_choices,
                                        value=_lite_preferences["parallel_rooms"],
                                        label="本体にも残すペルソナ（上で選んだ中から）",
                                    )
                                _lite_daily_settings = lite_travel.get_settings()
                                _lite_daily_profile = str(
                                    _lite_daily_settings.get("credential_profile_id") or ""
                                )
                                _lite_daily_model = str(_lite_daily_settings.get("model_id") or "")
                                gr.Markdown(
                                    "#### 今回使うAI\n"
                                    "出発時に使い始めるAIサービスとモデルです。外出中もLiteから変更できます。"
                                )
                                with gr.Row():
                                    lite_daily_credential_profile_id = gr.Dropdown(
                                        label="AIサービス／接続",
                                        choices=ui_handlers.build_lite_ai_connection_choices(
                                            _lite_daily_profile
                                        ),
                                        value=_lite_daily_profile or None,
                                        interactive=True,
                                    )
                                    lite_daily_model_id = gr.Dropdown(
                                        label="AIモデル",
                                        choices=ui_handlers.build_lite_travel_model_choices(
                                            _lite_daily_profile,
                                            _lite_daily_model,
                                        ),
                                        value=_lite_daily_model or None,
                                        filterable=True,
                                        interactive=True,
                                        allow_custom_value=True,
                                        info="一覧から選ぶか、利用するモデル名を直接入力できます。",
                                    )
                                lite_daily_ai_status = gr.Markdown(
                                    f"現在の設定: {_lite_daily_model or 'AIモデルを選んでください。'}"
                                )
                                lite_daily_ai_save = gr.Button(
                                    "今回使うAIを保存", variant="secondary"
                                )
                                with gr.Accordion("持ち出す情報を選ぶ", open=True):
                                    gr.Markdown(
                                        "**システムプロンプトは会話に必須のため、常に含まれます。** "
                                        "迷った時は「おすすめ」のままで大丈夫です。"
                                    )
                                    lite_travel_snapshot_preset = gr.Radio(
                                        label="持ち出す量",
                                        choices=[
                                            ("おすすめ", "recommended"),
                                            ("最小限（システムプロンプトのみ）", "minimal"),
                                            ("自分で選ぶ", "custom"),
                                        ],
                                        value="custom" if _lite_preferences["restored"] else "recommended",
                                    )
                                    lite_travel_snapshot_preset_status = gr.Markdown(
                                        "前回準備した選択を復元しました。内容を確認して続けてください。" if _lite_preferences["restored"]
                                        else "おすすめ: コアメモリ、エピソード記憶、直近の会話をバランスよく持ち出します。"
                                    )
                                    with gr.Accordion("内容を確認・細かく調整", open=False):
                                        lite_travel_include_core_memory = gr.Checkbox(
                                            label="コアメモリを含める",
                                            value=_lite_preferences["include_core_memory"],
                                            interactive=_lite_preferences["restored"],
                                            info="ペルソナのコアメモリを持ち出します。",
                                        )
                                        lite_travel_include_episodic_memory = gr.Checkbox(
                                            label="エピソード記憶を含める",
                                            value=_lite_preferences["include_episodic_memory"],
                                            interactive=_lite_preferences["restored"],
                                            info="昨日までに整理されたエピソード記憶を持ち出します。",
                                        )
                                        lite_travel_episodic_memory_days = gr.Slider(
                                            minimum=0,
                                            maximum=30,
                                            value=_lite_preferences["episodic_memory_days"],
                                            step=1,
                                            interactive=_lite_preferences["restored"] and _lite_preferences["include_episodic_memory"],
                                            label="エピソード記憶を含める日数（今日を除く）",
                                            info="2なら昨日と一昨日が対象です。",
                                        )
                                        lite_travel_recent_message_limit = gr.Slider(
                                            minimum=0,
                                            maximum=40,
                                            value=_lite_preferences["recent_message_limit"],
                                            step=5,
                                            interactive=_lite_preferences["restored"],
                                            label="直近の会話を含める件数（ペルソナごと）",
                                            info="最近の会話の続きから話したい時に使います。",
                                        )
                                gr.Markdown("**次に押すボタン:** PC停止に備えるコピーを更新します。出発や課金は始まりません。")
                                lite_travel_prepare_standby = gr.Button(
                                    "1. Lite用クラウドへ送る内容を確認", variant="primary"
                                )
                                lite_travel_standby_preview = gr.Markdown("送信前の確認: 未作成")
                                with gr.Accordion("確認する本文（snapshot JSON）", open=False):
                                    lite_travel_standby_snapshot_json = gr.Code(
                                        label="送信予定のsnapshot（読み取り専用）",
                                        language="json",
                                        interactive=False,
                                        lines=12,
                                    )
                                lite_travel_confirm_standby = gr.Button(
                                    "2. 確認した内容をLite用クラウドへ準備",
                                    variant="secondary",
                                    interactive=False,
                                )
                                lite_travel_standby_status = gr.Markdown("この画面での送信操作: 未実行。すでに有効な準備データがあれば再送は不要です。")

                            with gr.Group(
                                elem_classes=["lite-outing-stage"], visible=False
                            ) as lite_travel_departure_group:
                                gr.Markdown(
                                    "### 3. 出発\n"
                                    "まず出発内容を作り、表示された内容を確認してから出発します。出発は自動では行いません。"
                                )
                                lite_travel_build_snapshot = gr.Button(
                                    "選んだペルソナの出発内容を作る", variant="primary"
                                )
                                lite_travel_departure_summary = gr.Markdown("出発前の確認: 未作成")
                                with gr.Accordion("技術情報（snapshot JSON）", open=False):
                                    lite_travel_snapshot_json = gr.Code(
                                        label="生成済みsnapshot（読み取り専用）",
                                        language="json",
                                        interactive=False,
                                        lines=12,
                                    )
                                lite_travel_start_button = gr.Button(
                                    "表示内容を確認して出発する",
                                    variant="secondary",
                                    interactive=False,
                                )

                            with gr.Group(
                                elem_classes=["lite-outing-stage"], visible=False
                            ) as lite_travel_return_group:
                                gr.Markdown(
                                    "### 4. 帰宅\n"
                                    "Liteで増えた会話を先に確認し、問題がなければ本体へ戻します。帰宅も自動では行いません。"
                                )
                                lite_travel_return_preview_button = gr.Button(
                                    "帰宅する内容を確認", variant="primary"
                                )
                                lite_travel_return_preview = gr.Markdown("帰宅内容: 未確認")
                                lite_travel_online_return_button = gr.Button(
                                    "確認した内容を本体へ戻す",
                                    variant="secondary",
                                    interactive=False,
                                )
                                with gr.Accordion("オンライン帰宅できないとき（ファイルで復旧）", open=False):
                                    gr.Markdown("帰宅データ（署名付きbundle）を書き出し、本体で署名を確認して取り込みます。")
                                    lite_travel_export_button = gr.Button("1. 帰宅データを書き出す", variant="secondary")
                                    lite_travel_bundle_file = gr.File(
                                        label="帰宅データ（署名付きbundle / 書き出し後は自動選択）",
                                        file_types=[".json"],
                                        interactive=True,
                                    )
                                    lite_travel_import_button = gr.Button("2. 署名を確認して本体へ戻す", variant="primary")
                                with gr.Accordion("帰宅後の追加設定（通常は不要）", open=False):
                                    lite_travel_route_proposals = gr.CheckboxGroup(
                                        choices=[], value=[], label="次回のお出かけ設定へ反映するペルソナ",
                                    )
                                    lite_travel_apply_routes = gr.Button("選んだ会話経路を次回へ反映", variant="secondary")
                                    lite_travel_route_apply_status = gr.Markdown("会話経路の反映: 未実行")

                            with gr.Accordion("保守・復旧操作（問題があるときだけ）", open=False):
                                gr.Markdown(
                                    "ここは通常のお出かけでは使いません。削除や緊急帰還は元に戻せない場合があるため、"
                                    "状況を確認してから実行してください。"
                                )
                                lite_travel_delete_content = gr.Button("Lite用クラウド上の会話本文を削除", variant="stop")
                                lite_travel_emergency_reason = gr.Textbox(
                                    label="緊急帰還の理由",
                                    placeholder="Lite用クラウドへ接続できない等。分岐可能性として記録されます。",
                                )
                                lite_travel_emergency_button = gr.Button("緊急帰還して本体を再開", variant="stop")

                        with gr.Column(
                            visible=True,
                            elem_id="outing_lite_setup",
                            elem_classes=["outing-mode-panel"],
                        ) as outing_lite_setup_group:
                            _api_gateway_settings = config_manager.CONFIG_GLOBAL.get("api_gateway_settings", {}) or {}
                            external_api_status = gr.Markdown("API状態: 待機中")

                            with gr.Accordion("Nexus Ark Liteを使い始める", open=True):
                                gr.HTML(value=ui_handlers.build_api_gateway_personal_use_guide())
                                with gr.Row():
                                    lite_start_connected_button = gr.Button(
                                        "PCをつけたまま使う",
                                        variant="secondary",
                                    )
                                    lite_start_independent_button = gr.Button(
                                        "PCを止めても使う",
                                        variant="primary",
                                    )
                                open_lite_cloud_quick_guide_btn = gr.Button(
                                    "「PCを止めても使う」の詳しい説明", variant="secondary"
                                )

                            with gr.Accordion(
                                "本体接続の設定",
                                open=False,
                                elem_id="lite_connected_setup_flow",
                            ) as lite_connected_setup_accordion:
                                gr.Markdown(
                                    "### 1. 用途\n"
                                    "PCで起動中のNexus Ark本体へスマホやタブレットから接続し、"
                                    "本体と同じ会話・記憶・機能を使うモードです。独立モード用のデータ作成は不要です。\n\n"
                                    "### 2. 必要条件\n"
                                    "PCの電源とNexus Arkを起動したままにし、スマホを **同じWi-Fi** に接続するか、"
                                    "PCとスマホの両方で **Tailscale** に接続します。PCがスリープ・終了するとLiteも切断されます。\n\n"
                                    "### 3. 本体URLと接続用Token\n"
                                    "**本体URL** はスマホから開く住所、**接続用Token** はこの本体へ入るための合言葉です。"
                                    "Token認証は通常ONのまま使い、Tokenを他人へ送ったり、公開画面やスクリーンショットへ載せたりしないでください。"
                                    "初回は下の「Token生成」を押し、接続方法を選んでから設定を保存します。"
                                )
                                with gr.Row():
                                    external_api_enabled_checkbox = gr.Checkbox(
                                        label="本体接続を有効にする（API Gateway）",
                                        value=bool(_api_gateway_settings.get("enabled", False)),
                                        interactive=True,
                                        scale=1,
                                    )
                                    external_api_require_auth_checkbox = gr.Checkbox(
                                        label="Token認証を使う（推奨・通常はON）",
                                        value=bool(_api_gateway_settings.get("require_auth", True)),
                                        interactive=True,
                                        scale=1,
                                    )
                                with gr.Row():
                                    external_api_auth_token_input = gr.Textbox(
                                        label="接続用Token（スマホ用の合言葉）",
                                        value=_api_gateway_settings.get("auth_token", ""),
                                        type="password",
                                        interactive=True,
                                        scale=3,
                                    )
                                    external_api_token_generate_button = gr.Button("Token生成", variant="secondary", scale=1)
                                    external_api_token_show_button = gr.Button("保存済みTokenを表示", variant="secondary", scale=1)
                                external_api_token_copy_output = gr.Textbox(
                                    label="PWA入力用Token（一時表示）",
                                    value="",
                                    interactive=False,
                                    lines=1,
                                    placeholder="「保存済みTokenを表示」を押すと、PWAへコピーするTokenを表示します。",
                                )
                                with gr.Accordion("接続先の詳細（通常は変更不要）", open=False):
                                    gr.Markdown(
                                        "通常は **Host `0.0.0.0` / Port `8000`** のまま使います。"
                                        "別のアプリとPortが重なる場合や、詳しい案内を受けた場合だけ変更してください。"
                                    )
                                    with gr.Row():
                                        external_api_host_input = gr.Textbox(
                                            label="Host",
                                            value=_api_gateway_settings.get("host", "0.0.0.0"),
                                            interactive=True,
                                            scale=2,
                                        )
                                        external_api_port_input = gr.Number(
                                            label="Port",
                                            value=int(_api_gateway_settings.get("port", 8000) or 8000),
                                            precision=0,
                                            interactive=True,
                                            scale=1,
                                        )
                                gr.Markdown(
                                    "### 4. 同じWi-FiとHTTPSの選び方\n"
                                    "- **同じWi-Fi**: 最初に試しやすい方法です。表示された `http://192.168...` のURLをスマホで開きます。\n"
                                    "- **Tailscale HTTPS**: Liteのインストール、音声入力、通知も使う場合の推奨方法です。"
                                    "PCとスマホへTailscaleを導入してログインしてから設定します。\n\n"
                                    "公共Wi-Fiや、ルーターでインターネットへ直接公開する使い方は避けてください。"
                                )
                                external_api_auto_tailscale_checkbox = gr.Checkbox(
                                    label="次回起動時もTailscale HTTPSを自動設定",
                                    value=bool(_api_gateway_settings.get("auto_start_tailscale_serve", False)),
                                    interactive=True,
                                )
                                with gr.Row():
                                    external_api_save_button = gr.Button("本体接続の設定を保存", variant="primary")
                                    external_tailscale_button = gr.Button("Tailscale HTTPS設定を実行", variant="secondary")
                                    external_api_refresh_button = gr.Button("スマホ用URL・接続情報を更新", variant="secondary")
                                with gr.Accordion("Nexus Ark Lite 接続情報", open=True):
                                    external_lite_connection_help = gr.Markdown(
                                        "設定を保存し、「スマホ用URL・接続情報を更新」を押すと、ここに本体URLが表示されます。"
                                    )
                                    external_lite_qr_image = gr.HTML(
                                        ui_handlers.build_api_gateway_lite_qr_html()
                                    )
                                gr.Markdown(
                                    "### 5. スマホで接続を確認\n"
                                    "上に表示されたURLをスマホで開き、Liteの「設定」→「接続設定」で本体URLとTokenを確認して"
                                    "「接続」を押します。画面上部が **🏠 本体接続**、メニューが **接続済み** になり、"
                                    "ルーム一覧や会話が表示されれば完了です。"
                                    "同じWi-Fiで開けない時は、Windowsの確認画面でNexus ArkまたはPythonの"
                                    " **プライベートネットワーク** 通信だけを許可してください。\n\n"
                                    "### 6. 普段の使い方\n"
                                    "次回からはPCでNexus Arkを起動して、同じスマホのブラウザまたはホーム画面へ追加したLiteを開きます。"
                                    "本体URLとTokenはその端末に保存されるため、通常は再入力不要です。接続先を変えた時やTokenを作り直した時だけ更新してください。"
                                )

                            _lite_travel_settings = config_manager.CONFIG_GLOBAL.get("lite_travel_settings", {}) or {}
                            with gr.Accordion(
                                "PCを止めても使うための初回設定",
                                open=False,
                                elem_id="lite_independent_setup_flow",
                            ) as lite_independent_setup_accordion:
                                _lite_cloud_setup_initial = ui_handlers.build_lite_cloud_setup_initial_view(
                                    _lite_travel_settings
                                )
                                lite_cloud_setup_state = gr.State(_lite_cloud_setup_initial[0])
                                gr.Markdown(
                                    "### 1. Liteの準備を確認\n"
                                    "表示されたボタンを押して、このPCの準備状態を確認してください。"
                                )
                                with gr.Accordion("Liteの準備ツール", open=True):
                                    gr.Markdown(
                                        "Lite独立モードを使う準備ができているか確認します。"
                                    )
                                    lite_runtime_status = gr.Markdown(
                                        "### Liteの準備ツール: 未確認\n\n「状態を確認」を押してください。"
                                    )
                                    lite_runtime_status_button = gr.Button(
                                        "状態を確認", variant="primary"
                                    )
                                    with gr.Accordion("確認した内容", open=False):
                                        lite_runtime_details = gr.Markdown(
                                            "まだ診断していません。診断はローカルのファイルを読むだけで、Cloudflareを変更しません。"
                                        )
                                    with gr.Group(visible=False) as lite_runtime_repair_group:
                                        gr.Markdown(
                                            "「次の手順を確認」を押すと、続けて押すボタンが"
                                            "すぐ下に表示されます。"
                                        )
                                        lite_runtime_repair_check_button = gr.Button(
                                            "次の手順を確認", variant="secondary"
                                        )
                                        lite_runtime_repair_result = gr.Markdown("")
                                        lite_runtime_repair_apply_button = gr.Button(
                                            "署名済み更新で修復", variant="primary", visible=False
                                        )
                                gr.Markdown("#### Cloudflareアカウントを選ぶ")
                                gr.Markdown(
                                    "既存のCloudflareアカウントを使うか、新しいアカウントを作成して接続します。"
                                )
                                gr.Markdown(
                                    "**別の／新しいアカウントを使う**  \n"
                                    "Cloudflare公式画面が別タブで開きます。初めて作る場合は"
                                    "「Sign up（新規登録）」、すでに持っている場合は"
                                    "「Sign in（ログイン）」を選びます。"
                                    "「Authorize（接続を許可）」は、登録・ログイン後の接続許可画面で押します。"
                                )
                                lite_cloud_setup_login_confirm = gr.Checkbox(
                                    label="ブラウザでCloudflareへの接続を許可する",
                                    value=False,
                                )
                                lite_cloud_setup_login_hint = gr.Markdown(
                                    "先に上の接続許可をチェックしてください。"
                                )
                                lite_cloud_setup_login_button = gr.Button(
                                    "別の／新しいアカウントで接続",
                                    variant="secondary",
                                    interactive=False,
                                )
                                lite_cloud_setup_login_status = gr.Markdown("アカウントの追加・切替: この画面では未実行（保存済みのLite接続とは別の操作です）")
                                lite_cloud_setup_summary = gr.Markdown(_lite_cloud_setup_initial[1])
                                with gr.Group(
                                    visible=bool(
                                        _lite_cloud_setup_initial[20].get("visible", False)
                                    )
                                ) as lite_cloud_setup_check_group:
                                    lite_cloud_setup_check_button = gr.Button(
                                        value=_lite_cloud_setup_initial[3].get(
                                            "value", "Cloudflareの接続・アカウントを確認"
                                        ),
                                        variant=_lite_cloud_setup_initial[3].get(
                                            "variant", "primary"
                                        ),
                                        visible=True,
                                        interactive=bool(
                                            _lite_cloud_setup_initial[3].get("interactive", True)
                                        ),
                                    )
                                with gr.Group(
                                    visible=bool(
                                        _lite_cloud_setup_initial[18].get("visible", False)
                                    )
                                ) as lite_cloud_setup_account_group:
                                    gr.Markdown(
                                        "**表示中のアカウントを使う**  \n"
                                        "ここに表示されるのは、Cloudflareにすでにあるアカウントです。"
                                    )
                                    with gr.Row():
                                        lite_cloud_setup_account = gr.Dropdown(
                                            label="利用するCloudflareアカウント",
                                            choices=_lite_cloud_setup_initial[4].get("choices", []),
                                            value=_lite_cloud_setup_initial[4].get("value"),
                                            visible=True,
                                            interactive=bool(
                                                _lite_cloud_setup_initial[4].get("interactive", True)
                                            ),
                                        )
                                        lite_cloud_setup_confirm_account_button = gr.Button(
                                            "このアカウントで続ける",
                                            variant=_lite_cloud_setup_initial[5].get(
                                                "variant", "primary"
                                            ),
                                            visible=True,
                                            interactive=bool(
                                                _lite_cloud_setup_initial[5].get(
                                                    "interactive", False
                                                )
                                            ),
                                        )
                                with gr.Group(
                                    visible=bool(
                                        _lite_cloud_setup_initial[17].get("visible", False)
                                    )
                                ) as lite_cloud_setup_manual_account_group:
                                    gr.Markdown(
                                        "**アカウント候補を取得できない時だけ使う復旧欄**  \n"
                                        "Cloudflare公式Dashboardで対象を開き、表示名とaccount IDを照合してください。"
                                        "account IDはこのPC内の診断にだけ使い、コマンド引数へ出しません。"
                                    )
                                    lite_cloud_setup_manual_account_name = gr.Textbox(
                                        label="Cloudflare公式画面のアカウント表示名",
                                        placeholder="例: 自分専用のLite用アカウント",
                                    )
                                    lite_cloud_setup_manual_account_id = gr.Textbox(
                                        label="Cloudflare公式画面で照合したaccount ID",
                                        type="password",
                                    )
                                    lite_cloud_setup_manual_account_confirm = gr.Checkbox(
                                        label=(
                                            "表示名とaccount IDが一致し、D1／KV／Workerが全0件、"
                                            "workers.devが未登録であることを公式Dashboardで確認しました"
                                        ),
                                        value=False,
                                    )
                                    lite_cloud_setup_manual_account_button = gr.Button(
                                        "照合したアカウントを読み取り確認",
                                        variant="primary",
                                    )
                                with gr.Group(
                                    visible=bool(
                                        _lite_cloud_setup_initial[19].get("visible", False)
                                    )
                                ) as lite_cloud_setup_mode_group:
                                    with gr.Row():
                                        lite_cloud_setup_new_button = gr.Button(
                                            "新しいLite用クラウドの作成内容を確認",
                                            variant=_lite_cloud_setup_initial[6].get(
                                                "variant", "secondary"
                                            ),
                                            visible=True,
                                            interactive=bool(
                                                _lite_cloud_setup_initial[6].get(
                                                    "interactive", False
                                                )
                                            ),
                                        )
                                        lite_cloud_setup_import_button = gr.Button(
                                            "準備済みのLite用クラウドを接続",
                                            variant=_lite_cloud_setup_initial[7].get(
                                                "variant", "primary"
                                            ),
                                            visible=True,
                                            interactive=bool(
                                                _lite_cloud_setup_initial[7].get(
                                                    "interactive", False
                                                )
                                            ),
                                        )
                                with gr.Group(
                                    visible=bool(_lite_cloud_setup_initial[8].get("visible", False))
                                ) as lite_cloud_setup_plan_group:
                                    lite_cloud_setup_plan_summary = gr.Markdown(
                                        _lite_cloud_setup_initial[9].get("value", "")
                                    )
                                    gr.Markdown(ui_handlers.build_lite_cloud_setup_release_gate_notice())
                                    gr.Markdown(
                                        "**CloudflareのSubdomainを確認**  \n"
                                        "[Cloudflare Dashboard](https://dash.cloudflare.com/) を開き、"
                                        "**Build → Compute → Workers & Pages** へ進みます。"
                                        "画面右側の **Account details → Subdomain** に表示された値を、"
                                        "そのまま下へ入力してください。"
                                    )
                                    lite_cloud_setup_worker_url = gr.Textbox(
                                        label="Cloudflareに表示されたSubdomain（必須）",
                                        value=_lite_cloud_setup_initial[10].get("value", ""),
                                        visible=True,
                                        interactive=bool(
                                            _lite_cloud_setup_initial[10].get("interactive", True)
                                        ),
                                        placeholder="例: my-subdomain.workers.dev",
                                        info="末尾が workers.dev の表示をそのまま入力できます。"
                                        "完全なLite URLが分かる場合は、https:// から入力することもできます。",
                                    )
                                    lite_cloud_setup_prepare_confirm = gr.Checkbox(
                                        label=ui_handlers.build_lite_cloud_setup_prepare_consent_label(),
                                        value=bool(
                                            _lite_cloud_setup_initial[11].get("value", False)
                                        ),
                                        visible=True,
                                        interactive=bool(
                                            _lite_cloud_setup_initial[11].get("interactive", True)
                                        ),
                                    )
                                    lite_cloud_setup_prepare_button = gr.Button(
                                        value=_lite_cloud_setup_initial[12].get(
                                            "value", "確認した計画で準備を開始"
                                        ),
                                        variant=_lite_cloud_setup_initial[12].get(
                                            "variant", "secondary"
                                        ),
                                        visible=True,
                                        interactive=bool(
                                            _lite_cloud_setup_initial[12].get("interactive", False)
                                        ),
                                    )
                                with gr.Group(
                                    visible=bool(
                                        _lite_cloud_setup_initial[13].get("visible", False)
                                    )
                                ) as lite_cloud_setup_publish_group:
                                    lite_cloud_setup_publish_summary = gr.Markdown(
                                        _lite_cloud_setup_initial[14].get("value", "")
                                    )
                                    lite_cloud_setup_publish_confirm = gr.Checkbox(
                                        label="公開URL・残る資源・料金の可能性を確認し、このLite用クラウドを公開することに同意します",
                                        value=bool(
                                            _lite_cloud_setup_initial[15].get("value", False)
                                        ),
                                        visible=True,
                                        interactive=bool(
                                            _lite_cloud_setup_initial[15].get("interactive", True)
                                        ),
                                    )
                                    lite_cloud_setup_publish_button = gr.Button(
                                        value=_lite_cloud_setup_initial[16].get(
                                            "value", "Lite用クラウドを公開して接続を確認"
                                        ),
                                        variant=_lite_cloud_setup_initial[16].get(
                                            "variant", "secondary"
                                        ),
                                        visible=True,
                                        interactive=bool(
                                            _lite_cloud_setup_initial[16].get("interactive", False)
                                        ),
                                    )
                                with gr.Accordion("接続確認の詳しい情報（必要な時だけ）", open=False):
                                    lite_cloud_setup_details = gr.Markdown(_lite_cloud_setup_initial[2])
                                gr.Markdown("---")
                                gr.Markdown(
                                    "### 2. AIサービスとモデルを選ぶ\n"
                                    "「1. Liteの準備を確認」でLite用クラウドの公開・接続確認が完了してから、"
                                    "Liteで使うAIサービスとモデルを選びます。"
                                    "Cloudflareへのログインだけでは、まだ準備は完了していません。"
                                )
                                with gr.Accordion(
                                    "本体に保存済みのAIサービスをLiteでも使えるようにする",
                                    open=True,
                                ):
                                    gr.Markdown(
                                        "APIキーの再入力は不要です。PCを止めても使えるよう、選んだ1件を"
                                        "あなたのLite用クラウドへ安全に保存します。"
                                    )
                                    gr.Markdown(
                                        "予備を登録する場合は、下の「登録する接続」で予備枠を選びます。"
                                        "旅行前に日次とお出かけ全体の予算を確認してください。"
                                        "Geminiは同一Google project内で無料枠が共通です。"
                                    )
                                    _lite_travel_initial_keys = lite_travel.get_local_key_choices("gemini")
                                    _lite_travel_initial_key_state = (
                                        ui_handlers.build_lite_provider_key_setup_state(
                                            "gemini", _lite_travel_initial_keys
                                        )
                                    )
                                    _lite_travel_initial_registration_choices = (
                                        ui_handlers.build_lite_provider_registration_choices("gemini")
                                    )
                                    _lite_travel_initial_registration_binding = (
                                        _lite_travel_initial_registration_choices[0][1]
                                        if _lite_travel_initial_registration_choices
                                        else None
                                    )
                                    with gr.Row():
                                        lite_travel_secret_provider = gr.Dropdown(
                                            label="AIサービス",
                                            choices=[
                                                ("Gemini", "gemini"),
                                                ("OpenAI", "openai"),
                                                ("Anthropic", "anthropic"),
                                                ("xAI", "xai"),
                                                ("OpenRouter", "openrouter"),
                                            ],
                                            value="gemini",
                                            interactive=True,
                                        )
                                        lite_travel_local_key_reference = gr.Dropdown(
                                            label="本体に保存済みのAPIキー",
                                            choices=_lite_travel_initial_keys,
                                            value=_lite_travel_initial_keys[0][1] if _lite_travel_initial_keys else None,
                                            interactive=True,
                                        )
                                    lite_travel_secret_registration_target = gr.Dropdown(
                                        label="登録する接続",
                                        choices=_lite_travel_initial_registration_choices,
                                        value=_lite_travel_initial_registration_binding,
                                        interactive=True,
                                        info="通常用または予備の接続先を選びます。登録は選んだ1件だけです。",
                                    )
                                    lite_travel_local_key_status = gr.Markdown(
                                        _lite_travel_initial_key_state["status"]
                                    )
                                    with gr.Accordion("詳細設定（通常は変更不要）", open=False):
                                        with gr.Row():
                                            lite_travel_secret_binding = gr.Dropdown(
                                                label="Cloudflare Secretの保存名",
                                                choices=[
                                                    binding
                                                    for _label, binding in _lite_travel_initial_registration_choices
                                                ],
                                                value=_lite_travel_initial_registration_binding,
                                                interactive=False,
                                            )
                                            lite_travel_secret_profile_id = gr.Textbox(
                                                label="Lite内部のAI接続ID",
                                                value="gemini-personal-1",
                                                interactive=True,
                                            )
                                            lite_travel_secret_display_name = gr.Textbox(
                                                label="Liteに表示する名前",
                                                value="Gemini（個人用1）",
                                                interactive=True,
                                            )
                                    lite_travel_secret_confirm = gr.Checkbox(
                                        label="選んだ保存済みキー1件を、自分のLite用クラウドへ保存することを確認しました",
                                        value=False,
                                    )
                                    lite_travel_secret_register_button = gr.Button(
                                        _lite_travel_initial_key_state["button_label"],
                                        variant="secondary",
                                        interactive=_lite_travel_initial_key_state["interactive"],
                                    )
                                    lite_travel_secret_status = gr.Markdown("")
                                    with gr.Accordion("登録済み接続に本体のキー名を表示する", open=False):
                                        gr.Markdown(
                                            "上のキーと登録先を、その接続へ登録した時と同じ組合せで選びます。"
                                            "本体のキー名と、Geminiでは本体の有料設定／無料設定を表示へ反映します。"
                                            "実際の課金状態を確認するものではありません。キー値の再送や接続の変更は行いません。"
                                        )
                                        lite_travel_profile_label_confirm = gr.Checkbox(
                                            label="選んだ本体キーが、この接続に登録したキーと同じだと確認しました",
                                            value=False,
                                        )
                                        lite_travel_profile_label_button = gr.Button(
                                            "キー名の表示だけを更新",
                                            variant="secondary",
                                            interactive=_lite_travel_initial_key_state["interactive"],
                                        )

                                with gr.Accordion("Lite用クラウドの接続情報（通常は変更不要）", open=False):
                                    gr.Markdown("初回設定で自動保存されます。接続を修復する場合以外は変更不要です。キーは公開・共有しないでください。")
                                    lite_travel_worker_url = gr.Textbox(
                                        label="Lite用クラウドのURL（Worker URL）",
                                        value=_lite_travel_settings.get("worker_url", ""),
                                        placeholder="https://your-worker.example.workers.dev",
                                    )
                                    with gr.Row():
                                        lite_travel_owner_token = gr.Textbox(
                                            label="本体確認キー（OWNER Token）",
                                            value=_lite_travel_settings.get("owner_token", ""),
                                            type="password",
                                        )
                                        lite_travel_signing_key = gr.Textbox(
                                            label="帰宅データ確認キー（署名鍵）",
                                            value=_lite_travel_settings.get("bundle_signing_key", ""),
                                            type="password",
                                        )
                                    lite_travel_wrangler_config_path = gr.Textbox(
                                        label="詳細設定ファイル（通常は変更不要）",
                                        value=_lite_travel_settings.get("wrangler_config_path", "cloud/lite-relay/wrangler.phase2.jsonc"),
                                    )
                                with gr.Row():
                                    _lite_travel_initial_profile = str(
                                        _lite_travel_settings.get("credential_profile_id", "gemini-personal-1") or ""
                                    )
                                    lite_travel_credential_profile_id = gr.Dropdown(
                                        label="使用するAIサービス／接続",
                                        choices=ui_handlers.build_lite_ai_connection_choices(
                                            _lite_travel_initial_profile
                                        ),
                                        value=_lite_travel_initial_profile or None,
                                        interactive=True,
                                    )
                                    _lite_travel_initial_model = str(_lite_travel_settings.get("model_id", "") or "")
                                    lite_travel_model_id = gr.Dropdown(
                                        label="最初に使うAIモデル（必須）",
                                        choices=ui_handlers.build_lite_travel_model_choices(
                                            _lite_travel_initial_profile,
                                            _lite_travel_initial_model,
                                        ),
                                        value=_lite_travel_initial_model or None,
                                        filterable=True,
                                        interactive=True,
                                        allow_custom_value=True,
                                        info="普段と同じモデルを一覧から選ぶか、最新のモデル名を直接入力できます。",
                                    )
                                lite_travel_refresh_models_button = gr.Button(
                                    "最新のモデル一覧を取得",
                                    variant="secondary",
                                    size="sm",
                                )
                                lite_travel_ai_connection_status = gr.Markdown(
                                    "本体に保存済みの候補を表示しています。必要なら最新一覧を取得できます。"
                                )
                                lite_travel_use_custom_model = gr.State(False)
                                lite_travel_custom_model_id = gr.State("")
                                with gr.Row():
                                    lite_travel_retention_days = gr.Dropdown(
                                        label="帰宅後、Lite用クラウドに会話本文を残す期間",
                                        choices=[
                                            ("帰宅時にすぐ削除（0日）", 0),
                                            ("帰宅後7日で削除", 7),
                                            ("帰宅後30日で削除", 30),
                                        ],
                                        value=int(_lite_travel_settings.get("retention_days", 7)),
                                        interactive=True,
                                    )
                                gr.Markdown(
                                    "この期間は、帰宅後の会話本文を復旧用に残す長さです。"
                                    "「お出かけ前データ」の保存期間とは別です。"
                                )
                                with gr.Accordion("料金と応答の詳細設定（通常は変更不要）", open=False):
                                    with gr.Row():
                                        lite_travel_daily_budget = gr.Number(
                                            label="1日の利用上限（USD）",
                                            value=_lite_travel_settings.get("budget_daily_limit_usd", 1.0),
                                            minimum=0,
                                        )
                                        lite_travel_session_budget = gr.Number(
                                            label="1回のお出かけ上限（USD）",
                                            value=_lite_travel_settings.get("budget_session_limit_usd", 0.5),
                                            minimum=0,
                                        )
                                        lite_travel_budget_warning_ratio = gr.Slider(
                                            label="上限の何割で警告するか",
                                            minimum=0.1,
                                            maximum=1.0,
                                            step=0.05,
                                            value=float(_lite_travel_settings.get("budget_warning_ratio", 0.8)),
                                        )
                                    with gr.Row():
                                        lite_travel_max_output_tokens = gr.Number(
                                            label="1回答の最大長（空欄は自動）",
                                            value=_lite_travel_settings.get("budget_max_output_tokens"),
                                            minimum=1,
                                            maximum=65536,
                                            precision=0,
                                            info="通常は空欄のまま、選んだモデルに長さを任せます。必要な場合だけ上限を指定します。",
                                        )
                                        lite_travel_budget_timezone = gr.Textbox(
                                            label="1日の区切りに使う地域",
                                            value=_lite_travel_settings.get("budget_timezone", "Asia/Tokyo"),
                                        )
                                        lite_travel_cache_policy = gr.Dropdown(
                                            label="応答を効率化する仕組み",
                                            choices=[
                                                ("自動（おすすめ）", "auto"),
                                                ("使用しない", "off"),
                                                ("Geminiの明示キャッシュ", "gemini_explicit"),
                                            ],
                                            value=_lite_travel_settings.get("cache_policy", "auto"),
                                        )
                                    lite_travel_allow_unknown_price = gr.State(True)
                                lite_travel_settings_save = gr.Button("AIと独立お出かけ設定を保存", variant="primary")
                                lite_travel_settings_status = gr.Markdown("設定: 未確認")

                                with gr.Accordion("詳しい診断・端末管理（問題がある時だけ）", open=False):
                                    gr.Markdown(
                                        "ここから下は、詳しい診断や端末の解除を行う時だけ使います。"
                                        "技術用語を含むため、通常の利用では変更しないでください。"
                                    )
                                    lite_phase5_diagnostics_button = gr.Button("Lite用クラウドを詳しく診断", variant="secondary")
                                    lite_phase5_diagnostic_export_button = gr.Button("共有用診断を生成", variant="secondary")
                                    lite_phase5_diagnostics_status = gr.Markdown("詳しい診断: 未実行")
                                    with gr.Row():
                                        lite_phase5_devices_button = gr.Button("接続済みスマホを確認", variant="secondary")
                                        lite_phase5_revoke_all_confirm = gr.Checkbox(label="すべてのスマホ接続解除を確認", value=False)
                                        lite_phase5_revoke_all_button = gr.Button("すべてのスマホ接続を解除", variant="stop")
                                    lite_phase5_devices_status = gr.Markdown("接続済みスマホ: 未取得")
                                    with gr.Row():
                                        lite_phase5_device_id = gr.Textbox(label="解除するスマホのID")
                                        lite_phase5_revoke_device_confirm = gr.Checkbox(label="このスマホの接続解除を確認", value=False)
                                        lite_phase5_revoke_device_button = gr.Button("このスマホの接続を解除", variant="stop")
                                    with gr.Row():
                                        lite_phase5_retention_preview_button = gr.Button("削除期限を迎えたデータを確認", variant="secondary")
                                        lite_phase5_retention_run_button = gr.Button("期限を迎えた本文を削除", variant="stop")
                                    lite_phase5_retention_status = gr.Markdown("保存期限の処理: 未実行")

                            with gr.Accordion(
                                "接続確認とスマホ登録",
                                open=False,
                                visible=True,
                                elem_id="lite_independent_connectivity_flow",
                            ) as lite_independent_connectivity_accordion:
                                gr.Markdown(
                                    "### 3. 接続確認とスマホ登録\n"
                                    "4状態を確認して、スマホを登録します。"
                                )
                                with gr.Row():
                                    lite_connectivity_flow = gr.Radio(
                                        label="今回の目的",
                                        choices=[
                                            ("初回設定", "initial"),
                                            ("既存接続の確認", "existing"),
                                            ("端末を再登録", "re_pair"),
                                        ],
                                        value="existing",
                                        interactive=True,
                                    )
                                    lite_connectivity_refresh_button = gr.Button(
                                        "4状態を確認", variant="primary"
                                    )
                                lite_connectivity_card = gr.HTML(
                                    value=ui_handlers.build_lite_connectivity_wizard(
                                        "existing",
                                        refresh_remote=False,
                                        refresh_action_label="4状態を確認",
                                    )
                                )
                                with gr.Accordion(
                                    "Lite用クラウドを更新",
                                    open=False,
                                    # 初期DOMを保持し、後から開いた時にも子の手順・ボタンを描画する。
                                    visible="hidden",
                                    elem_id="lite_worker_update_guide",
                                ) as lite_worker_update_guide:
                                    gr.Markdown(
                                        "### 次にすること：Lite用クラウドを更新\n"
                                        "左サイドバーの **🔄 アップデート・再起動** で"
                                        "「本体とスマホ版の更新を確認」を押し、"
                                        "**スマホ版Liteも更新** から実行できます。"
                                        "保存領域名や更新計画の入力は不要です。"
                                    )
                                    with gr.Accordion("詳細・復旧手順", open=False):
                                        gr.Markdown(
                                            "接続設定を復旧する場合の手順です。保存領域名は接続設定から自動入力します。"
                                            "空欄の場合はCloudflare Dashboardの「Storage & databases」→"
                                            "「D1 SQL Database」に表示される **Name** を確認してください。**UUIDではありません。**"
                                        )
                                        _lite_update_preflight_text, _lite_update_preflight_ready = (
                                            ui_handlers.build_lite_update_preflight_view()
                                        )
                                        lite_update_preflight_status = gr.Markdown(_lite_update_preflight_text)
                                        with gr.Row():
                                            lite_phase5_database_name = gr.Textbox(
                                                label="1. 更新する保存領域（自動入力）",
                                                value=ui_handlers.build_lite_update_database_name(),
                                                placeholder="例: nexus-ark-lite-relay（UUIDではありません）",
                                                info="通常は変更不要です。空欄の場合だけCloudflareのD1一覧にあるNameを確認してください。",
                                            )
                                            lite_phase5_plan_button = gr.Button(
                                                "2. 安全更新計画を作成",
                                                variant="primary" if _lite_update_preflight_ready else "secondary",
                                                interactive=_lite_update_preflight_ready,
                                            )
                                        with gr.Accordion("3. 作成された更新計画を確認", open=False):
                                            lite_phase5_operation = gr.Code(
                                                label="再開可能な更新操作（秘密値なし）",
                                                language="json", interactive=False, lines=10,
                                            )
                                        lite_phase5_update_confirm = gr.Checkbox(
                                            label="復旧点を取得してから保存領域とLite用クラウドを更新し、自動では元に戻さないことを確認しました",
                                            value=False,
                                        )
                                        lite_phase5_run_button = gr.Button(
                                            "4. 確認した更新計画を実行", variant="secondary", interactive=False,
                                        )
                                        lite_phase5_update_status = gr.Markdown(
                                            "まず「2. 安全更新計画を作成」を押してください。計画作成だけではクラウドを変更しません。"
                                        )
                                        gr.Markdown("更新成功後は4状態を再診断します。失敗時は自動で元へ戻さず、復旧点を表示します。")
                                with gr.Group(visible=False) as lite_connectivity_retention_group:
                                    lite_connectivity_retention_prompt = gr.Markdown("")
                                    with gr.Row():
                                        lite_connectivity_retention_delete_button = gr.Button(
                                            "期限切れ本文を削除して状態を更新",
                                            variant="stop",
                                        )
                                        lite_connectivity_retention_dismiss_button = gr.Button(
                                            "今は削除しない",
                                            variant="secondary",
                                        )
                                lite_pairing_code_ttl_minutes = gr.Dropdown(
                                    choices=[("5分", 5), ("15分", 15), ("30分", 30)],
                                    value=15,
                                    label="登録用コードの有効期限",
                                    info="発行時に適用します。標準は15分です。ペアリング後の端末認証の期限とは別です。",
                                    allow_custom_value=False,
                                )
                                with gr.Row():
                                    lite_connectivity_pair_button = gr.Button(
                                        "短期ペアリングコードを発行", variant="secondary"
                                    )
                                    lite_connectivity_prepare_button = gr.Button(
                                        "現在のルームのデータを直接準備（選択画面を省略）",
                                        variant="secondary",
                                        visible=False,
                                    )
                                gr.Markdown(
                                    "発行したコードは、実際に持ち出すPWAで入力します。"
                                    "お出かけ前データの細かな選択は、次の日常画面で行えます。"
                                )
                                lite_connectivity_action_status = gr.Markdown("操作結果: 未実行")
                                lite_connectivity_pairing_handoff = gr.HTML("")
                                lite_connectivity_open_travel_button = gr.Button(
                                    "4. お出かけの準備へ進む",
                                    variant="primary",
                                )

                            with gr.Accordion("安全診断", open=False):
                                external_api_security_diagnostics = gr.Markdown(
                                    value=ui_handlers.build_api_gateway_security_diagnostics()
                                )

                        with gr.Column(
                            visible=False,
                            elem_id="outing_export_panel",
                            elem_classes=["outing-mode-panel"],
                        ) as outing_export_group:
                            gr.Markdown(
                                "## 外部AIへ持ち出す\n"
                                "Gemini・ChatGPT・Claudeなどで会話を続ける文面を作ります。\n\n"
                                "1. **読み込む** — 現在のペルソナ情報を集めます。  \n"
                                "2. **内容を確認する** — 個人情報や渡したくない記憶を削除できます。  \n"
                                "3. **文面をコピーする** — 外部AIの最初のメッセージ欄へ貼り付けます。"
                            )

                            # --- 読み込みボタン ---
                            with gr.Row():
                                outing_load_button = gr.Button("🔄 読み込む", variant="primary", scale=1)
                                outing_total_char_count = gr.Markdown("📝 合計文字数: ---")

                            # --- セクション別アコーディオン ---
                            # システムプロンプト
                            with gr.Accordion("📜 システムプロンプト", open=False):
                                outing_system_prompt_text = gr.Textbox(
                                    label="システムプロンプト", lines=8, max_lines=20, interactive=True,
                                    placeholder="「🔄 読み込む」で読み込まれます"
                                )
                                with gr.Row():
                                    outing_system_prompt_chars = gr.Markdown("文字数: ---")
                                    outing_system_prompt_reload = gr.Button("🔄", variant="secondary", scale=0, min_width=40)
                                    outing_system_prompt_compress = gr.Button("✨ 圧縮", variant="secondary", scale=0)

                            # コアメモリ（永続記憶）
                            with gr.Accordion("🧠 コアメモリ（永続記憶）", open=False):
                                outing_permanent_text = gr.Textbox(
                                    label="永続記憶", lines=8, max_lines=20, interactive=True,
                                    placeholder="「🔄 読み込む」で読み込まれます"
                                )
                                with gr.Row():
                                    outing_permanent_chars = gr.Markdown("文字数: ---")
                                    outing_permanent_reload = gr.Button("🔄", variant="secondary", scale=0, min_width=40)
                                    outing_permanent_compress = gr.Button("✨ 圧縮", variant="secondary", scale=0)

                            # コアメモリ（日記要約）
                            with gr.Accordion("📔 コアメモリ（日記要約）", open=False):
                                outing_diary_text = gr.Textbox(
                                    label="日記要約", lines=8, max_lines=20, interactive=True,
                                    placeholder="「🔄 読み込む」で読み込まれます"
                                )
                                with gr.Row():
                                    outing_diary_chars = gr.Markdown("文字数: ---")
                                    outing_diary_reload = gr.Button("🔄", variant="secondary", scale=0, min_width=40)
                                    outing_diary_compress = gr.Button("✨ 圧縮", variant="secondary", scale=0)

                            # エピソード記憶
                            with gr.Accordion("📖 エピソード記憶", open=False):
                                outing_episode_days_slider = gr.Slider(
                                    minimum=0, maximum=90, value=7, step=1,
                                    label="過去N日分", info="0で無効 (最大90日)"
                                )
                                outing_episodic_text = gr.Textbox(
                                    label="エピソード記憶", lines=8, max_lines=20, interactive=True,
                                    placeholder="「🔄 読み込む」で読み込まれます"
                                )
                                with gr.Row():
                                    outing_episodic_chars = gr.Markdown("文字数: ---")
                                    outing_episodic_reload = gr.Button("🔄", variant="secondary", scale=0, min_width=40)
                                    outing_episodic_compress = gr.Button("✨ 圧縮", variant="secondary", scale=0)

                            # 会話ログ
                            with gr.Accordion("💬 会話ログ", open=False):
                                with gr.Row():
                                    outing_log_mode = gr.Radio(
                                        choices=["最新N件", "本日分（高度）"],
                                        value="最新N件",
                                        label="構成モード",
                                        scale=1
                                    )
                                    outing_log_count_slider = gr.Slider(
                                        minimum=5, maximum=100, value=20, step=5,
                                        label="取得件数", scale=1, visible=True
                                    )
                                    with gr.Column(visible=False) as outing_log_today_options:
                                        outing_auto_summary_checkbox = gr.Checkbox(
                                            label="自動要約を有効化",
                                            value=False
                                        )
                                        outing_log_summary_threshold = gr.Slider(
                                            minimum=5000, maximum=100000, value=12000, step=1000,
                                            label="要約閾値",
                                            info="この文字数を超えると前半を要約します"
                                        )
                                with gr.Row():
                                    outing_logs_include_timestamp = gr.Checkbox(label="タイムスタンプを含む", value=False, scale=1)
                                    outing_logs_include_model = gr.Checkbox(label="モデル名を含む", value=False, scale=1)
                                    outing_logs_wrap_tags = gr.Checkbox(label="過去ログをタグで囲む（帰宅時の重複除去用）", value=True, scale=1)
                                outing_logs_text = gr.Textbox(
                                    label="会話ログ", lines=8, max_lines=20, interactive=True,
                                    placeholder="「🔄 読み込む」で読み込まれます"
                                )
                                with gr.Row():
                                    outing_logs_chars = gr.Markdown("文字数: ---")
                                    outing_logs_reload = gr.Button("🔄", variant="secondary", scale=0, min_width=40)
                                    outing_logs_compress = gr.Button("✨ 圧縮", variant="secondary", scale=0)

                            # --- エクスポートプレビュー・実行 ---
                            gr.Markdown("---")
                            gr.Markdown("### 📝 エクスポートプレビュー")
                            with gr.Row():
                                outing_system_prompt_enabled = gr.Checkbox(label="システムプロンプト", value=True, scale=1)
                                outing_permanent_enabled = gr.Checkbox(label="永続記憶", value=True, scale=1)
                                outing_diary_enabled = gr.Checkbox(label="日記要約", value=True, scale=1)
                                outing_episodic_enabled = gr.Checkbox(label="エピソード記憶", value=True, scale=1)
                                outing_logs_enabled = gr.Checkbox(label="会話ログ", value=True, scale=1)

                            outing_preview_text = gr.Textbox(
                                label="エクスポート内容の最終確認・編集",
                                lines=15, max_lines=30, interactive=True,
                                placeholder="各セクションを読み込むとここに結合された内容が表示されます",
                                elem_id="outing_preview_area"
                            )

                            with gr.Row():
                                outing_copy_button = gr.Button("📋 文面をコピー", variant="primary", scale=2)
                                outing_export_button = gr.Button("📤 ファイルに保存", variant="secondary", scale=1)
                                outing_open_folder_button = gr.Button("📂 フォルダを開く", variant="secondary", scale=1)
                            outing_download_file = gr.File(label="ダウンロード", visible=False, elem_id="outing_download_file")

                        with gr.Column(
                            visible=False,
                            elem_id="outing_import_panel",
                            elem_classes=["outing-mode-panel"],
                        ) as outing_import_group:
                            gr.Markdown(
                                "## 外部AIから帰宅\n"
                                "外部AIで増えた会話を確認し、現在のルームへ追記します。"
                            )

                            # ファイル取り込み
                            with gr.Accordion("📂 ファイルから取り込み", open=False):
                                with gr.Column(elem_classes=["outing-accordion-content"]):
                                    gr.Markdown(
                                        "ChatGPT・Claudeなどの会話を **MD/TXT** に整え、"
                                        "発言の先頭を `[user]` と `[AI]` にして読み込みます。"
                                        "公式サービスのJSON書き出しを直接読む機能ではありません。"
                                    )
                                    outing_import_file = gr.File(label="ログファイルをアップロード（MD/TXT）", file_types=[".md", ".txt"])
                                    with gr.Accordion("発言ヘッダーなどの詳細設定", open=False):
                                        outing_import_source = gr.Textbox(
                                            label="お出かけ先の名称",
                                            value="外部チャットアプリ",
                                            placeholder="例: Gemini, ChatGPT, Claude",
                                        )
                                        outing_import_user_header = gr.Textbox(label="ユーザーの発言ヘッダー", value="[user]", placeholder="例: [user]")
                                        outing_import_agent_header = gr.Textbox(label="AIの発言ヘッダー", value="[AI]", placeholder="例: [AI]")

                                    with gr.Row():
                                        outing_import_include_marker = gr.Checkbox(label="システムマーカー（開始・終了アナウンス）を含める", value=True)

                                    with gr.Row():
                                        outing_import_load_button = gr.Button("1. ファイルを読み込んでプレビュー", variant="secondary")

                                    outing_import_preview_text = gr.Textbox(
                                        label="インポート内容のプレビュー（ここで編集・調整できます）",
                                        lines=10, max_lines=25,
                                        placeholder="ファイルを読み込むとここに内容が表示されます",
                                        interactive=True,
                                        visible=False
                                    )

                                    outing_import_execute_button = gr.Button("2. ログを履歴に統合して帰宅する", variant="primary", visible=False)

                            # URL取り込み (Gemini)
                            with gr.Accordion("♊ Gemini共有URLから取り込み", open=False):
                                with gr.Column(elem_classes=["outing-accordion-content"]):
                                    gr.Markdown("Geminiの公開共有URLは、そのまま読み込んで内容を確認できます。")
                                    gemini_import_url = gr.Textbox(label="共有URL", placeholder="https://gemini.google.com/share/...", lines=1)
                                    with gr.Row():
                                        gemini_import_include_marker = gr.Checkbox(label="システムマーカーを含める", value=True)
                                    gemini_import_load_button = gr.Button("1. URLの内容を読み込んでプレビュー", variant="secondary")
                                    gemini_import_status = gr.Markdown("")

                            outing_import_status = gr.Markdown("ステータス: 待機中")

                    with gr.TabItem("Roblox", id="external_roblox", key="external_tab_roblox", visible=False):
                        gr.Markdown("## Roblox")
                        with gr.Accordion("クイックスタートガイド", open=False):
                            roblox_guide_display = gr.Markdown(value=ui_handlers.load_roblox_guide())
                        with gr.Row():
                            roblox_api_key_input = gr.Textbox(label="Open Cloud API Key", type="password", interactive=True, scale=2)
                            roblox_universe_id_input = gr.Textbox(label="Universe ID", interactive=True, scale=1)
                        with gr.Row():
                            roblox_topic_input = gr.Textbox(label="MessagingService Topic", value="NexusArkCommands", interactive=True)
                            roblox_filtering_enabled_checkbox = gr.Checkbox(label="チャットフィルタリング", value=True, interactive=True)
                        with gr.Row():
                            roblox_webhook_enabled_checkbox = gr.Checkbox(label="Webhookを有効化", value=True, interactive=True)
                            roblox_activation_mode_radio = gr.Radio(
                                choices=[("自動", "auto"), ("有効", "enabled"), ("無効", "disabled")],
                                value="auto",
                                label="起動モード",
                                interactive=True,
                            )
                        roblox_webhook_domain_input = gr.Textbox(label="Webhook公開URL / Cloudflare Tunnel URL", interactive=True)
                        with gr.Row():
                            save_cloudflare_url_button = gr.Button("URLだけ保存", variant="secondary")
                            save_roblox_settings_button = gr.Button("Roblox設定を保存", variant="primary")
                            test_roblox_connection_button = gr.Button("接続テスト", variant="secondary")
                        roblox_webhook_secret_input = gr.Textbox(label="Webhook Secret", type="password", interactive=False)
                        with gr.Row():
                            roblox_webhook_regenerate_button = gr.Button("Webhook Secretを再生成", variant="secondary")
                            roblox_webhook_refresh_logs_button = gr.Button("Webhookログを更新", variant="secondary")
                        roblox_test_result_output = gr.Textbox(label="接続テスト結果", lines=4, interactive=False)
                        roblox_webhook_logs_display = gr.Textbox(label="Webhookログ", lines=8, interactive=False)

            with gr.TabItem("クローゼット・アイテム", id="items", key="top_tab_items") as item_root_tab:
                with gr.Tabs(selected="item_creation_tab") as item_sub_tabs:
                    with gr.TabItem("アイテム作成", id="item_creation_tab"):
                        with gr.Tabs(selected="std_item_placeholder_tab") as item_creation_tabs:
                            with gr.TabItem("通常アイテム", id="std_item_placeholder_tab"):
                                gr.Markdown("## 📦 通常アイテム作成\n装飾品、雑貨、家具などのアイテムを作成できます。")

                                with gr.Accordion("📝 新規作成", open=True):
                                    with gr.Row():
                                        std_item_name_input = gr.Textbox(label="アイテム名", placeholder="例: 銀の懐中時計", scale=2)
                                        std_item_category_input = gr.Dropdown(
                                            label="カテゴリ",
                                            choices=["アクセサリー", "服飾", "雑貨", "容器", "食器", "家具", "道具", "その他"],
                                            value="雑貨",
                                            allow_custom_value=True,
                                            scale=1
                                        )
                                        std_item_amount_input = gr.Number(label="個数", value=1, minimum=1, maximum=99, precision=0, scale=1)

                                    with gr.Row():
                                        std_item_base_info = gr.Textbox(
                                            label="詳細・エピソード（任意）",
                                            placeholder="例: 代々受け継がれてきた、裏蓋に獅子の刻印がある銀製の懐中時計。",
                                            lines=3,
                                            scale=3
                                        )
                                        std_item_image_input = gr.Image(label="アイテムの画像 (オプション)", type="filepath", scale=1)

                                    with gr.Accordion("🎨 画像を生成", open=False):
                                        std_item_image_gen_prompt = gr.Textbox(
                                            label="画像生成プロンプト",
                                            placeholder="例: A small antique silver pocket watch with a lion engraving, product photo, detailed",
                                            lines=2
                                        )
                                        std_item_image_gen_refs = gr.File(
                                            label="参照画像（任意・最大4枚）",
                                            file_types=["image"],
                                            file_count="multiple"
                                        )
                                        std_item_image_gen_button = gr.Button("🎨 画像を生成", variant="secondary")

                                    std_item_generate_button = gr.Button("✨ AIで詳細を生成", variant="primary")
                                    std_item_status = gr.Markdown("", visible=False)

                                    with gr.Accordion("🎨 外見と質感", open=False):
                                        with gr.Row():
                                            std_item_appearance_desc = gr.Textbox(label="外見の説明", placeholder="例: 鈍い銀の光沢を放つ、円形の金属ケース。")
                                            std_item_appearance_color = gr.Textbox(label="基調の色", placeholder="例: 曇った銀色")
                                            std_item_appearance_design = gr.Textbox(label="意匠・装飾", placeholder="例: 裏蓋の獅子刻印")
                                        with gr.Row():
                                            std_item_texture = gr.Textbox(label="質感・手触り", placeholder="例: 滑らかで冷んやりとした金属感")
                                            std_item_weight = gr.Textbox(label="重量感", placeholder="例: 手のひらに心地よい重み")
                                            std_item_temp = gr.Textbox(label="温度感", placeholder="例: 常に冷たい")

                                    std_item_flavor_text = gr.Textbox(label="フレーバーテキスト（情景描写用）", lines=3)
                                    std_item_raw_json_state = gr.State(value=None)

                                    with gr.Row():
                                        std_item_save_button = gr.Button("💾 保存 / 上書き", variant="primary", scale=2)
                                        std_item_save_as_new_button = gr.Button("➕ 別アイテムとして保存", variant="secondary", scale=2)
                                        load_std_item_to_editor_button = gr.Button("📝 選択中のアイテムを読み込む", variant="secondary", scale=1)

                            with gr.TabItem("食べ物", id="food_item_placeholder_tab"):
                                gr.Markdown("## 🍳 食べ物アイテム作成\nAIアシストを使って、味覚データ付きの食べ物アイテムを作成できます。")

                                with gr.Accordion("📝 新規作成", open=True):
                                    with gr.Row():
                                        food_item_name_input = gr.Textbox(label="アイテム名", placeholder="例: 手作りクッキー", scale=2)
                                        food_item_category_input = gr.Dropdown(
                                            label="カテゴリ",
                                            choices=["料理", "お菓子", "飲み物", "果物", "パン", "その他"],
                                            value="料理",
                                            allow_custom_value=True,
                                            scale=1
                                        )
                                        food_item_amount_input = gr.Number(label="個数", value=1, minimum=1, maximum=99, precision=0, scale=1)

                                    with gr.Row():
                                        food_item_base_info = gr.Textbox(
                                            label="詳細・エピソード（任意）",
                                            placeholder="例: 心を込めて焼いたチョコチップクッキー。少し焦げがある。",
                                            lines=3,
                                            scale=3
                                        )
                                        food_item_image_input = gr.Image(label="アイテムの画像 (オプション)", type="filepath", scale=1)

                                    with gr.Accordion("🎨 画像を生成", open=False):
                                        food_item_image_gen_prompt = gr.Textbox(
                                            label="画像生成プロンプト",
                                            placeholder="例: Freshly baked chocolate chip cookies on a small plate, warm lighting, appetizing",
                                            lines=2
                                        )
                                        food_item_image_gen_refs = gr.File(
                                            label="参照画像（任意・最大4枚）",
                                            file_types=["image"],
                                            file_count="multiple"
                                        )
                                        food_item_image_gen_button = gr.Button("🎨 画像を生成", variant="secondary")

                                    food_item_generate_button = gr.Button("✨ AIで味覚データを生成", variant="primary")
                                    food_item_status = gr.Markdown("", visible=False)

                                    with gr.Accordion("🔬 味覚パラメータ", open=False):
                                        with gr.Row():
                                            food_sweetness = gr.Slider(0, 1, step=0.1, label="甘味", value=0)
                                            food_saltiness = gr.Slider(0, 1, step=0.1, label="塩味", value=0)
                                            food_sourness = gr.Slider(0, 1, step=0.1, label="酸味", value=0)
                                        with gr.Row():
                                            food_bitterness = gr.Slider(0, 1, step=0.1, label="苦味", value=0)
                                            food_umami = gr.Slider(0, 1, step=0.1, label="旨味", value=0)
                                        food_taste_description = gr.Textbox(label="味の詳細説明", lines=2)

                                    with gr.Accordion("🌡️ 物理感覚 (食感・温度)", open=False):
                                        with gr.Row():
                                            food_temp = gr.Slider(0, 1, step=0.1, label="温度 (低↔高)", value=0.5)
                                            food_astringency = gr.Slider(0, 1, step=0.1, label="渋み", value=0)
                                            food_viscosity = gr.Slider(0, 1, step=0.1, label="とろみ", value=0)
                                            food_weight = gr.Slider(0, 1, step=0.1, label="重み/密度", value=0.5)
                                        food_phys_description = gr.Textbox(label="物理的な感触の説明", lines=2)

                                    with gr.Accordion("⏳ 香り・味の時間的変化", open=False):
                                        with gr.Row():
                                            food_time_top = gr.Textbox(label="第一印象 (Top)", placeholder="例: 鮮烈な柑橘の香り")
                                            food_time_middle = gr.Textbox(label="広がり (Middle)", placeholder="例: 包み込むような甘さ")
                                            food_time_last = gr.Textbox(label="余韻 (Last)", placeholder="例: 仄かな苦味と郷愁")

                                    with gr.Accordion("🎨 共感覚・イメージ", open=False):
                                        with gr.Row():
                                            food_syn_color = gr.Textbox(label="浮かぶ色", placeholder="例: 深い琥珀色")
                                            food_syn_emotion = gr.Textbox(label="呼び起こす感情", placeholder="例: 静かな安堵、憧憬")
                                        food_syn_landscape = gr.Textbox(label="連想する風景", placeholder="夕暮れの古い図書館")

                                    food_flavor_text = gr.Textbox(label="短評・フレーバーテキスト（食べた時の演出文）", lines=3)
                                    food_raw_json_state = gr.State(value=None)

                                    with gr.Row():
                                        food_item_save_button = gr.Button("💾 保存 / 上書き", variant="primary", scale=2)
                                        food_item_save_as_new_button = gr.Button("➕ 別アイテムとして保存", variant="secondary", scale=2)
                                        load_food_item_to_editor_button = gr.Button("📝 選択中のアイテムを読み込む", variant="secondary", scale=1)

                    with gr.TabItem("インベントリ", id="inventory_tab"):
                        gr.Markdown("## 📦 インベントリ管理\nユーザーとペルソナの所持品を一括管理できます。")
                        with gr.Row():
                            inventory_target_radio = gr.Radio(
                                ["ユーザー", "ペルソナ"],
                                label="表示対象",
                                value="ユーザー",
                                interactive=True
                            )
                            inventory_refresh_btn = gr.Button("🔄 最新の状態に更新", variant="secondary")

                        unified_inventory_df = gr.HTML(
                            "<p class='info-text'>「最新の状態に更新」を押すとインベントリを読み込みます。</p>",
                            elem_id="unified_inventory_df"
                        )
                        inventory_item_dropdown = gr.Dropdown(
                            label="操作するアイテム",
                            choices=[],
                            value=None,
                            interactive=False,
                        )

                        inventory_status = gr.Markdown("", visible=False)

                        with gr.Row():
                            inventory_edit_btn = gr.Button("📝 編集", variant="secondary")
                            inventory_copy_btn = gr.Button("👯 複製", variant="secondary")
                            inventory_delete_btn = gr.Button("🗑️ 削除", variant="stop")
                            inventory_transfer_btn = gr.Button("🎁 相手に渡す", variant="primary")

                        with gr.Accordion("👕 クローゼットに登録（着用可能にする）", open=False):
                            with gr.Row():
                                closet_bridge_part_dropdown = gr.Dropdown(
                                    label="部位",
                                    choices=list(closet_manager.CLOSET_PARTS),
                                    value="その他",
                                    interactive=True,
                                    scale=1,
                                )
                                closet_bridge_name_input = gr.Textbox(label="登録名", scale=2)
                            closet_bridge_description_input = gr.Textbox(label="説明", lines=3, max_lines=8)
                            closet_bridge_tags_input = gr.Textbox(label="タグ（カンマ区切り）")
                            with gr.Row():
                                closet_bridge_prefill_button = gr.Button("選択アイテム情報を入力", variant="secondary")
                                closet_bridge_register_button = gr.Button("👕 クローゼットに登録", variant="primary")
                                user_closet_bridge_register_button = gr.Button("👤 ユーザー外見に登録", variant="secondary")

                        inventory_selected_idx = gr.State(None)
                        inventory_selected_item_id = gr.State(None)

                    with gr.TabItem("クローゼット", id="closet_catalog_tab"):
                        gr.Markdown("## 👕 クローゼット")
                        closet_scope_radio = gr.Radio(
                            ["ユーザー", "ペルソナ"],
                            label="表示対象",
                            value="ユーザー",
                            interactive=True,
                        )

                        with gr.Column(visible=True) as closet_user_group:
                            _initial_user_common_closet = ui_handlers.load_user_closet_common_ui()
                            _initial_user_room_closet = ui_handlers.load_user_closet_room_ui(effective_initial_room)
                            with gr.Accordion("🪞 姿見", open=False):
                                _initial_user_appearance = ui_handlers.load_current_appearance_ui(effective_initial_room, "user")
                                _initial_user_appearance_image = (
                                    _initial_user_appearance[0].get("value")
                                    if isinstance(_initial_user_appearance[0], dict)
                                    else _initial_user_appearance[0]
                                )
                                user_appearance_preview = gr.Image(
                                    label="現在の姿",
                                    value=_initial_user_appearance_image,
                                    type="filepath",
                                    interactive=False,
                                    height=640,
                                )
                                user_appearance_status = gr.Markdown(_initial_user_appearance[1])
                                user_appearance_extra_prompt = gr.Textbox(
                                    label="生成時の補足（任意）",
                                    lines=2,
                                    max_lines=6,
                                    placeholder="ポーズ、構図、背景、画風などを必要に応じて指定",
                                )
                                user_appearance_use_current_state = gr.State(True)
                                user_appearance_reset_reference_state = gr.State(False)
                                with gr.Row():
                                    user_appearance_generate_button = gr.Button("🔄 この姿をもとに再生成", variant="secondary")
                                    user_appearance_reset_button = gr.Button("🎨 基準画像から作り直す", variant="primary")
                                with gr.Accordion("共通既定", open=False):
                                    user_common_closet_enabled = gr.Checkbox(
                                        label="ユーザー外見を使う",
                                        value=bool(_initial_user_common_closet[0]),
                                        interactive=True,
                                    )
                                    user_common_closet_description = gr.Textbox(
                                        label="ベース外見",
                                        value=_initial_user_common_closet[1],
                                        lines=5,
                                        max_lines=14,
                                        placeholder="髪型・髪色・目・服装の基調・体格・年齢感など",
                                        interactive=True,
                                    )
                                    with gr.Row():
                                        user_common_closet_save_button = gr.Button("ユーザー外見を保存", variant="primary")
                                        user_common_closet_upload_button = gr.UploadButton("参照画像を追加", file_types=["image"], scale=1)
                                    user_common_closet_gallery = gr.Gallery(
                                        label="登録済み参照画像",
                                        value=_initial_user_common_closet[2],
                                        columns=2,
                                        height=360,
                                        object_fit="contain",
                                    )
                                    with gr.Row():
                                        user_common_closet_delete_ref_dropdown = gr.Dropdown(
                                            label="削除する参照画像",
                                            choices=getattr(_initial_user_common_closet[3], "get", lambda _k, _d=None: _d)("choices", []),
                                            value=getattr(_initial_user_common_closet[3], "get", lambda _k, _d=None: _d)("value", None),
                                            interactive=True,
                                            allow_custom_value=False,
                                            scale=3,
                                        )
                                        user_common_closet_delete_ref_button = gr.Button("選択画像を削除", variant="stop", scale=1)
                                    user_common_current_note = gr.Textbox(
                                        label="現在の装いメモ",
                                        value=_initial_user_common_closet[7],
                                        lines=2,
                                        max_lines=6,
                                        interactive=True,
                                    )
                                    user_common_current_note_save_button = gr.Button("現在の装いメモを保存", variant="secondary")
                                    user_common_current_outfit = gr.Markdown(_initial_user_common_closet[8])
                                    user_common_closet_status = gr.Markdown(_initial_user_common_closet[9])

                                with gr.Accordion("このルーム", open=True):
                                    user_room_use_common = gr.Checkbox(
                                        label="共通設定を使う",
                                        value=bool(_initial_user_room_closet[0]),
                                        interactive=True,
                                    )
                                    user_room_closet_enabled = gr.Checkbox(
                                        label="このルーム専用のユーザー外見を使う",
                                        value=getattr(_initial_user_room_closet[1], "get", lambda _k, _d=None: _d)("value", False),
                                        interactive=getattr(_initial_user_room_closet[1], "get", lambda _k, _d=None: _d)("interactive", True),
                                    )
                                    user_room_closet_description = gr.Textbox(
                                        label="ベース外見",
                                        value=getattr(_initial_user_room_closet[2], "get", lambda _k, _d=None: _d)("value", ""),
                                        lines=5,
                                        max_lines=14,
                                        placeholder="共通設定を使わない場合、このルームだけのユーザー外見を設定します。",
                                        interactive=getattr(_initial_user_room_closet[2], "get", lambda _k, _d=None: _d)("interactive", True),
                                    )
                                    with gr.Row():
                                        user_room_closet_save_button = gr.Button("このルームのユーザー外見を保存", variant="primary")
                                        user_room_closet_upload_button = gr.UploadButton("参照画像を追加", file_types=["image"], scale=1)
                                        user_room_promote_to_common_button = gr.Button("この設定を共通にする", variant="secondary")
                                    user_room_closet_gallery = gr.Gallery(
                                        label="登録済み参照画像",
                                        value=_initial_user_room_closet[3],
                                        columns=2,
                                        height=360,
                                        object_fit="contain",
                                    )
                                    with gr.Row():
                                        user_room_closet_delete_ref_dropdown = gr.Dropdown(
                                            label="削除する参照画像",
                                            choices=getattr(_initial_user_room_closet[4], "get", lambda _k, _d=None: _d)("choices", []),
                                            value=getattr(_initial_user_room_closet[4], "get", lambda _k, _d=None: _d)("value", None),
                                            interactive=True,
                                            allow_custom_value=False,
                                            scale=3,
                                        )
                                        user_room_closet_delete_ref_button = gr.Button("選択画像を削除", variant="stop", scale=1)
                                    user_room_current_note = gr.Textbox(
                                        label="現在の装いメモ",
                                        value=getattr(_initial_user_room_closet[8], "get", lambda _k, _d=None: _d)("value", ""),
                                        lines=2,
                                        max_lines=6,
                                        interactive=getattr(_initial_user_room_closet[8], "get", lambda _k, _d=None: _d)("interactive", True),
                                    )
                                    user_room_current_note_save_button = gr.Button("現在の装いメモを保存", variant="secondary")
                                    user_room_current_outfit = gr.Markdown(_initial_user_room_closet[9])
                                    user_room_closet_status = gr.Markdown(_initial_user_room_closet[10])

                            with gr.Accordion("📋 クローゼット管理", open=False):
                                with gr.Accordion("共通既定", open=False):
                                    user_common_closet_html = gr.HTML(_initial_user_common_closet[4])
                                    user_common_closet_dropdown = gr.Dropdown(
                                        label="操作する項目",
                                        choices=getattr(_initial_user_common_closet[5], "get", lambda _k, _d=None: _d)("choices", []),
                                        value=getattr(_initial_user_common_closet[5], "get", lambda _k, _d=None: _d)("value", None),
                                        interactive=True,
                                        allow_custom_value=False,
                                    )
                                    user_common_closet_selected_id = gr.State(None)
                                    user_common_closet_detail = gr.Markdown(_initial_user_common_closet[6])
                                    with gr.Row():
                                        user_common_closet_wear_button = gr.Button("着用", variant="primary")
                                        user_common_closet_takeoff_button = gr.Button("脱ぐ", variant="secondary")
                                        user_common_closet_delete_button = gr.Button("削除", variant="stop")
                                    with gr.Accordion("リアル服を登録", open=False):
                                        user_common_real_image = gr.Image(label="服の画像", type="filepath")
                                        with gr.Row():
                                            user_common_real_name = gr.Textbox(label="名前", scale=2)
                                            user_common_real_part = gr.Dropdown(
                                                label="部位",
                                                choices=list(closet_manager.CLOSET_PARTS),
                                                value="その他",
                                                scale=1,
                                            )
                                        user_common_real_description = gr.Textbox(label="説明", lines=3)
                                        user_common_real_tags = gr.Textbox(label="タグ（カンマ区切り）")
                                        user_common_real_register_button = gr.Button("リアル服を登録", variant="primary")

                                with gr.Accordion("このルーム", open=True):
                                    user_room_closet_html = gr.HTML(_initial_user_room_closet[5])
                                    user_room_closet_dropdown = gr.Dropdown(
                                        label="操作する項目",
                                        choices=getattr(_initial_user_room_closet[6], "get", lambda _k, _d=None: _d)("choices", []),
                                        value=getattr(_initial_user_room_closet[6], "get", lambda _k, _d=None: _d)("value", None),
                                        interactive=True,
                                        allow_custom_value=False,
                                    )
                                    user_room_closet_selected_id = gr.State(None)
                                    user_room_closet_detail = gr.Markdown(_initial_user_room_closet[7])
                                    with gr.Row():
                                        user_room_closet_wear_button = gr.Button("着用", variant="primary")
                                        user_room_closet_takeoff_button = gr.Button("脱ぐ", variant="secondary")
                                        user_room_closet_delete_button = gr.Button("削除", variant="stop")
                                    with gr.Accordion("リアル服を登録", open=False):
                                        user_room_real_image = gr.Image(label="服の画像", type="filepath")
                                        with gr.Row():
                                            user_room_real_name = gr.Textbox(label="名前", scale=2)
                                            user_room_real_part = gr.Dropdown(
                                                label="部位",
                                                choices=list(closet_manager.CLOSET_PARTS),
                                                value="その他",
                                                scale=1,
                                            )
                                        user_room_real_description = gr.Textbox(label="説明", lines=3)
                                        user_room_real_tags = gr.Textbox(label="タグ（カンマ区切り）")
                                        user_room_real_register_button = gr.Button("リアル服を登録", variant="primary")

                        with gr.Column(visible=False) as closet_persona_group:
                            with gr.Accordion("🪞 姿見", open=False):
                                _initial_persona_appearance = ui_handlers.load_current_appearance_ui(effective_initial_room, "persona")
                                _initial_persona_appearance_image = (
                                    _initial_persona_appearance[0].get("value")
                                    if isinstance(_initial_persona_appearance[0], dict)
                                    else _initial_persona_appearance[0]
                                )
                                persona_appearance_preview = gr.Image(
                                    label="現在の姿",
                                    value=_initial_persona_appearance_image,
                                    type="filepath",
                                    interactive=False,
                                    height=640,
                                )
                                persona_appearance_status = gr.Markdown(_initial_persona_appearance[1])
                                persona_appearance_extra_prompt = gr.Textbox(
                                    label="生成時の補足（任意）",
                                    lines=2,
                                    max_lines=6,
                                    placeholder="ポーズ、構図、背景、画風などを必要に応じて指定",
                                )
                                persona_appearance_use_current_state = gr.State(True)
                                persona_appearance_reset_reference_state = gr.State(False)
                                with gr.Row():
                                    persona_appearance_generate_button = gr.Button("🔄 この姿をもとに再生成", variant="secondary")
                                    persona_appearance_reset_button = gr.Button("🎨 基準画像から作り直す", variant="primary")
                                _initial_closet_profile = ui_handlers.load_closet_profile_ui(effective_initial_room)
                                closet_enabled_checkbox = gr.Checkbox(
                                    label="このペルソナでクローゼットを使う",
                                    value=bool(_initial_closet_profile[0]),
                                    interactive=True,
                                )
                                closet_description_textbox = gr.Textbox(
                                    label="ベース外見",
                                    value=_initial_closet_profile[1],
                                    lines=6,
                                    max_lines=18,
                                    placeholder="髪型・髪色・目・服装の基調・体格・年齢感など",
                                    interactive=True,
                                )
                                with gr.Row():
                                    closet_save_button = gr.Button("クローゼットを保存", variant="primary")
                                    closet_image_upload_button = gr.UploadButton(
                                        "参照画像を追加",
                                        file_types=["image"],
                                        scale=1,
                                    )
                                closet_reference_gallery = gr.Gallery(
                                    label="登録済み参照画像",
                                    value=_initial_closet_profile[2],
                                    columns=2,
                                    height=360,
                                    object_fit="contain",
                                )
                                with gr.Row():
                                    closet_reference_delete_dropdown = gr.Dropdown(
                                        label="削除する参照画像",
                                        choices=getattr(_initial_closet_profile[3], "get", lambda _k, _d=None: _d)("choices", []),
                                        value=getattr(_initial_closet_profile[3], "get", lambda _k, _d=None: _d)("value", None),
                                        interactive=True,
                                        allow_custom_value=False,
                                        scale=3,
                                    )
                                    closet_reference_delete_button = gr.Button("選択画像を削除", variant="stop", scale=1)
                                closet_status_markdown = gr.Markdown(_initial_closet_profile[4])

                            with gr.Accordion("📋 クローゼット管理", open=False):
                                _initial_closet_catalog = ui_handlers.load_closet_catalog_ui(effective_initial_room)
                                gr.Markdown("## 👕 クローゼット管理")
                                with gr.Row():
                                    closet_catalog_refresh_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                                closet_catalog_html = gr.HTML(_initial_closet_catalog[0], elem_id="closet_catalog_table")
                                closet_catalog_dropdown = gr.Dropdown(
                                    label="操作するクローゼット項目",
                                    choices=getattr(_initial_closet_catalog[1], "get", lambda _k, _d=None: _d)("choices", []),
                                    value=getattr(_initial_closet_catalog[1], "get", lambda _k, _d=None: _d)("value", None),
                                    interactive=True,
                                    allow_custom_value=False,
                                )
                                closet_selected_item_id = gr.State(None)
                                closet_catalog_detail = gr.Markdown(_initial_closet_catalog[2])
                                with gr.Row():
                                    closet_wear_button = gr.Button("着用", variant="primary")
                                    closet_take_off_button = gr.Button("脱ぐ", variant="secondary")
                                    closet_delete_button = gr.Button("削除", variant="stop")
                                closet_current_note_textbox = gr.Textbox(
                                    label="現在の装いメモ",
                                    value=_initial_closet_catalog[3],
                                    lines=2,
                                    max_lines=6,
                                    interactive=True,
                                )
                                closet_current_note_save_button = gr.Button("現在の装いメモを保存", variant="secondary")
                                closet_current_outfit_markdown = gr.Markdown(_initial_closet_catalog[4])
                                closet_catalog_status = gr.Markdown(_initial_closet_catalog[5])

            with gr.TabItem("ワールド・ビルダー", id="world_builder", key="top_tab_world_builder") as world_builder_tab:
                gr.Markdown("## ワールド・ビルダー\n`world_settings.txt` の内容を、直感的に、または直接的に編集・確認できます。")
                load_world_builder_button = gr.Button("🔄 読み込む", variant="secondary")

                with gr.Tabs():
                    with gr.TabItem("構造化エディタ"):
                        gr.Markdown("エリアと場所を選択して、その内容をピンポイントで編集します。")
                        with gr.Row(equal_height=False):
                            with gr.Column(scale=1, min_width=250):
                                gr.Markdown("### 1. 編集対象を選択")
                                area_selector = gr.Dropdown(label="エリア (`##`)", interactive=True, allow_custom_value=True)
                                place_selector = gr.Dropdown(label="場所 (`###`)", interactive=True, allow_custom_value=True)
                                gr.Markdown("---")
                                add_area_button = gr.Button("エリアを新規作成")
                                add_place_button = gr.Button("場所を新規作成")
                                with gr.Column(visible=False) as new_item_form:
                                    new_item_form_title = gr.Markdown("#### 新規作成")
                                    new_item_type = gr.Textbox(visible=False)
                                    new_item_name = gr.Textbox(label="エリア名 / 場所名 (必須)", placeholder="例: メインエントランス")
                                    with gr.Row():
                                        confirm_add_button = gr.Button("決定", variant="primary")
                                        cancel_add_button = gr.Button("キャンセル")
                            with gr.Column(scale=3):
                                gr.Markdown("### 2. 内容を編集")
                                content_editor = gr.Textbox(label="世界設定を記述", lines=20, interactive=True, visible=False)
                                with gr.Row(visible=False) as save_button_row:
                                    save_button = gr.Button("この場所の設定を保存", variant="primary")
                                    delete_place_button = gr.Button("この場所を削除", variant="stop")

                    with gr.TabItem("RAWテキストエディタ"):
                        gr.Markdown("世界設定ファイル (`world_settings.txt`) の全体像を直接編集します。**書式（`##`や`###`）を崩さないようご注意ください。**")
                        reload_raw_button = gr.Button("🔄 最新の状態に更新", variant="secondary")
                        gr.Markdown("<small>※ 編集中の未保存内容は失われます。</small>")
                        world_settings_raw_editor = gr.Code( # 変数名を _raw_display から _raw_editor に変更
                            label="world_settings.txt",
                            language="markdown",
                            interactive=True, # 編集可能に
                            lines=25
                        )
                        with gr.Row():
                            save_raw_button = gr.Button("RAWテキスト全体を保存", variant="primary")

            with gr.TabItem("デバッグコンソール", id="debug_console", key="top_tab_debug_console"):
                gr.Markdown("## デバッグコンソール\nアプリケーションの内部的な動作ログ（ターミナルに出力される内容）をここに表示します。")
                debug_console_output = gr.Textbox(
                    label="コンソール出力",
                    lines=30,
                    interactive=False,
                    autoscroll=True
                )
                clear_debug_console_button = gr.Button("コンソールをクリア", variant="secondary")

        # --- イベントハンドラ定義 ---
        initial_load_chat_outputs = [
            current_room_name, chatbot_display, current_log_map_state,
            chat_input_multimodal,
            profile_image_display,
            identity_editor, memory_txt_editor, notepad_editor, creative_notes_editor, research_notes_editor, working_memory_slot_dropdown, working_memory_editor, system_prompt_editor,
            core_memory_editor,
            room_dropdown,
            alarm_room_dropdown, timer_room_dropdown, manage_room_selector,
            location_dropdown,
            current_scenery_display, room_tts_provider_dropdown, room_tts_profile_dropdown, room_tts_model_dropdown, room_voice_dropdown,
            room_voice_style_prompt_textbox,
            room_voice_speed_slider, room_voice_pitch_slider, room_voice_intonation_slider, room_voice_volume_slider,
            enable_typewriter_effect_checkbox,
            streaming_speed_slider,
            room_temperature_slider, room_top_p_slider,
            room_safety_harassment_dropdown, room_safety_hate_speech_dropdown,
            room_safety_sexually_explicit_dropdown, room_safety_dangerous_content_dropdown,
            room_display_thoughts_checkbox,
            room_send_thoughts_checkbox,
            room_enable_retrieval_checkbox,
            room_add_timestamp_checkbox,
            room_send_current_time_checkbox,
            room_send_notepad_checkbox,
            room_use_common_prompt_checkbox,
            room_send_core_memory_checkbox,
            room_send_scenery_checkbox,
            room_scenery_send_mode_dropdown,
            auto_memory_enabled_checkbox,
            room_enable_self_awareness_checkbox,
            room_settings_info,
            scenery_image_display,
            enable_scenery_system_checkbox,
            profile_scenery_accordion,
            room_api_history_limit_dropdown,
            room_thinking_level_dropdown,
            api_history_limit_state,
            room_episode_memory_days_dropdown,
            episodic_memory_info_display,
            room_enable_autonomous_checkbox,
            room_autonomous_inactivity_slider,
            room_allow_schedule_tool_checkbox,
            room_schedule_cooldown_slider,
            room_autonomous_guidelines_textbox,
            room_quiet_hours_start,
            room_quiet_hours_end,
            room_persona_workspace_permission_tier_dropdown,
            room_agent_delegation_enabled_checkbox,
            room_agent_delegation_permission_tier_dropdown,
            room_agent_delegation_allow_web_checkbox,
            room_agent_delegation_wake_on_completion_checkbox,
            room_agent_delegation_wake_respect_quiet_hours_checkbox,
            room_agent_delegation_exec_provider_dropdown,
            room_agent_delegation_exec_profile_dropdown,
            room_agent_delegation_exec_model_dropdown,
            room_agent_delegation_backend_info,
            room_model_dropdown,  # [追加] ルーム個別モデル設定 (Dropdown)
            # [Phase 3] 個別プロバイダ設定
            room_provider_radio,
            room_google_settings_group,
            room_openai_settings_group,
            room_api_key_dropdown,
            room_openai_profile_dropdown,  # 追加: プロファイル選択
            room_openai_base_url_input,
            room_openai_api_key_input,
            room_openai_model_dropdown,
            room_openai_tool_use_checkbox,  # 追加: ツール使用オンオフ
            room_rotation_dropdown, # [Phase 1.5]
            roblox_api_key_input,
            roblox_universe_id_input,
            roblox_topic_input,
            roblox_webhook_enabled_checkbox,
            roblox_activation_mode_radio,
            roblox_webhook_domain_input,
            roblox_webhook_secret_input,
            roblox_filtering_enabled_checkbox,  # Step 14: チャットフィルタリング
            # --- 睡眠時記憶整理 ---
            sleep_consolidation_episodic_cb,
            sleep_consolidation_memory_index_cb,
            sleep_consolidation_current_log_cb,
            sleep_consolidation_entity_memory_cb,
            sleep_consolidation_compress_cb,
            sleep_consolidation_extract_questions_cb,
            compress_episodes_status,
            # --- [v25] テーマ設定 ---
            room_theme_enabled_checkbox,  # 個別テーマのオンオフ
            chat_style_radio,
            font_size_slider,
            line_height_slider,
            theme_primary_picker,
            theme_secondary_picker,
            theme_background_picker,
            theme_text_picker,
            theme_accent_soft_picker,
            # --- 詳細設定 ---
            theme_input_bg_picker,
            theme_input_border_picker,
            theme_code_bg_picker,
            theme_subdued_text_picker,
            theme_button_bg_picker,
            theme_button_hover_picker,
            theme_stop_button_bg_picker,
            theme_stop_button_hover_picker,
            theme_checkbox_off_picker,
            theme_table_bg_picker,
            theme_radio_label_picker,
            theme_dropdown_list_bg_picker,
            theme_ui_opacity_slider,
            # 背景画像設定
            theme_bg_image_picker,
            theme_bg_opacity_slider,
            theme_bg_blur_slider,
            theme_bg_size_dropdown,
            theme_bg_position_dropdown,
            theme_bg_repeat_dropdown,
            theme_bg_custom_width,
            theme_bg_radius_slider,
            theme_bg_mask_blur_slider,
            theme_bg_overlay_checkbox,
            theme_bg_src_mode,
            # Sync設定
            theme_bg_sync_opacity_slider,
            theme_bg_sync_blur_slider,
            theme_bg_sync_size_dropdown,
            theme_bg_sync_position_dropdown,
            theme_bg_sync_repeat_dropdown,
            theme_bg_sync_custom_width,
            theme_bg_sync_radius_slider,
            theme_bg_sync_mask_blur_slider,
            theme_bg_sync_overlay_checkbox,
            # ---
            save_room_theme_button,
            style_injector,
            # --- [Phase 11/12] 夢日記対応 ---
            dream_date_dropdown,
            dream_detail_text,
            dream_year_filter,
            dream_month_filter,
            # --- [Phase 14] エピソード記憶閲覧 ---
            episodic_date_dropdown,
            episodic_detail_text,
            episodic_year_filter,
            episodic_month_filter,
            episodic_update_status, # [Phase 14 追加] エピソード更新ステータス
            entity_dropdown,
            entity_content_editor,
            internal_embedding_provider, # [Phase 16 → 統合] エンベディングプロバイダ同期用
            dream_status_display,  # [Phase 17 追加] 睡眠時記憶整理ステータス
            room_auto_summary_checkbox,
            room_auto_summary_threshold_slider,
            room_project_root_input,
            room_project_exclude_dirs_input,
            room_project_exclude_files_input,
            expressions_html,
            expression_target_dropdown,
            creative_notes_file_dropdown,
            research_notes_file_dropdown,
            temp_scenery_display,
            saved_locations_dropdown,
            temp_scenery_image_display,
            scenery_mode_tabs,
            room_include_knowledge_retrieval_checkbox,
            temp_location_applied_status,
            temp_location_name_input,
            creative_year_filter, creative_month_filter, creative_entry_dropdown,
            creative_notes_summary, creative_note_edit_state,
            creative_notes_raw_editor, creative_note_raw_state, creative_notes_details,
            research_year_filter, research_month_filter, research_entry_dropdown,
            research_notes_summary, research_note_edit_state,
            research_notes_raw_editor, research_note_raw_state, research_notes_details,
        ]

        initial_load_outputs = [
            alarm_dataframe, alarm_dataframe_original_data, selection_feedback_markdown
        ] + initial_load_chat_outputs + [
            redaction_rules_df, token_count_display, api_key_dropdown, gemini_delete_key_dropdown,
            world_data_state,
            time_mode_radio,
            fixed_season_dropdown,
            fixed_time_of_day_dropdown,
            fixed_time_controls,
            onboarding_guide,
            onboarding_group,  # オンボーディングモーダルを動的に制御
            model_dropdown,
            debug_mode_checkbox,
            alarm_notification_service_radio,
            user_notification_service_radio,
            backup_rotation_count_number,
            pushover_user_key_input,
            pushover_app_token_input,
            discord_webhook_input,
            image_gen_provider_radio,
            image_gen_api_key_dropdown,
            gemini_image_model_dropdown,
            openai_image_model_dropdown,
            # --- [追加] Pollinations / Hugging Face 画像生成設定 ---
            pollinations_api_key_input,
            pollinations_image_model_dropdown,
            huggingface_api_token_input,
            huggingface_image_model_dropdown,
            paid_keys_checkbox_group,
            allow_external_connection_checkbox,
            custom_scenery_location_dropdown,
            custom_scenery_season_dropdown,
            custom_scenery_time_dropdown,
            # --- [追加] OpenAI設定UIへの反映 ---
            openai_profile_dropdown,
            openai_base_url_input,
            openai_api_key_input,
            openai_model_dropdown,
            openai_tool_use_checkbox,
            # --- 索引ステータス欄（最終更新日時表示用）---
            memory_reindex_status,
            current_log_reindex_status,
            # --- [Phase 3] 内部モデル設定（混合編成対応） ---
            internal_processing_category,
            internal_processing_model,
            internal_summarization_category,
            internal_summarization_model,
            internal_translation_category,
            internal_translation_model,
            internal_embedding_model,
            internal_fallback_checkbox,
            groq_api_key_input, # [Phase 3b]
            local_model_path_input, # [Phase 3c]
            tavily_api_key_input, # [Phase 3]
            settings_rotation_checkbox, # [Phase 1.5]
            release_notes_markdown, # NEW: アップデートUI改善
            # [Added for working memory sync v3]
            working_memory_slot_dropdown,
            working_memory_editor,
            active_working_memory_status,
            system_prompt_editor_room,
            core_memory_editor_room,
        ]
        initial_load_output_count = gr.State(len(initial_load_outputs))

        refresh_common_settings_button.click(
            fn=ui_handlers.handle_initial_load,
            inputs=[current_room_name, initial_load_output_count],
            outputs=initial_load_outputs,
            show_progress="hidden",
        ).then(
            fn=lambda: "共通設定: 設定ファイルから最新状態を読み込みました",
            outputs=[common_settings_status],
            show_progress="hidden",
        )

        world_builder_outputs = [world_data_state, area_selector, world_settings_raw_editor, place_selector]
        session_management_outputs = [active_participants_state, session_status_display, participant_checkbox_group]

        # 【v5: 司令塔契約統一版】
        # ルームの変更や削除時に、UI全体をリフレッシュする全てのコンポーネントをここに集約する
        unified_full_room_refresh_outputs = initial_load_chat_outputs + world_builder_outputs + session_management_outputs + [
            redaction_rules_df,
            archive_date_dropdown,
            time_mode_radio,
            fixed_season_dropdown,
            fixed_time_of_day_dropdown,
            fixed_time_controls,
            attachments_df,
            active_attachments_display,
            custom_scenery_location_dropdown,
            custom_scenery_season_dropdown,
            custom_scenery_time_dropdown,
            # 司令塔間で戻り値の数を統一するための追加コンポーネント
            token_count_display,
            room_delete_confirmed_state, # handle_delete_room が返すリセット値用
            memory_reindex_status,
            current_log_reindex_status,
            # [Added for working memory sync v3]
            active_working_memory_status,
            working_memory_slot_dropdown,
            working_memory_editor,
            system_prompt_editor_room,
            core_memory_editor_room,
        ]
        full_refresh_output_count = gr.State(len(unified_full_room_refresh_outputs))

        refresh_room_settings_button.click(
            fn=lambda: (
                True,
                gr.update(value="設定ファイルから最新値を再取得中...", visible=True),
            ),
            outputs=[is_switching_room, room_transition_status],
            show_progress="hidden",
        ).then(
            fn=ui_handlers.handle_refresh_room_settings_from_disk,
            inputs=[current_room_name, full_refresh_output_count],
            outputs=unified_full_room_refresh_outputs,
            show_progress="hidden",
        ).then(
            fn=lambda room: (
                False,
                gr.update(value="", visible=False),
                f"{room}: 設定ファイルから最新状態を読み込みました",
            ),
            inputs=[current_room_name],
            outputs=[is_switching_room, room_transition_status, room_settings_save_status],
            show_progress="hidden",
        )

        initial_fast_load_outputs = [
            current_room_name,
            chatbot_display,
            current_log_map_state,
            chat_input_multimodal,
            profile_image_display,
            room_dropdown,
            location_dropdown,
            current_scenery_display,
            scenery_image_display,
            style_injector,
            token_count_display,
            api_key_dropdown,
            current_api_key_name_state,
            api_history_limit_state,
            model_dropdown,
            current_model_name,
            room_display_thoughts_checkbox,
            room_add_timestamp_checkbox,
            onboarding_guide,
            onboarding_group,
            room_tts_provider_dropdown,
            room_tts_model_dropdown,
            room_voice_dropdown,
            room_voice_style_prompt_textbox,
            room_voice_speed_slider,
            room_voice_pitch_slider,
            room_voice_intonation_slider,
            room_voice_volume_slider,
            room_temperature_slider,
            room_top_p_slider,
            room_safety_harassment_dropdown,
            room_safety_hate_speech_dropdown,
            room_safety_sexually_explicit_dropdown,
            room_safety_dangerous_content_dropdown,
            enable_typewriter_effect_checkbox,
            streaming_speed_slider,
            room_send_thoughts_checkbox,
            room_enable_retrieval_checkbox,
            room_send_current_time_checkbox,
            room_send_notepad_checkbox,
            room_use_common_prompt_checkbox,
            room_send_core_memory_checkbox,
            room_send_scenery_checkbox,
            room_scenery_send_mode_dropdown,
            enable_scenery_system_checkbox,
            auto_memory_enabled_checkbox,
            room_enable_self_awareness_checkbox,
            room_api_history_limit_dropdown,
            room_thinking_level_dropdown,
            room_episode_memory_days_dropdown,
            room_enable_autonomous_checkbox,
            room_autonomous_inactivity_slider,
            room_allow_schedule_tool_checkbox,
            room_schedule_cooldown_slider,
            room_autonomous_guidelines_textbox,
            room_quiet_hours_start,
            room_quiet_hours_end,
            room_persona_workspace_permission_tier_dropdown,
            room_agent_delegation_enabled_checkbox,
            room_agent_delegation_permission_tier_dropdown,
            room_agent_delegation_allow_web_checkbox,
            room_agent_delegation_wake_on_completion_checkbox,
            room_agent_delegation_wake_respect_quiet_hours_checkbox,
            room_agent_delegation_exec_provider_dropdown,
            room_agent_delegation_exec_profile_dropdown,
            room_agent_delegation_exec_model_dropdown,
            room_agent_delegation_backend_info,
            room_model_dropdown,
            room_provider_radio,
            room_google_settings_group,
            room_openai_settings_group,
            room_anthropic_settings_group,
            room_claude_subscription_settings_group,
            room_local_settings_group,
            room_claude_subscription_delegation_warning,
            room_api_key_dropdown,
            room_openai_profile_dropdown,
            room_openai_base_url_input,
            room_openai_api_key_input,
            room_openai_model_dropdown,
            room_openai_tool_use_checkbox,
            room_anthropic_model_dropdown,
            room_claude_subscription_model_dropdown,
            room_rotation_dropdown,
            sleep_consolidation_episodic_cb,
            sleep_consolidation_memory_index_cb,
            sleep_consolidation_current_log_cb,
            sleep_consolidation_entity_memory_cb,
            sleep_consolidation_compress_cb,
            sleep_consolidation_extract_questions_cb,
            room_auto_summary_checkbox,
            room_auto_summary_threshold_slider,
            room_project_root_input,
            room_project_exclude_dirs_input,
            room_project_exclude_files_input,
            room_include_knowledge_retrieval_checkbox,
            release_notes_markdown,
            active_working_memory_status,
            working_memory_slot_dropdown,
            working_memory_editor
        ]



        # 数が一致することを確認（デバッグ用）
        # print(f"DEBUG: initial_load_outputs len = {len(initial_load_outputs)}")
        initial_load_output_count = gr.State(len(initial_load_outputs))
        emotion_panel_outputs = [
            emotion_panel["states"], emotion_panel["selector"], emotion_panel["name"],
            emotion_panel["description"], emotion_panel["enabled"], emotion_panel["half_life"],
            emotion_panel["max_age"], emotion_panel["detail"], emotion_panel["save"],
            emotion_panel["status"], emotion_panel["session"],
        ]
        app_lite_update_outputs = [
            app_lite_update_status, app_lite_update_button, app_lite_update_offer,
            app_lite_update_confirmation, app_lite_update_confirmed,
            app_lite_update_group, app_update_accordion,
            app_lite_auth_recovery_group, app_lite_auth_recovery_confirmation,
            app_lite_auth_recovery_confirmed,
        ]
        app_update_host_outputs = [
            app_update_host_status, app_update_host_group, app_update_host_migration_button,
            app_update_host_confirmed, restart_app_button, app_update_accordion,
        ]
        demo.load(
            fn=ui_handlers.handle_initial_chat_load,
            inputs=[current_room_name],
            outputs=initial_fast_load_outputs,
            show_progress="hidden"
        ).then(
            # 初期fast出力の設定契約を増やさず、一時状態だけ正本から軽量同期する。
            fn=ui_handlers.get_temp_location_ui_state,
            inputs=[current_room_name],
            outputs=[
                temp_scenery_display,
                saved_locations_dropdown,
                temp_scenery_image_display,
                scenery_mode_tabs,
                temp_location_applied_status,
                temp_location_name_input,
            ],
            show_progress="hidden",
        ).then(
            fn=ui_handlers.handle_load_emotion_panel,
            inputs=[room_dropdown],
            outputs=emotion_panel_outputs,
            show_progress="hidden",
            api_visibility="private",
            concurrency_id="emotion_panel", concurrency_limit=1,
        ).then(
            # 起動時もこのルームのカレンダー個別設定を反映（軽量・保存は初期化グレースで抑止）
            fn=ui_handlers.load_room_calendar_settings,
            inputs=[current_room_name],
            outputs=[room_gcal_inject_cb, room_gcal_reminder_cb, room_gcal_read_mode, room_gcal_read_calendars, room_gcal_write_dropdown],
            show_progress="hidden"
        ).then(
            # 起動時もこのルームの自動レビュー設定を反映（巨大出力は触らず自前の小さな出力で）
            fn=ui_handlers.load_room_review_settings,
            inputs=[current_room_name],
            outputs=[
                room_agent_delegation_review_iterations_number,
                room_agent_delegation_review_provider_dropdown,
                room_agent_delegation_review_profile_dropdown,
                room_agent_delegation_review_model_dropdown,
            ],
            show_progress="hidden"
        ).then(
            fn=ui_handlers.load_room_persona_contract_ui,
            inputs=[current_room_name],
            outputs=[
                room_persona_contract_enabled_checkbox,
                room_persona_contract_persona_name_input,
                room_persona_contract_user_name_input,
                room_persona_contract_preferred_address_input,
                room_persona_contract_forbidden_address_input,
                room_persona_contract_required_terms_input,
                room_persona_contract_forbidden_terms_input,
                room_persona_contract_tone_rules_input,
                room_persona_contract_forbidden_severity_dropdown,
                room_persona_contract_required_severity_dropdown,
                room_persona_contract_address_severity_dropdown,
            ],
            show_progress="hidden"
        ).then(
            fn=ui_handlers.load_room_gemini_explicit_cache_settings,
            inputs=[current_room_name],
            outputs=[
                room_gemini_explicit_cache_enabled_checkbox,
                room_gemini_explicit_cache_ttl_slider,
                room_gemini_explicit_cache_tool_limit_slider,
                room_gemini_explicit_cache_status,
            ],
            show_progress="hidden"
        ).then(
            fn=ui_handlers.load_closet_profile_ui,
            inputs=[current_room_name],
            outputs=[
                closet_enabled_checkbox,
                closet_description_textbox,
                closet_reference_gallery,
                closet_reference_delete_dropdown,
                closet_status_markdown,
            ],
            show_progress="hidden"
        ).then(
            fn=ui_handlers.load_closet_catalog_ui,
            inputs=[current_room_name],
            outputs=[
                closet_catalog_html,
                closet_catalog_dropdown,
                closet_catalog_detail,
                closet_current_note_textbox,
                closet_current_outfit_markdown,
                closet_catalog_status,
            ],
            show_progress="hidden"
        ).then(
            fn=ui_handlers.load_user_closet_room_ui,
            inputs=[current_room_name],
            outputs=[
                user_room_use_common,
                user_room_closet_enabled,
                user_room_closet_description,
                user_room_closet_gallery,
                user_room_closet_delete_ref_dropdown,
                user_room_closet_html,
                user_room_closet_dropdown,
                user_room_closet_detail,
                user_room_current_note,
                user_room_current_outfit,
                user_room_closet_status,
                user_room_closet_save_button,
            ],
            show_progress="hidden"
        ).then(
            # 起動時/リロード時もこのルームのアトリエAPI個別設定(https_only)を保存値から反映
            # （ページリロードで巻き戻るのを防ぐ。gcal個別設定と同じ対策）
            fn=ui_handlers.atelier_app_api_room_updates,
            inputs=[current_room_name],
            outputs=[room_atelier_https_only_checkbox],
            show_progress="hidden"
        ).then(
            # 共通カレンダー設定を保存値から復元（ブラウザのページリロードで巻き戻るのを防ぐ）。
            # .change を持つ gcal_enabled_cb は対象外（freeze対策）。
            fn=ui_handlers.refresh_gcal_settings_ui,
            inputs=None,
            outputs=[
                gcal_status_md, gcal_client_id, gcal_client_secret, gcal_calendar_select,
                gcal_sync_interval, gcal_exclude_keywords, gcal_mask_private_cb, gcal_reminder_sync_cb,
            ],
            show_progress="hidden"
        ).then(
            # ページリロード時も有料キー設定を正本から復元する（軽量ロードは共通設定全体を更新しないため）。
            fn=ui_handlers.load_paid_keys_display,
            inputs=None,
            outputs=[api_key_dropdown, paid_keys_checkbox_group],
            show_progress="hidden"
        ).then(
            # チャットと保存済み設定を先に表示したあと、接続済みLiteの版だけを照合する。
            fn=ui_handlers.handle_lite_update_check,
            inputs=[current_room_name], outputs=app_lite_update_outputs,
            show_progress="hidden", api_visibility="private",
            concurrency_id="lite-update-check", concurrency_limit=1,
        ).then(
            fn=ui_handlers.handle_app_update_host_check,
            inputs=None, outputs=app_update_host_outputs,
            show_progress="hidden", api_visibility="private",
        )
        # 本体の更新照会や管理系一覧は、該当タブ/ボタン操作時だけ実行する。

        start_session_button.click(
            fn=ui_handlers.handle_start_session,
            inputs=[current_room_name, participant_checkbox_group],
            outputs=[active_participants_state, session_status_display]
        )
        end_session_button.click(
            fn=ui_handlers.handle_end_session,
            inputs=[current_room_name, active_participants_state],
            outputs=[active_participants_state, session_status_display, participant_checkbox_group]
        )

        chat_inputs = [
            chat_input_multimodal,
            room_dropdown, # [Fix] StateではなくUIコンポーネントの値を直接使用して混線を防止
            current_api_key_name_state,
            api_history_limit_state,
            debug_mode_checkbox,
            debug_console_state,
            active_participants_state,
            group_hide_thoughts_checkbox,  # グループ会話 思考ログ非表示
            active_attachments_state,
            model_dropdown,
            enable_typewriter_effect_checkbox,
            streaming_speed_slider,
            current_scenery_display,
            screenshot_mode_checkbox,
            redaction_rules_state,
            enable_supervisor_cb, # [v18] Supervisorモード
            group_supervisor_rounds_number,
            translation_cache_state, # [v22] 翻訳不整合対策
        ]

        rerun_inputs = [
            selected_message_state,
            current_room_name,
            current_api_key_name_state,
            api_history_limit_state,
            debug_mode_checkbox,
            debug_console_state,
            active_participants_state,
            group_hide_thoughts_checkbox,  # グループ会話 思考ログ非表示
            active_attachments_state,
            model_dropdown,
            enable_typewriter_effect_checkbox,
            streaming_speed_slider,
            current_scenery_display,
            screenshot_mode_checkbox,
            redaction_rules_state,
            enable_supervisor_cb, # [v18] Supervisorモード
            group_supervisor_rounds_number,
            translation_cache_state, # [v22] 翻訳不整合対策
            selected_message_index_state,
        ]

        # 新規送信と再生成で、UI更新の対象（outputs）を完全に一致させる
        unified_streaming_outputs = [
            chatbot_display, current_log_map_state, chat_input_multimodal,
            token_count_display,
            location_dropdown,
            current_scenery_display,
            alarm_dataframe_original_data, alarm_dataframe, scenery_image_display,
            debug_console_state, debug_console_output,
            stop_button, chat_reload_button,
            action_button_group,
            profile_image_display, # [v19] Added for Thinking Animation
            style_injector, # [v21] Sync Background
            translation_cache_state # [v22] 翻訳キャッシュ追加
        ]

        rerun_event = rerun_button.click(
            fn=lambda: gr.update(active=False),
            outputs=[auto_idle_timer]
        ).then(
            fn=ui_handlers.handle_rerun_button_click,
            inputs=rerun_inputs,
            outputs=unified_streaming_outputs
        ).then(
            fn=lambda: gr.update(active=True),
            outputs=[auto_idle_timer]
        )

        # 【v5: 堅牢化】ルーム変更イベントを2段階に分離
        # 1. まず、選択されたルーム名をconfig.jsonに即時保存するだけの小さな処理を実行
        room_dropdown.input(
            fn=lambda: (
                True,
                gr.update(value="ルームを切り替え中です...", visible=True)
            ),
            outputs=[is_switching_room, room_transition_status],
            show_progress="hidden"
        ).then(
            fn=ui_handlers.handle_save_last_room, # <<< lambdaから専用ハンドラに変更
            inputs=[room_dropdown],
            outputs=None,
            show_progress="hidden"
        ).then(
            fn=ui_handlers.handle_refresh_background_css,
            inputs=[room_dropdown],
            outputs=[style_injector],
            show_progress="hidden"
        ).then(
            fn=ui_handlers.handle_room_change_chat_fast,
            inputs=[room_dropdown, api_key_dropdown],
            outputs=[
                current_room_name,
                chatbot_display,
                current_log_map_state,
                chat_input_multimodal,
                token_count_display,
                room_transition_status
            ],
            show_progress="hidden"
        # 2. その後(.then)、UI全体を更新する重い処理を実行
        ).then(
            fn=ui_handlers.handle_room_change_for_all_tabs_preserve_chat,
            inputs=[room_dropdown, api_key_dropdown, full_refresh_output_count],
            outputs=unified_full_room_refresh_outputs,
            show_progress="hidden"
        # 3. 補助設定を1イベントで同期し、直列キュー往復を抑える。
        ).then(
            fn=ui_handlers.load_room_switch_supplemental_ui,
            inputs=[room_dropdown],
            outputs=[
                avatar_mode_radio,
                room_gcal_inject_cb,
                room_gcal_reminder_cb,
                room_gcal_read_mode,
                room_gcal_read_calendars,
                room_gcal_write_dropdown,
                room_agent_delegation_review_iterations_number,
                room_agent_delegation_review_provider_dropdown,
                room_agent_delegation_review_profile_dropdown,
                room_agent_delegation_review_model_dropdown,
                room_persona_contract_enabled_checkbox,
                room_persona_contract_persona_name_input,
                room_persona_contract_user_name_input,
                room_persona_contract_preferred_address_input,
                room_persona_contract_forbidden_address_input,
                room_persona_contract_required_terms_input,
                room_persona_contract_forbidden_terms_input,
                room_persona_contract_tone_rules_input,
                room_persona_contract_forbidden_severity_dropdown,
                room_persona_contract_required_severity_dropdown,
                room_persona_contract_address_severity_dropdown,
                room_gemini_explicit_cache_enabled_checkbox,
                room_gemini_explicit_cache_ttl_slider,
                room_gemini_explicit_cache_tool_limit_slider,
                room_gemini_explicit_cache_status,
                closet_enabled_checkbox,
                closet_description_textbox,
                closet_reference_gallery,
                closet_reference_delete_dropdown,
                closet_status_markdown,
                closet_catalog_html,
                closet_catalog_dropdown,
                closet_catalog_detail,
                closet_current_note_textbox,
                closet_current_outfit_markdown,
                closet_catalog_status,
                user_room_use_common,
                user_room_closet_enabled,
                user_room_closet_description,
                user_room_closet_gallery,
                user_room_closet_delete_ref_dropdown,
                user_room_closet_html,
                user_room_closet_dropdown,
                user_room_closet_detail,
                user_room_current_note,
                user_room_current_outfit,
                user_room_closet_status,
                user_room_closet_save_button,
                atelier_delegation_readiness,
                prepare_atelier_delegation_button,
            ],
            show_progress="hidden"
        ).then(
            fn=lambda: (
                False,
                gr.update(value="", visible=False)
            ),
            outputs=[is_switching_room, room_transition_status],
            show_progress="hidden"
        )

        chat_reload_button.click(
            fn=ui_handlers.reload_chat_log,
            inputs=[current_room_name, api_history_limit_state, room_add_timestamp_checkbox, room_display_thoughts_checkbox, screenshot_mode_checkbox, redaction_rules_state],
            outputs=[chatbot_display, current_log_map_state]
        ).then(
            fn=ui_handlers.load_user_memo,
            inputs=[current_room_name],
            outputs=[user_memo_textbox]
        ).then(
            # 高速再読込でも別端末からの一時的現在地変更を正本から反映する。
            fn=ui_handlers.get_temp_location_ui_state,
            inputs=[current_room_name],
            outputs=[
                temp_scenery_display,
                saved_locations_dropdown,
                temp_scenery_image_display,
                scenery_mode_tabs,
                temp_location_applied_status,
                temp_location_name_input,
            ],
            show_progress="hidden",
        )

        # --- 日記アーカイブ機能のイベント接続 ---

        # 「記憶をアーカイブする」アコーディオンが開かれた時に、日付ドロップダウンを更新
        memory_archive_accordion.expand(
            fn=ui_handlers.handle_archive_memory_tab_select,
            inputs=[current_room_name],
            outputs=[archive_date_dropdown]
        )

        # アーカイブ実行ボタンがクリックされたら、JavaScriptで確認ダイアログを表示し、
        # 結果を非表示のTextbox `archive_confirm_state` に書き込む
        archive_memory_button.click(
            fn=None,
            inputs=None,
            outputs=[archive_confirm_state],
            js="() => confirm('本当によろしいですか？ この操作はmemory_main.txtを直接変更します。')"
        )

        # 非表示Textboxの値が変更されたら（＝ユーザーがダイアログを操作したら）、
        # バックエンドの処理を実行する
        archive_confirm_state.change(
            fn=ui_handlers.handle_archive_memory_click,
            inputs=[archive_confirm_state, current_room_name, api_key_dropdown, archive_date_dropdown],
            outputs=[memory_txt_editor, archive_date_dropdown]
        )
        chatbot_display.select(
            fn=ui_handlers.handle_chatbot_selection,
            inputs=[current_room_name, api_history_limit_state, current_log_map_state, translation_cache_state, show_translation_state, selected_message_index_state],
            outputs=[selected_message_state, action_button_group, play_audio_button, translate_thought_button, selected_message_index_state],
            show_progress=False
        )

        translate_thought_button.click(
            fn=ui_handlers.handle_translate_thought,
            inputs=[
                selected_message_index_state, current_room_name, api_history_limit_state,
                room_add_timestamp_checkbox, screenshot_mode_checkbox, redaction_rules_state,
                room_display_thoughts_checkbox, translation_cache_state, show_translation_state,
                current_log_map_state
            ],
            outputs=[chatbot_display, current_log_map_state, translation_cache_state, show_translation_state, translate_thought_button]
        )
        chatbot_display.edit(
            fn=ui_handlers.handle_chatbot_edit,
            inputs=[
                chatbot_display,
                current_room_name,
                api_history_limit_state,
                current_log_map_state,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                translation_cache_state,
                show_translation_state
            ],
            outputs=[chatbot_display, current_log_map_state, translation_cache_state],
            show_progress="hidden"
        )

        delete_selection_button.click(
            fn=None,
            inputs=None,
            outputs=[message_delete_confirmed_state],
            js="() => confirm('本当にこのメッセージを削除しますか？この操作は元に戻せません。')"
        )
        message_delete_confirmed_state.change(
            fn=ui_handlers.handle_delete_button_click,
            inputs=[
                message_delete_confirmed_state,
                selected_message_state,
                current_room_name,
                api_history_limit_state,
                room_add_timestamp_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state,
                room_display_thoughts_checkbox,
                selected_message_index_state,
                translation_cache_state
            ],
            outputs=[chatbot_display, current_log_map_state, selected_message_state, action_button_group, message_delete_confirmed_state, selected_message_index_state, translation_cache_state]
        )

        room_api_history_limit_dropdown.change(
            fn=ui_handlers.update_api_history_limit_state_and_reload_chat,
            inputs=[
                room_api_history_limit_dropdown,
                current_room_name,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state,
                is_switching_room
            ],
            outputs=[api_history_limit_state, chatbot_display, current_log_map_state],
            show_progress="hidden"
        )

        create_room_button.click(
            fn=ui_handlers.handle_create_room,
            inputs=[new_room_name, new_user_display_name, new_agent_display_name, new_room_description, initial_system_prompt],
            outputs=[
                room_dropdown,             # メインルーム選択
                manage_room_selector,      # 管理タブ
                alarm_room_dropdown,       # アラーム
                timer_room_dropdown,       # タイマー
                new_room_name,
                new_user_display_name,
                new_agent_display_name,
                new_room_description,
                initial_system_prompt
            ]
        )

        # 既存のイベントハンドラのoutputsを再利用しやすいように変数に格納
        manage_room_select_outputs = [
            manage_room_details,
            manage_room_name,
            manage_user_display_name,
            manage_agent_display_name,
            manage_room_description,
            manage_folder_name_display
        ]

        # 既存のイベント
        manage_room_selector.change(
            fn=ui_handlers.handle_manage_room_select,
            inputs=[manage_room_selector],
            outputs=manage_room_select_outputs
        )

        # Gradio 6ではアコーディオン開閉時の自動ロードが積み重なると固まりやすい。
        # 管理情報はルーム選択時だけ読み込む。

        save_room_config_button.click(
            fn=ui_handlers.handle_save_room_config,
            inputs=[
                manage_folder_name_display,
                manage_room_name,
                manage_user_display_name,
                manage_agent_display_name,
                manage_room_description
            ],
            outputs=[room_dropdown, manage_room_selector]
        )

        delete_room_button.click(
            fn=None,
            inputs=None,
            outputs=[room_delete_confirmed_state],
            js="() => confirm('本当にこのルームを削除しますか？この操作は取り消せません。')"
        )
        room_delete_confirmed_state.change(
            fn=ui_handlers.handle_delete_room,
            inputs=[room_delete_confirmed_state, manage_folder_name_display, api_key_dropdown, current_room_name, full_refresh_output_count],
            outputs=unified_full_room_refresh_outputs
        )

        # --- Screenshot Helper Event Handlers ---
        redaction_rules_df.select(
            fn=ui_handlers.handle_redaction_rule_select,
            inputs=[redaction_rules_df],
            outputs=[selected_redaction_rule_state, redaction_find_textbox, redaction_replace_textbox, redaction_color_picker]
        )
        redaction_color_picker.change(
            fn=lambda color: color,
            inputs=[redaction_color_picker],
            outputs=[redaction_rule_color_state]
        )
        add_rule_button.click(
            fn=ui_handlers.handle_add_or_update_redaction_rule,
            inputs=[redaction_rules_state, selected_redaction_rule_state, redaction_find_textbox, redaction_replace_textbox, redaction_rule_color_state],
            outputs=[redaction_rules_df, redaction_rules_state, selected_redaction_rule_state, redaction_find_textbox, redaction_replace_textbox, redaction_color_picker]
        ).then(
            # メインチャットの更新（reload_chat_log を強制的に呼ぶ必要があるが、現状のロジックでは自動更新されない仕様の可能性がある）
            # ここではプレビューの更新のみを追加する（要望範囲）
            fn=ui_handlers.handle_update_log_preview,
            inputs=[
                current_room_name,
                chat_log_month_dropdown,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state
            ],
            outputs=[chat_log_preview_chatbot]
        )
        clear_rule_form_button.click(
            fn=lambda: (None, "", "", "#62827e", "#62827e"),
            outputs=[selected_redaction_rule_state, redaction_find_textbox, redaction_replace_textbox, redaction_color_picker, redaction_rule_color_state]
        )
        delete_rule_button.click(
            fn=ui_handlers.handle_delete_redaction_rule,
            inputs=[redaction_rules_state, selected_redaction_rule_state],
            outputs=[redaction_rules_df, redaction_rules_state, selected_redaction_rule_state, redaction_find_textbox, redaction_replace_textbox, redaction_color_picker]
        ).then(
            fn=ui_handlers.handle_update_log_preview,
            inputs=[
                current_room_name,
                chat_log_month_dropdown,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state
            ],
            outputs=[chat_log_preview_chatbot]
        )
        screenshot_mode_checkbox.change(
            fn=ui_handlers.reload_chat_log,
            inputs=[current_room_name, api_history_limit_state, room_add_timestamp_checkbox, room_display_thoughts_checkbox, screenshot_mode_checkbox, redaction_rules_state],
            outputs=[chatbot_display, current_log_map_state]
        ).then(
            fn=ui_handlers.handle_update_log_preview,
            inputs=[
                current_room_name,
                chat_log_month_dropdown,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state
            ],
            outputs=[chat_log_preview_chatbot]
        )

        correct_punctuation_button.click(
            fn=None,
            inputs=None,
            outputs=[correction_confirmed_state],
            # 確認ダイアログを表示するJavaScript
            js="() => confirm('選択した行以降のAI応答の読点を修正します。\\nこの操作はログファイルを直接変更し、元に戻せません。\\n（処理前にバックアップが作成されます）\\n\\n本当によろしいですか？')"
        )

        correction_confirmed_state.change(
            fn=ui_handlers.handle_log_punctuation_correction,
            inputs=[correction_confirmed_state, selected_message_state, current_room_name, current_api_key_name_state, api_history_limit_state, room_add_timestamp_checkbox],
            outputs=[chatbot_display, current_log_map_state, correct_punctuation_button, selected_message_state, action_button_group, correction_confirmed_state]
        )
        gen_settings_inputs = [
            room_temperature_slider, room_top_p_slider,
            room_safety_harassment_dropdown, room_safety_hate_speech_dropdown,
            room_safety_sexually_explicit_dropdown, room_safety_dangerous_content_dropdown
        ]
        # 個別設定の即時保存対応。
        # Gradio 6移行後のPC/スマホ併用で古いUI値が他項目を巻き戻さないよう、
        # 全項目一括保存ではなく、変更されたキーだけを差分保存する。
        def _bind_room_delta(component, field):
            component.input(
                fn=lambda room, value, switching, f=field: ui_handlers.handle_save_room_setting_delta(room, f, value, switching),
                inputs=[current_room_name, component, is_switching_room],
                outputs=[room_settings_save_status],
                show_progress="hidden",
                queue=False
            )

        def _bind_room_nested(component, parent_key, child_key, label, value_type="raw"):
            component.input(
                fn=lambda room, value, switching, p=parent_key, c=child_key, l=label, t=value_type: ui_handlers.handle_save_room_nested_setting_delta(room, p, c, value, l, t, switching),
                inputs=[current_room_name, component, is_switching_room],
                outputs=[room_settings_save_status],
                show_progress="hidden",
                queue=False
            )

        # 個別AI設定（モデル/キー/ローテーション）は、保存時に provider も相乗りさせて
        # 「モデルだけ保存され provider 欠落→個別モデルが無視される」不整合を防ぐ。
        def _bind_room_ai_field_delta(component, field):
            component.input(
                fn=lambda room, value, provider_value, switching, f=field: ui_handlers.handle_save_room_ai_field_delta(room, f, value, provider_value, switching),
                inputs=[current_room_name, component, room_provider_radio, is_switching_room],
                outputs=[room_settings_save_status],
                show_progress="hidden",
                queue=False
            )

        def _bind_room_gemini_explicit_cache(component, child_key, label, value_type="raw"):
            component.input(
                fn=lambda room, value, switching, c=child_key, l=label, t=value_type: ui_handlers.handle_save_room_gemini_explicit_cache_setting_delta(room, c, value, l, t, switching),
                inputs=[current_room_name, component, is_switching_room],
                outputs=[room_settings_save_status, room_gemini_explicit_cache_status, token_count_display],
                show_progress="hidden",
                queue=False
            )

        closet_save_button.click(
            fn=ui_handlers.handle_save_closet_profile,
            inputs=[current_room_name, closet_enabled_checkbox, closet_description_textbox],
            outputs=[closet_reference_gallery, closet_reference_delete_dropdown, closet_status_markdown],
            show_progress="hidden",
        )
        closet_image_upload_button.upload(
            fn=ui_handlers.handle_add_closet_reference_image,
            inputs=[closet_image_upload_button, current_room_name],
            outputs=[closet_reference_gallery, closet_reference_delete_dropdown, closet_status_markdown],
            show_progress="hidden",
        )
        closet_reference_delete_button.click(
            fn=ui_handlers.handle_remove_closet_reference_image,
            inputs=[current_room_name, closet_reference_delete_dropdown],
            outputs=[closet_reference_gallery, closet_reference_delete_dropdown, closet_status_markdown],
            show_progress="hidden",
        )

        for component, field in [
            (room_tts_provider_dropdown, "tts_provider"),
            (room_tts_profile_dropdown, "tts_profile_name"),
            (room_tts_model_dropdown, "tts_model"),
            (room_voice_dropdown, "tts_voice"),
            (room_voice_style_prompt_textbox, "voice_style_prompt"),
            (room_voice_speed_slider, "tts_voice_speed"),
            (room_voice_pitch_slider, "tts_voice_pitch"),
            (room_voice_intonation_slider, "tts_voice_intonation"),
            (room_voice_volume_slider, "tts_voice_volume"),
            (room_temperature_slider, "temperature"),
            (room_top_p_slider, "top_p"),
            (room_safety_harassment_dropdown, "safety_block_threshold_harassment"),
            (room_safety_hate_speech_dropdown, "safety_block_threshold_hate_speech"),
            (room_safety_sexually_explicit_dropdown, "safety_block_threshold_sexually_explicit"),
            (room_safety_dangerous_content_dropdown, "safety_block_threshold_dangerous_content"),
            (enable_typewriter_effect_checkbox, "enable_typewriter_effect"),
            (streaming_speed_slider, "streaming_speed"),
            (room_display_thoughts_checkbox, "display_thoughts"),
            (room_send_thoughts_checkbox, "send_thoughts"),
            (room_enable_retrieval_checkbox, "enable_auto_retrieval"),
            (room_include_knowledge_retrieval_checkbox, "include_knowledge_in_auto_retrieval"),
            (room_add_timestamp_checkbox, "add_timestamp"),
            (room_send_current_time_checkbox, "send_current_time"),
            (room_send_notepad_checkbox, "send_notepad"),
            (room_use_common_prompt_checkbox, "use_common_prompt"),
            (room_send_core_memory_checkbox, "send_core_memory"),
            (room_send_scenery_checkbox, "send_scenery"),
            (room_scenery_send_mode_dropdown, "scenery_send_mode"),
            (enable_scenery_system_checkbox, "enable_scenery_system"),
            (auto_memory_enabled_checkbox, "auto_memory_enabled"),
            (room_enable_self_awareness_checkbox, "enable_self_awareness"),
            (room_api_history_limit_dropdown, "api_history_limit"),
            (room_thinking_level_dropdown, "thinking_level"),
            (room_episode_memory_days_dropdown, "episode_memory_lookback_days"),
            (room_auto_summary_checkbox, "auto_summary_enabled"),
            (room_auto_summary_threshold_slider, "auto_summary_threshold"),
        ]:
            _bind_room_delta(component, field)

        # モデル/キー/ローテーションは provider 相乗り保存にする（不整合防止）
        for component, field in [
            (room_model_dropdown, "model_name"),
            (room_api_key_dropdown, "api_key_name"),
            (room_rotation_dropdown, "enable_api_key_rotation"),
        ]:
            _bind_room_ai_field_delta(component, field)

        _bind_room_gemini_explicit_cache(room_gemini_explicit_cache_enabled_checkbox, "enabled", "Gemini Explicitキャッシュ", "bool")
        _bind_room_gemini_explicit_cache(room_gemini_explicit_cache_ttl_slider, "ttl_minutes", "Gemini ExplicitキャッシュTTL", "int")
        _bind_room_gemini_explicit_cache(room_gemini_explicit_cache_tool_limit_slider, "tool_limit", "Gemini Explicitキャッシュツール上限", "int")
        room_gemini_explicit_cache_pause_button.click(
            fn=ui_handlers.handle_pause_room_gemini_explicit_cache,
            inputs=[current_room_name, is_switching_room],
            outputs=[
                room_settings_save_status,
                room_gemini_explicit_cache_enabled_checkbox,
                room_gemini_explicit_cache_status,
                token_count_display,
            ],
            show_progress="hidden",
            queue=False,
        )

        for component, child_key, label, value_type in [
            (room_enable_autonomous_checkbox, "enabled", "自律行動モード", "bool"),
            (room_autonomous_inactivity_slider, "inactivity_minutes", "無操作判定時間", "int"),
            (room_allow_schedule_tool_checkbox, "allow_schedule_tool", "次行動予約", "bool"),
            (room_schedule_cooldown_slider, "schedule_cooldown_minutes", "自律行動クールダウン", "int"),
            (room_autonomous_guidelines_textbox, "autonomous_guidelines", "自律行動の指針", "str"),
            (room_quiet_hours_start, "quiet_hours_start", "通知禁止時間帯", "raw"),
            (room_quiet_hours_end, "quiet_hours_end", "通知禁止時間帯", "raw"),
        ]:
            _bind_room_nested(component, "autonomous_settings", child_key, label, value_type)

        room_autonomous_inactivity_preset.input(
            fn=lambda room, value, switching: (
                gr.update(value=value),
                ui_handlers.handle_save_room_nested_setting_delta(
                    room,
                    "autonomous_settings",
                    "inactivity_minutes",
                    value,
                    "無操作判定時間",
                    "int",
                    switching,
                ),
            ) if value is not None else (gr.update(), gr.update()),
            inputs=[current_room_name, room_autonomous_inactivity_preset, is_switching_room],
            outputs=[room_autonomous_inactivity_slider, room_settings_save_status],
            show_progress="hidden",
            queue=False,
        )

        for component, child_key, label in [
            (sleep_consolidation_episodic_cb, "update_episodic_memory", "睡眠時記憶整理"),
            (sleep_consolidation_memory_index_cb, "update_memory_index", "睡眠時記憶整理"),
            (sleep_consolidation_current_log_cb, "update_current_log_index", "睡眠時記憶整理"),
            (sleep_consolidation_entity_memory_cb, "update_entity_memory", "睡眠時記憶整理"),
            (sleep_consolidation_compress_cb, "compress_old_episodes", "睡眠時記憶整理"),
            (sleep_consolidation_extract_questions_cb, "extract_open_questions", "睡眠時記憶整理"),
        ]:
            _bind_room_nested(component, "sleep_consolidation", child_key, label, "bool")

        for component, child_key, label, value_type in [
            (room_openai_profile_dropdown, "profile", "OpenAI互換プロファイル", "str"),
            (room_openai_base_url_input, "base_url", "OpenAI互換 Base URL", "str"),
            (room_openai_api_key_input, "api_key", "OpenAI互換 API Key", "str"),
            (room_openai_model_dropdown, "model", "OpenAI互換モデル", "str"),
            (room_openai_tool_use_checkbox, "tool_use_enabled", "ツール使用", "bool"),
        ]:
            _bind_room_nested(component, "openai_settings", child_key, label, value_type)

        _bind_room_nested(room_anthropic_model_dropdown, "anthropic_settings", "model", "Anthropicモデル", "str")
        _bind_room_nested(room_claude_subscription_model_dropdown, "claude_subscription_settings", "model", "Claudeサブスクモデル", "str")
        _bind_room_nested(room_project_root_input, "project_explorer", "root_path", "プロジェクトルート", "str")
        _bind_room_nested(room_project_exclude_dirs_input, "project_explorer", "exclude_dirs", "除外ディレクトリ", "csv_list")
        _bind_room_nested(room_project_exclude_files_input, "project_explorer", "exclude_files", "除外ファイル", "csv_list")

        # カレンダー個別設定（このルーム）の差分保存
        _bind_room_nested(room_gcal_inject_cb, "google_calendar", "inject_context", "予定サマリーの注入", "bool")
        _bind_room_nested(room_gcal_reminder_cb, "google_calendar", "reminder_enabled", "カレンダーのリマインダー", "bool")
        room_gcal_read_mode.input(
            fn=ui_handlers.handle_save_room_calendar_read_mode,
            inputs=[current_room_name, room_gcal_read_mode, room_gcal_read_calendars, is_switching_room],
            outputs=[room_settings_save_status, room_gcal_read_calendars],
            show_progress="hidden",
            queue=False,
        )
        _bind_room_nested(room_gcal_read_calendars, "google_calendar", "visible_calendars", "読み取り対象カレンダー", "raw")
        _bind_room_nested(room_gcal_write_dropdown, "google_calendar", "persona_write_calendar_id", "書き込み先カレンダー", "str")
        _bind_room_nested(room_atelier_https_only_checkbox, "atelier_app_api", "https_only", "アトリエ配信HTTPS限定", "bool")

        current_room_name.change(
            fn=ui_handlers.atelier_app_api_room_updates,
            inputs=[current_room_name],
            outputs=[room_atelier_https_only_checkbox],
            show_progress="hidden",
            queue=False
        )

        current_room_name.change(
            fn=ui_handlers.refresh_atelier_app_grants,
            inputs=[current_room_name],
            outputs=[
                atelier_app_pending_grants_df,
                atelier_app_active_grants_df,
                atelier_app_pending_selection_state,
                atelier_app_active_grant_selection_state,
                atelier_app_grants_status,
                atelier_app_grant_warning,
            ],
            show_progress="hidden",
            queue=False
        )

        current_room_name.change(
            fn=ui_handlers.atelier_file_room_change_hint,
            inputs=[current_room_name],
            outputs=[atelier_file_intro],
            show_progress="hidden",
            queue=False
        )

        preview_event = room_preview_voice_button.click(
            fn=ui_handlers.handle_voice_preview,
            inputs=[
                current_room_name, room_tts_provider_dropdown, room_tts_model_dropdown,
                room_voice_dropdown, room_voice_style_prompt_textbox, room_preview_text_textbox,
                api_key_dropdown,
                room_voice_speed_slider, room_voice_pitch_slider, room_voice_intonation_slider, room_voice_volume_slider,
                room_tts_profile_dropdown
            ],
            outputs=[audio_player, play_audio_button, room_preview_voice_button]
        )
        preview_event.failure(
            fn=ui_handlers._reset_preview_on_failure,
            inputs=None,
            outputs=[audio_player, play_audio_button, room_preview_voice_button]
        )

        room_tts_provider_dropdown.input(
            fn=ui_handlers.handle_tts_provider_change,
            inputs=[room_tts_provider_dropdown, current_room_name],
            outputs=[
                room_tts_model_dropdown,
                room_voice_dropdown,
                room_voice_style_prompt_textbox,
                room_voice_speed_slider,
                room_voice_pitch_slider,
                room_voice_intonation_slider,
                room_voice_volume_slider,
                room_tts_profile_dropdown
            ],
            show_progress="hidden",
            queue=False
        )

        room_tts_profile_dropdown.input(
            fn=ui_handlers.handle_tts_profile_change,
            inputs=[room_tts_profile_dropdown, current_room_name],
            outputs=[
                room_tts_model_dropdown,
                room_voice_dropdown,
                room_voice_style_prompt_textbox,
            ],
            show_progress="hidden",
            queue=False
        )

        room_tts_model_dropdown.input(
            fn=ui_handlers.handle_tts_model_change_for_voice_choices,
            inputs=[current_room_name, room_tts_provider_dropdown, room_tts_profile_dropdown, room_tts_model_dropdown],
            outputs=[room_voice_dropdown],
            show_progress="hidden",
            queue=False
        )

        room_fetch_tts_models_button.click(
            fn=ui_handlers.handle_fetch_openai_compatible_tts_models,
            inputs=[current_room_name, room_tts_provider_dropdown, room_tts_profile_dropdown],
            outputs=[room_tts_model_dropdown, room_voice_dropdown],
            show_progress="full",
            queue=True
        )

        room_refresh_speakers_button.click(
            fn=ui_handlers.handle_refresh_speakers,
            inputs=[current_room_name, room_tts_provider_dropdown, room_tts_model_dropdown],
            outputs=[room_voice_dropdown]
        )

        # --- [Phase 3] 個別プロバイダ切り替えイベント ---
        # --- [Phase 3] Anthropic用モデルリスト取得イベント ---
        room_fetch_anthropic_models_button.click(
            fn=ui_handlers.handle_fetch_anthropic_models,
            inputs=[anthropic_api_key_input],
            outputs=[room_anthropic_model_dropdown]
        )

        room_fetch_claude_subscription_models_button.click(
            fn=ui_handlers.handle_fetch_claude_subscription_models,
            inputs=[claude_subscription_oauth_token_input, room_claude_subscription_model_dropdown],
            outputs=[room_claude_subscription_model_dropdown, room_claude_subscription_status]
        )

        # --- [Phase 3] 個別プロファイル選択時の自動入力イベント ---
        def _load_room_openai_profile(profile_name):
            """プロファイル選択時に共通設定から設定を読み込んで自動入力"""
            if not profile_name:
                return "", "", gr.update(choices=[], value=None)
            settings_list = config_manager.get_openai_settings_list()
            target = next((s for s in settings_list if s["name"] == profile_name), None)
            if not target:
                return "", "", gr.update(choices=[], value=None)
            available_models = target.get("available_models", [])
            default_model = target.get("default_model", "")
            return (
                target.get("base_url", ""),
                target.get("api_key", ""),
                gr.update(choices=available_models, value=default_model)
            )

        room_openai_profile_dropdown.input(
            fn=_load_room_openai_profile,
            inputs=[room_openai_profile_dropdown],
            outputs=[room_openai_base_url_input, room_openai_api_key_input, room_openai_model_dropdown]
        )

        # [v25] Theme & Display Handlers
        theme_preview_inputs = [
            room_theme_enabled_checkbox,  # 個別テーマのオンオフ
            font_size_slider, line_height_slider, chat_style_radio,
            # 基本配色
            theme_primary_picker, theme_secondary_picker, theme_background_picker, theme_text_picker, theme_accent_soft_picker,
            # 詳細設定
            theme_input_bg_picker, theme_input_border_picker, theme_code_bg_picker, theme_subdued_text_picker,
            theme_button_bg_picker, theme_button_hover_picker, theme_stop_button_bg_picker, theme_stop_button_hover_picker,
            theme_checkbox_off_picker, theme_table_bg_picker, theme_radio_label_picker, theme_dropdown_list_bg_picker,
            theme_ui_opacity_slider,
            # 背景画像設定
            theme_bg_image_picker, theme_bg_opacity_slider, theme_bg_blur_slider,
            theme_bg_size_dropdown, theme_bg_position_dropdown, theme_bg_repeat_dropdown,
            theme_bg_custom_width, theme_bg_radius_slider, theme_bg_mask_blur_slider,
            theme_bg_overlay_checkbox,
            theme_bg_src_mode,
            # Sync設定 (追加)
            theme_bg_sync_opacity_slider, theme_bg_sync_blur_slider,
            theme_bg_sync_size_dropdown, theme_bg_sync_position_dropdown, theme_bg_sync_repeat_dropdown,
            theme_bg_sync_custom_width, theme_bg_sync_radius_slider, theme_bg_sync_mask_blur_slider,
            theme_bg_sync_overlay_checkbox
        ]

        for comp in theme_preview_inputs:
            comp.input(
                fn=ui_handlers.handle_theme_preview,
                inputs=[current_room_name] + theme_preview_inputs + [is_switching_room],
                outputs=[style_injector],
                show_progress="hidden",
                queue=False
            )

        save_room_theme_button.click(
            fn=lambda *args: ui_handlers.handle_save_theme_settings(*args, force_notify=True),
            inputs=[room_dropdown] + theme_preview_inputs,
            outputs=None
        )

        # ▼▼▼【ここからが新しいイベント定義です】▼▼▼
        # 思考表示チェックボックスの変更イベント
        room_display_thoughts_checkbox.input(
            fn=lambda is_checked: gr.update(interactive=is_checked) if is_checked else gr.update(interactive=False, value=False),
            inputs=[room_display_thoughts_checkbox],
            outputs=[room_send_thoughts_checkbox]
        )

        # 自動要約設定のイベント
        room_auto_summary_checkbox.change(
            fn=lambda is_checked: gr.update(visible=is_checked),
            inputs=[room_auto_summary_checkbox],
            outputs=[room_auto_summary_threshold_slider]
        )

        # --- [新規] アイテムシステム拡張のイベント接続 ---
        # 1. 所持品操作
        place_item_button.click(
            fn=ui_handlers.handle_place_item_button_click,
            inputs=[current_room_name, location_dropdown, food_use_item_dropdown, item_operation_amount, placed_at_furniture],
            outputs=[food_use_status, unified_inventory_df, food_use_item_dropdown, location_item_dropdown, placed_at_furniture]
        ).then(
            fn=lambda r, i: ui_handlers.handle_get_item_details(r, i, is_location=False),
            inputs=[current_room_name, food_use_item_dropdown],
            outputs=[item_details_markdown, food_use_item_image_preview]
        ).then(
            fn=lambda r, i: ui_handlers.handle_get_item_details(r, i, is_location=True),
            inputs=[current_room_name, location_item_dropdown],
            outputs=[location_item_details_markdown, location_item_image_preview]
        )

        # 2. 場所アイテム操作
        refresh_location_items_button.click(
            fn=ui_handlers.handle_refresh_location_items,
            inputs=[current_room_name, location_dropdown],
            outputs=[location_item_dropdown]
        ).then(
            fn=lambda r, i: ui_handlers.handle_get_item_details(r, i, is_location=True),
            inputs=[current_room_name, location_item_dropdown],
            outputs=[location_item_details_markdown, location_item_image_preview]
        )

        pickup_item_button.click(
            fn=ui_handlers.handle_pickup_item_button_click,
            inputs=[current_room_name, location_dropdown, location_item_dropdown, location_item_operation_amount],
            outputs=[food_use_status, unified_inventory_df, food_use_item_dropdown, location_item_dropdown]
        ).then(
            fn=lambda r, i: ui_handlers.handle_get_item_details(r, i, is_location=True),
            inputs=[current_room_name, location_item_dropdown],
            outputs=[location_item_details_markdown, location_item_image_preview]
        ).then(
            fn=lambda r, i: ui_handlers.handle_get_item_details(r, i, is_location=False),
            inputs=[current_room_name, food_use_item_dropdown],
            outputs=[item_details_markdown, food_use_item_image_preview]
        )

        consume_location_item_button.click(
            fn=ui_handlers.handle_consume_location_item_button_click,
            inputs=[current_room_name, location_dropdown, location_item_dropdown, location_item_operation_amount],
            outputs=[food_use_status, location_item_dropdown, unified_inventory_df, food_use_item_dropdown, chat_input_multimodal]
        ).then(
            fn=lambda r, i: ui_handlers.handle_get_item_details(r, i, is_location=True),
            inputs=[current_room_name, location_item_dropdown],
            outputs=[location_item_details_markdown, location_item_image_preview]
        ).then(
            fn=lambda r, i: ui_handlers.handle_get_item_details(r, i, is_location=False),
            inputs=[current_room_name, food_use_item_dropdown],
            outputs=[item_details_markdown, food_use_item_image_preview]
        )

        # 3. インベントリ管理（削除・コピー）
        copy_inventory_item_button.click(
            fn=ui_handlers.handle_copy_inventory_item,
            inputs=[current_room_name, food_use_item_dropdown],
            outputs=[food_use_status, unified_inventory_df, food_use_item_dropdown]
        ).then(
            fn=lambda r, i: ui_handlers.handle_get_item_details(r, i, is_location=False),
            inputs=[current_room_name, food_use_item_dropdown],
            outputs=[item_details_markdown, food_use_item_image_preview]
        )

        delete_inventory_item_button.click(
            fn=None,
            js="() => confirm('本当にこのアイテムを削除しますか？')",
            outputs=[item_op_confirm_state]
        )

        # 選択連動の詳細表示
        food_use_item_dropdown.change(
            fn=lambda r, i: ui_handlers.handle_get_item_details(r, i, is_location=False),
            inputs=[current_room_name, food_use_item_dropdown],
            outputs=[item_details_markdown, food_use_item_image_preview]
        )
        location_item_dropdown.change(
            fn=lambda r, i: ui_handlers.handle_get_item_details(r, i, is_location=True),
            inputs=[current_room_name, location_item_dropdown],
            outputs=[location_item_details_markdown, location_item_image_preview]
        )
        # 5. 所持品リストの更新
        food_use_refresh_button.click(
            fn=ui_handlers.handle_manual_refresh_inventory,
            inputs=[current_room_name],
            outputs=[food_use_status, unified_inventory_df, food_use_item_dropdown]
        )

        item_op_confirm_state.change(
            fn=lambda room, confirm_val, item_choice: ui_handlers.handle_delete_inventory_item(
                room, confirm_val, item_choice
            ),
            inputs=[current_room_name, item_op_confirm_state, food_use_item_dropdown],
            outputs=[food_use_status, unified_inventory_df, food_use_item_dropdown]
        )

        # 場所切り替え時に場所アイテム一覧も更新する
        location_dropdown.input(
            fn=ui_handlers.handle_refresh_location_items,
            inputs=[current_room_name, location_dropdown],
            outputs=[location_item_dropdown]
        )

        # model_dropdownのイベント
        model_dropdown.change(fn=ui_handlers.update_model_state, inputs=[model_dropdown], outputs=[current_model_name])
        thinking_level_dropdown.change(
            fn=lambda value: ui_handlers.handle_save_global_setting_delta(
                "thinking_level",
                next((k for k, v in constants.THINKING_LEVEL_OPTIONS.items() if v == value), constants.DEFAULT_THINKING_LEVEL),
                "Thinking レベル",
                skip_grace=True
            ),
            inputs=[thinking_level_dropdown],
            outputs=[common_settings_status]
        )

        api_key_dropdown.change(
            fn=ui_handlers.update_api_key_state,
            inputs=[api_key_dropdown],
            outputs=[current_api_key_name_state],
        )
        api_test_button.click(fn=ui_handlers.handle_api_connection_test, inputs=[api_key_dropdown], outputs=None)
        refresh_usage_summary_button.click(
            fn=ui_handlers.handle_refresh_usage_summary,
            inputs=None,
            outputs=[usage_summary_markdown],
            show_progress="hidden",
        )
        open_usage_detail_button.click(
            fn=ui_handlers.open_usage_detail,
            inputs=None,
            outputs=[doc_viewer_overlay, doc_viewer_display],
            show_progress="hidden",
            js="() => { const o = document.getElementById('doc_viewer_overlay'); if (o) o.style.removeProperty('display'); }"
        )
        open_user_guide_btn.click(
            fn=ui_handlers.handle_open_user_guide,
            inputs=None,
            outputs=[doc_viewer_overlay, doc_viewer_display],
            show_progress="hidden",
            js="() => { const o = document.getElementById('doc_viewer_overlay'); if (o) o.style.removeProperty('display'); }"
        )
        # chat_submit_outputs の定義を削除し、代わりに unified_streaming_outputs を使用
        submit_event = chat_input_multimodal.submit(
            fn=lambda: gr.update(active=False),
            outputs=[auto_idle_timer]
        ).then(
            fn=ui_handlers.handle_message_submission,
            inputs=chat_inputs,
            outputs=unified_streaming_outputs # ここを変更
        ).then(
            fn=lambda: gr.update(active=True),
            outputs=[auto_idle_timer]
        )

        stop_button.click(
            fn=ui_handlers.handle_stop_button_click,
            inputs=[current_room_name, api_history_limit_state, room_add_timestamp_checkbox, room_display_thoughts_checkbox, screenshot_mode_checkbox, redaction_rules_state],
            outputs=unified_streaming_outputs,
            cancels=[submit_event, rerun_event]
        )

        # 実トークン数は応答完了時に token_count_display へ反映する。
        # 入力中の推定トークン再計算は、Gradio 6 でIME入力中も頻繁に発火し
        # Python側CPU使用率を押し上げるため接続しない。

        common_settings_tab.select(
            fn=ui_handlers.get_weather_status_preview_html,
            inputs=None,
            outputs=[weather_status_preview],
            show_progress="hidden",
        )

        gradio_voice_audio_input.change(
            fn=ui_handlers.handle_gradio_voice_transcription,
            inputs=[
                gradio_voice_audio_input,
                gradio_voice_stt_provider_dropdown,
                gradio_voice_action_dropdown,
                chat_input_multimodal,
                current_room_name,
                current_api_key_name_state,
            ],
            outputs=[chat_input_multimodal, gradio_voice_status, gradio_voice_auto_submit_state],
            show_progress="hidden",
        ).then(
            fn=ui_handlers.handle_gradio_voice_auto_submission,
            inputs=[gradio_voice_auto_submit_state] + chat_inputs,
            outputs=unified_streaming_outputs,
        )

        refresh_scenery_button.click(
            fn=ui_handlers.handle_scenery_refresh,
            inputs=[current_room_name, api_key_dropdown],
            outputs=[location_dropdown, current_scenery_display, scenery_image_display, custom_scenery_location_dropdown, style_injector],
            show_progress="hidden"
        )
        location_dropdown.input(
            fn=ui_handlers.handle_location_change,
            inputs=[current_room_name, location_dropdown, api_key_dropdown],
            outputs=[location_dropdown, current_scenery_display, scenery_image_display, custom_scenery_location_dropdown, style_injector],
            show_progress="hidden"
        )

        # --- 一時的現在地システムのイベント配線 ---
        # タブ選択でモード切り替え
        # JSが渡す操作意図は通常inputにする（gr.Stateはサーバー値へ置換される）。
        temp_location_user_tab_intent = gr.Checkbox(value=False, visible=False, interactive=False)
        # 初期化や正本同期のselectは表示だけ。実際のタブ操作を一度だけ消費する。
        temp_location_tab_intent_js = r"""(room, unused) => {
            if (!window.nexusArkTemporaryLocationIntentInstalled) {
                window.nexusArkTemporaryLocationIntentInstalled = true;
                document.addEventListener('click', event => {
                    const tab = event.target.closest?.('[role="tab"]');
                    if (!event.isTrusted || !tab || tab.getAttribute('aria-selected') === 'true') return;
                    const label = tab.textContent.trim();
                    if (['🏠 仮想現在地', '📍 一時的現在地'].includes(label)) {
                        window.nexusArkTemporaryLocationIntent = {label, at: Date.now()};
                    }
                }, true);
            }
            const intent = window.nexusArkTemporaryLocationIntent;
            const explicit = Boolean(intent && intent.label === '__EXPECTED_TAB__' && Date.now() - intent.at < 2000);
            if (explicit) window.nexusArkTemporaryLocationIntent = null;
            return [room, explicit];
        }"""
        virtual_location_tab.select(
            fn=ui_handlers.handle_virtual_location_activate,
            inputs=[current_room_name, temp_location_user_tab_intent],
            outputs=None,
            js=temp_location_tab_intent_js.replace('__EXPECTED_TAB__', '🏠 仮想現在地'),
        ).then(
            fn=ui_handlers.get_temp_location_ui_state,
            inputs=[current_room_name],
            outputs=[
                temp_scenery_display,
                saved_locations_dropdown,
                temp_scenery_image_display,
                scenery_mode_tabs,
                temp_location_applied_status,
                temp_location_name_input,
            ],
            show_progress="hidden",
        )
        temp_location_tab.select(
            fn=ui_handlers.handle_temp_location_activate,
            inputs=[current_room_name, temp_location_user_tab_intent],
            outputs=None,
            js=temp_location_tab_intent_js.replace('__EXPECTED_TAB__', '📍 一時的現在地'),
        ).then(
            fn=ui_handlers.get_temp_location_ui_state,
            inputs=[current_room_name],
            outputs=[
                temp_scenery_display,
                saved_locations_dropdown,
                temp_scenery_image_display,
                scenery_mode_tabs,
                temp_location_applied_status,
                temp_location_name_input,
            ],
            show_progress="hidden",
        )
        # 画像から情景テキスト生成
        generate_temp_scenery_button.click(
            fn=ui_handlers.handle_generate_temp_scenery,
            inputs=[current_room_name, temp_image_upload, api_key_dropdown, temp_user_hint_textbox, temp_location_name_input],
            outputs=[temp_scenery_display, temp_scenery_edit_textbox, temp_scenery_image_display]
        ).then(
            fn=ui_handlers.handle_refresh_background_css,
            inputs=[current_room_name],
            outputs=[style_injector]
        ).then(
            fn=ui_handlers.get_temp_location_ui_state,
            inputs=[current_room_name],
            outputs=[
                temp_scenery_display,
                saved_locations_dropdown,
                temp_scenery_image_display,
                scenery_mode_tabs,
                temp_location_applied_status,
                temp_location_name_input,
            ],
            show_progress="hidden",
        )
        # テキスト適用
        apply_temp_scenery_button.click(
            fn=ui_handlers.handle_apply_temp_scenery,
            inputs=[current_room_name, temp_scenery_edit_textbox, temp_scenery_image_display, temp_location_name_input],
            outputs=[temp_scenery_display]
        ).then(
            fn=ui_handlers.handle_refresh_background_css,
            inputs=[current_room_name],
            outputs=[style_injector]
        ).then(
            fn=ui_handlers.get_temp_location_ui_state,
            inputs=[current_room_name],
            outputs=[
                temp_scenery_display,
                saved_locations_dropdown,
                temp_scenery_image_display,
                scenery_mode_tabs,
                temp_location_applied_status,
                temp_location_name_input,
            ],
            show_progress="hidden",
        )
        # 保存
        save_location_button.click(
            fn=ui_handlers.handle_save_temp_location,
            inputs=[current_room_name, save_location_name_input],
            outputs=[temp_location_status, saved_locations_dropdown]
        )
        # ロード
        load_location_button.click(
            fn=ui_handlers.handle_load_temp_location,
            inputs=[current_room_name, saved_locations_dropdown],
            outputs=[temp_scenery_display, temp_scenery_edit_textbox, temp_scenery_image_display]
        ).then(
            fn=ui_handlers.handle_refresh_background_css,
            inputs=[current_room_name],
            outputs=[style_injector]
        ).then(
            fn=ui_handlers.get_temp_location_ui_state,
            inputs=[current_room_name],
            outputs=[
                temp_scenery_display,
                saved_locations_dropdown,
                temp_scenery_image_display,
                scenery_mode_tabs,
                temp_location_applied_status,
                temp_location_name_input,
            ],
            show_progress="hidden",
        )
        # 削除
        delete_location_button.click(
            fn=ui_handlers.handle_delete_temp_location,
            inputs=[current_room_name, saved_locations_dropdown],
            outputs=[temp_location_status, saved_locations_dropdown, temp_scenery_image_display]
        ).then(
            fn=ui_handlers.handle_refresh_background_css,
            inputs=[current_room_name],
            outputs=[style_injector]
        ).then(
            fn=ui_handlers.get_temp_location_ui_state,
            inputs=[current_room_name],
            outputs=[
                temp_scenery_display,
                saved_locations_dropdown,
                temp_scenery_image_display,
                scenery_mode_tabs,
                temp_location_applied_status,
                temp_location_name_input,
            ],
            show_progress="hidden",
        )
        cancel_selection_button.click(fn=lambda: (None, gr.update(visible=False), None), inputs=None, outputs=[selected_message_state, action_button_group, selected_message_index_state])

        save_prompt_button.click(
            fn=ui_handlers.handle_save_system_prompt,
            inputs=[current_room_name, system_prompt_editor, room_dropdown, system_prompt_editor_room, is_switching_room],
            outputs=None,
        )
        reload_prompt_button.click(
            fn=ui_handlers.handle_reload_system_prompt_for_editor,
            inputs=[room_dropdown],
            outputs=[system_prompt_editor, system_prompt_editor_room],
        )

        # --- 永続記憶・属性 (Identity) のイベントハンドラ ---
        # 開くだけでは読み込まず、再読込ボタンで明示的に取得する。
        save_identity_button.click(fn=ui_handlers.handle_save_identity, inputs=[current_room_name, identity_editor], outputs=None)
        reload_identity_button.click(fn=ui_handlers.handle_load_identity, inputs=[current_room_name], outputs=[identity_editor])
        reflect_identity_to_core_button.click(
            fn=ui_handlers.handle_reflect_identity_to_core_for_editor,
            inputs=[current_room_name, room_dropdown, is_switching_room],
            outputs=[core_memory_editor, core_memory_editor_room]
        )
        refresh_identity_edit_requests_button.click(
            fn=ui_handlers.handle_refresh_identity_edit_requests,
            inputs=[current_room_name],
            outputs=[identity_edit_requests_df],
            show_progress="hidden",
        )
        identity_edit_requests_df.select(
            fn=ui_handlers.handle_load_selected_identity_edit_request,
            inputs=[identity_edit_requests_df, current_room_name],
            outputs=[
                identity_edit_request_id_state,
                identity_edit_proposal_text,
                identity_edit_request_detail,
                identity_edit_reject_reason,
            ],
            show_progress="hidden",
        )
        approve_identity_edit_request_button.click(
            fn=ui_handlers.handle_approve_identity_edit_request,
            inputs=[current_room_name, identity_edit_request_id_state],
            outputs=[
                identity_edit_requests_df,
                identity_editor,
                identity_edit_request_id_state,
                identity_edit_proposal_text,
                identity_edit_request_detail,
                identity_edit_reject_reason,
            ]
        )
        reject_identity_edit_request_button.click(
            fn=ui_handlers.handle_reject_identity_edit_request,
            inputs=[current_room_name, identity_edit_request_id_state, identity_edit_reject_reason],
            outputs=[
                identity_edit_requests_df,
                identity_edit_request_id_state,
                identity_edit_proposal_text,
                identity_edit_request_detail,
                identity_edit_reject_reason,
            ]
        )

        # --- 主観的記憶（日記）のイベントハンドラ ---
        # エントリ読み込み → 年・月フィルタと日付リストを更新
        refresh_diary_button.click(
            fn=ui_handlers.handle_load_diary_entries,
            inputs=[current_room_name],
            outputs=[diary_year_filter, diary_month_filter, diary_entry_dropdown, diary_raw_editor]
        )
        # 最新を表示ボタン
        show_latest_diary_button.click(
            fn=ui_handlers.handle_show_latest_diary,
            inputs=[current_room_name],
            outputs=[diary_year_filter, diary_month_filter, diary_entry_dropdown, memory_txt_editor, diary_raw_editor]
        )
        # フィルタ変更時 → ドロップダウン選択肢を更新
        diary_year_filter.change(
            fn=ui_handlers.handle_diary_filter_change,
            inputs=[current_room_name, diary_year_filter, diary_month_filter],
            outputs=[diary_entry_dropdown]
        )
        diary_month_filter.change(
            fn=ui_handlers.handle_diary_filter_change,
            inputs=[current_room_name, diary_year_filter, diary_month_filter],
            outputs=[diary_entry_dropdown]
        )
        # エントリ選択時 → 詳細表示
        diary_entry_dropdown.change(
            fn=ui_handlers.handle_diary_selection,
            inputs=[current_room_name, diary_entry_dropdown],
            outputs=[memory_txt_editor]
        )
        # 保存・再読込
        save_memory_button.click(fn=ui_handlers.handle_save_diary_entry, inputs=[current_room_name, diary_entry_dropdown, memory_txt_editor], outputs=[memory_txt_editor])
        reload_memory_button.click(fn=ui_handlers.handle_diary_selection, inputs=[current_room_name, diary_entry_dropdown], outputs=[memory_txt_editor])
        # RAW編集
        save_diary_raw_button.click(fn=ui_handlers.handle_save_diary_raw, inputs=[current_room_name, diary_raw_editor], outputs=[diary_raw_editor])
        reload_diary_raw_button.click(fn=ui_handlers.handle_reload_diary_raw, inputs=[current_room_name], outputs=[diary_raw_editor])
        save_notepad_button.click(fn=ui_handlers.handle_save_notepad_click, inputs=[current_room_name, notepad_editor], outputs=[notepad_editor])
        reload_notepad_button.click(fn=ui_handlers.handle_reload_notepad, inputs=[current_room_name], outputs=[notepad_editor])
        clear_notepad_button.click(fn=ui_handlers.handle_clear_notepad_click, inputs=[current_room_name], outputs=[notepad_editor])
        # --- 創作ノート: 過去分を含む年月閲覧と、独立したファイル全文編集 ---
        refresh_creative_notes_button.click(
            fn=ui_handlers.handle_note_history_load,
            inputs=[current_room_name, creative_note_kind],
            outputs=[creative_year_filter, creative_month_filter, creative_entry_dropdown,
                     creative_notes_editor, creative_notes_summary, creative_note_edit_state],
        )
        show_latest_creative_button.click(
            fn=ui_handlers.handle_note_history_latest,
            inputs=[current_room_name, creative_note_kind],
            outputs=[creative_year_filter, creative_month_filter, creative_entry_dropdown,
                     creative_notes_editor, creative_notes_summary, creative_note_edit_state],
        )
        creative_year_filter.input(
            fn=ui_handlers.handle_note_history_filter,
            inputs=[current_room_name, creative_note_kind, creative_year_filter, creative_month_filter],
            outputs=[creative_month_filter, creative_entry_dropdown, creative_notes_editor,
                     creative_notes_summary, creative_note_edit_state],
        )
        creative_month_filter.input(
            fn=ui_handlers.handle_note_history_filter,
            inputs=[current_room_name, creative_note_kind, creative_year_filter, creative_month_filter],
            outputs=[creative_month_filter, creative_entry_dropdown, creative_notes_editor,
                     creative_notes_summary, creative_note_edit_state],
        )
        creative_entry_dropdown.input(
            fn=ui_handlers.handle_note_history_selection,
            inputs=[current_room_name, creative_note_kind, creative_entry_dropdown],
            outputs=[creative_notes_editor, creative_note_edit_state],
        )
        save_creative_notes_button.click(
            fn=ui_handlers.handle_note_history_save,
            inputs=[current_room_name, creative_note_kind, creative_entry_dropdown,
                    creative_notes_editor, creative_note_edit_state, creative_year_filter, creative_month_filter],
            outputs=[creative_month_filter, creative_entry_dropdown, creative_notes_editor,
                     creative_notes_summary, creative_note_edit_state],
        )
        reload_creative_notes_button.click(
            fn=ui_handlers.handle_note_history_selection,
            inputs=[current_room_name, creative_note_kind, creative_entry_dropdown],
            outputs=[creative_notes_editor, creative_note_edit_state],
        )
        refresh_creative_file_list_button.click(
            fn=lambda r: ui_handlers.handle_note_file_list_refresh(r, "creative"),
            inputs=[current_room_name], outputs=[creative_notes_file_dropdown],
        )
        creative_notes_file_dropdown.input(
            fn=ui_handlers.handle_note_raw_load,
            inputs=[current_room_name, creative_note_kind, creative_notes_file_dropdown],
            outputs=[creative_notes_raw_editor, creative_note_raw_state],
        )
        reload_creative_raw_button.click(
            fn=ui_handlers.handle_note_raw_load,
            inputs=[current_room_name, creative_note_kind, creative_notes_file_dropdown],
            outputs=[creative_notes_raw_editor, creative_note_raw_state],
        )
        save_creative_raw_button.click(
            fn=ui_handlers.handle_note_raw_save,
            inputs=[current_room_name, creative_note_kind, creative_notes_file_dropdown,
                    creative_notes_raw_editor, creative_note_raw_state],
            outputs=[creative_notes_raw_editor, creative_note_raw_state],
        )

        # --- 研究・分析ノート: 過去分を含む年月閲覧と、独立したファイル全文編集 ---
        refresh_research_notes_button.click(
            fn=ui_handlers.handle_note_history_load,
            inputs=[current_room_name, research_note_kind],
            outputs=[research_year_filter, research_month_filter, research_entry_dropdown,
                     research_notes_editor, research_notes_summary, research_note_edit_state],
        )
        show_latest_research_button.click(
            fn=ui_handlers.handle_note_history_latest,
            inputs=[current_room_name, research_note_kind],
            outputs=[research_year_filter, research_month_filter, research_entry_dropdown,
                     research_notes_editor, research_notes_summary, research_note_edit_state],
        )
        research_year_filter.input(
            fn=ui_handlers.handle_note_history_filter,
            inputs=[current_room_name, research_note_kind, research_year_filter, research_month_filter],
            outputs=[research_month_filter, research_entry_dropdown, research_notes_editor,
                     research_notes_summary, research_note_edit_state],
        )
        research_month_filter.input(
            fn=ui_handlers.handle_note_history_filter,
            inputs=[current_room_name, research_note_kind, research_year_filter, research_month_filter],
            outputs=[research_month_filter, research_entry_dropdown, research_notes_editor,
                     research_notes_summary, research_note_edit_state],
        )
        research_entry_dropdown.input(
            fn=ui_handlers.handle_note_history_selection,
            inputs=[current_room_name, research_note_kind, research_entry_dropdown],
            outputs=[research_notes_editor, research_note_edit_state],
        )
        save_research_notes_button.click(
            fn=ui_handlers.handle_note_history_save,
            inputs=[current_room_name, research_note_kind, research_entry_dropdown,
                    research_notes_editor, research_note_edit_state, research_year_filter, research_month_filter],
            outputs=[research_month_filter, research_entry_dropdown, research_notes_editor,
                     research_notes_summary, research_note_edit_state],
        )
        reload_research_notes_button.click(
            fn=ui_handlers.handle_note_history_selection,
            inputs=[current_room_name, research_note_kind, research_entry_dropdown],
            outputs=[research_notes_editor, research_note_edit_state],
        )
        refresh_research_file_list_button.click(
            fn=lambda r: ui_handlers.handle_note_file_list_refresh(r, "research"),
            inputs=[current_room_name], outputs=[research_notes_file_dropdown],
        )
        research_notes_file_dropdown.input(
            fn=ui_handlers.handle_note_raw_load,
            inputs=[current_room_name, research_note_kind, research_notes_file_dropdown],
            outputs=[research_notes_raw_editor, research_note_raw_state],
        )
        reload_research_raw_button.click(
            fn=ui_handlers.handle_note_raw_load,
            inputs=[current_room_name, research_note_kind, research_notes_file_dropdown],
            outputs=[research_notes_raw_editor, research_note_raw_state],
        )
        save_research_raw_button.click(
            fn=ui_handlers.handle_note_raw_save,
            inputs=[current_room_name, research_note_kind, research_notes_file_dropdown,
                    research_notes_raw_editor, research_note_raw_state],
            outputs=[research_notes_raw_editor, research_note_raw_state],
        )

        refresh_research_threads_button.click(
            fn=ui_handlers.handle_refresh_research_threads,
            inputs=[current_room_name],
            outputs=[research_thread_dropdown, research_thread_body_editor, research_threads_index_editor, research_threads_status]
        )
        research_thread_dropdown.change(
            fn=ui_handlers.handle_research_thread_selection,
            inputs=[current_room_name, research_thread_dropdown],
            outputs=[research_thread_body_editor, research_threads_status]
        )
        save_research_thread_body_button.click(
            fn=ui_handlers.handle_save_research_thread_body,
            inputs=[current_room_name, research_thread_dropdown, research_thread_body_editor],
            outputs=[research_thread_body_editor, research_threads_status]
        )
        reload_research_thread_body_button.click(
            fn=ui_handlers.handle_research_thread_selection,
            inputs=[current_room_name, research_thread_dropdown],
            outputs=[research_thread_body_editor, research_threads_status]
        )
        save_research_threads_index_button.click(
            fn=ui_handlers.handle_save_research_threads_index,
            inputs=[current_room_name, research_threads_index_editor],
            outputs=[research_thread_dropdown, research_thread_body_editor, research_threads_index_editor, research_threads_status]
        )

        # --- アクションメモリエベント ---
        refresh_action_memory_button.click(
            fn=ui_handlers.handle_action_memory_refresh,
            inputs=[current_room_name],
            outputs=[action_memory_display]
        )

        # --- ワーキングメモリエベント ---
        current_room_name.change(
            fn=ui_handlers.handle_working_memory_cleanup_notice,
            inputs=[current_room_name],
            outputs=[
                working_memory_cleanup_notice_group,
                working_memory_cleanup_notice,
                working_memory_cleanup_notice_state,
            ],
            queue=False,
            show_progress="hidden",
        )
        working_memory_start_fresh_button.click(
            fn=ui_handlers.handle_start_fresh_working_memory,
            inputs=[current_room_name],
            outputs=[
                working_memory_cleanup_notice_group,
                working_memory_slot_dropdown,
                working_memory_editor,
                active_working_memory_status,
                working_memory_edit_state,
                working_memory_metadata_editor,
                working_memory_metadata_status,
                working_memory_cleanup_notice_state,
            ],
        )
        working_memory_keep_current_button.click(
            fn=ui_handlers.handle_dismiss_working_memory_cleanup_notice,
            inputs=[current_room_name, working_memory_cleanup_notice_state],
            outputs=[
                working_memory_cleanup_notice_group,
                working_memory_cleanup_notice_state,
            ],
            queue=False,
            show_progress="hidden",
        )
        working_memory_slot_dropdown.input(
            fn=ui_handlers.handle_working_memory_slot_change,
            inputs=[current_room_name, working_memory_slot_dropdown],
            outputs=[working_memory_editor, active_working_memory_status, working_memory_edit_state]
        )
        working_memory_slot_dropdown.change(
            fn=ui_handlers.handle_get_working_memory_edit_state,
            inputs=[current_room_name, working_memory_slot_dropdown],
            outputs=[working_memory_edit_state],
            queue=False,
            show_progress="hidden",
        )
        working_memory_new_slot_button.click(
            fn=ui_handlers.handle_new_working_memory_slot,
            inputs=[current_room_name],
            outputs=[working_memory_slot_dropdown, working_memory_editor, active_working_memory_status, working_memory_edit_state]
        )
        working_memory_save_event = save_working_memory_button.click(
            fn=ui_handlers.handle_save_working_memory,
            inputs=[current_room_name, working_memory_editor, working_memory_slot_dropdown, working_memory_edit_state],
            outputs=[working_memory_editor, working_memory_edit_state, active_working_memory_status]
        )
        working_memory_reload_event = reload_working_memory_button.click(
            fn=ui_handlers.handle_reload_working_memory,
            inputs=[current_room_name, working_memory_slot_dropdown],
            outputs=[working_memory_slot_dropdown, working_memory_editor, active_working_memory_status, working_memory_edit_state]
        )
        reload_working_memory_metadata_button.click(
            fn=ui_handlers.handle_reload_working_memory_metadata,
            inputs=[current_room_name],
            outputs=[working_memory_metadata_editor, working_memory_metadata_status]
        )
        working_memory_metadata_save_event = save_working_memory_metadata_button.click(
            fn=ui_handlers.handle_save_working_memory_metadata,
            inputs=[current_room_name, working_memory_metadata_editor],
            outputs=[working_memory_metadata_editor, working_memory_metadata_status]
        )
        for working_memory_refresh_event in (
            working_memory_save_event,
            working_memory_reload_event,
            working_memory_metadata_save_event,
        ):
            working_memory_refresh_event.then(
                fn=ui_handlers.handle_working_memory_cleanup_notice,
                inputs=[current_room_name],
                outputs=[
                    working_memory_cleanup_notice_group,
                    working_memory_cleanup_notice,
                    working_memory_cleanup_notice_state,
                ],
                queue=False,
                show_progress="hidden",
            )

        alarm_dataframe.select(
            fn=ui_handlers.handle_alarm_selection_for_all_updates,
            inputs=[alarm_dataframe_original_data],
            outputs=[
                selected_alarm_ids_state, selection_feedback_markdown,
                alarm_add_button, alarm_context_input, alarm_room_dropdown,
                alarm_days_checkboxgroup, alarm_emergency_checkbox,
                alarm_hour_dropdown, alarm_minute_dropdown,
                editing_alarm_id_state, cancel_edit_button
            ],
            show_progress=False
        )
        enable_button.click(fn=lambda ids: ui_handlers.toggle_selected_alarms_status(ids, True), inputs=[selected_alarm_ids_state], outputs=[alarm_dataframe_original_data, alarm_dataframe])
        disable_button.click(fn=lambda ids: ui_handlers.toggle_selected_alarms_status(ids, False), inputs=[selected_alarm_ids_state], outputs=[alarm_dataframe_original_data, alarm_dataframe])
        delete_alarm_button.click(
            fn=ui_handlers.handle_delete_alarms_and_update_ui,
            inputs=[selected_alarm_ids_state],
            outputs=[
                alarm_dataframe_original_data, alarm_dataframe,
                selected_alarm_ids_state, selection_feedback_markdown
            ]
        )
        alarm_add_button.click(
            fn=ui_handlers.handle_add_or_update_alarm,
            inputs=[
                editing_alarm_id_state, alarm_hour_dropdown, alarm_minute_dropdown,
                alarm_room_dropdown, alarm_context_input, alarm_days_checkboxgroup,
                alarm_emergency_checkbox
            ],
            outputs=[
                alarm_dataframe_original_data, alarm_dataframe,
                alarm_add_button, alarm_context_input, alarm_room_dropdown,
                alarm_days_checkboxgroup, alarm_emergency_checkbox,
                alarm_hour_dropdown, alarm_minute_dropdown,
                editing_alarm_id_state, selected_alarm_ids_state,
                selection_feedback_markdown, cancel_edit_button
            ]
        )
        cancel_edit_button.click(
            fn=ui_handlers.handle_cancel_alarm_edit,
            inputs=None,
            outputs=[
                alarm_add_button, alarm_context_input, alarm_room_dropdown,
                alarm_days_checkboxgroup, alarm_emergency_checkbox,
                alarm_hour_dropdown, alarm_minute_dropdown,
                editing_alarm_id_state, selected_alarm_ids_state,
                selection_feedback_markdown, cancel_edit_button
            ]
        )
        timer_type_radio.change(fn=lambda t: (gr.update(visible=t=="通常タイマー"), gr.update(visible=t=="ポモドーロタイマー"), ""), inputs=[timer_type_radio], outputs=[normal_timer_ui, pomo_timer_ui, timer_status_output])
        timer_submit_button.click(
            fn=ui_handlers.handle_timer_submission,
            inputs=[
            timer_type_radio,
            timer_duration_number,
            pomo_work_number,
            pomo_break_number,
            pomo_cycles_number,
            timer_room_dropdown,
            timer_work_theme_input,
            timer_break_theme_input,
            current_api_key_name_state,
            normal_timer_theme_input
            ],
            outputs=[timer_status_output]
        )

        alarm_notification_service_radio.change(
            fn=ui_handlers.handle_alarm_notification_service_change,
            inputs=[alarm_notification_service_radio],
            outputs=[common_settings_status],
        )
        user_notification_service_radio.change(
            fn=ui_handlers.handle_user_notification_service_change,
            inputs=[user_notification_service_radio],
            outputs=[common_settings_status],
        )

        # Pushover保存ボタンのイベント
        save_pushover_config_button.click(
            fn=ui_handlers.handle_save_pushover_config,
            inputs=[pushover_user_key_input, pushover_app_token_input],
            outputs=None
        )

        # Discord保存ボタンのイベント
        save_discord_webhook_button.click(
            fn=ui_handlers.handle_save_discord_webhook,
            inputs=[discord_webhook_input],
            outputs=None
        )

        # 【v14: 責務分離アーキテクチャ】
        # 1. まず、キーの保存と、それに関連するUIのみを更新する
        save_key_event = save_gemini_key_button.click(
            fn=ui_handlers.handle_save_gemini_key,
            inputs=[gemini_key_name_input, gemini_key_value_input],
            outputs=[
                api_key_dropdown,
                gemini_delete_key_dropdown,
                paid_keys_checkbox_group,
                gemini_key_name_input,
                gemini_key_value_input,
            ]
        )
        # 2. その後(.then)、UI全体を初期化する司令塔を呼び出す
        save_key_event.then(
            fn=ui_handlers.handle_initial_load,
            inputs=None,
            outputs=initial_load_outputs,
            show_progress="hidden"
        )

        # Gemini APIキー削除
        delete_key_event = delete_gemini_key_button.click(
            fn=ui_handlers.handle_delete_gemini_key,
            inputs=[gemini_delete_key_dropdown],
            outputs=[
                api_key_dropdown,
                gemini_delete_key_dropdown,
                paid_keys_checkbox_group
            ]
        )
        delete_key_event.then(
            fn=ui_handlers.handle_initial_load,
            inputs=None,
            outputs=initial_load_outputs,
            show_progress="hidden"
        )


        add_log_to_memory_queue_button.click(
            fn=ui_handlers.handle_add_current_log_to_queue,
            inputs=[current_room_name, debug_console_state],
            # 成功/失敗を通知するだけなので、outputは無しで良い
            outputs=None
        )


        core_memory_update_button.click(
            fn=ui_handlers.handle_core_memory_update_for_editor,
            inputs=[current_room_name, current_api_key_name_state, room_dropdown, is_switching_room],
            outputs=[core_memory_editor, core_memory_editor_room]
        )

        update_episodic_memory_button.click(
            fn=ui_handlers.handle_update_episodic_memory,
            inputs=[current_room_name, current_api_key_name_state],
            outputs=[update_episodic_memory_button, chat_input_multimodal, episodic_update_status]
        )

        # --- Goals Events ---
        refresh_goals_button.click(
            fn=ui_handlers.handle_refresh_goals,
            inputs=[current_room_name],
            outputs=[short_term_goals_display, long_term_goals_display, goals_meta_display]
        )

        clear_open_questions_button.click(
            fn=ui_handlers.handle_clear_open_questions,
            inputs=[current_room_name],
            outputs=[open_questions_display, open_questions_status, selected_question_topics_state]
        )

        # selectイベント：選択された行の話題をStateに保存
        open_questions_display.select(
            fn=ui_handlers.handle_question_row_selection,
            inputs=[open_questions_display],
            outputs=[selected_question_topics_state, open_questions_status]
        )

        delete_selected_questions_button.click(
            fn=ui_handlers.handle_delete_selected_questions,
            inputs=[current_room_name, selected_question_topics_state],
            outputs=[open_questions_display, open_questions_status, selected_question_topics_state]
        )

        resolve_selected_questions_button.click(
            fn=ui_handlers.handle_resolve_selected_questions,
            inputs=[current_room_name, selected_question_topics_state],
            outputs=[open_questions_display, open_questions_status, selected_question_topics_state]
        )

        # --- Internal State Maintenance ---
        reset_internal_state_button.click(
            fn=ui_handlers.handle_reset_internal_state,
            inputs=[current_room_name],
            outputs=[reset_internal_state_status]
        )

        # --- Watchlist Events ---
        watchlist_refresh_button.click(
            fn=ui_handlers.handle_watchlist_refresh,
            inputs=[current_room_name],
            outputs=[watchlist_dataframe, watchlist_status]
        )

        # 監視頻度変更時に指定時刻入力欄の表示/非表示を切り替え
        def toggle_daily_time_visibility(interval):
            return gr.update(visible=(interval == "daily"))

        watchlist_interval_dropdown.change(
            fn=toggle_daily_time_visibility,
            inputs=[watchlist_interval_dropdown],
            outputs=[watchlist_daily_time_row]
        )

        watchlist_add_button.click(
            fn=ui_handlers.handle_watchlist_add,
            inputs=[current_room_name, watchlist_url_input, watchlist_name_input, watchlist_interval_dropdown, watchlist_daily_time],
            outputs=[watchlist_dataframe, watchlist_status]
        )

        watchlist_check_button.click(
            fn=ui_handlers.handle_watchlist_check_all,
            inputs=[current_room_name, api_key_dropdown],
            outputs=[watchlist_dataframe, watchlist_status]
        )

        # DataFrameの行選択イベント（Golden Contract準拠）
        def on_watchlist_select(df_data, evt: gr.SelectData):
            if evt is None or evt.index is None or df_data is None:
                return [""] * 5

            # evt.indexはタプル(row, col)または単一の整数の場合がある
            idx = evt.index
            row_idx = idx[0] if isinstance(idx, (tuple, list)) else idx

            if row_idx is not None:
                try:
                    # df_dataがDataFrameの場合
                    if hasattr(df_data, "iloc"):
                        row = df_data.iloc[row_idx]
                        selected_id = str(row.iloc[0])
                        name = str(row.iloc[1])
                        url = str(row.iloc[2])
                        interval_display = str(row.iloc[3])
                    else:
                        # リストの場合
                        row = df_data[row_idx]
                        selected_id = str(row[0])
                        name = str(row[1])
                        url = str(row[2])
                        interval_display = str(row[3])

                    # 頻度表示（"毎日 09:00" など）から内部値（"daily", "09:00"）を復元
                    interval_val = "manual"
                    daily_time_val = "09:00"

                    if "毎日" in interval_display:
                        interval_val = "daily"
                        if " " in interval_display:
                            daily_time_val = interval_display.split(" ")[1]
                    elif "1時間" in interval_display: interval_val = "hourly_1"
                    elif "3時間" in interval_display: interval_val = "hourly_3"
                    elif "6時間" in interval_display: interval_val = "hourly_6"
                    elif "12時間" in interval_display: interval_val = "hourly_12"

                    return selected_id, url, name, interval_val, daily_time_val
                except Exception as e:
                    print(f"Error in on_watchlist_select: {e}")

            return [""] * 5

        watchlist_dataframe.select(
            fn=on_watchlist_select,
            inputs=[watchlist_dataframe],
            outputs=[watchlist_selected_id, watchlist_url_input, watchlist_name_input, watchlist_interval_dropdown, watchlist_daily_time]
        )

        def delete_selected_wrapper(room_name, selected_id, df_data):
            if not selected_id:
                import gradio as gr
                gr.Warning("削除するエントリを選択してください")
                return gr.update(), "エントリを選択してください"

            # 選択されたIDを含む行を探す
            selected_row = None
            if df_data is not None:
                # df_dataがDataFrameの場合とリストの場合の両方に対応
                import pandas as pd
                if isinstance(df_data, pd.DataFrame):
                    for _, row in df_data.iterrows():
                        if str(row.iloc[0]) == selected_id:
                            # 後の処理(handle_watchlist_delete)がリストを期待しているため変換
                            selected_row = row.tolist()
                            break
                elif isinstance(df_data, list):
                    for row in df_data:
                        if str(row[0]) == selected_id:
                            selected_row = row
                            break

            return ui_handlers.handle_watchlist_delete(room_name, selected_row)

        watchlist_delete_button.click(
            fn=delete_selected_wrapper,
            inputs=[current_room_name, watchlist_selected_id, watchlist_dataframe],
            outputs=[watchlist_dataframe, watchlist_status]
        )

        # --- リサーチ・テーマ（継続調査）購読イベント（Phase 1b） ---
        def on_research_sub_select(df, evt: gr.SelectData):
            try:
                row = evt.index[0]
                import pandas as pd
                if isinstance(df, pd.DataFrame):
                    return str(df.iloc[row, 0])
                return str(df[row][0])
            except Exception:
                return ""

        research_sub_refresh_button.click(
            fn=ui_handlers.handle_research_subscription_refresh,
            inputs=[current_room_name],
            outputs=[research_sub_dataframe, research_sub_status]
        )
        research_sub_add_button.click(
            fn=ui_handlers.handle_research_subscription_add,
            inputs=[current_room_name, research_sub_topic_input, research_sub_focus_input,
                    research_sub_frequency_dropdown, research_sub_depth_dropdown,
                    research_sub_runtime_input, research_sub_seed_urls_input],
            outputs=[research_sub_dataframe, research_sub_status]
        )
        research_sub_dataframe.select(
            fn=on_research_sub_select,
            inputs=[research_sub_dataframe],
            outputs=[research_sub_selected_id]
        ).then(
            fn=ui_handlers.handle_research_subscription_preview,
            inputs=[current_room_name, research_sub_selected_id],
            outputs=[research_sub_preview]
        )
        research_sub_run_now_button.click(
            fn=ui_handlers.handle_research_subscription_run_now,
            inputs=[current_room_name, research_sub_selected_id],
            outputs=[research_sub_dataframe, research_sub_status]
        )
        research_sub_toggle_button.click(
            fn=ui_handlers.handle_research_subscription_toggle,
            inputs=[current_room_name, research_sub_selected_id],
            outputs=[research_sub_dataframe, research_sub_status]
        )
        research_sub_delete_button.click(
            fn=ui_handlers.handle_research_subscription_delete,
            inputs=[current_room_name, research_sub_selected_id],
            outputs=[research_sub_dataframe, research_sub_status]
        )
        research_sub_import_watchlist_button.click(
            fn=ui_handlers.handle_research_import_watchlist_urls,
            inputs=[current_room_name],
            outputs=[research_sub_seed_urls_input]
        )
        research_sub_daily_cap_save_button.click(
            fn=ui_handlers.handle_research_daily_cap_save,
            inputs=[research_sub_daily_cap_input],
            outputs=[research_sub_status]
        )
        # 注: 1日上限の現在値は demo.load では読み込まない。
        # Gradio 6 では demo.load の複数登録がタブ移動フリーズを誘発する
        # （docs/plans/gradio6_migration_recovery_plan.md 参照）。
        # 保存済み値は Number の初期 value（ビルド時に config から読込）で反映する。

        # ウォッチリストは開くだけでは読み込まず、一覧更新ボタンで明示的に取得する。
        def refresh_watchlist_and_groups(room_name):
            df, status = ui_handlers.handle_watchlist_refresh(room_name)
            group_df, _ = ui_handlers.handle_group_refresh(room_name)
            choices_update = ui_handlers.handle_get_group_choices(room_name)
            return df, status, group_df, choices_update

        # --- Group Management Events ---

        # グループ作成
        group_create_button.click(
            fn=ui_handlers.handle_group_add,
            inputs=[current_room_name, group_name_input, group_description_input, group_interval_dropdown, group_daily_time],
            outputs=[group_dataframe, group_status]
        ).then(
            fn=ui_handlers.handle_get_group_choices,
            inputs=[current_room_name],
            outputs=[watchlist_move_group_dropdown]
        )

        # グループ選択
        def on_group_select(df_data, evt: gr.SelectData):
            if evt is None or evt.index is None or df_data is None:
                return ""

            idx = evt.index
            row_idx = idx[0] if isinstance(idx, (tuple, list)) else idx

            if row_idx is not None:
                try:
                    if hasattr(df_data, "iloc"):
                        selected_id = str(df_data.iloc[row_idx].iloc[0])
                    else:
                        selected_id = str(df_data[row_idx][0])
                    return selected_id
                except:
                    pass
            return ""

        group_dataframe.select(
            fn=on_group_select,
            inputs=[group_dataframe],
            outputs=[group_selected_id]
        )

        # グループ削除
        group_delete_button.click(
            fn=ui_handlers.handle_group_delete,
            inputs=[current_room_name, group_selected_id],
            outputs=[group_dataframe, watchlist_dataframe, group_status]
        ).then(
            fn=ui_handlers.handle_get_group_choices,
            inputs=[current_room_name],
            outputs=[watchlist_move_group_dropdown]
        )

        # グループ時刻一括変更
        group_update_interval_button.click(
            fn=ui_handlers.handle_group_update_interval,
            inputs=[current_room_name, group_selected_id, group_new_interval_dropdown, group_new_daily_time],
            outputs=[group_dataframe, watchlist_dataframe, group_status]
        )

        # エントリーをグループに移動
        watchlist_move_button.click(
            fn=ui_handlers.handle_move_entry_to_group,
            inputs=[current_room_name, watchlist_selected_id, watchlist_move_group_dropdown],
            outputs=[watchlist_dataframe, watchlist_status]
        )

        # --- AI自動リスト作成イベント ---

        # 候補を検索
        ai_generate_button.click(
            fn=ui_handlers.handle_ai_generate_candidates,
            inputs=[current_room_name, ai_genre_input, api_key_dropdown],
            outputs=[ai_generate_status, ai_candidates_checkboxgroup, ai_candidates_data, ai_add_row, ai_add_to_group_dropdown]
        )

        # 選択したサイトを追加
        ai_add_button.click(
            fn=ui_handlers.handle_ai_add_selected,
            inputs=[current_room_name, ai_candidates_checkboxgroup, ai_candidates_data, ai_add_to_group_dropdown],
            outputs=[watchlist_dataframe, group_dataframe, ai_generate_status]
        )

        # --- Dream Journal Events ---
        refresh_dream_button.click(
            fn=ui_handlers.handle_refresh_dream_journal,
            inputs=[current_room_name],
            outputs=[dream_date_dropdown, dream_detail_text, dream_year_filter, dream_month_filter]
        )

        show_latest_dream_button.click(
            fn=ui_handlers.handle_show_latest_dream,
            inputs=[current_room_name],
            outputs=[dream_date_dropdown, dream_detail_text, dream_year_filter, dream_month_filter]
        )

        dream_year_filter.input(
            fn=ui_handlers.handle_dream_filter_change,
            inputs=[current_room_name, dream_year_filter, dream_month_filter],
            outputs=[dream_date_dropdown]
        )

        dream_month_filter.input(
            fn=ui_handlers.handle_dream_filter_change,
            inputs=[current_room_name, dream_year_filter, dream_month_filter],
            outputs=[dream_date_dropdown]
        )

        dream_date_dropdown.input(
            fn=ui_handlers.handle_dream_journal_selection_from_dropdown,
            inputs=[current_room_name, dream_date_dropdown],
            outputs=[dream_detail_text]
        )

        # --- [Phase 14] Episodic Memory Browser Events ---
        refresh_episodic_button.click(
            fn=ui_handlers.handle_refresh_episodic_entries,
            inputs=[current_room_name],
            outputs=[episodic_date_dropdown, episodic_detail_text, episodic_year_filter, episodic_month_filter]
        )

        show_latest_episodic_button.click(
            fn=ui_handlers.handle_show_latest_episodic,
            inputs=[current_room_name],
            outputs=[episodic_date_dropdown, episodic_detail_text, episodic_year_filter, episodic_month_filter]
        )

        episodic_year_filter.input(
            fn=ui_handlers.handle_episodic_filter_change,
            inputs=[current_room_name, episodic_year_filter, episodic_month_filter],
            outputs=[episodic_date_dropdown]
        )

        episodic_month_filter.input(
            fn=ui_handlers.handle_episodic_filter_change,
            inputs=[current_room_name, episodic_year_filter, episodic_month_filter],
            outputs=[episodic_date_dropdown]
        )

        # Twitter外部接続UIは退避中のため、認証方式切替/接続テストイベントは登録しない。

        episodic_date_dropdown.input(
            fn=ui_handlers.handle_episodic_selection_from_dropdown,
            inputs=[current_room_name, episodic_date_dropdown],
            outputs=[episodic_detail_text]
        )

        # --- 📌 Entity Memory Events ---
        refresh_entity_button.click(
            fn=ui_handlers.handle_refresh_entity_list,
            inputs=[current_room_name],
            outputs=[entity_dropdown, merge_target_entity_dropdown, entity_content_editor, entity_metadata_editor]
        )

        entity_dropdown.input(
            fn=ui_handlers.handle_entity_selection_change,
            inputs=[current_room_name, entity_dropdown],
            outputs=[entity_content_editor, entity_metadata_editor, merge_target_entity_dropdown]
        )

        save_entity_button.click(
            fn=ui_handlers.handle_save_entity_memory,
            inputs=[current_room_name, entity_dropdown, entity_content_editor],
            outputs=[entity_metadata_editor, entity_index_viewer]
        ).then(fn=lambda: gr.Info("保存しました"), outputs=None)

        delete_entity_button.click(
            fn=ui_handlers.handle_delete_entity_memory,
            inputs=[current_room_name, entity_dropdown],
            outputs=[entity_dropdown, merge_target_entity_dropdown, entity_content_editor, entity_metadata_editor, entity_index_viewer]
        )

        dormant_entity_button.click(
            fn=ui_handlers.handle_mark_entity_dormant,
            inputs=[current_room_name, entity_dropdown],
            outputs=[entity_metadata_editor, entity_index_viewer]
        )

        restore_entity_button.click(
            fn=ui_handlers.handle_restore_entity_memory,
            inputs=[current_room_name, entity_dropdown],
            outputs=[entity_metadata_editor, entity_index_viewer]
        )

        merge_entity_button.click(
            fn=ui_handlers.handle_merge_entity_into_target,
            inputs=[current_room_name, entity_dropdown, merge_target_entity_dropdown],
            outputs=[entity_dropdown, merge_target_entity_dropdown, entity_metadata_editor, entity_index_viewer]
        )

        entity_merge_candidate_load_button.click(
            fn=ui_handlers.refresh_entity_merge_candidates,
            inputs=[current_room_name],
            outputs=[
                entity_merge_candidate_df,
                entity_merge_candidate_dropdown,
                entity_merge_candidate_status,
                entity_merge_candidate_note,
                entity_merge_keep_preview,
                entity_merge_source_preview,
            ]
        )

        entity_merge_candidate_dropdown.input(
            fn=ui_handlers.select_entity_merge_candidate,
            inputs=[current_room_name, entity_merge_candidate_dropdown],
            outputs=[
                entity_merge_candidate_note,
                entity_merge_keep_preview,
                entity_merge_source_preview,
            ]
        )

        entity_merge_approve_button.click(
            fn=ui_handlers.approve_entity_merge_candidate,
            inputs=[current_room_name, entity_merge_candidate_dropdown],
            outputs=[
                entity_merge_candidate_df,
                entity_merge_candidate_dropdown,
                entity_merge_candidate_status,
                entity_merge_candidate_note,
                entity_merge_keep_preview,
                entity_merge_source_preview,
                entity_dropdown,
                merge_target_entity_dropdown,
                entity_content_editor,
                entity_metadata_editor,
                entity_index_viewer,
            ]
        )

        entity_merge_dismiss_button.click(
            fn=ui_handlers.dismiss_entity_merge_candidate,
            inputs=[current_room_name, entity_merge_candidate_dropdown],
            outputs=[
                entity_merge_candidate_df,
                entity_merge_candidate_dropdown,
                entity_merge_candidate_status,
                entity_merge_candidate_note,
                entity_merge_keep_preview,
                entity_merge_source_preview,
                entity_dropdown,
                merge_target_entity_dropdown,
                entity_content_editor,
                entity_metadata_editor,
                entity_index_viewer,
            ]
        )

        show_entity_index_button.click(
            fn=ui_handlers.handle_show_entity_index,
            inputs=[current_room_name],
            outputs=[entity_index_viewer]
        )

        # --- 手動圧縮ボタン ---
        compress_episodes_button.click(
            fn=ui_handlers.handle_compress_episodes,
            inputs=[current_room_name, current_api_key_name_state],
            outputs=[compress_episodes_status]
        )



        # --- エンベディングプロバイダ設定（統合後） ---
        internal_embedding_provider.input(
            fn=ui_handlers.handle_embedding_mode_change,
            inputs=[current_room_name, internal_embedding_provider],
            outputs=None
        )

        save_core_memory_button.click(
            fn=ui_handlers.handle_save_core_memory,
            inputs=[current_room_name, core_memory_editor, room_dropdown, core_memory_editor_room, is_switching_room],
            outputs=None,
        )
        reload_core_memory_button.click(
            fn=ui_handlers.handle_reload_core_memory_for_editor,
            inputs=[room_dropdown],
            outputs=[core_memory_editor, core_memory_editor_room]
        )
        init_purpose_profile_button.click(
            fn=ui_handlers.handle_init_purpose_profile,
            inputs=[current_room_name],
            outputs=[purpose_profile_editor, purpose_profile_status]
        )
        save_purpose_profile_button.click(
            fn=ui_handlers.handle_save_purpose_profile,
            inputs=[current_room_name, purpose_profile_editor],
            outputs=[purpose_profile_editor, purpose_profile_status]
        )
        reload_purpose_profile_button.click(
            fn=ui_handlers.handle_reload_purpose_profile,
            inputs=[current_room_name],
            outputs=[purpose_profile_editor, purpose_profile_status]
        )
        approve_purpose_change_button.click(
            fn=ui_handlers.handle_approve_purpose_change,
            inputs=[current_room_name, purpose_proposal_id_input],
            outputs=[purpose_profile_editor, purpose_profile_status]
        )
        discard_purpose_change_button.click(
            fn=ui_handlers.handle_discard_purpose_change,
            inputs=[current_room_name, purpose_proposal_id_input],
            outputs=[purpose_profile_editor, purpose_profile_status]
        )


        # [v21] 画像生成後に背景CSSも更新
        generate_scenery_image_button.click(
            fn=ui_handlers.handle_generate_or_regenerate_scenery_image,
            inputs=[current_room_name, api_key_dropdown, scenery_style_radio],
            outputs=[scenery_image_display]
        ).then(
            fn=ui_handlers.handle_refresh_background_css,
            inputs=[current_room_name],
            outputs=[style_injector]
        )
        # [v21] カスタム画像登録後に背景CSSも更新
        register_custom_scenery_button.click(
            fn=ui_handlers.handle_register_custom_scenery,
            inputs=[current_room_name, api_key_dropdown, custom_scenery_location_dropdown, custom_scenery_season_dropdown, custom_scenery_time_dropdown, custom_scenery_image_upload],
            outputs=[current_scenery_display, scenery_image_display]
        ).then(
            fn=ui_handlers.handle_refresh_background_css,
            inputs=[current_room_name],
            outputs=[style_injector]
        )
        # audio_player.stop(fn=lambda: gr.update(visible=False), inputs=None, outputs=[audio_player])
        # audio_player.pause(fn=lambda: gr.update(visible=True), inputs=None, outputs=[audio_player])

        # ワールドビルダーは world_settings.txt と Code editor の更新が重いため、
        # タブ選択時の自動ロードは行わない。必要時はRAWエディタの再読み込みボタンで更新する。
        load_world_builder_button.click(
            fn=ui_handlers.handle_world_builder_load,
            inputs=[current_room_name],
            outputs=[world_data_state, area_selector, world_settings_raw_editor, place_selector]
        ).then(
            # ボタンクリック後に content_editor を直接初期化（連鎖イベントの二重発火を回避）
            fn=ui_handlers.handle_wb_place_select,
            inputs=[world_data_state, area_selector, place_selector],
            outputs=[content_editor, save_button_row, delete_place_button],
            show_progress="hidden"
        )
        area_selector.input(
            fn=ui_handlers.handle_wb_area_select,
            inputs=[world_data_state, area_selector],
            outputs=[place_selector],
            show_progress="hidden"  # 連鎖更新時のローディング表示を抑制
        ).then(
            # .input はプログラム更新で発火しないため、エリア選択の後続読込を明示する。
            fn=ui_handlers.handle_wb_place_select,
            inputs=[world_data_state, area_selector, place_selector],
            outputs=[content_editor, save_button_row, delete_place_button],
            show_progress="hidden",
        )
        place_selector.input(
            fn=ui_handlers.handle_wb_place_select,
            inputs=[world_data_state, area_selector, place_selector],
            outputs=[content_editor, save_button_row, delete_place_button],
            show_progress="hidden"  # 連鎖更新時のローディング表示を抑制
        )
        save_button.click(
            fn=ui_handlers.handle_wb_save,
            inputs=[current_room_name, world_data_state, area_selector, place_selector, content_editor],
            outputs=[world_data_state, world_settings_raw_editor, location_dropdown]
        )
        delete_place_button.click(
            fn=ui_handlers.handle_wb_delete_place,
            inputs=[current_room_name, world_data_state, area_selector, place_selector],
            outputs=[world_data_state, area_selector, place_selector, content_editor, save_button_row, delete_place_button, world_settings_raw_editor, location_dropdown]
        )
        add_area_button.click(
            fn=lambda: ("area", gr.update(visible=True), "#### 新しいエリアの作成"),
            outputs=[new_item_type, new_item_form, new_item_form_title]
        )
        add_place_button.click(
            fn=ui_handlers.handle_wb_add_place_button_click,
            inputs=[area_selector],
            outputs=[new_item_type, new_item_form, new_item_form_title]
        )
        confirm_add_button.click(
            fn=ui_handlers.handle_wb_confirm_add,
            inputs=[current_room_name, world_data_state, area_selector, new_item_type, new_item_name],
            outputs=[world_data_state, area_selector, place_selector, new_item_form, new_item_name, world_settings_raw_editor, location_dropdown]
        )
        cancel_add_button.click(
            fn=lambda: (gr.update(visible=False), ""),
            outputs=[new_item_form, new_item_name]
        )

        # --- アバターアップロード機能のイベント接続 ---

        # 3. アバターモード切り替えイベント
        avatar_mode_radio.input(
            fn=ui_handlers.handle_avatar_mode_change,
            inputs=[current_room_name, avatar_mode_radio],
            outputs=[profile_image_display, expressions_html]
        )

        # 5. 表情差分管理イベント
        # アコーディオンが開かれたら表情リストを読み込む
        expression_management_accordion.expand(
            fn=ui_handlers.refresh_expressions_list,
            inputs=[current_room_name],
            outputs=[expressions_html]
        )

        # 表情追加ボタン
        add_expression_button.click(
            fn=ui_handlers.handle_add_expression,
            inputs=[current_room_name, expression_target_dropdown],
            outputs=[expressions_html, expression_target_dropdown]
        )

        # 表情ファイルアップロード
        expression_file_upload.upload(
            fn=ui_handlers.handle_expression_file_upload,
            inputs=[expression_file_upload, current_room_name, expression_target_dropdown],
            outputs=[expressions_html, expression_target_dropdown]
        )

        # 表情削除ボタン
        delete_expression_button.click(
            fn=ui_handlers.handle_delete_expression,
            inputs=[current_room_name, expression_target_dropdown],
            outputs=[expressions_html, expression_target_dropdown]
        )

        # 6. アバター自動待機化タイマー
        auto_idle_timer.tick(
            fn=lambda r: (ui_handlers.get_avatar_html(r, state="neutral"), gr.update(active=False)),
            inputs=[current_room_name],
            outputs=[profile_image_display, auto_idle_timer]
        )

        world_builder_raw_outputs = [
            world_data_state,
            area_selector,
            place_selector,
            world_settings_raw_editor,
            location_dropdown
        ]

        save_raw_button.click(
            fn=ui_handlers.handle_save_world_settings_raw,
            inputs=[current_room_name, world_settings_raw_editor],
            outputs=world_builder_raw_outputs
        )
        reload_raw_button.click(
            fn=ui_handlers.handle_reload_world_settings_raw,
            inputs=[current_room_name],
            outputs=world_builder_raw_outputs
        )

        # --- 会話ログ管理のイベント接続 ---
        # Gradio 6ではログ管理タブを開いただけでRAWログ/プレビュー/バックアップ一覧を
        # 同時ロードすると固まりやすい。タブ選択時の自動ロードは行わず、
        # 「リスト更新」「再読込」「一覧を更新」ボタンに分離する。

        # 保存ボタン: ログを保存してチャット表示・プレビューを更新 → 最下部にスクロール
        save_chat_log_button.click(
            fn=ui_handlers.handle_save_chat_log_raw,
            inputs=[
                current_room_name,
                chat_log_raw_editor,
                api_history_limit_state,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state,
                chat_log_month_dropdown
            ],
            outputs=[chat_log_raw_editor, chatbot_display, current_log_map_state, chat_log_preview_chatbot]
        ).then(
            fn=None,
            inputs=None,
            outputs=None,
            js="""
            () => {
                setTimeout(() => {
                    const editor = document.querySelector('#chat_log_raw_editor .cm-scroller');
                    if (editor) {
                        editor.scrollTop = editor.scrollHeight;
                    }
                }, 100);
            }
            """
        )

        # --- [NEW] バックアップ・復元のイベント配線 ---
        manual_backup_button.click(
            fn=ui_handlers.handle_manual_backup,
            inputs=[current_room_name],
            outputs=[restore_backup_dropdown, backup_status_markdown]
        )
        restore_backup_button.click(
            fn=ui_handlers.handle_restore_from_backup,
            inputs=[current_room_name, restore_backup_dropdown],
            outputs=[restore_backup_dropdown, backup_status_markdown]
        )
        refresh_backup_list_button.click(
            fn=ui_handlers.handle_refresh_backup_list,
            inputs=[current_room_name],
            outputs=[restore_backup_dropdown]
        )
        # 再読込ボタン: 最後に保存した内容を読み込む → 最下部にスクロール
        reload_chat_log_button.click(
            fn=ui_handlers.handle_reload_chat_log_raw,
            inputs=[
                current_room_name,
                chat_log_month_dropdown,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state
            ],
            outputs=[chat_log_raw_editor, chat_log_preview_chatbot]
        ).then(
            fn=None,
            inputs=None,
            outputs=None,
            js="""
            () => {
                setTimeout(() => {
                    const editor = document.querySelector('#chat_log_raw_editor .cm-scroller');
                    if (editor) {
                        editor.scrollTop = editor.scrollHeight;
                    }
                }, 100);
            }
            """
        )

        # 月選択ドロップダウン変更時
        chat_log_month_dropdown.change(
            fn=ui_handlers.handle_load_chat_log_raw,
            inputs=[
                current_room_name,
                chat_log_month_dropdown,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state
            ],
            outputs=[chat_log_raw_editor, chat_log_preview_chatbot]
        ).then(
            fn=None,
            inputs=None,
            outputs=None,
            js="""
            () => {
                setTimeout(() => {
                    const editor = document.querySelector('#chat_log_raw_editor .cm-scroller');
                    if (editor) {
                        editor.scrollTop = editor.scrollHeight;
                    }
                }, 100);
            }
            """
        )

        # リスト更新ボタン
        refresh_chat_log_months_button.click(
            fn=ui_handlers.handle_refresh_chat_log_months,
            inputs=[current_room_name],
            outputs=[chat_log_month_dropdown]
        )

        # 検索ボタン
        chat_log_search_button.click(
            fn=ui_handlers.handle_search_chat_log_keyword,
            inputs=[current_room_name, chat_log_search_textbox],
            outputs=[chat_log_month_dropdown]
        ).then(
            # 検索後に（もしヒットして選択値が変わっていれば）その月のログを読み込む
            fn=ui_handlers.handle_load_chat_log_raw,
            inputs=[
                current_room_name,
                chat_log_month_dropdown,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state
            ],
            outputs=[chat_log_raw_editor, chat_log_preview_chatbot]
        ).then(
            fn=None,
            inputs=None,
            outputs=None,
            js="""
            () => {
                setTimeout(() => {
                    const editor = document.querySelector('#chat_log_raw_editor .cm-scroller');
                    if (editor) {
                        editor.scrollTop = editor.scrollHeight;
                    }
                }, 100);
            }
            """
        )

        # 検索ボックスでEnterキーを押した時も同様
        chat_log_search_textbox.submit(
            fn=ui_handlers.handle_search_chat_log_keyword,
            inputs=[current_room_name, chat_log_search_textbox],
            outputs=[chat_log_month_dropdown]
        ).then(
            fn=ui_handlers.handle_load_chat_log_raw,
            inputs=[
                current_room_name,
                chat_log_month_dropdown,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state
            ],
            outputs=[chat_log_raw_editor, chat_log_preview_chatbot]
        )

        clear_debug_console_button.click(
            fn=lambda: ("", ""),
            outputs=[debug_console_state, debug_console_output]
        )
        # --- Attachment Management Event Handlers ---
        refresh_attachments_button.click(
            fn=ui_handlers.handle_attachment_tab_load,
            inputs=[current_room_name],
            outputs=[attachments_df, active_attachments_state, active_attachments_display]
        )

        attachments_df.select(
            fn=ui_handlers.handle_attachment_selection,
            inputs=[current_room_name, attachments_df, active_attachments_state],
            outputs=[active_attachments_state, active_attachments_display, selected_attachment_index_state],
            show_progress=False
        )

        delete_attachment_button.click(
            fn=ui_handlers.handle_delete_attachment,
            inputs=[current_room_name, selected_attachment_index_state, active_attachments_state],
            outputs=[attachments_df, selected_attachment_index_state, active_attachments_state, active_attachments_display]
        )

        open_attachments_folder_button.click(
            fn=ui_handlers.handle_open_attachments_folder,
            inputs=[current_room_name],
            outputs=None
        )

        # --- 書き置き機能 Event Handlers ---
        save_user_memo_button.click(
            fn=ui_handlers.handle_save_user_memo,
            inputs=[current_room_name, user_memo_textbox],
            outputs=None
        )
        clear_user_memo_button.click(
            fn=ui_handlers.handle_clear_user_memo,
            inputs=[current_room_name],
            outputs=[user_memo_textbox]
        )
        letterbox_open_button.click(
            fn=ui_handlers.refresh_letterbox,
            inputs=[current_room_name],
            outputs=[
                letterbox_df,
                letterbox_dropdown,
                letterbox_status,
                letterbox_meta,
                letterbox_body,
            ],
            show_progress="hidden",
        )
        letterbox_dropdown.change(
            fn=ui_handlers.select_letterbox_letter,
            inputs=[current_room_name, letterbox_dropdown],
            outputs=[
                letterbox_df,
                letterbox_dropdown,
                letterbox_status,
                letterbox_meta,
                letterbox_body,
            ],
            show_progress="hidden",
        )
        letterbox_delete_button.click(
            fn=None,
            inputs=None,
            outputs=[letterbox_delete_confirmed_state],
            js="() => confirm('選択中の手紙を削除しますか？この操作は元に戻せません。')"
        )
        letterbox_delete_confirmed_state.change(
            fn=ui_handlers.handle_delete_letterbox_letter,
            inputs=[letterbox_delete_confirmed_state, current_room_name, letterbox_dropdown],
            outputs=[
                letterbox_df,
                letterbox_dropdown,
                letterbox_status,
                letterbox_meta,
                letterbox_body,
                letterbox_delete_confirmed_state,
            ],
            show_progress="hidden",
        )

        # --- ChatGPT Importer Event Handlers ---
        chatgpt_import_file.upload(
            fn=ui_handlers.handle_chatgpt_file_upload,
            inputs=[chatgpt_import_file],
            outputs=[chatgpt_thread_dropdown, chatgpt_import_form, chatgpt_thread_choices_state]
        )

        chatgpt_thread_dropdown.change(
            fn=ui_handlers.handle_chatgpt_thread_selection,
            inputs=[chatgpt_thread_choices_state, chatgpt_thread_dropdown],
            outputs=[chatgpt_room_name_textbox]
        )


        chatgpt_import_button.click(
            fn=ui_handlers.handle_chatgpt_import_button_click,
            inputs=[
                chatgpt_import_file,
                chatgpt_thread_dropdown,
                chatgpt_room_name_textbox,
                chatgpt_user_name_textbox
            ],
            outputs=[
                chatgpt_import_file,
                chatgpt_import_form,
                room_dropdown,
                manage_room_selector,
                alarm_room_dropdown,
                timer_room_dropdown
            ]
        )

        # --- Claude Importer Event Handlers ---
        claude_import_file.upload(
            fn=ui_handlers.handle_claude_file_upload,
            inputs=[claude_import_file],
            outputs=[claude_thread_dropdown, claude_import_form, claude_thread_choices_state]
        )

        claude_thread_dropdown.change(
            fn=ui_handlers.handle_claude_thread_selection,
            inputs=[claude_thread_choices_state, claude_thread_dropdown],
            outputs=[claude_room_name_textbox]
        )

        claude_import_button.click(
            fn=ui_handlers.handle_claude_import_button_click,
            inputs=[
            claude_import_file,
            claude_thread_dropdown,
            claude_room_name_textbox,
            claude_user_name_textbox
            ],
            outputs=[
            claude_import_file,
            claude_import_form,
            room_dropdown,
            manage_room_selector,
            alarm_room_dropdown,
            timer_room_dropdown
            ]
        )

        # --- Generic Importer Event Handlers ---
        generic_import_file.upload(
            fn=ui_handlers.handle_generic_file_upload,
            inputs=[generic_import_file],
            outputs=[
            generic_import_form,
            generic_room_name_textbox,
            generic_user_name_textbox,
            generic_user_header_textbox,
            generic_agent_header_textbox
            ]
        )

        generic_import_button.click(
            fn=ui_handlers.handle_generic_import_button_click,
            inputs=[
            generic_import_file,
            generic_room_name_textbox,
            generic_user_name_textbox,
            generic_user_header_textbox,
            generic_agent_header_textbox
            ],
            outputs=[
            generic_import_file,
            generic_import_form,
            room_dropdown,
            manage_room_selector,
            alarm_room_dropdown,
            timer_room_dropdown
            ]
        )

        # --- Theme Management Event Handlers ---
        theme_tab.select(
            fn=ui_handlers.handle_theme_tab_load,
            inputs=None,
            outputs=[theme_selector, theme_preview_light, theme_preview_dark]
        ).then(
            fn=ui_handlers.handle_room_theme_reload,
            inputs=[room_dropdown],
            outputs=[
                room_theme_enabled_checkbox,  # 個別テーマのオンオフ
                chat_style_radio, font_size_slider, line_height_slider,
                # 基本配色
                theme_primary_picker, theme_secondary_picker, theme_background_picker,
                theme_text_picker, theme_accent_soft_picker,
                # 詳細設定
                theme_input_bg_picker, theme_input_border_picker, theme_code_bg_picker,
                theme_subdued_text_picker,
                theme_button_bg_picker, theme_button_hover_picker,
                theme_stop_button_bg_picker, theme_stop_button_hover_picker,
                theme_checkbox_off_picker, theme_table_bg_picker, theme_radio_label_picker, theme_dropdown_list_bg_picker,
                theme_ui_opacity_slider,
                # 背景画像設定
                theme_bg_image_picker, theme_bg_opacity_slider, theme_bg_blur_slider,
                theme_bg_size_dropdown, theme_bg_position_dropdown, theme_bg_repeat_dropdown,
                theme_bg_custom_width, theme_bg_radius_slider, theme_bg_mask_blur_slider,
                theme_bg_overlay_checkbox,
                theme_bg_src_mode,
                # Sync設定
                theme_bg_sync_opacity_slider, theme_bg_sync_blur_slider,
                theme_bg_sync_size_dropdown, theme_bg_sync_position_dropdown, theme_bg_sync_repeat_dropdown,
                theme_bg_sync_custom_width, theme_bg_sync_radius_slider, theme_bg_sync_mask_blur_slider,
                theme_bg_sync_overlay_checkbox,
                # CSS注入
                style_injector
            ]
        )

        theme_selector.change(
            fn=ui_handlers.handle_theme_selection,
            inputs=[theme_selector],
            outputs=[
                theme_preview_light, theme_preview_dark,
                primary_hue_picker, secondary_hue_picker, neutral_hue_picker,
                font_dropdown, save_theme_button, export_theme_button
            ]
        )

        save_theme_button.click(
            fn=ui_handlers.handle_save_custom_theme,
            inputs=[
                custom_theme_name_input, primary_hue_picker,
                secondary_hue_picker, neutral_hue_picker, font_dropdown
            ],
            outputs=[theme_selector, custom_theme_name_input]
        )

        export_theme_button.click(
            fn=ui_handlers.handle_export_theme_to_file,
            inputs=[
                custom_theme_name_input, primary_hue_picker,
                secondary_hue_picker, neutral_hue_picker, font_dropdown
            ],
            outputs=[custom_theme_name_input]
        )

        apply_theme_button.click(
            fn=ui_handlers.handle_apply_theme,
            inputs=[theme_selector],
            outputs=None
        )

        backup_rotation_count_number.change(
            fn=ui_handlers.handle_save_backup_rotation_count,
            inputs=[backup_rotation_count_number],
            outputs=[common_settings_status]
        )

        log_backup_rotation_count_number.change(
            fn=ui_handlers.handle_save_log_backup_rotation_count,
            inputs=[log_backup_rotation_count_number],
            outputs=[common_settings_status]
        )

        periodic_backup_interval_dropdown.change(
            fn=ui_handlers.handle_periodic_backup_interval_change,
            inputs=[periodic_backup_interval_dropdown],
            outputs=[common_settings_status]
        )

        open_backup_folder_button.click(
            fn=ui_handlers.handle_open_backup_folder,
            inputs=[current_room_name],
            outputs=None
        )

        # --- [v6: 時間連動情景更新イベント] ---
        # 時間設定UIのいずれかの値が変更されたら、新しい統合ハンドラを呼び出す
        time_setting_inputs = [
            current_room_name,
            current_api_key_name_state,
            time_mode_radio,
            fixed_season_dropdown,
            fixed_time_of_day_dropdown
        ]
        time_setting_outputs = [
            current_scenery_display,
            scenery_image_display
        ]

        # 1. モードが切り替わった時
        time_mode_radio.input(
            fn=ui_handlers.handle_time_settings_change_and_update_scenery,
            inputs=time_setting_inputs,
            outputs=time_setting_outputs,
            show_progress="hidden"
        ).then(
            # その後、UIの表示/非表示を切り替える
            fn=ui_handlers.handle_time_mode_change,
            inputs=[time_mode_radio],
            outputs=[fixed_time_controls]
        )

        # 2. 固定モードの季節が変更された時
        fixed_season_dropdown.input(
            fn=ui_handlers.handle_time_settings_change_and_update_scenery,
            inputs=time_setting_inputs,
            outputs=time_setting_outputs,
            show_progress="hidden"
        )

        # 3. 固定モードの時間帯が変更された時
        fixed_time_of_day_dropdown.input(
            fn=ui_handlers.handle_time_settings_change_and_update_scenery,
            inputs=time_setting_inputs,
            outputs=time_setting_outputs,
            show_progress="hidden"
        )

        # 4. 保存ボタンが押された時（念のため残すが、主役はchangeイベント）
        save_time_settings_button.click(
            fn=ui_handlers.handle_time_settings_change_and_update_scenery,
            inputs=time_setting_inputs,
            outputs=time_setting_outputs,
            show_progress="hidden"
        )

        # --- [v7: 情景システム ON/OFF イベント] ---
        enable_scenery_system_checkbox.input(
            fn=ui_handlers.handle_enable_scenery_system_change,
            inputs=[enable_scenery_system_checkbox],
            outputs=[profile_scenery_accordion, room_send_scenery_checkbox]
        )

        # フォルダを開くボタンのイベント
        open_room_folder_button.click(
            fn=ui_handlers.handle_open_room_folder,
            inputs=[manage_folder_name_display], # 管理タブで選択されているルームのフォルダ名
            outputs=None
        )
        open_audio_folder_button.click(
            fn=ui_handlers.handle_open_audio_folder,
            inputs=[current_room_name], # 現在チャット中のルーム名
            outputs=None
        )

        # --- Knowledge Tab Event Handlers ---
        knowledge_refresh_button.click(
            fn=ui_handlers.handle_knowledge_tab_load,
            inputs=[current_room_name],
            outputs=[knowledge_file_list, knowledge_file_dropdown, knowledge_status_output],
            show_progress="hidden",
            queue=False
        )

        knowledge_upload_button.upload(
            fn=ui_handlers.handle_knowledge_file_upload,
            inputs=[current_room_name, knowledge_upload_button],
            outputs=[knowledge_file_list, knowledge_file_dropdown, knowledge_status_output]
        )

        knowledge_delete_button.click(
            fn=ui_handlers.handle_knowledge_file_delete,
            inputs=[current_room_name, knowledge_file_dropdown],
            outputs=[knowledge_file_list, knowledge_file_dropdown, knowledge_status_output]
        )

        knowledge_reindex_button.click(
            fn=ui_handlers.handle_knowledge_reindex,
            inputs=[current_room_name, current_api_key_name_state],
            outputs=[knowledge_status_output, knowledge_reindex_button]
        )

        skill_refresh_button.click(
            fn=ui_handlers.handle_skills_refresh,
            inputs=[current_room_name],
            outputs=[skill_list_html, skill_selector, skill_status],
            show_progress="hidden",
            queue=False
        )
        skill_selector.change(
            fn=ui_handlers.handle_skill_select,
            inputs=[current_room_name, skill_selector],
            outputs=[skill_scope, skill_id, skill_editor, skill_status],
            show_progress="hidden",
            queue=False
        )
        skill_new_button.click(
            fn=ui_handlers.handle_skill_new_template,
            inputs=[skill_scope],
            outputs=[skill_scope, skill_id, skill_editor, skill_status],
            show_progress="hidden",
            queue=False
        )
        skill_save_button.click(
            fn=ui_handlers.handle_skill_save,
            inputs=[current_room_name, skill_selector, skill_scope, skill_id, skill_editor],
            outputs=[skill_list_html, skill_selector, skill_status],
            show_progress="hidden",
            queue=False
        )
        skill_delete_button.click(
            fn=ui_handlers.handle_skill_delete,
            inputs=[current_room_name, skill_selector],
            outputs=[skill_list_html, skill_selector, skill_scope, skill_id, skill_editor, skill_status],
            show_progress="hidden",
            queue=False
        )

        memory_reindex_button.click(
            fn=ui_handlers.handle_memory_reindex,
            inputs=[current_room_name, current_api_key_name_state],
            outputs=[memory_reindex_status, memory_reindex_button]
        )

        full_reindex_button.click(
            fn=ui_handlers.handle_full_reindex,
            inputs=[current_room_name, current_api_key_name_state],
            outputs=[memory_reindex_status, memory_reindex_button] # 既存のステータスとボタンを共有
        )

        current_log_reindex_button.click(
            fn=ui_handlers.handle_current_log_reindex,
            inputs=[current_room_name, current_api_key_name_state],
            outputs=[current_log_reindex_status, current_log_reindex_button]
        )

        # メンテナンスアコーディオン展開時に、保存済みの最終実行日時を遅延ロード
        maintenance_accordion.expand(
            fn=ui_handlers.handle_maintenance_accordion_load,
            inputs=[current_room_name, current_api_key_name_state],
            outputs=[episodic_update_status, dream_status_display,
                     memory_reindex_status, current_log_reindex_status,
                     compress_episodes_status, sleep_maintenance_status_display],
            show_progress="hidden"
        )

        manual_sleep_maintenance_button.click(
            fn=ui_handlers.handle_manual_sleep_maintenance,
            inputs=[current_room_name, current_api_key_name_state],
            outputs=[manual_sleep_maintenance_button, sleep_maintenance_status_display]
        )

        refresh_sleep_maintenance_status_button.click(
            fn=ui_handlers.handle_refresh_sleep_maintenance_status,
            inputs=[current_room_name],
            outputs=[sleep_maintenance_status_display],
            show_progress="hidden"
        )

        manual_dream_button.click(
            fn=ui_handlers.handle_manual_dreaming,
            inputs=[current_room_name, current_api_key_name_state],
            outputs=[manual_dream_button, dream_status_display]
        )

        manual_insight_button.click(
            fn=ui_handlers.handle_manual_insight_only,
            inputs=[current_room_name, current_api_key_name_state],
            outputs=[manual_insight_button, dream_status_display]
        )

        food_attach_button.click(
            fn=ui_handlers.handle_food_attach,
            inputs=[food_use_item_dropdown, current_room_name],
            outputs=[food_use_status, unified_inventory_df, food_use_item_dropdown]
        ).then(
            fn=ui_handlers.update_api_history_limit_state_and_reload_chat,
            inputs=[
                room_api_history_limit_dropdown,
                current_room_name,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state,
                is_switching_room
            ],
            outputs=[api_history_limit_state, chatbot_display, current_log_map_state]
        )

        food_consume_button.click(
            fn=ui_handlers.handle_food_consume,
            inputs=[food_use_item_dropdown, current_room_name],
            outputs=[food_use_status, unified_inventory_df, food_use_item_dropdown, food_use_item_image_preview, chat_input_multimodal]
        ).then(
            fn=ui_handlers.update_api_history_limit_state_and_reload_chat,
            inputs=[
                room_api_history_limit_dropdown,
                current_room_name,
                room_add_timestamp_checkbox,
                room_display_thoughts_checkbox,
                screenshot_mode_checkbox,
                redaction_rules_state,
                is_switching_room
            ],
            outputs=[api_history_limit_state, chatbot_display, current_log_map_state]
        )

        # アイテム選択変更時のプレビュー更新
        food_use_item_dropdown.change(
            fn=ui_handlers.handle_food_item_select,
            inputs=[food_use_item_dropdown, current_room_name],
            outputs=[food_use_item_image_preview]
        )

        # --- 統合インベントリ イベントハンドラー ---
        inventory_item_dropdown.change(
            fn=ui_handlers.handle_inventory_item_selection,
            inputs=[inventory_item_dropdown],
            outputs=[inventory_selected_idx, inventory_selected_item_id, inventory_status],
            show_progress="hidden",
            queue=False
        )

        inventory_target_radio.change(
            fn=ui_handlers.handle_refresh_unified_inventory_with_selector,
            inputs=[current_room_name, inventory_target_radio],
            outputs=[unified_inventory_df, inventory_item_dropdown],
            show_progress="hidden",
            queue=False
        )

        inventory_refresh_btn.click(
            fn=ui_handlers.handle_refresh_unified_inventory_with_selector,
            inputs=[current_room_name, inventory_target_radio],
            outputs=[unified_inventory_df, inventory_item_dropdown],
            show_progress="hidden",
            queue=False
        )

        inventory_edit_btn.click(
            fn=ui_handlers.handle_inventory_edit_to_creation_form,
            inputs=[current_room_name, inventory_selected_item_id, inventory_target_radio],
            outputs=[
                item_sub_tabs, item_creation_tabs, inventory_status,
                std_item_name_input, std_item_image_input, std_item_category_input, std_item_amount_input, std_item_base_info,
                std_item_appearance_desc, std_item_appearance_color, std_item_appearance_design,
                std_item_texture, std_item_weight, std_item_temp,
                std_item_flavor_text, std_item_raw_json_state, std_item_status,
                food_item_name_input, food_item_image_input, food_item_category_input, food_item_amount_input, food_item_base_info,
                food_sweetness, food_saltiness, food_sourness, food_bitterness, food_umami, food_taste_description,
                food_temp, food_astringency, food_viscosity, food_weight, food_phys_description,
                food_time_top, food_time_middle, food_time_last,
                food_syn_color, food_syn_emotion, food_syn_landscape,
                food_flavor_text, food_raw_json_state, food_item_status
            ],
            show_progress="hidden",
            queue=False
        )

        inventory_copy_btn.click(
            fn=ui_handlers.handle_inventory_copy,
            inputs=[current_room_name, inventory_target_radio, inventory_selected_idx, inventory_item_dropdown, inventory_selected_item_id],
            outputs=[inventory_status, unified_inventory_df],
            show_progress="hidden",
            queue=False
        )

        inventory_delete_btn.click(
            fn=ui_handlers.handle_inventory_delete,
            inputs=[current_room_name, inventory_target_radio, inventory_selected_idx, inventory_item_dropdown, inventory_selected_item_id],
            outputs=[inventory_status, unified_inventory_df],
            show_progress="hidden",
            queue=False
        )

        inventory_transfer_btn.click(
            fn=ui_handlers.handle_inventory_transfer,
            inputs=[current_room_name, inventory_target_radio, inventory_selected_idx, inventory_item_dropdown, inventory_selected_item_id],
            outputs=[inventory_status, unified_inventory_df],
            show_progress="hidden",
            queue=False
        )

        closet_bridge_prefill_button.click(
            fn=ui_handlers.handle_prepare_closet_bridge,
            inputs=[current_room_name, inventory_target_radio, inventory_selected_item_id],
            outputs=[closet_bridge_name_input, closet_bridge_description_input, closet_bridge_tags_input, inventory_status],
            show_progress="hidden",
            queue=False
        )

        closet_scope_radio.change(
            fn=lambda scope: (
                gr.update(visible=scope == "ユーザー"),
                gr.update(visible=scope == "ペルソナ"),
            ),
            inputs=[closet_scope_radio],
            outputs=[closet_user_group, closet_persona_group],
            show_progress="hidden",
            queue=False,
        )

        user_appearance_generate_button.click(
            fn=ui_handlers.handle_generate_appearance_image,
            inputs=[
                user_appearance_target_state,
                current_room_name,
                current_api_key_name_state,
                user_appearance_extra_prompt,
                user_appearance_use_current_state,
            ],
            outputs=[user_appearance_preview, user_appearance_status],
            show_progress="hidden",
        )

        user_appearance_reset_button.click(
            fn=ui_handlers.handle_generate_appearance_image,
            inputs=[
                user_appearance_target_state,
                current_room_name,
                current_api_key_name_state,
                user_appearance_extra_prompt,
                user_appearance_reset_reference_state,
            ],
            outputs=[user_appearance_preview, user_appearance_status],
            show_progress="hidden",
        )

        persona_appearance_generate_button.click(
            fn=ui_handlers.handle_generate_appearance_image,
            inputs=[
                persona_appearance_target_state,
                current_room_name,
                current_api_key_name_state,
                persona_appearance_extra_prompt,
                persona_appearance_use_current_state,
            ],
            outputs=[persona_appearance_preview, persona_appearance_status],
            show_progress="hidden",
        )

        persona_appearance_reset_button.click(
            fn=ui_handlers.handle_generate_appearance_image,
            inputs=[
                persona_appearance_target_state,
                current_room_name,
                current_api_key_name_state,
                persona_appearance_extra_prompt,
                persona_appearance_reset_reference_state,
            ],
            outputs=[persona_appearance_preview, persona_appearance_status],
            show_progress="hidden",
        )

        current_room_name.change(
            fn=lambda room: (
                *ui_handlers.load_current_appearance_ui(room, "user"),
                *ui_handlers.load_current_appearance_ui(room, "persona"),
            ),
            inputs=[current_room_name],
            outputs=[
                user_appearance_preview,
                user_appearance_status,
                persona_appearance_preview,
                persona_appearance_status,
            ],
            show_progress="hidden",
            queue=False,
        )

        closet_bridge_register_button.click(
            fn=ui_handlers.handle_register_inventory_item_to_closet_ui,
            inputs=[
                current_room_name,
                inventory_target_radio,
                inventory_selected_item_id,
                closet_bridge_part_dropdown,
                closet_bridge_name_input,
                closet_bridge_description_input,
                closet_bridge_tags_input,
            ],
            outputs=[
                closet_catalog_html,
                closet_catalog_dropdown,
                closet_catalog_detail,
                closet_current_note_textbox,
                closet_current_outfit_markdown,
                closet_catalog_status,
            ],
            show_progress="hidden",
            queue=False
        )

        closet_catalog_refresh_button.click(
            fn=ui_handlers.load_closet_catalog_ui,
            inputs=[current_room_name],
            outputs=[
                closet_catalog_html,
                closet_catalog_dropdown,
                closet_catalog_detail,
                closet_current_note_textbox,
                closet_current_outfit_markdown,
                closet_catalog_status,
            ],
            show_progress="hidden",
            queue=False
        )

        closet_catalog_dropdown.change(
            fn=ui_handlers.handle_closet_catalog_selection,
            inputs=[current_room_name, closet_catalog_dropdown],
            outputs=[closet_selected_item_id, closet_catalog_detail],
            show_progress="hidden",
            queue=False
        )

        closet_wear_button.click(
            fn=ui_handlers.handle_wear_closet_item_ui,
            inputs=[current_room_name, closet_catalog_dropdown],
            outputs=[
                closet_catalog_html,
                closet_catalog_dropdown,
                closet_catalog_detail,
                closet_current_outfit_markdown,
                closet_catalog_status,
            ],
            show_progress="hidden",
            queue=False
        )

        closet_take_off_button.click(
            fn=ui_handlers.handle_take_off_closet_item_ui,
            inputs=[current_room_name, closet_catalog_dropdown],
            outputs=[
                closet_catalog_html,
                closet_catalog_dropdown,
                closet_catalog_detail,
                closet_current_outfit_markdown,
                closet_catalog_status,
            ],
            show_progress="hidden",
            queue=False
        )

        closet_delete_button.click(
            fn=ui_handlers.handle_delete_closet_item_ui,
            inputs=[current_room_name, closet_catalog_dropdown],
            outputs=[
                closet_catalog_html,
                closet_catalog_dropdown,
                closet_catalog_detail,
                closet_current_outfit_markdown,
                closet_catalog_status,
            ],
            show_progress="hidden",
            queue=False
        )

        closet_current_note_save_button.click(
            fn=ui_handlers.handle_save_closet_current_note_ui,
            inputs=[current_room_name, closet_current_note_textbox],
            outputs=[closet_current_outfit_markdown, closet_catalog_status],
            show_progress="hidden",
            queue=False
        )

        _user_common_outputs = [
            user_common_closet_enabled,
            user_common_closet_description,
            user_common_closet_gallery,
            user_common_closet_delete_ref_dropdown,
            user_common_closet_html,
            user_common_closet_dropdown,
            user_common_closet_detail,
            user_common_current_note,
            user_common_current_outfit,
            user_common_closet_status,
        ]
        _user_room_outputs = [
            user_room_closet_enabled,
            user_room_closet_description,
            user_room_closet_gallery,
            user_room_closet_delete_ref_dropdown,
            user_room_closet_html,
            user_room_closet_dropdown,
            user_room_closet_detail,
            user_room_current_note,
            user_room_current_outfit,
            user_room_closet_status,
        ]
        _user_room_load_outputs = [
            user_room_use_common,
            user_room_closet_enabled,
            user_room_closet_description,
            user_room_closet_gallery,
            user_room_closet_delete_ref_dropdown,
            user_room_closet_html,
            user_room_closet_dropdown,
            user_room_closet_detail,
            user_room_current_note,
            user_room_current_outfit,
            user_room_closet_status,
            user_room_closet_save_button,
        ]

        user_common_closet_save_button.click(
            fn=ui_handlers.handle_save_user_closet_profile,
            inputs=[user_common_closet_scope_state, user_common_closet_room_state, user_common_closet_enabled, user_common_closet_description],
            outputs=_user_common_outputs,
            show_progress="hidden",
            queue=False
        )
        user_common_closet_upload_button.upload(
            fn=ui_handlers.handle_add_user_reference_image,
            inputs=[user_common_closet_upload_button, user_common_closet_scope_state, user_common_closet_room_state],
            outputs=_user_common_outputs,
            show_progress="hidden",
            queue=False
        )
        user_common_closet_delete_ref_button.click(
            fn=ui_handlers.handle_remove_user_reference_image,
            inputs=[user_common_closet_scope_state, user_common_closet_room_state, user_common_closet_delete_ref_dropdown],
            outputs=_user_common_outputs,
            show_progress="hidden",
            queue=False
        )
        user_common_closet_dropdown.change(
            fn=ui_handlers.handle_user_closet_selection,
            inputs=[user_common_closet_scope_state, user_common_closet_room_state, user_common_closet_dropdown],
            outputs=[user_common_closet_selected_id, user_common_closet_detail],
            show_progress="hidden",
            queue=False
        )
        user_common_closet_wear_button.click(
            fn=ui_handlers.handle_wear_user_closet_item_ui,
            inputs=[user_common_closet_scope_state, user_common_closet_room_state, user_common_closet_dropdown],
            outputs=[user_common_closet_html, user_common_closet_dropdown, user_common_closet_detail, user_common_current_outfit, user_common_closet_status],
            show_progress="hidden",
            queue=False
        )
        user_common_closet_takeoff_button.click(
            fn=ui_handlers.handle_take_off_user_closet_item_ui,
            inputs=[user_common_closet_scope_state, user_common_closet_room_state, user_common_closet_dropdown],
            outputs=[user_common_closet_html, user_common_closet_dropdown, user_common_closet_detail, user_common_current_outfit, user_common_closet_status],
            show_progress="hidden",
            queue=False
        )
        user_common_closet_delete_button.click(
            fn=ui_handlers.handle_delete_user_closet_item_ui,
            inputs=[user_common_closet_scope_state, user_common_closet_room_state, user_common_closet_dropdown],
            outputs=[user_common_closet_html, user_common_closet_dropdown, user_common_closet_detail, user_common_current_outfit, user_common_closet_status],
            show_progress="hidden",
            queue=False
        )
        user_common_current_note_save_button.click(
            fn=ui_handlers.handle_save_user_current_note_ui,
            inputs=[user_common_closet_scope_state, user_common_closet_room_state, user_common_current_note],
            outputs=[user_common_current_outfit, user_common_closet_status],
            show_progress="hidden",
            queue=False
        )
        user_common_real_register_button.click(
            fn=ui_handlers.handle_add_user_real_closet_item,
            inputs=[user_common_closet_scope_state, user_common_closet_room_state, user_common_real_image, user_common_real_name, user_common_real_part, user_common_real_description, user_common_real_tags],
            outputs=_user_common_outputs,
            show_progress="hidden",
            queue=False
        )

        user_room_use_common.change(
            fn=ui_handlers.handle_set_user_closet_common,
            inputs=[current_room_name, user_room_use_common],
            outputs=_user_room_load_outputs,
            show_progress="hidden",
            queue=False
        )
        user_room_promote_to_common_button.click(
            fn=ui_handlers.handle_promote_user_room_to_common,
            inputs=[current_room_name],
            outputs=_user_common_outputs + _user_room_load_outputs,
            show_progress="hidden",
            queue=False
        )
        user_room_closet_save_button.click(
            fn=ui_handlers.handle_save_user_closet_profile,
            inputs=[user_room_closet_scope_state, current_room_name, user_room_closet_enabled, user_room_closet_description],
            outputs=_user_room_outputs,
            show_progress="hidden",
            queue=False
        )
        user_room_closet_upload_button.upload(
            fn=ui_handlers.handle_add_user_reference_image,
            inputs=[user_room_closet_upload_button, user_room_closet_scope_state, current_room_name],
            outputs=_user_room_outputs,
            show_progress="hidden",
            queue=False
        )
        user_room_closet_delete_ref_button.click(
            fn=ui_handlers.handle_remove_user_reference_image,
            inputs=[user_room_closet_scope_state, current_room_name, user_room_closet_delete_ref_dropdown],
            outputs=_user_room_outputs,
            show_progress="hidden",
            queue=False
        )
        user_room_closet_dropdown.change(
            fn=ui_handlers.handle_user_closet_selection,
            inputs=[user_room_closet_scope_state, current_room_name, user_room_closet_dropdown],
            outputs=[user_room_closet_selected_id, user_room_closet_detail],
            show_progress="hidden",
            queue=False
        )
        user_room_closet_wear_button.click(
            fn=ui_handlers.handle_wear_user_closet_item_ui,
            inputs=[user_room_closet_scope_state, current_room_name, user_room_closet_dropdown],
            outputs=[user_room_closet_html, user_room_closet_dropdown, user_room_closet_detail, user_room_current_outfit, user_room_closet_status],
            show_progress="hidden",
            queue=False
        )
        user_room_closet_takeoff_button.click(
            fn=ui_handlers.handle_take_off_user_closet_item_ui,
            inputs=[user_room_closet_scope_state, current_room_name, user_room_closet_dropdown],
            outputs=[user_room_closet_html, user_room_closet_dropdown, user_room_closet_detail, user_room_current_outfit, user_room_closet_status],
            show_progress="hidden",
            queue=False
        )
        user_room_closet_delete_button.click(
            fn=ui_handlers.handle_delete_user_closet_item_ui,
            inputs=[user_room_closet_scope_state, current_room_name, user_room_closet_dropdown],
            outputs=[user_room_closet_html, user_room_closet_dropdown, user_room_closet_detail, user_room_current_outfit, user_room_closet_status],
            show_progress="hidden",
            queue=False
        )
        user_room_current_note_save_button.click(
            fn=ui_handlers.handle_save_user_current_note_ui,
            inputs=[user_room_closet_scope_state, current_room_name, user_room_current_note],
            outputs=[user_room_current_outfit, user_room_closet_status],
            show_progress="hidden",
            queue=False
        )
        user_room_real_register_button.click(
            fn=ui_handlers.handle_add_user_real_closet_item,
            inputs=[user_room_closet_scope_state, current_room_name, user_room_real_image, user_room_real_name, user_room_real_part, user_room_real_description, user_room_real_tags],
            outputs=_user_room_outputs,
            show_progress="hidden",
            queue=False
        )

        user_closet_bridge_register_button.click(
            fn=ui_handlers.handle_register_inventory_item_to_user_closet_ui,
            inputs=[
                current_room_name,
                inventory_target_radio,
                inventory_selected_item_id,
                closet_bridge_part_dropdown,
                closet_bridge_name_input,
                closet_bridge_description_input,
                closet_bridge_tags_input,
            ],
            outputs=[
                user_room_closet_html,
                user_room_closet_dropdown,
                user_room_closet_detail,
                user_room_current_note,
                user_room_current_outfit,
                user_room_closet_status,
            ],
            show_progress="hidden",
            queue=False
        )

        std_item_image_gen_button.click(
            fn=ui_handlers.handle_generate_item_image,
            inputs=[std_item_image_gen_prompt, current_room_name, current_api_key_name_state, std_item_image_gen_refs],
            outputs=[std_item_image_input, std_item_status],
            show_progress="hidden"
        )

        std_item_generate_button.click(
            fn=ui_handlers.handle_std_item_generate,
            inputs=[std_item_name_input, std_item_category_input, std_item_base_info, std_item_image_input],
            outputs=[
                std_item_status, std_item_name_input, std_item_appearance_desc,
                std_item_appearance_color, std_item_appearance_design,
                std_item_texture, std_item_weight, std_item_temp, std_item_flavor_text,
                std_item_raw_json_state
            ]
        )

        std_item_save_button.click(
            fn=ui_handlers.handle_save_std_item,
            inputs=[
                current_room_name, std_item_name_input, std_item_category_input, std_item_amount_input,
                std_item_base_info, std_item_image_input,
                std_item_appearance_desc, std_item_appearance_color, std_item_appearance_design,
                std_item_texture, std_item_weight, std_item_temp, std_item_flavor_text,
                std_item_raw_json_state
            ],
            outputs=[
                std_item_status, unified_inventory_df, food_use_item_dropdown, inventory_status,
                std_item_name_input, std_item_category_input, std_item_amount_input,
                std_item_base_info, std_item_image_input,
                std_item_appearance_desc, std_item_appearance_color, std_item_appearance_design,
                std_item_texture, std_item_weight, std_item_temp, std_item_flavor_text,
                std_item_raw_json_state
            ],
            show_progress="hidden",
            queue=False
        )

        std_item_save_as_new_button.click(
            fn=ui_handlers.handle_save_std_item_as_new,
            inputs=[
                current_room_name, std_item_name_input, std_item_category_input, std_item_amount_input,
                std_item_base_info, std_item_image_input,
                std_item_appearance_desc, std_item_appearance_color, std_item_appearance_design,
                std_item_texture, std_item_weight, std_item_temp, std_item_flavor_text,
                std_item_raw_json_state
            ],
            outputs=[
                std_item_status, unified_inventory_df, food_use_item_dropdown, inventory_status,
                std_item_name_input, std_item_category_input, std_item_amount_input,
                std_item_base_info, std_item_image_input,
                std_item_appearance_desc, std_item_appearance_color, std_item_appearance_design,
                std_item_texture, std_item_weight, std_item_temp, std_item_flavor_text,
                std_item_raw_json_state
            ],
            show_progress="hidden",
            queue=False
        )

        load_std_item_to_editor_button.click(
            fn=ui_handlers.handle_load_std_item_to_editor_by_id,
            inputs=[current_room_name, inventory_selected_item_id, inventory_target_radio],
            outputs=[
                std_item_name_input, std_item_image_input, std_item_category_input, std_item_amount_input, std_item_base_info,
                std_item_appearance_desc, std_item_appearance_color, std_item_appearance_design,
                std_item_texture, std_item_weight, std_item_temp,
                std_item_flavor_text, std_item_raw_json_state, std_item_status
            ],
            show_progress="hidden",
            queue=False
        )

        food_item_image_gen_button.click(
            fn=ui_handlers.handle_generate_item_image,
            inputs=[food_item_image_gen_prompt, current_room_name, current_api_key_name_state, food_item_image_gen_refs],
            outputs=[food_item_image_input, food_item_status],
            show_progress="hidden"
        )

        food_item_generate_button.click(
            fn=ui_handlers.handle_generate_food_item,
            inputs=[food_item_name_input, food_item_category_input, food_item_base_info, food_item_amount_input, food_item_image_input],
            outputs=[
                food_item_status, food_sweetness, food_saltiness, food_sourness, food_bitterness, food_umami, food_taste_description,
                food_temp, food_astringency, food_viscosity, food_weight, food_phys_description,
                food_time_top, food_time_middle, food_time_last,
                food_syn_color, food_syn_emotion, food_syn_landscape,
                food_flavor_text, food_raw_json_state
            ]
        )

        food_item_save_button.click(
            fn=ui_handlers.handle_save_food_item,
            inputs=[
                current_room_name, food_item_name_input, food_item_category_input, food_item_amount_input, food_item_image_input,
                food_sweetness, food_saltiness, food_sourness, food_bitterness, food_umami, food_taste_description,
                food_temp, food_astringency, food_viscosity, food_weight, food_phys_description,
                food_time_top, food_time_middle, food_time_last,
                food_syn_color, food_syn_emotion, food_syn_landscape,
                food_flavor_text, food_raw_json_state
            ],
            outputs=[
                food_item_status, unified_inventory_df, food_use_item_dropdown, inventory_status,
                food_item_name_input, food_item_category_input, food_item_amount_input, food_item_image_input,
                food_sweetness, food_saltiness, food_sourness, food_bitterness, food_umami, food_taste_description,
                food_temp, food_astringency, food_viscosity, food_weight, food_phys_description,
                food_time_top, food_time_middle, food_time_last,
                food_syn_color, food_syn_emotion, food_syn_landscape,
                food_flavor_text, food_raw_json_state
            ],
            show_progress="hidden",
            queue=False
        )

        food_item_save_as_new_button.click(
            fn=ui_handlers.handle_save_food_item_as_new,
            inputs=[
                current_room_name, food_item_name_input, food_item_category_input, food_item_amount_input, food_item_image_input,
                food_sweetness, food_saltiness, food_sourness, food_bitterness, food_umami, food_taste_description,
                food_temp, food_astringency, food_viscosity, food_weight, food_phys_description,
                food_time_top, food_time_middle, food_time_last,
                food_syn_color, food_syn_emotion, food_syn_landscape,
                food_flavor_text, food_raw_json_state
            ],
            outputs=[
                food_item_status, unified_inventory_df, food_use_item_dropdown, inventory_status,
                food_item_name_input, food_item_category_input, food_item_amount_input, food_item_image_input,
                food_sweetness, food_saltiness, food_sourness, food_bitterness, food_umami, food_taste_description,
                food_temp, food_astringency, food_viscosity, food_weight, food_phys_description,
                food_time_top, food_time_middle, food_time_last,
                food_syn_color, food_syn_emotion, food_syn_landscape,
                food_flavor_text, food_raw_json_state
            ],
            show_progress="hidden",
            queue=False
        )

        load_food_item_to_editor_button.click(
            fn=ui_handlers.handle_load_food_item_to_editor_by_id,
            inputs=[current_room_name, inventory_selected_item_id, inventory_target_radio],
            outputs=[
                food_item_name_input, food_item_image_input, food_item_category_input, food_item_amount_input, food_item_base_info,
                food_sweetness, food_saltiness, food_sourness, food_bitterness, food_umami, food_taste_description,
                food_temp, food_astringency, food_viscosity, food_weight, food_phys_description,
                food_time_top, food_time_middle, food_time_last,
                food_syn_color, food_syn_emotion, food_syn_landscape,
                food_flavor_text, food_raw_json_state, food_item_status
            ],
            show_progress="hidden",
            queue=False
        )

        play_audio_event = play_audio_button.click(
            fn=ui_handlers.handle_play_audio_button_click,
            inputs=[selected_message_state, current_room_name, api_key_dropdown, tts_playback_mode_dropdown],
            outputs=[
                audio_player,
                play_audio_button,
                rerun_button,
                tts_segment_dropdown,
                play_tts_segment_button,
                tts_playlist_state,
                tts_playlist_index_state,
            ]
        )
        play_audio_event.failure(
            fn=ui_handlers._reset_play_audio_on_failure,
            inputs=None,
            outputs=[
                audio_player,
                play_audio_button,
                rerun_button,
                tts_segment_dropdown,
                play_tts_segment_button,
                tts_playlist_state,
                tts_playlist_index_state,
            ],
        )
        play_tts_segment_button.click(
            fn=ui_handlers.handle_play_tts_segment,
            inputs=[tts_segment_dropdown, tts_playlist_state],
            outputs=[audio_player, tts_playlist_index_state],
            show_progress="hidden",
        )
        auto_play_next_trigger_btn.click(
            fn=ui_handlers.handle_play_next_tts_segment,
            inputs=[tts_playlist_state, tts_playlist_index_state],
            outputs=[audio_player, tts_playlist_index_state],
            queue=False,
            show_progress="hidden",
        )
        audio_player.change(
            fn=None,
            inputs=None,
            outputs=None,
            js="""
            () => {
                const gradioApp = document.querySelector('gradio-app');
                if (!gradioApp) return;
                const root = gradioApp.shadowRoot || document;
                const audioEl = root.querySelector('#main_audio_player audio');
                if (!audioEl) return;
                if (audioEl.dataset.hasEndedListener) return;
                audioEl.dataset.hasEndedListener = "true";
                audioEl.addEventListener('ended', () => {
                    console.log("--- [JS:PlayAudio] Audio ended, triggering next segment...");
                    const btn = root.querySelector('#auto_play_next_trigger_btn');
                    if (btn) {
                        btn.click();
                    }
                });
            }
            """
        )
        audio_player.clear(
            fn=lambda: gr.update(visible=False),
            inputs=None,
            outputs=[audio_player]
        )
        copy_scenery_prompt_button.click(
            fn=None, inputs=[scenery_prompt_output_textbox], outputs=None,
            js="(text) => { navigator.clipboard.writeText(text); const toast = document.createElement('gradio-toast'); toast.setAttribute('description', 'プロンプトをコピーしました！'); document.querySelector('.gradio-toast-container-x-center').appendChild(toast); }"
        )

        generate_scenery_prompt_button.click(
            fn=ui_handlers.handle_show_scenery_prompt,
            inputs=[current_room_name, api_key_dropdown, scenery_style_radio],
            outputs=[scenery_prompt_output_textbox]
        )

        search_provider_radio.change(
            fn=ui_handlers.handle_search_provider_change,
            inputs=[search_provider_radio],
            outputs=[common_settings_status]  # 個別表示制御を廃止し、常時表示（アコーディオン）へ
        )

        search_model_dropdown.change(
            fn=ui_handlers.handle_search_model_change,
            inputs=[search_model_dropdown],
            outputs=[common_settings_status]
        )

        fetch_search_models_button.click(
            fn=ui_handlers.handle_fetch_search_models,
            inputs=[api_key_dropdown, search_model_dropdown],
            outputs=[search_model_dropdown]
        )

        test_search_model_button.click(
            fn=ui_handlers.handle_test_search_model,
            inputs=[search_model_dropdown, api_key_dropdown],
            outputs=[]
        )

        save_tavily_key_button.click(
            fn=ui_handlers.handle_save_tavily_key,
            inputs=[tavily_api_key_input],
            outputs=None
        )

        save_zhipu_key_button.click(
            fn=ui_handlers.handle_save_zhipu_key,
            inputs=[zhipu_api_key_input],
            outputs=None
        )

        save_groq_key_button.click(
            fn=ui_handlers.handle_save_groq_key,
            inputs=[groq_api_key_input],
            outputs=[groq_api_key_input]
        )

        save_moonshot_key_button.click(
            fn=ui_handlers.handle_save_moonshot_key,
            inputs=[moonshot_api_key_input],
            outputs=None
        )

        # --- [Phase 4] New Providers ---
        save_openai_official_key_button.click(
            fn=ui_handlers.handle_save_openai_official_key,
            inputs=[openai_official_api_key_input],
            outputs=[openai_official_api_key_input, openai_profile_dropdown]
        )

        save_anthropic_key_button.click(
            fn=ui_handlers.handle_save_anthropic_key,
            inputs=[anthropic_api_key_input_simple],
            outputs=[anthropic_api_key_input_simple]
        )

        fetch_anthropic_models_button.click(
            fn=ui_handlers.handle_fetch_anthropic_models,
            inputs=[anthropic_api_key_input],
            outputs=[anthropic_model_dropdown]
        )

        save_nim_key_button.click(
            fn=ui_handlers.handle_save_nim_key,
            inputs=[nim_api_key_input],
            outputs=[nim_api_key_input, openai_profile_dropdown]
        )

        save_xai_key_button.click(
            fn=ui_handlers.handle_save_xai_key,
            inputs=[xai_api_key_input],
            outputs=[xai_api_key_input, openai_profile_dropdown]
        )

        save_elevenlabs_key_button.click(
            fn=ui_handlers.handle_save_elevenlabs_key,
            inputs=[elevenlabs_api_key_input],
            outputs=[elevenlabs_api_key_input]
        )

        add_custom_openai_button.click(
            fn=ui_handlers.handle_add_custom_openai_provider,
            inputs=[custom_openai_name_input, custom_openai_url_input, custom_openai_key_input],
            outputs=[custom_openai_name_input, custom_openai_url_input, custom_openai_key_input, openai_profile_dropdown]
        )

        add_ollama_profile_button.click(
            fn=ui_handlers.handle_add_ollama_preset,
            inputs=None,
            outputs=[openai_profile_dropdown]
        )

        # --- [Doc Viewer Events] ---
        # 軽量な更新イベントは show_progress="hidden" を付けないと、Gradio6では
        # キューの進捗表示（"processing…"）が回り続ける（decisions/003 参照）。
        open_local_llm_guide_btn.click(
            fn=ui_handlers.handle_open_local_llm_guide,
            outputs=[doc_viewer_overlay, doc_viewer_display],
            show_progress="hidden",
            js="() => { const o = document.getElementById('doc_viewer_overlay'); if (o) o.style.removeProperty('display'); }"
        )
        open_explicit_cache_guide_btn.click(
            fn=ui_handlers.handle_open_explicit_cache_guide,
            outputs=[doc_viewer_overlay, doc_viewer_display],
            show_progress="hidden",
            js="() => { const o = document.getElementById('doc_viewer_overlay'); if (o) o.style.removeProperty('display'); }"
        )
        open_lite_cloud_quick_guide_btn.click(
            fn=ui_handlers.handle_open_lite_cloud_quick_guide,
            outputs=[doc_viewer_overlay, doc_viewer_display],
            show_progress="hidden",
            js="() => { const o = document.getElementById('doc_viewer_overlay'); if (o) o.style.removeProperty('display'); }"
        )
        lite_start_connected_button.click(
            fn=ui_handlers.handle_lite_start_connected,
            outputs=[
                lite_connected_setup_accordion,
                lite_independent_setup_accordion,
                lite_independent_connectivity_accordion,
            ],
            queue=False,
            show_progress="hidden",
            js="() => setTimeout(() => document.getElementById('lite_connected_setup_flow')?.scrollIntoView({behavior: 'smooth', block: 'start'}), 100)",
        )
        lite_start_independent_button.click(
            fn=ui_handlers.handle_lite_start_independent,
            outputs=[
                lite_connected_setup_accordion,
                lite_independent_setup_accordion,
                lite_independent_connectivity_accordion,
            ],
            queue=False,
            show_progress="hidden",
            js="() => setTimeout(() => document.getElementById('lite_independent_setup_flow')?.scrollIntoView({behavior: 'smooth', block: 'start'}), 100)",
        )
        # CSSのID指定(display:flex)がGradioの非表示クラスに詳細度で勝ち、閉じても
        # オーバーレイが残る。インラインstyle(!important)で確実に消す/戻す。
        close_doc_btn.click(
            fn=ui_handlers.handle_close_doc_viewer,
            outputs=[doc_viewer_overlay],
            show_progress="hidden",
            js="() => { const o = document.getElementById('doc_viewer_overlay'); if (o) o.style.setProperty('display', 'none', 'important'); }"
        )

        save_huggingface_key_button_main.click(
            fn=ui_handlers.handle_save_huggingface_key_main,
            inputs=[huggingface_api_token_input_main],
            outputs=[huggingface_api_token_input_main]
        )

        save_pollinations_key_button_main.click(
            fn=ui_handlers.handle_save_pollinations_key_main,
            inputs=[pollinations_api_key_input_main],
            outputs=[pollinations_api_key_input_main]
        )

        add_hf_preset_button.click(
            fn=ui_handlers.handle_add_huggingface_preset,
            inputs=None,
            outputs=[openai_profile_dropdown]
        )

        add_pollinations_preset_button.click(
            fn=ui_handlers.handle_add_pollinations_preset,
            inputs=None,
            outputs=[openai_profile_dropdown]
        )

        save_local_model_path_button.click(
            fn=ui_handlers.handle_save_local_model_path,
            inputs=[local_model_path_input],
            outputs=[local_model_path_input]
        )

        # --- 外部接続 / API Gateway ---
        external_api_token_generate_button.click(
            fn=ui_handlers.handle_generate_api_gateway_token,
            outputs=[external_api_auth_token_input, external_api_token_copy_output, external_api_status]
        )
        external_api_token_show_button.click(
            fn=ui_handlers.handle_show_saved_api_gateway_token,
            outputs=[external_api_token_copy_output]
        )
        external_api_save_button.click(
            fn=ui_handlers.handle_save_external_api_gateway_settings,
            inputs=[
                external_api_enabled_checkbox,
                external_api_host_input,
                external_api_port_input,
                external_api_require_auth_checkbox,
                external_api_auth_token_input,
                external_api_auto_tailscale_checkbox,
                current_room_name,
            ],
            outputs=[
                external_api_status,
                external_api_token_copy_output,
                external_api_security_diagnostics,
                external_lite_connection_help,
                external_lite_qr_image,
                external_api_docs,
            ]
        )
        external_api_refresh_button.click(
            fn=ui_handlers.handle_refresh_external_api_gateway_panel,
            inputs=[current_room_name],
            outputs=[
                external_api_security_diagnostics,
                external_lite_connection_help,
                external_lite_qr_image,
                external_api_docs,
            ]
        )
        external_tailscale_button.click(
            fn=ui_handlers.handle_configure_tailscale_lite_https,
            outputs=[
                external_api_security_diagnostics,
                external_lite_connection_help,
                external_lite_qr_image,
                external_api_status,
            ]
        )
        lite_connectivity_flow.change(
            fn=ui_handlers.handle_lite_connectivity_flow_change,
            inputs=[lite_connectivity_flow],
            outputs=[
                lite_connectivity_card,
                lite_connectivity_retention_group,
                lite_connectivity_retention_prompt,
                lite_worker_update_guide,
            ],
            queue=False,
            show_progress="hidden",
        )
        lite_connectivity_refresh_button.click(
            fn=ui_handlers.handle_lite_connectivity_refresh,
            inputs=[lite_connectivity_flow, current_room_name],
            outputs=[
                lite_connectivity_card,
                lite_connectivity_retention_group,
                lite_connectivity_retention_prompt,
                lite_worker_update_guide,
                lite_phase5_database_name,
                lite_connectivity_open_travel_button,
            ],
        ).then(
            fn=ui_handlers.handle_lite_update_check,
            inputs=[current_room_name], outputs=app_lite_update_outputs,
            show_progress="hidden", api_visibility="private",
            concurrency_id="lite-update-check", concurrency_limit=1,
        )
        lite_connectivity_retention_delete_button.click(
            fn=ui_handlers.handle_lite_connectivity_retention_delete,
            inputs=[lite_connectivity_flow],
            outputs=[
                lite_connectivity_action_status,
                lite_connectivity_card,
                lite_connectivity_retention_group,
                lite_connectivity_retention_prompt,
                lite_worker_update_guide,
            ],
        )
        lite_connectivity_retention_dismiss_button.click(
            fn=ui_handlers.handle_lite_connectivity_retention_dismiss,
            outputs=[lite_connectivity_retention_group, lite_connectivity_action_status],
            queue=False,
            show_progress="hidden",
        )
        lite_connectivity_pair_button.click(
            fn=ui_handlers.handle_lite_connectivity_issue_pairing_code,
            inputs=[lite_connectivity_flow, current_room_name, lite_pairing_code_ttl_minutes],
            outputs=[
                lite_connectivity_action_status,
                lite_connectivity_pairing_handoff,
                lite_connectivity_card,
                lite_connectivity_retention_group,
                lite_connectivity_retention_prompt,
                lite_worker_update_guide,
                lite_phase5_database_name,
                lite_connectivity_open_travel_button,
            ],
        )
        lite_connectivity_prepare_button.click(
            fn=ui_handlers.handle_lite_connectivity_prepare_standby,
            inputs=[lite_connectivity_flow, current_room_name],
            outputs=[
                lite_connectivity_action_status,
                lite_connectivity_card,
                lite_connectivity_retention_group,
                lite_connectivity_retention_prompt,
                lite_worker_update_guide,
                lite_phase5_database_name,
                lite_connectivity_open_travel_button,
            ],
        )
        outing_mode_outputs = [
            outing_lite_setup_group,
            outing_lite_daily_group,
            outing_export_group,
            outing_import_group,
            external_open_lite_outing,
            external_open_outing_export,
            external_open_outing_import,
        ]
        lite_open_daily_event = lite_connectivity_open_travel_button.click(
            fn=ui_handlers.handle_outing_show_lite_independent,
            outputs=outing_mode_outputs,
            queue=False,
            show_progress="hidden",
            js=_outing_mode_visibility_js("independent"),
        )
        lite_entry_event = external_open_lite_outing.click(
            fn=ui_handlers.handle_outing_open_lite,
            inputs=[current_room_name],
            outputs=outing_mode_outputs,
            queue=False,
            show_progress="hidden",
            js="(room) => { window.clearInterval(window.__nexusOutingModeTimer); window.__nexusOutingModeRequest = null; document.querySelectorAll('#outing_tab .outing-mode-panel').forEach(p => p.style.removeProperty('display')); return [room]; }",
        )
        lite_shortcut_events = []
        for button in (lite_daily_shortcut, lite_return_shortcut):
            lite_shortcut_events.append(button.click(
                fn=ui_handlers.handle_outing_show_lite_independent,
                outputs=outing_mode_outputs,
                queue=False,
                show_progress="hidden",
                js=_outing_mode_visibility_js("independent"),
            ))
        for button, handler, immediate_mode in (
            (lite_outing_back_to_setup, ui_handlers.handle_outing_show_lite, "setup"),
            (external_open_outing_export, ui_handlers.handle_outing_show_export, "export"),
            (external_open_outing_import, ui_handlers.handle_outing_show_import, "import"),
        ):
            button.click(
                fn=handler,
                outputs=outing_mode_outputs,
                queue=False,
                show_progress="hidden",
                js=_outing_mode_visibility_js(immediate_mode),
            )
        def _start_lite_busy_button(button, busy_label):
            return button.click(
                fn=lambda: gr.update(value=busy_label, interactive=False),
                outputs=[button],
                queue=False,
                show_progress="hidden",
            )

        def _restore_lite_busy_button(event, button, idle_label):
            return event.then(
                fn=lambda: gr.update(value=idle_label, interactive=True),
                outputs=[button],
                queue=False,
                show_progress="hidden",
            )

        _lite_cloud_setup_outputs = [
            lite_cloud_setup_state,
            lite_cloud_setup_summary,
            lite_cloud_setup_details,
            lite_cloud_setup_check_button,
            lite_cloud_setup_account,
            lite_cloud_setup_confirm_account_button,
            lite_cloud_setup_new_button,
            lite_cloud_setup_import_button,
            lite_cloud_setup_plan_group,
            lite_cloud_setup_plan_summary,
            lite_cloud_setup_worker_url,
            lite_cloud_setup_prepare_confirm,
            lite_cloud_setup_prepare_button,
            lite_cloud_setup_publish_group,
            lite_cloud_setup_publish_summary,
            lite_cloud_setup_publish_confirm,
            lite_cloud_setup_publish_button,
            lite_cloud_setup_manual_account_group,
            lite_cloud_setup_account_group,
            lite_cloud_setup_mode_group,
            lite_cloud_setup_check_group,
        ]
        lite_cloud_setup_check_event = _start_lite_busy_button(
            lite_cloud_setup_check_button,
            "確認中…",
        )
        lite_cloud_setup_check_event.then(
            fn=ui_handlers.handle_lite_cloud_setup_check,
            inputs=[lite_cloud_setup_state],
            outputs=_lite_cloud_setup_outputs,
            queue=False,
            show_progress="hidden",
        )
        lite_runtime_status_event = _start_lite_busy_button(
            lite_runtime_status_button,
            "確認中…",
        ).then(
            fn=ui_handlers.handle_lite_runtime_status_check,
            outputs=[lite_runtime_status, lite_runtime_details, lite_runtime_repair_group],
            queue=False,
            show_progress="hidden",
        )
        _restore_lite_busy_button(
            lite_runtime_status_event,
            lite_runtime_status_button,
            "状態を確認",
        )
        lite_runtime_repair_check_event = _start_lite_busy_button(
            lite_runtime_repair_check_button,
            "確認中…",
        ).then(
            fn=ui_handlers.handle_lite_runtime_repair_check,
            outputs=[lite_runtime_repair_result, lite_runtime_repair_apply_button],
            trigger_mode="once",
            concurrency_limit=1,
            concurrency_id="lite-runtime-repair-check",
        )
        _restore_lite_busy_button(
            lite_runtime_repair_check_event,
            lite_runtime_repair_check_button,
            "次の手順を確認",
        )
        lite_cloud_setup_login_confirm.change(
            fn=ui_handlers.handle_lite_cloud_setup_login_consent_change,
            inputs=[lite_cloud_setup_login_confirm],
            outputs=[lite_cloud_setup_login_button, lite_cloud_setup_login_hint],
            queue=False,
            show_progress="hidden",
        )
        lite_cloud_setup_login_button.click(
            fn=ui_handlers.handle_lite_cloud_setup_login,
            inputs=[lite_cloud_setup_login_confirm, lite_cloud_setup_state],
            outputs=[lite_cloud_setup_login_status, *_lite_cloud_setup_outputs],
        )
        lite_cloud_setup_confirm_account_event = _start_lite_busy_button(
            lite_cloud_setup_confirm_account_button,
            "アカウントを確認中…",
        ).then(
            fn=ui_handlers.handle_lite_cloud_setup_confirm_account,
            inputs=[lite_cloud_setup_state, lite_cloud_setup_account],
            outputs=_lite_cloud_setup_outputs,
            trigger_mode="once",
            concurrency_limit=1,
            concurrency_id="lite-cloud-account-confirm",
        )
        _restore_lite_busy_button(
            lite_cloud_setup_confirm_account_event,
            lite_cloud_setup_confirm_account_button,
            "このアカウントで続ける",
        )
        lite_cloud_setup_manual_account_button.click(
            fn=ui_handlers.handle_lite_cloud_setup_confirm_manual_account,
            inputs=[
                lite_cloud_setup_state,
                lite_cloud_setup_manual_account_name,
                lite_cloud_setup_manual_account_id,
                lite_cloud_setup_manual_account_confirm,
            ],
            outputs=_lite_cloud_setup_outputs,
            queue=False,
            show_progress="hidden",
        )
        lite_cloud_setup_new_button.click(
            fn=ui_handlers.handle_lite_cloud_setup_select_new,
            inputs=[lite_cloud_setup_state],
            outputs=_lite_cloud_setup_outputs,
            queue=False,
            show_progress="hidden",
        )
        lite_cloud_setup_import_button.click(
            fn=ui_handlers.handle_lite_cloud_setup_select_import,
            inputs=[lite_cloud_setup_state],
            outputs=_lite_cloud_setup_outputs,
            queue=False,
            show_progress="hidden",
        )
        lite_cloud_setup_prepare_confirm.change(
            fn=ui_handlers.handle_lite_cloud_setup_confirmation_toggle,
            inputs=[lite_cloud_setup_prepare_confirm],
            outputs=[lite_cloud_setup_prepare_button],
            queue=False,
            show_progress="hidden",
        )
        lite_cloud_setup_prepare_event = _start_lite_busy_button(
            lite_cloud_setup_prepare_button,
            "Lite用クラウドを準備中…",
        ).then(
            fn=ui_handlers.handle_lite_cloud_setup_prepare,
            inputs=[
                lite_cloud_setup_state,
                lite_cloud_setup_worker_url,
                lite_cloud_setup_prepare_confirm,
            ],
            outputs=_lite_cloud_setup_outputs,
            trigger_mode="once",
            concurrency_limit=1,
            concurrency_id="app-update-mutation",
            show_progress="hidden",
        )
        _restore_lite_busy_button(
            lite_cloud_setup_prepare_event,
            lite_cloud_setup_prepare_button,
            "確認した内容で準備を開始",
        )
        lite_cloud_setup_publish_confirm.change(
            fn=ui_handlers.handle_lite_cloud_setup_confirmation_toggle,
            inputs=[lite_cloud_setup_publish_confirm],
            outputs=[lite_cloud_setup_publish_button],
            queue=False,
            show_progress="hidden",
        )
        lite_cloud_setup_publish_event = _start_lite_busy_button(
            lite_cloud_setup_publish_button,
            "Lite用クラウドを公開中…",
        )
        lite_cloud_setup_publish_result_event = lite_cloud_setup_publish_event.then(
            fn=ui_handlers.handle_lite_cloud_setup_publish,
            inputs=[lite_cloud_setup_state, lite_cloud_setup_publish_confirm],
            outputs=_lite_cloud_setup_outputs,
            trigger_mode="once",
            concurrency_limit=1,
            concurrency_id="app-update-mutation",
            show_progress="hidden",
        )
        lite_cloud_setup_publish_sync_event = lite_cloud_setup_publish_result_event.then(
            fn=ui_handlers.handle_lite_cloud_setup_sync_saved_connection_fields,
            inputs=[
                lite_cloud_setup_state,
                lite_travel_worker_url,
                lite_travel_owner_token,
                lite_travel_signing_key,
                lite_travel_wrangler_config_path,
            ],
            outputs=[
                lite_travel_worker_url,
                lite_travel_owner_token,
                lite_travel_signing_key,
                lite_travel_wrangler_config_path,
            ],
            queue=False,
            show_progress="hidden",
        )
        _restore_lite_busy_button(
            lite_cloud_setup_publish_sync_event,
            lite_cloud_setup_publish_button,
            "Lite用クラウドを公開して接続を確認",
        )
        lite_travel_settings_save_event = lite_travel_settings_save.click(
            fn=ui_handlers.handle_save_lite_travel_settings,
            inputs=[
                lite_travel_worker_url,
                lite_travel_owner_token,
                lite_travel_signing_key,
                lite_travel_credential_profile_id,
                lite_travel_model_id,
                lite_travel_retention_days,
                lite_travel_wrangler_config_path,
                lite_travel_daily_budget,
                lite_travel_session_budget,
                lite_travel_budget_warning_ratio,
                lite_travel_allow_unknown_price,
                lite_travel_max_output_tokens,
                lite_travel_budget_timezone,
                lite_travel_cache_policy,
                lite_travel_use_custom_model,
                lite_travel_custom_model_id,
            ],
            outputs=[lite_travel_settings_status],
        )
        lite_travel_settings_save_event.then(
            fn=ui_handlers.handle_lite_connectivity_flow_change,
            inputs=[lite_connectivity_flow],
            outputs=[
                lite_connectivity_card,
                lite_connectivity_retention_group,
                lite_connectivity_retention_prompt,
                lite_worker_update_guide,
            ],
            show_progress="hidden",
        )
        lite_travel_settings_save_event.then(
            fn=ui_handlers.handle_refresh_lite_daily_ai_route,
            outputs=[
                lite_daily_credential_profile_id,
                lite_daily_model_id,
                lite_daily_ai_status,
            ],
            queue=False,
            show_progress="hidden",
        )
        lite_travel_secret_provider_event = lite_travel_secret_provider.change(
            fn=ui_handlers.handle_lite_travel_secret_provider_change,
            inputs=[lite_travel_secret_provider],
            outputs=[
                lite_travel_local_key_reference,
                lite_travel_secret_binding,
                lite_travel_secret_profile_id,
                lite_travel_secret_display_name,
                lite_travel_local_key_status,
                lite_travel_secret_register_button,
            ],
        )
        lite_travel_secret_provider_event.then(
            fn=ui_handlers.handle_lite_travel_secret_registration_provider_change,
            inputs=[lite_travel_secret_provider],
            outputs=[
                lite_travel_secret_registration_target,
                lite_travel_secret_binding,
                lite_travel_secret_profile_id,
                lite_travel_secret_display_name,
                lite_travel_secret_confirm,
            ],
            queue=False,
            show_progress="hidden",
        )
        lite_travel_secret_key_event = lite_travel_local_key_reference.change(
            fn=ui_handlers.handle_lite_travel_secret_key_change,
            inputs=[lite_travel_local_key_reference],
            outputs=[lite_travel_secret_confirm],
            queue=False,
            show_progress="hidden",
        )
        lite_travel_secret_target_event = lite_travel_secret_registration_target.change(
            fn=ui_handlers.handle_lite_travel_secret_registration_target_change,
            inputs=[lite_travel_secret_provider, lite_travel_secret_registration_target],
            outputs=[
                lite_travel_secret_binding,
                lite_travel_secret_profile_id,
                lite_travel_secret_display_name,
                lite_travel_secret_confirm,
            ],
            queue=False,
            show_progress="hidden",
        )
        lite_travel_secret_profile_event = lite_travel_secret_profile_id.input(
            fn=ui_handlers.handle_lite_travel_secret_key_change,
            inputs=[lite_travel_secret_profile_id],
            outputs=[lite_travel_secret_confirm],
            queue=False,
            show_progress="hidden",
        )
        lite_travel_secret_display_event = lite_travel_secret_display_name.input(
            fn=ui_handlers.handle_lite_travel_secret_key_change,
            inputs=[lite_travel_secret_display_name],
            outputs=[lite_travel_secret_confirm],
            queue=False,
            show_progress="hidden",
        )
        lite_travel_credential_profile_id.input(
            fn=ui_handlers.handle_lite_ai_connection_change,
            inputs=[lite_travel_credential_profile_id, lite_travel_model_id],
            outputs=[lite_travel_model_id, lite_travel_ai_connection_status],
            queue=False,
            show_progress="hidden",
        )
        lite_travel_refresh_models_event = _start_lite_busy_button(
            lite_travel_refresh_models_button,
            "モデル一覧を取得中…",
        ).then(
            fn=ui_handlers.handle_fetch_lite_travel_models,
            inputs=[lite_travel_credential_profile_id, lite_travel_model_id],
            outputs=[lite_travel_model_id, lite_travel_ai_connection_status],
            trigger_mode="once",
            concurrency_limit=1,
            concurrency_id="lite-model-list-fetch",
        )
        _restore_lite_busy_button(
            lite_travel_refresh_models_event,
            lite_travel_refresh_models_button,
            "最新のモデル一覧を取得",
        )
        lite_travel_secret_register_event = lite_travel_secret_register_button.click(
            fn=ui_handlers.handle_register_lite_travel_secret,
            inputs=[
                lite_travel_secret_provider,
                lite_travel_local_key_reference,
                lite_travel_secret_registration_target,
                lite_travel_secret_profile_id,
                lite_travel_secret_display_name,
                lite_travel_wrangler_config_path,
                lite_travel_secret_confirm,
                lite_travel_model_id,
            ],
            outputs=[
                lite_travel_secret_status,
                lite_travel_credential_profile_id,
                lite_travel_model_id,
            ],
        )
        lite_travel_secret_register_event.then(
            fn=ui_handlers.handle_refresh_lite_daily_ai_route,
            inputs=[lite_travel_credential_profile_id, lite_travel_model_id],
            outputs=[
                lite_daily_credential_profile_id,
                lite_daily_model_id,
                lite_daily_ai_status,
            ],
            queue=False,
            show_progress="hidden",
        )
        lite_travel_secret_provider_event.then(
            fn=ui_handlers.handle_lite_travel_secret_key_change,
            inputs=[lite_travel_secret_provider],
            outputs=[lite_travel_profile_label_confirm], queue=False, show_progress="hidden",
        )
        lite_travel_secret_key_event.then(
            fn=ui_handlers.handle_lite_travel_secret_key_change,
            inputs=[lite_travel_local_key_reference],
            outputs=[lite_travel_profile_label_confirm], queue=False, show_progress="hidden",
        )
        lite_travel_secret_target_event.then(
            fn=ui_handlers.handle_lite_travel_secret_key_change,
            inputs=[lite_travel_secret_registration_target],
            outputs=[lite_travel_profile_label_confirm], queue=False, show_progress="hidden",
        )
        lite_travel_secret_profile_event.then(
            fn=ui_handlers.handle_lite_travel_secret_key_change,
            inputs=[lite_travel_secret_profile_id],
            outputs=[lite_travel_profile_label_confirm], queue=False, show_progress="hidden",
        )
        lite_travel_secret_display_event.then(
            fn=ui_handlers.handle_lite_travel_secret_key_change,
            inputs=[lite_travel_secret_display_name],
            outputs=[lite_travel_profile_label_confirm], queue=False, show_progress="hidden",
        )
        lite_travel_profile_label_event = lite_travel_profile_label_button.click(
            fn=ui_handlers.handle_update_lite_travel_secret_display,
            inputs=[
                lite_travel_secret_provider, lite_travel_local_key_reference,
                lite_travel_secret_registration_target, lite_travel_secret_profile_id,
                lite_travel_secret_display_name, lite_travel_profile_label_confirm,
                lite_travel_credential_profile_id, lite_travel_model_id,
            ],
            outputs=[lite_travel_secret_status, lite_travel_credential_profile_id, lite_travel_model_id],
        )
        lite_travel_profile_label_event.then(
            fn=ui_handlers.handle_refresh_lite_daily_ai_route,
            inputs=[lite_daily_credential_profile_id, lite_daily_model_id],
            outputs=[lite_daily_credential_profile_id, lite_daily_model_id, lite_daily_ai_status],
            queue=False, show_progress="hidden",
        )
        lite_phase5_diagnostics_button.click(
            fn=ui_handlers.handle_lite_phase5_diagnostics,
            outputs=[lite_phase5_diagnostics_status],
        )
        lite_phase5_diagnostic_export_button.click(
            fn=ui_handlers.handle_lite_phase5_diagnostic_export,
            outputs=[lite_phase5_diagnostics_status],
        )
        lite_phase5_plan_button.click(
            fn=ui_handlers.handle_lite_phase5_plan_update,
            inputs=[lite_phase5_database_name],
            outputs=[lite_phase5_operation, lite_phase5_update_status, lite_phase5_run_button],
        )
        lite_phase5_run_button.click(
            fn=ui_handlers.handle_lite_phase5_run_update,
            inputs=[lite_phase5_operation, lite_phase5_update_confirm, lite_connectivity_flow],
            outputs=[
                lite_phase5_operation,
                lite_phase5_update_status,
                lite_connectivity_card,
                lite_worker_update_guide,
            ],
            trigger_mode="once", concurrency_limit=1,
            concurrency_id="app-update-mutation",
        )
        lite_phase5_devices_button.click(
            fn=ui_handlers.handle_lite_phase5_devices,
            outputs=[lite_phase5_devices_status],
        )
        lite_phase5_revoke_all_button.click(
            fn=ui_handlers.handle_lite_phase5_revoke_all_devices,
            inputs=[lite_phase5_revoke_all_confirm],
            outputs=[lite_phase5_devices_status],
        )
        lite_phase5_revoke_device_button.click(
            fn=ui_handlers.handle_lite_phase5_revoke_device,
            inputs=[lite_phase5_device_id, lite_phase5_revoke_device_confirm],
            outputs=[lite_phase5_devices_status],
        )
        lite_phase5_retention_preview_button.click(
            fn=lambda: ui_handlers.handle_lite_phase5_retention(True),
            outputs=[lite_phase5_retention_status],
        )
        lite_phase5_retention_run_button.click(
            fn=lambda: ui_handlers.handle_lite_phase5_retention(False),
            outputs=[lite_phase5_retention_status],
        )
        external_event_type_dropdown.change(
            fn=ui_handlers.handle_external_event_type_change,
            inputs=[external_event_type_dropdown],
            outputs=[external_event_data_json]
        )
        external_event_test_button.click(
            fn=ui_handlers.handle_test_external_event,
            inputs=[
                current_room_name,
                external_event_type_dropdown,
                external_event_source_input,
                external_event_notify_checkbox,
                external_event_importance_dropdown,
                external_event_data_json,
            ],
            outputs=[external_event_result]
        )

        # --- 外部接続 / Twitter ---
        twitter_auth_mode_radio.change(
            fn=ui_handlers.handle_twitter_auth_mode_change,
            inputs=[twitter_auth_mode_radio],
            outputs=[twitter_browser_auth_group, twitter_api_auth_group]
        )
        twitter_load_settings_button.click(
            fn=ui_handlers.handle_load_twitter_settings,
            inputs=[current_room_name],
            outputs=[
                twitter_enabled_checkbox,
                twitter_auth_mode_radio,
                twitter_posting_summary_input,
                twitter_posting_guidelines_input,
                twitter_auto_post_checkbox,
                twitter_notify_on_approval_checkbox,
                twitter_api_key_input,
                twitter_api_secret_input,
                twitter_access_token_input,
                twitter_access_token_secret_input,
                twitter_browser_auth_group,
                twitter_api_auth_group,
                twitter_is_premium_checkbox,
                twitter_privacy_filter_checkbox,
                twitter_fetch_thread_checkbox,
                twitter_thread_fetch_count_number,
            ]
        )
        twitter_check_session_button.click(
            fn=ui_handlers.handle_check_twitter_session,
            inputs=[current_room_name],
            outputs=[twitter_session_status]
        )
        twitter_login_button.click(
            fn=ui_handlers.handle_twitter_login,
            inputs=[current_room_name],
            outputs=[twitter_session_status]
        )
        twitter_cookie_import_button.click(
            fn=ui_handlers.handle_twitter_cookie_import,
            inputs=[twitter_cookie_input, current_room_name],
            outputs=[twitter_session_status]
        )
        twitter_test_api_button.click(
            fn=ui_handlers.handle_test_twitter_api,
            inputs=[
                twitter_api_key_input,
                twitter_api_secret_input,
                twitter_access_token_input,
                twitter_access_token_secret_input,
            ],
            outputs=[twitter_test_result]
        )
        twitter_save_button.click(
            fn=lambda *args: (ui_handlers.handle_save_twitter_settings(*args), "Twitter状態: 設定を保存しました。")[1],
            inputs=[
                current_room_name,
                twitter_enabled_checkbox,
                twitter_auth_mode_radio,
                twitter_api_key_input,
                twitter_api_secret_input,
                twitter_access_token_input,
                twitter_access_token_secret_input,
                twitter_posting_summary_input,
                twitter_posting_guidelines_input,
                twitter_auto_post_checkbox,
                twitter_notify_on_approval_checkbox,
                twitter_is_premium_checkbox,
                twitter_privacy_filter_checkbox,
                twitter_fetch_thread_checkbox,
                twitter_thread_fetch_count_number,
            ],
            outputs=[twitter_status]
        )
        twitter_refresh_pending_button.click(
            fn=ui_handlers.handle_refresh_twitter_pending,
            inputs=[current_room_name],
            outputs=[twitter_pending_df]
        )
        twitter_pending_df.select(
            fn=ui_handlers.handle_load_selected_twitter_draft,
            inputs=[twitter_pending_df],
            outputs=[
                twitter_selected_draft_id_state,
                twitter_draft_editor,
                twitter_draft_warnings,
                twitter_reply_preview,
                twitter_reply_url_state,
                twitter_reply_id_state,
                twitter_media_file,
                twitter_media_gallery,
            ]
        )
        twitter_load_selected_draft_button.click(
            fn=ui_handlers.handle_load_twitter_draft_by_button,
            inputs=[twitter_selected_draft_id_state],
            outputs=[
                twitter_selected_draft_id_state,
                twitter_draft_editor,
                twitter_draft_warnings,
                twitter_reply_preview,
                twitter_reply_url_state,
                twitter_reply_id_state,
                twitter_media_file,
                twitter_media_gallery,
            ]
        )
        twitter_media_file.change(
            fn=ui_handlers.handle_twitter_media_file_change,
            inputs=[twitter_media_file],
            outputs=[twitter_media_gallery],
            show_progress="hidden",
        )
        twitter_approve_button.click(
            fn=ui_handlers.handle_approve_twitter_tweet,
            inputs=[
                twitter_selected_draft_id_state,
                twitter_draft_editor,
                twitter_reply_url_state,
                twitter_media_file,
            ],
            outputs=[
                twitter_pending_df,
                twitter_history_df,
                twitter_selected_draft_id_state,
                twitter_draft_editor,
                twitter_approval_detail,
                twitter_media_file,
                twitter_media_gallery,
            ]
        )
        twitter_reject_button.click(
            fn=ui_handlers.handle_reject_twitter_tweet,
            inputs=[twitter_selected_draft_id_state],
            outputs=[
                twitter_pending_df,
                twitter_history_df,
                twitter_selected_draft_id_state,
                twitter_draft_editor,
                twitter_approval_detail,
                twitter_media_file,
                twitter_media_gallery,
            ]
        )
        twitter_refresh_history_button.click(
            fn=ui_handlers.handle_refresh_twitter_history,
            outputs=[twitter_history_df]
        )
        twitter_history_df.select(
            fn=ui_handlers.handle_twitter_history_select,
            inputs=[twitter_history_df],
            outputs=[twitter_history_selected_id_state, twitter_history_detail]
        )
        twitter_history_retry_button.click(
            fn=ui_handlers.handle_twitter_history_retry_lite,
            inputs=[twitter_history_selected_id_state],
            outputs=[twitter_pending_df, twitter_history_df, twitter_history_detail]
        )
        twitter_history_delete_button.click(
            fn=ui_handlers.handle_delete_twitter_history,
            inputs=[twitter_history_selected_id_state],
            outputs=[twitter_history_df]
        )

        # --- 外部接続 / Roblox ---
        save_cloudflare_url_button.click(
            fn=ui_handlers.handle_save_cloudflare_url,
            inputs=[current_room_name, roblox_webhook_domain_input],
            outputs=None
        )
        save_roblox_settings_button.click(
            fn=ui_handlers.handle_save_roblox_settings,
            inputs=[
                current_room_name,
                roblox_api_key_input,
                roblox_universe_id_input,
                roblox_topic_input,
                roblox_webhook_enabled_checkbox,
                roblox_activation_mode_radio,
                roblox_webhook_domain_input,
                roblox_filtering_enabled_checkbox,
            ],
            outputs=[roblox_webhook_secret_input]
        )
        test_roblox_connection_button.click(
            fn=ui_handlers.handle_test_roblox_connection,
            inputs=[
                current_room_name,
                roblox_api_key_input,
                roblox_universe_id_input,
                roblox_topic_input,
            ],
            outputs=[roblox_test_result_output]
        )
        roblox_webhook_regenerate_button.click(
            fn=ui_handlers.handle_regenerate_roblox_webhook_secret,
            inputs=[current_room_name],
            outputs=[roblox_webhook_secret_input]
        )
        roblox_webhook_refresh_logs_button.click(
            fn=ui_handlers.handle_refresh_roblox_webhook_logs,
            outputs=[roblox_webhook_logs_display]
        )

        # --- 外部接続 / 拡張ツール ---
        custom_tools_enabled_checkbox.change(
            fn=ui_handlers.handle_custom_tools_enabled_change,
            inputs=[custom_tools_enabled_checkbox],
            outputs=None
        )
        local_plugin_refresh_button.click(
            fn=ui_handlers.handle_refresh_local_plugin_files,
            outputs=[local_plugin_file_dropdown]
        )
        local_plugin_file_dropdown.change(
            fn=ui_handlers.handle_load_plugin_code,
            inputs=[local_plugin_file_dropdown],
            outputs=[local_plugin_code_editor, local_plugin_enabled_checkbox]
        )
        local_plugin_create_button.click(
            fn=ui_handlers.handle_create_new_plugin,
            inputs=[local_plugin_new_filename_input],
            outputs=[local_plugin_file_dropdown, local_plugin_status]
        )
        local_plugin_save_button.click(
            fn=ui_handlers.handle_save_plugin_code_lite,
            inputs=[local_plugin_file_dropdown, local_plugin_code_editor, local_plugin_enabled_checkbox],
            outputs=[local_plugin_status, local_plugin_file_dropdown]
        )
        local_plugin_delete_button.click(
            fn=ui_handlers.handle_delete_plugin,
            inputs=[local_plugin_file_dropdown],
            outputs=[local_plugin_file_dropdown, local_plugin_status]
        )
        refresh_mcp_servers_button.click(
            fn=ui_handlers.handle_refresh_mcp_servers_lite,
            outputs=[mcp_servers_df]
        )
        mcp_server_type_dropdown.change(
            fn=ui_handlers.handle_mcp_type_change,
            inputs=[mcp_server_type_dropdown],
            outputs=[mcp_server_command_input, mcp_server_args_input]
        )
        add_mcp_server_button.click(
            fn=ui_handlers.handle_add_mcp_server,
            inputs=[
                mcp_server_name_input,
                mcp_server_type_dropdown,
                mcp_server_command_input,
                mcp_server_args_input,
                mcp_server_enabled_checkbox,
            ],
            outputs=[mcp_servers_df, mcp_status]
        )
        mcp_servers_df.change(
            fn=ui_handlers.handle_mcp_servers_df_change,
            inputs=[mcp_servers_df],
            outputs=None
        )
        mcp_servers_df.select(
            fn=ui_handlers.handle_mcp_server_select,
            inputs=[mcp_servers_df],
            outputs=[mcp_selected_server_state]
        )
        edit_mcp_server_button.click(
            fn=ui_handlers.handle_edit_mcp_server,
            inputs=[mcp_selected_server_state],
            outputs=[
                mcp_server_name_input,
                mcp_server_type_dropdown,
                mcp_server_command_input,
                mcp_server_args_input,
                mcp_server_enabled_checkbox,
            ]
        )
        remove_mcp_server_button.click(
            fn=ui_handlers.handle_remove_mcp_server,
            inputs=[mcp_selected_server_state],
            outputs=[mcp_servers_df]
        )
        test_mcp_connection_button.click(
            fn=ui_handlers.handle_test_mcp_connection,
            inputs=[mcp_selected_server_state],
            outputs=[mcp_status, mcp_tools_df]
        )
        mcp_tools_df.change(
            fn=ui_handlers.handle_mcp_tools_config_change,
            inputs=[mcp_tools_df, mcp_selected_server_state],
            outputs=None
        )

# --- API Key / Webhook Events ---# --- API Key / Webhook Events ---
        settings_rotation_checkbox.change(
            fn=ui_handlers.handle_rotation_setting_change,
            inputs=[settings_rotation_checkbox],
            outputs=[common_settings_status]
        )

        paid_keys_checkbox_group.change(
            fn=ui_handlers.handle_paid_keys_change,
            inputs=[paid_keys_checkbox_group],
            outputs=[api_key_dropdown, paid_keys_checkbox_group]
        )

        allow_external_connection_checkbox.change(
            fn=ui_handlers.handle_allow_external_connection_change,
            inputs=[allow_external_connection_checkbox],
            outputs=[common_settings_status]
        )


        # --- 天気・環境連携イベント ---
        weather_search_btn.click(
            fn=ui_handlers.handle_weather_search,
            inputs=[weather_city_input],
            outputs=[weather_candidate_dropdown]
        )

        weather_candidate_dropdown.change(
            fn=ui_handlers.handle_weather_candidate_change,
            inputs=[weather_candidate_dropdown],
            outputs=[weather_lat_display, weather_lon_display]
        )

        weather_refresh_btn.click(
            fn=ui_handlers.handle_weather_manual_refresh,
            inputs=None,
            outputs=[weather_status_preview]
        )

        weather_save_btn.click(
            fn=ui_handlers.handle_save_weather_settings,
            inputs=[weather_city_input, weather_candidate_dropdown, enable_weather_context_cb, enable_weather_scenery_cb],
            outputs=[weather_status_preview, common_settings_status]
        )

        # --- Googleカレンダー連携設定の配線 ---
        open_gcal_guide_btn.click(
            fn=ui_handlers.handle_open_gcal_guide,
            outputs=[doc_viewer_overlay, doc_viewer_display],
            show_progress="hidden",
            js="() => { const o = document.getElementById('doc_viewer_overlay'); if (o) o.style.removeProperty('display'); }"
        )
        gcal_generate_url_btn.click(
            fn=ui_handlers.handle_gcal_generate_url,
            inputs=[gcal_client_id, gcal_client_secret],
            outputs=[gcal_auth_url_box]
        )
        gcal_auth_btn.click(
            fn=ui_handlers.handle_gcal_exchange_code,
            inputs=[gcal_client_id, gcal_client_secret, gcal_code_input],
            outputs=[gcal_status_md, gcal_calendar_select]
        )
        gcal_revoke_btn.click(
            fn=ui_handlers.handle_gcal_revoke,
            inputs=[],
            outputs=[gcal_status_md, gcal_enabled_cb]
        )
        gcal_refresh_calendars_btn.click(
            fn=ui_handlers.handle_gcal_refresh_calendars,
            inputs=[],
            outputs=[gcal_calendar_select]
        )
        gcal_save_btn.click(
            fn=ui_handlers.handle_save_gcal_settings,
            inputs=[gcal_enabled_cb, gcal_client_id, gcal_client_secret, gcal_calendar_select,
                    gcal_sync_interval, gcal_exclude_keywords, gcal_mask_private_cb, gcal_reminder_sync_cb],
            outputs=[gcal_status_md, common_settings_status]
        )
        # 有効化トグルは即時保存（保存ボタンを押さなくてもリロード/再起動で維持される）。
        # 冪等化済み（値が変わらなければ書き込まない）。ユーザー操作時のみ発火させるため、
        # demo.load等のプログラム的な値設定では .change を誘発しない（起動連鎖・固まり対策）。
        gcal_enabled_cb.change(
            fn=ui_handlers.handle_gcal_toggle_enabled,
            inputs=[gcal_enabled_cb],
            outputs=[gcal_status_md],
            show_progress="hidden"
        )

        debug_mode_checkbox.change(
            fn=lambda enabled: ui_handlers.handle_save_global_setting_delta("debug_mode", bool(enabled), "デバッグモード", skip_grace=True),
            inputs=[debug_mode_checkbox],
            outputs=[common_settings_status]
        )

        global_reasoning_inputs = [
            provider_radio, model_dropdown, openai_profile_dropdown, openai_model_dropdown,
            openai_base_url_input, anthropic_model_dropdown,
        ]
        room_reasoning_inputs = [
            room_dropdown, room_provider_radio, room_model_dropdown, room_openai_profile_dropdown,
            room_openai_model_dropdown, room_openai_base_url_input, room_anthropic_model_dropdown,
        ]
        wire_response_reasoning_events(
            demo, global_reasoning_panel, room_reasoning_panel,
            global_reasoning_inputs, room_reasoning_inputs,
        )
        from gemini_connection_ui import wire_gemini_connection_events
        from ui_handlers import response_reasoning as reasoning_handlers
        gemini_connection_events = wire_gemini_connection_events(
            demo, global_gemini_connection_panel, room_gemini_connection_panel,
            room_dropdown, provider_radio, room_provider_radio,
            vertex_key_panel=vertex_key_management_panel,
        )
        from gemini_connection_ui import wire_provider_connection_events
        gemini_connection_events.update(wire_provider_connection_events(
            provider_radio, room_provider_radio, room_dropdown, is_switching_room,
            global_gemini_connection_panel, room_gemini_connection_panel,
            [google_settings_group, openai_settings_group, anthropic_settings_group,
             claude_subscription_settings_group, common_local_settings_group],
            [room_google_settings_group, room_openai_settings_group, room_anthropic_settings_group,
             room_claude_subscription_settings_group, room_local_settings_group,
             room_claude_subscription_delegation_warning, room_model_dropdown,
             room_api_key_dropdown, room_rotation_dropdown],
            global_ai_studio_settings, room_ai_studio_settings, room_settings_save_status,
            gemini_connection_events,
            common_refresh=refresh_common_settings_button,
            room_refresh=refresh_room_settings_button,
            common_accordion=common_provider_accordion, room_accordion=room_provider_accordion,
        ))
        for connection_event in gemini_connection_events.values():
            # 同モデルでも接続を変えると別の推論設定になる。保存失敗時も実効値を再照合する。
            connection_event.then(
                fn=reasoning_handlers.load_global,
                inputs=global_reasoning_inputs, outputs=global_reasoning_panel["outputs"],
                show_progress="hidden", api_visibility="private",
            ).then(
                fn=reasoning_handlers.load_room,
                inputs=room_reasoning_inputs, outputs=room_reasoning_panel["outputs"],
                show_progress="hidden", api_visibility="private",
            ).then(
                fn=ui_handlers.refresh_chat_connection_input,
                inputs=[room_dropdown], outputs=[chat_input_multimodal],
                show_progress="hidden", api_visibility="private",
            )

# --- Multi-Provider Events ---

        openai_profile_dropdown.change(
            fn=ui_handlers.handle_openai_profile_select,
            inputs=[openai_profile_dropdown],
            outputs=[openai_base_url_input, openai_api_key_input, openai_model_dropdown, openai_temperature_slider, openai_top_p_slider, openai_max_tokens_input, openai_free_only_checkbox]
        )

        save_openai_config_button.click(
            fn=ui_handlers.handle_save_openai_config,
            inputs=[
                openai_profile_dropdown, openai_base_url_input, openai_api_key_input, openai_model_dropdown,
                openai_temperature_slider, openai_top_p_slider, openai_max_tokens_input, openai_tool_use_checkbox
            ],
            outputs=None
        )

        save_anthropic_config_button.click(
            fn=ui_handlers.handle_save_anthropic_config,
            inputs=[anthropic_api_key_input, anthropic_model_dropdown],
            outputs=None
        )

        save_claude_subscription_config_button.click(
            fn=ui_handlers.handle_save_claude_subscription_config,
            inputs=[claude_subscription_oauth_token_input, claude_subscription_model_dropdown],
            outputs=[claude_subscription_status]
        )

        test_claude_subscription_button.click(
            fn=ui_handlers.handle_test_claude_subscription_connection,
            inputs=[claude_subscription_oauth_token_input, claude_subscription_model_dropdown],
            outputs=[claude_subscription_status]
        )

        fetch_claude_subscription_models_button.click(
            fn=ui_handlers.handle_fetch_claude_subscription_models,
            inputs=[claude_subscription_oauth_token_input, claude_subscription_model_dropdown],
            outputs=[claude_subscription_model_dropdown, claude_subscription_status]
        )

        save_agent_delegation_settings_button.click(
            fn=ui_handlers.handle_save_agent_delegation_settings,
            inputs=[
                agent_delegation_max_concurrent_input,
                agent_delegation_max_turns_input,
                agent_delegation_timeout_input,
                agent_delegation_auto_tune_checkbox,
                agent_delegation_exec_provider_dropdown,
                agent_delegation_exec_profile_dropdown,
                agent_delegation_exec_model_dropdown,
                agent_delegation_wake_chain_max_depth_input,
                agent_delegation_wake_daily_cap_input,
                agent_delegation_wake_min_interval_input,
                agent_delegation_tier_fast_provider_dropdown,
                agent_delegation_tier_fast_profile_dropdown,
                agent_delegation_tier_fast_model_dropdown,
                agent_delegation_tier_balanced_provider_dropdown,
                agent_delegation_tier_balanced_profile_dropdown,
                agent_delegation_tier_balanced_model_dropdown,
                agent_delegation_tier_deep_provider_dropdown,
                agent_delegation_tier_deep_profile_dropdown,
                agent_delegation_tier_deep_model_dropdown,
                agent_delegation_task_tier_deep_research_dropdown,
                agent_delegation_task_tier_anthology_dropdown,
                agent_delegation_task_tier_review_dropdown,
            ],
            outputs=[agent_delegation_status]
        )

        fetch_agent_delegation_exec_models_button.click(
            fn=ui_handlers.handle_fetch_internal_models,
            inputs=[agent_delegation_exec_provider_dropdown, agent_delegation_exec_profile_dropdown, agent_delegation_exec_model_dropdown],
            outputs=[agent_delegation_exec_model_dropdown],
            show_progress="hidden",
        )

        agent_delegation_exec_provider_dropdown.change(
            fn=ui_handlers.handle_delegation_exec_provider_change,
            inputs=[agent_delegation_exec_provider_dropdown, agent_delegation_exec_profile_dropdown, agent_delegation_exec_model_dropdown],
            outputs=[agent_delegation_exec_profile_dropdown, agent_delegation_exec_model_dropdown],
            show_progress="hidden",
            queue=False,
        )

        fetch_agent_delegation_tier_fast_models_button.click(
            fn=ui_handlers.handle_fetch_internal_models,
            inputs=[agent_delegation_tier_fast_provider_dropdown, agent_delegation_tier_fast_profile_dropdown, agent_delegation_tier_fast_model_dropdown],
            outputs=[agent_delegation_tier_fast_model_dropdown],
            show_progress="hidden",
        )

        agent_delegation_tier_fast_provider_dropdown.change(
            fn=ui_handlers.handle_delegation_exec_provider_change,
            inputs=[agent_delegation_tier_fast_provider_dropdown, agent_delegation_tier_fast_profile_dropdown, agent_delegation_tier_fast_model_dropdown],
            outputs=[agent_delegation_tier_fast_profile_dropdown, agent_delegation_tier_fast_model_dropdown],
            show_progress="hidden",
            queue=False,
        )

        fetch_agent_delegation_tier_balanced_models_button.click(
            fn=ui_handlers.handle_fetch_internal_models,
            inputs=[agent_delegation_tier_balanced_provider_dropdown, agent_delegation_tier_balanced_profile_dropdown, agent_delegation_tier_balanced_model_dropdown],
            outputs=[agent_delegation_tier_balanced_model_dropdown],
            show_progress="hidden",
        )

        agent_delegation_tier_balanced_provider_dropdown.change(
            fn=ui_handlers.handle_delegation_exec_provider_change,
            inputs=[agent_delegation_tier_balanced_provider_dropdown, agent_delegation_tier_balanced_profile_dropdown, agent_delegation_tier_balanced_model_dropdown],
            outputs=[agent_delegation_tier_balanced_profile_dropdown, agent_delegation_tier_balanced_model_dropdown],
            show_progress="hidden",
            queue=False,
        )

        fetch_agent_delegation_tier_deep_models_button.click(
            fn=ui_handlers.handle_fetch_internal_models,
            inputs=[agent_delegation_tier_deep_provider_dropdown, agent_delegation_tier_deep_profile_dropdown, agent_delegation_tier_deep_model_dropdown],
            outputs=[agent_delegation_tier_deep_model_dropdown],
            show_progress="hidden",
        )

        agent_delegation_tier_deep_provider_dropdown.change(
            fn=ui_handlers.handle_delegation_exec_provider_change,
            inputs=[agent_delegation_tier_deep_provider_dropdown, agent_delegation_tier_deep_profile_dropdown, agent_delegation_tier_deep_model_dropdown],
            outputs=[agent_delegation_tier_deep_profile_dropdown, agent_delegation_tier_deep_model_dropdown],
            show_progress="hidden",
            queue=False,
        )

        fetch_room_agent_delegation_exec_models_button.click(
            fn=ui_handlers.handle_fetch_internal_models,
            inputs=[room_agent_delegation_exec_provider_dropdown, room_agent_delegation_exec_profile_dropdown, room_agent_delegation_exec_model_dropdown],
            outputs=[room_agent_delegation_exec_model_dropdown],
            show_progress="hidden",
        )

        room_agent_delegation_exec_provider_dropdown.change(
            fn=ui_handlers.handle_delegation_exec_provider_change,
            inputs=[room_agent_delegation_exec_provider_dropdown, room_agent_delegation_exec_profile_dropdown, room_agent_delegation_exec_model_dropdown],
            outputs=[room_agent_delegation_exec_profile_dropdown, room_agent_delegation_exec_model_dropdown],
            show_progress="hidden",
            queue=False,
        )

        fetch_room_agent_delegation_review_models_button.click(
            fn=ui_handlers.handle_fetch_internal_models,
            inputs=[room_agent_delegation_review_provider_dropdown, room_agent_delegation_review_profile_dropdown, room_agent_delegation_review_model_dropdown],
            outputs=[room_agent_delegation_review_model_dropdown],
            show_progress="hidden",
        )

        room_agent_delegation_review_provider_dropdown.change(
            fn=ui_handlers.handle_delegation_exec_provider_change,
            inputs=[room_agent_delegation_review_provider_dropdown, room_agent_delegation_review_profile_dropdown, room_agent_delegation_review_model_dropdown],
            outputs=[room_agent_delegation_review_profile_dropdown, room_agent_delegation_review_model_dropdown],
            show_progress="hidden",
            queue=False,
        )

        save_room_agent_delegation_event = save_room_agent_delegation_settings_button.click(
            fn=ui_handlers.handle_save_room_agent_delegation_settings,
            inputs=[
                current_room_name,
                room_agent_delegation_enabled_checkbox,
                room_agent_delegation_permission_tier_dropdown,
                room_agent_delegation_allow_web_checkbox,
                room_agent_delegation_wake_on_completion_checkbox,
                room_agent_delegation_wake_respect_quiet_hours_checkbox,
                room_agent_delegation_exec_provider_dropdown,
                room_agent_delegation_exec_profile_dropdown,
                room_agent_delegation_exec_model_dropdown,
                room_agent_delegation_review_iterations_number,
                room_agent_delegation_review_provider_dropdown,
                room_agent_delegation_review_profile_dropdown,
                room_agent_delegation_review_model_dropdown,
            ],
            outputs=[room_agent_delegation_status],
            show_progress="hidden",
            queue=False
        )
        save_room_agent_delegation_event.then(
            fn=ui_handlers.load_atelier_delegation_readiness,
            inputs=[current_room_name],
            outputs=[atelier_delegation_readiness, prepare_atelier_delegation_button],
            show_progress="hidden",
            queue=False,
        )

        prepare_atelier_delegation_button.click(
            fn=ui_handlers.handle_prepare_atelier_delegation,
            inputs=[current_room_name],
            outputs=[
                atelier_delegation_readiness,
                room_agent_delegation_enabled_checkbox,
                room_agent_delegation_wake_on_completion_checkbox,
                room_agent_delegation_wake_respect_quiet_hours_checkbox,
                room_persona_workspace_permission_tier_dropdown,
                atelier_serve_enabled_checkbox,
                atelier_delegation_setup_status,
                prepare_atelier_delegation_button,
            ],
            show_progress="hidden",
            queue=False,
        )

        refresh_atelier_delegation_readiness_button.click(
            fn=ui_handlers.load_atelier_delegation_readiness,
            inputs=[current_room_name],
            outputs=[atelier_delegation_readiness, prepare_atelier_delegation_button],
            show_progress="hidden",
            queue=False,
        )

        save_room_persona_contract_button.click(
            fn=ui_handlers.handle_save_room_persona_contract,
            inputs=[
                current_room_name,
                room_persona_contract_enabled_checkbox,
                room_persona_contract_persona_name_input,
                room_persona_contract_user_name_input,
                room_persona_contract_preferred_address_input,
                room_persona_contract_forbidden_address_input,
                room_persona_contract_required_terms_input,
                room_persona_contract_forbidden_terms_input,
                room_persona_contract_tone_rules_input,
                room_persona_contract_forbidden_severity_dropdown,
                room_persona_contract_required_severity_dropdown,
                room_persona_contract_address_severity_dropdown,
            ],
            outputs=[room_persona_contract_status],
            show_progress="hidden",
            queue=False
        )

        save_room_persona_workspace_event = save_room_persona_workspace_settings_button.click(
            fn=ui_handlers.handle_save_room_persona_workspace_settings,
            inputs=[
                current_room_name,
                room_persona_workspace_enabled_state,
                room_persona_workspace_permission_tier_dropdown,
            ],
            outputs=[room_persona_workspace_status],
            show_progress="hidden",
            queue=False
        )
        save_room_persona_workspace_event.then(
            fn=ui_handlers.load_atelier_delegation_readiness,
            inputs=[current_room_name],
            outputs=[atelier_delegation_readiness, prepare_atelier_delegation_button],
            show_progress="hidden",
            queue=False,
        )

        refresh_agent_delegation_tasks_button.click(
            fn=ui_handlers.refresh_agent_delegation_task_view,
            inputs=None,
            outputs=[
                agent_delegation_tasks_df,
                agent_delegation_task_dropdown,
                agent_delegation_cost_summary,
                agent_delegation_task_log_textbox,
            ],
            show_progress="hidden",
            queue=False
        )

        resume_agent_delegation_task_button.click(
            fn=ui_handlers.handle_resume_agent_delegation_task,
            inputs=[agent_delegation_task_dropdown],
            outputs=[
                agent_delegation_tasks_df,
                agent_delegation_task_dropdown,
                agent_delegation_cost_summary,
                agent_delegation_task_log_textbox,
            ],
            show_progress="hidden",
            queue=False
        )

        delete_agent_delegation_task_button.click(
            fn=ui_handlers.handle_delete_agent_delegation_task,
            inputs=[agent_delegation_task_dropdown],
            outputs=[
                agent_delegation_tasks_df,
                agent_delegation_task_dropdown,
                agent_delegation_cost_summary,
                agent_delegation_task_log_textbox,
            ],
            show_progress="hidden",
            queue=False
        )

        clear_finished_agent_delegation_tasks_button.click(
            fn=ui_handlers.handle_clear_finished_agent_delegation_tasks,
            inputs=None,
            outputs=[
                agent_delegation_tasks_df,
                agent_delegation_task_dropdown,
                agent_delegation_cost_summary,
                agent_delegation_task_log_textbox,
            ],
            show_progress="hidden",
            queue=False
        )

        agent_delegation_tasks_df.select(
            fn=ui_handlers.handle_agent_delegation_task_row_select,
            inputs=[agent_delegation_tasks_df],
            outputs=[
                agent_delegation_task_dropdown,
                agent_delegation_task_log_textbox,
            ],
            show_progress="hidden",
            queue=False
        )

        agent_delegation_task_dropdown.change(
            fn=ui_handlers.load_agent_delegation_task_log,
            inputs=[agent_delegation_task_dropdown],
            outputs=[agent_delegation_task_log_textbox],
            show_progress="hidden",
            queue=False
        )

        steer_agent_delegation_task_button.click(
            fn=ui_handlers.handle_steer_agent_delegation_task,
            inputs=[agent_delegation_task_dropdown, agent_delegation_steer_textbox],
            outputs=[
                agent_delegation_tasks_df,
                agent_delegation_task_dropdown,
                agent_delegation_cost_summary,
                agent_delegation_task_log_textbox,
                agent_delegation_steer_textbox,
            ],
            show_progress="hidden",
            queue=False
        )

        share_research_result_button.click(
            fn=ui_handlers.handle_share_research_result_from_ui,
            inputs=[agent_delegation_task_dropdown],
            outputs=[
                agent_delegation_tasks_df,
                agent_delegation_task_dropdown,
                agent_delegation_cost_summary,
                agent_delegation_task_log_textbox,
            ],
            show_progress="hidden",
            queue=False
        )

        refresh_atelier_button.click(
            fn=ui_handlers.refresh_atelier_view,
            inputs=[current_room_name, atelier_view_state_radio],
            outputs=[
                atelier_works_df,
                atelier_work_dropdown,
                atelier_work_detail_textbox,
                atelier_status,
            ],
            show_progress="hidden",
            queue=False
        )

        atelier_view_state_radio.change(
            fn=ui_handlers.refresh_atelier_view,
            inputs=[current_room_name, atelier_view_state_radio],
            outputs=[
                atelier_works_df,
                atelier_work_dropdown,
                atelier_work_detail_textbox,
                atelier_status,
            ],
            show_progress="hidden",
            queue=False
        )

        atelier_works_df.select(
            fn=ui_handlers.handle_atelier_work_row_select,
            inputs=[current_room_name, atelier_works_df],
            outputs=[
                atelier_work_dropdown,
                atelier_work_detail_textbox,
            ],
            show_progress="hidden",
            queue=False
        )

        atelier_work_dropdown.change(
            fn=ui_handlers.load_atelier_work_detail,
            inputs=[current_room_name, atelier_work_dropdown],
            outputs=[atelier_work_detail_textbox],
            show_progress="hidden",
            queue=False
        )

        delete_archived_atelier_button.click(
            fn=ui_handlers.handle_delete_archived_atelier_work,
            inputs=[current_room_name, atelier_work_dropdown, atelier_view_state_radio],
            outputs=[
                atelier_works_df,
                atelier_work_dropdown,
                atelier_work_detail_textbox,
                atelier_status,
            ],
            show_progress="hidden",
            queue=False
        )

        refresh_atelier_assets_button.click(
            fn=ui_handlers.refresh_atelier_file_and_app_view,
            inputs=[current_room_name],
            outputs=[
                atelier_file_explorer,
                atelier_download_button,
                atelier_apps_df,
                atelier_app_dropdown,
                atelier_app_detail,
                atelier_app_qr_image,
                atelier_app_open_guide,
                atelier_asset_status,
            ],
            show_progress="hidden",
            queue=False
        )

        atelier_file_explorer.change(
            fn=ui_handlers.handle_atelier_file_select,
            inputs=[current_room_name, atelier_file_explorer],
            outputs=[atelier_download_button, atelier_asset_status],
            show_progress="hidden",
            queue=False
        )

        atelier_apps_df.select(
            fn=ui_handlers.handle_atelier_app_row_select,
            inputs=[current_room_name, atelier_apps_df],
            outputs=[atelier_app_dropdown, atelier_app_detail, atelier_app_qr_image, atelier_app_open_guide],
            show_progress="hidden",
            queue=False
        )

        atelier_app_dropdown.change(
            fn=ui_handlers.handle_atelier_app_dropdown_change,
            inputs=[current_room_name, atelier_app_dropdown],
            outputs=[atelier_app_detail, atelier_app_qr_image, atelier_app_open_guide],
            show_progress="hidden",
            queue=False
        )

        atelier_app_icon_save_button.click(
            fn=ui_handlers.handle_set_atelier_app_icon,
            inputs=[
                current_room_name,
                atelier_app_dropdown,
                atelier_app_icon_normal_upload,
                atelier_app_icon_maskable_upload,
            ],
            outputs=[
                atelier_app_icon_status,
                atelier_app_icon_normal_upload,
                atelier_app_icon_maskable_upload,
            ],
            show_progress="hidden",
            queue=False
        )

        refresh_atelier_app_pending_button.click(
            fn=ui_handlers.refresh_atelier_app_grants,
            inputs=[current_room_name],
            outputs=[
                atelier_app_pending_grants_df,
                atelier_app_active_grants_df,
                atelier_app_pending_selection_state,
                atelier_app_active_grant_selection_state,
                atelier_app_grants_status,
                atelier_app_grant_warning,
            ],
            show_progress="hidden",
            queue=False
        )

        refresh_atelier_app_active_button.click(
            fn=ui_handlers.refresh_atelier_app_grants,
            inputs=[current_room_name],
            outputs=[
                atelier_app_pending_grants_df,
                atelier_app_active_grants_df,
                atelier_app_pending_selection_state,
                atelier_app_active_grant_selection_state,
                atelier_app_grants_status,
                atelier_app_grant_warning,
            ],
            show_progress="hidden",
            queue=False
        )

        atelier_app_pending_grants_df.select(
            fn=ui_handlers.handle_atelier_app_pending_select,
            inputs=[current_room_name, atelier_app_pending_grants_df],
            outputs=[atelier_app_pending_selection_state, atelier_app_grants_status, atelier_app_grant_warning],
            show_progress="hidden",
            queue=False
        )

        atelier_app_active_grants_df.select(
            fn=ui_handlers.handle_atelier_app_active_grant_select,
            inputs=[atelier_app_active_grants_df],
            outputs=[atelier_app_active_grant_selection_state, atelier_app_grants_status, atelier_app_grant_warning],
            show_progress="hidden",
            queue=False
        )

        grant_atelier_app_scope_button.click(
            fn=ui_handlers.handle_grant_atelier_app_scope,
            inputs=[
                current_room_name,
                atelier_app_pending_selection_state,
                atelier_app_write_confirm_checkbox,
                atelier_app_outward_confirm_checkbox,
            ],
            outputs=[
                atelier_app_pending_grants_df,
                atelier_app_active_grants_df,
                atelier_app_pending_selection_state,
                atelier_app_grants_status,
                atelier_app_grant_warning,
            ],
            show_progress="hidden",
            queue=False
        )

        deny_atelier_app_scope_button.click(
            fn=ui_handlers.handle_deny_atelier_app_scope,
            inputs=[current_room_name, atelier_app_pending_selection_state],
            outputs=[
                atelier_app_pending_grants_df,
                atelier_app_active_grants_df,
                atelier_app_pending_selection_state,
                atelier_app_grants_status,
                atelier_app_grant_warning,
            ],
            show_progress="hidden",
            queue=False
        )

        revoke_atelier_app_scope_button.click(
            fn=ui_handlers.handle_revoke_atelier_app_scope,
            inputs=[current_room_name, atelier_app_active_grant_selection_state],
            outputs=[
                atelier_app_pending_grants_df,
                atelier_app_active_grants_df,
                atelier_app_active_grant_selection_state,
                atelier_app_grants_status,
                atelier_app_grant_warning,
            ],
            show_progress="hidden",
            queue=False
        )

        atelier_serve_save_event = atelier_serve_save_button.click(
            fn=ui_handlers.handle_save_atelier_serve_settings,
            inputs=[
                atelier_serve_enabled_checkbox,
                atelier_serve_host_input,
                atelier_serve_port_input,
                atelier_serve_https_port_input,
                atelier_serve_auto_tailscale_checkbox,
                atelier_api_enabled_checkbox,
                current_room_name,
                atelier_app_dropdown,
            ],
            outputs=[atelier_asset_status, atelier_serve_connection_help],
            show_progress="hidden",
            queue=False
        )
        atelier_serve_save_event.then(
            fn=ui_handlers.load_atelier_delegation_readiness,
            inputs=[current_room_name],
            outputs=[atelier_delegation_readiness, prepare_atelier_delegation_button],
            show_progress="hidden",
            queue=False,
        )

        enable_atelier_serve_for_apps_button.click(
            fn=ui_handlers.handle_enable_atelier_serve_for_apps,
            inputs=[current_room_name, atelier_app_dropdown],
            outputs=[
                atelier_serve_enabled_checkbox,
                atelier_asset_status,
                atelier_serve_connection_help,
                atelier_app_open_guide,
                atelier_delegation_readiness,
                prepare_atelier_delegation_button,
            ],
            show_progress="hidden",
            queue=False,
        )

        atelier_serve_tailscale_button.click(
            fn=ui_handlers.handle_configure_tailscale_atelier_https,
            inputs=[current_room_name, atelier_app_dropdown],
            outputs=[atelier_serve_connection_help, atelier_asset_status],
            show_progress="hidden",
            queue=False
        )

        save_common_local_config_button.click(
            fn=ui_handlers.handle_save_common_local_config,
            inputs=[common_local_model_path_input, common_local_n_ctx_input],
            outputs=None
        )

        # 外部接続UIは退避中のため、Disclaimer/Twitterイベントは登録しない。

        # --- [Phase 3] 内部処理モデル設定ボタンのイベント ---


        # --- 内部処理モデル連動イベント ---
        for cat_comp, prof_comp, model_comp in [
            (internal_processing_category, internal_processing_profile, internal_processing_model),
            (internal_summarization_category, internal_summarization_profile, internal_summarization_model),
            (internal_translation_category, internal_translation_profile, internal_translation_model)
        ]:
            cat_comp.change(
                fn=ui_handlers.handle_internal_category_change,
                inputs=[cat_comp, prof_comp, model_comp],
                outputs=[prof_comp, model_comp]
            )
            prof_comp.change(
                fn=ui_handlers.handle_internal_profile_change,
                inputs=[prof_comp, model_comp],
                outputs=[model_comp]
            )

        # --- エンベディングプロバイダ連動 ---
        internal_embedding_provider.input(
            fn=ui_handlers.handle_internal_embedding_provider_change,
            inputs=[internal_embedding_provider],
            outputs=[internal_embedding_model]
        )

        # --- 内部処理モデル 取得ボタン連動 ---
        fetch_processing_models_btn.click(
            fn=ui_handlers.handle_fetch_internal_models,
            inputs=[internal_processing_category, internal_processing_profile, internal_processing_model],
            outputs=[internal_processing_model]
        )
        fetch_summarization_models_btn.click(
            fn=ui_handlers.handle_fetch_internal_models,
            inputs=[internal_summarization_category, internal_summarization_profile, internal_summarization_model],
            outputs=[internal_summarization_model]
        )
        fetch_translation_models_btn.click(
            fn=ui_handlers.handle_fetch_internal_models,
            inputs=[internal_translation_category, internal_translation_profile, internal_translation_model],
            outputs=[internal_translation_model]
        )

        save_internal_model_button.click(
            fn=ui_handlers.handle_save_internal_model_settings,
            inputs=[
                internal_processing_category, internal_processing_profile, internal_processing_model,
                internal_summarization_category, internal_summarization_profile, internal_summarization_model,
                internal_translation_category, internal_translation_profile, internal_translation_model,
                internal_embedding_provider, internal_embedding_model,
                internal_fallback_checkbox
            ],
            outputs=[internal_model_status]
        )

        reset_internal_model_button.click(
            fn=ui_handlers.handle_reset_internal_model_settings,
            inputs=None,
            outputs=[
                internal_processing_category, internal_processing_profile, internal_processing_model,
                internal_summarization_category, internal_summarization_profile, internal_summarization_model,
                internal_translation_category, internal_translation_profile, internal_translation_model,
                internal_embedding_provider, internal_embedding_model,
                internal_fallback_checkbox,
                internal_model_status
            ]
        )

        # --- アップデート・再起動関連のイベント ---
        # 再起動を旧タブ側で検知し、同一タブでリロードするポーリング。
        # サーバーが一度落ちてから復帰したことを条件にするため、
        # 更新ダウンロード中（サーバー稼働中）には誤発火しない。15分でタイムアウト。
        _restart_watch_js_body = """
            if (!window.__nexusRestartWatch) {
                window.__nexusRestartWatch = true;
                const started = Date.now();
                let wasDown = false;
                const timer = setInterval(async () => {
                    if (Date.now() - started > 15 * 60 * 1000) {
                        clearInterval(timer);
                        window.__nexusRestartWatch = false;
                        return;
                    }
                    try {
                        const res = await fetch(window.location.origin + "/?__nexus_ping=" + Date.now(), { cache: "no-store" });
                        if (res.ok) {
                            if (wasDown) {
                                clearInterval(timer);
                                window.location.reload();
                            }
                        } else if (res.status >= 500) {
                            wasDown = true;
                        }
                    } catch (e) {
                        wasDown = true;
                    }
                }, 3000);
            }
        """
        update_check_button.click(
            fn=ui_handlers.handle_check_update,
            outputs=[update_status_markdown, update_download_group, update_apply_button]
        ).then(
            fn=ui_handlers.handle_app_update_host_check,
            inputs=None, outputs=app_update_host_outputs,
            show_progress="hidden", api_visibility="private",
        ).then(
            fn=ui_handlers.handle_lite_update_check,
            inputs=[current_room_name], outputs=app_lite_update_outputs,
            show_progress="hidden", api_visibility="private",
            concurrency_id="lite-update-check", concurrency_limit=1,
        )
        app_update_host_migration_button.click(
            fn=None, inputs=None, outputs=[app_update_host_confirmed],
            js="""() => {
                return confirm('本体を新しい更新方式へ移行しますか？\\n現在の本体は変更せず、通常終了後に起動用ファイルを切り替えます。\\n完了を待ち、同じStart.batから起動し直してください。') ? 'true' : '';
            }""",
            queue=False, api_visibility="private",
        )
        app_update_host_confirmed.change(
            fn=ui_handlers.handle_app_update_host_migration,
            inputs=[app_update_host_confirmed], outputs=app_update_host_outputs,
            trigger_mode="once", concurrency_limit=1,
            concurrency_id="app-update-mutation", api_visibility="private",
        )
        update_apply_button.click(
            fn=ui_handlers.handle_apply_update,
            outputs=[update_status_markdown],
            js="() => {" + _restart_watch_js_body + "}",
            trigger_mode="once", concurrency_limit=1,
            concurrency_id="app-update-mutation",
        )
        lite_runtime_repair_apply_button.click(
            fn=ui_handlers.handle_lite_runtime_repair_apply,
            outputs=[lite_runtime_repair_result],
            js="() => {" + _restart_watch_js_body + "}",
            trigger_mode="once",
            concurrency_limit=1,
            concurrency_id="app-update-mutation",
        )
        # 手動再起動: confirmの結果を隠しTextboxへ渡し、changeでハンドラを起動する
        # （確認キャンセルでfnが走らないようにするための既存パターン）。
        restart_app_button.click(
            fn=None,
            inputs=None,
            outputs=[restart_confirmed_state],
            js="""() => {
                if (!confirm('Nexus Arkを再起動しますか？\\n再起動後、このタブが自動でリロードされます。')) return '';
            """ + _restart_watch_js_body + """
                return 'true';
            }"""
        )
        restart_confirmed_state.change(
            fn=ui_handlers.handle_restart_app,
            inputs=[restart_confirmed_state],
            outputs=[update_status_markdown, restart_confirmed_state],
            trigger_mode="once", concurrency_limit=1,
            concurrency_id="app-update-mutation",
        )

        app_lite_update_button.click(
            fn=None, inputs=[app_lite_update_confirmation],
            outputs=[app_lite_update_confirmed],
            js="""(value) => {
                let proposal;
                try { proposal = JSON.parse(value); } catch { return ''; }
                return proposal.text && proposal.operation_id && confirm(proposal.text)
                    ? proposal.operation_id : '';
            }""",
            queue=False, api_visibility="private",
        )
        app_lite_update_confirmed.change(
            fn=ui_handlers.handle_lite_update_run,
            inputs=[app_lite_update_offer, app_lite_update_confirmed, current_room_name],
            outputs=app_lite_update_outputs,
            trigger_mode="once", concurrency_limit=1,
            concurrency_id="app-update-mutation", api_visibility="private",
        )
        app_lite_auth_recovery_button.click(
            fn=None, inputs=[app_lite_auth_recovery_confirmation],
            outputs=[app_lite_auth_recovery_confirmed],
            js="""(value) => {
                let proposal;
                try { proposal = JSON.parse(value); } catch { return ''; }
                return proposal.text && proposal.operation_id && confirm(proposal.text)
                    ? proposal.operation_id : '';
            }""",
            queue=False, api_visibility="private",
        )
        app_lite_auth_recovery_confirmed.change(
            fn=ui_handlers.handle_lite_update_auth_recovery,
            inputs=[app_lite_update_offer, app_lite_auth_recovery_confirmed, current_room_name],
            outputs=app_lite_update_outputs,
            trigger_mode="once", concurrency_limit=1,
            concurrency_id="app-update-mutation", api_visibility="private",
        )

        # --- 画像生成マルチプロバイダ設定のイベント ---
        image_gen_provider_radio.change(
            fn=ui_handlers.handle_image_gen_provider_change,
            inputs=[image_gen_provider_radio],
            outputs=[gemini_model_section, openai_image_section, pollinations_image_section, huggingface_image_section, image_gen_api_key_dropdown],
            show_progress="hidden"
        )

        save_image_gen_button.click(
            fn=ui_handlers.handle_save_image_generation_settings,
            inputs=[image_gen_provider_radio, image_gen_api_key_dropdown, gemini_image_model_dropdown, openai_image_profile_dropdown, openai_image_model_dropdown, pollinations_api_key_input, pollinations_image_model_dropdown, huggingface_api_token_input, huggingface_image_model_dropdown],
            outputs=None
        )

        fetch_image_models_button.click(
            fn=ui_handlers.handle_fetch_image_models,
            inputs=[image_gen_provider_radio, openai_image_profile_dropdown],
            outputs=[gemini_image_model_dropdown, openai_image_model_dropdown, pollinations_image_model_dropdown, huggingface_image_model_dropdown, user_gen_image_model]
        )

        # --- Geminiモデルリスト管理ボタンのイベント ---
        fetch_gemini_models_button.click(
            fn=ui_handlers.handle_fetch_gemini_models,
            inputs=[api_key_dropdown, model_dropdown],
            outputs=[model_dropdown]
        )

        # --- OpenAI互換モデルリスト管理ボタンのイベント ---
        fetch_models_button.click(
            fn=ui_handlers.handle_fetch_models,
            inputs=[openai_profile_dropdown, openai_base_url_input, openai_api_key_input, openai_free_only_checkbox],
            outputs=[openai_model_dropdown]
        )

        toggle_favorite_button.click(
            fn=ui_handlers.handle_toggle_favorite,
            inputs=[openai_profile_dropdown, openai_model_dropdown],
            outputs=[openai_model_dropdown]
        )

        # --- 個別設定のモデルリスト管理ボタンのイベント ---
        # Gemini個別設定
        room_fetch_gemini_models_button.click(
            fn=ui_handlers.handle_fetch_room_gemini_models,
            inputs=[room_api_key_dropdown, room_model_dropdown, room_dropdown],
            outputs=[room_model_dropdown]
        )

        # OpenAI互換個別設定
        room_fetch_models_button.click(
            fn=ui_handlers.handle_fetch_models,
            inputs=[room_openai_profile_dropdown, room_openai_base_url_input, room_openai_api_key_input, room_openai_free_only_checkbox],
            outputs=[room_openai_model_dropdown]
        )

        room_toggle_favorite_button.click(
            fn=ui_handlers.handle_toggle_favorite,
            inputs=[room_openai_profile_dropdown, room_openai_model_dropdown],
            outputs=[room_openai_model_dropdown]
        )

        # --- 「💼 お出かけ」専用タブのイベント接続 ---

        lite_travel_overview_outputs = [
            lite_travel_refresh_status,
            lite_travel_refresh_feedback,
            lite_travel_status,
            lite_travel_connectivity_card,
            lite_travel_progress,
            lite_travel_connection_group,
            lite_travel_standby_group,
            lite_travel_departure_group,
            lite_travel_return_group,
            lite_travel_build_snapshot,
            lite_travel_start_button,
            lite_travel_return_preview_button,
            lite_travel_online_return_button,
            lite_travel_departure_summary,
            lite_travel_snapshot_json,
            lite_travel_return_preview,
            lite_travel_snapshot_state,
        ]
        lite_open_daily_event.then(
            fn=ui_handlers.handle_lite_travel_overview_refresh,
            inputs=[lite_travel_focus_persona],
            outputs=lite_travel_overview_outputs,
        )
        lite_entry_event.then(
            fn=ui_handlers.handle_lite_entry_refresh,
            inputs=[lite_travel_focus_persona],
            outputs=lite_travel_overview_outputs,
        )
        for event in lite_shortcut_events:
            event.then(
                fn=ui_handlers.handle_lite_travel_overview_refresh,
                inputs=[lite_travel_focus_persona],
                outputs=lite_travel_overview_outputs,
            )
        lite_travel_refresh_status.click(
            fn=ui_handlers.handle_lite_travel_overview_refresh,
            inputs=[lite_travel_focus_persona],
            outputs=lite_travel_overview_outputs,
        )
        for component in (
            lite_travel_personas, lite_travel_parallel_personas, lite_travel_snapshot_preset,
            lite_travel_include_core_memory, lite_travel_include_episodic_memory,
            lite_travel_episodic_memory_days, lite_travel_recent_message_limit,
            lite_daily_credential_profile_id, lite_daily_model_id,
        ):
            component.change(
                fn=ui_handlers.handle_lite_travel_selection_changed,
                outputs=[
                    lite_travel_snapshot_state, lite_travel_standby_snapshot_state,
                    lite_travel_start_button, lite_travel_confirm_standby,
                    lite_travel_departure_summary, lite_travel_standby_preview,
                ],
                queue=False,
                show_progress="hidden",
            )
        lite_daily_credential_profile_id.input(
            fn=ui_handlers.handle_lite_ai_connection_change,
            inputs=[lite_daily_credential_profile_id, lite_daily_model_id],
            outputs=[lite_daily_model_id, lite_daily_ai_status],
            queue=False,
            show_progress="hidden",
        )
        lite_daily_ai_save.click(
            fn=ui_handlers.handle_save_lite_daily_ai_route,
            inputs=[lite_daily_credential_profile_id, lite_daily_model_id],
            outputs=[
                lite_daily_ai_status,
                lite_travel_credential_profile_id,
                lite_travel_model_id,
                lite_travel_settings_status,
            ],
        )
        lite_travel_snapshot_preset.change(
            fn=ui_handlers.handle_lite_snapshot_preset_change,
            inputs=[
                lite_travel_snapshot_preset,
                lite_travel_include_core_memory,
                lite_travel_include_episodic_memory,
                lite_travel_episodic_memory_days,
                lite_travel_recent_message_limit,
            ],
            outputs=[
                lite_travel_include_core_memory,
                lite_travel_include_episodic_memory,
                lite_travel_episodic_memory_days,
                lite_travel_recent_message_limit,
                lite_travel_snapshot_preset_status,
            ],
            queue=False,
            show_progress="hidden",
        )
        lite_travel_include_episodic_memory.change(
            fn=ui_handlers.handle_lite_snapshot_episodic_toggle,
            inputs=[lite_travel_include_episodic_memory, lite_travel_snapshot_preset],
            outputs=[lite_travel_episodic_memory_days],
            queue=False,
            show_progress="hidden",
        )
        for button in (lite_travel_open_worker_settings, lite_management_shortcut):
            button.click(
                fn=ui_handlers.handle_outing_show_lite,
                outputs=outing_mode_outputs,
                queue=False,
                show_progress="hidden",
                js=_outing_mode_visibility_js("setup"),
            ).then(
                fn=ui_handlers.handle_lite_open_connection_management,
                outputs=[lite_connected_setup_accordion, lite_independent_setup_accordion, lite_independent_connectivity_accordion],
                queue=False,
                show_progress="hidden",
                js="() => { setTimeout(() => document.getElementById('lite_independent_connectivity_flow')?.scrollIntoView({behavior: 'smooth', block: 'start'}), 150); return []; }",
            )
        lite_travel_pair_button.click(
            fn=ui_handlers.handle_lite_travel_pairing_code,
            inputs=[lite_pairing_code_ttl_minutes],
            outputs=[lite_travel_pairing_result],
        )
        lite_travel_build_snapshot.click(
            fn=ui_handlers.handle_lite_travel_build_multi_snapshot,
            inputs=[
                lite_travel_personas,
                lite_travel_parallel_personas,
                lite_travel_focus_persona,
                lite_travel_include_core_memory,
                lite_travel_include_episodic_memory,
                lite_travel_episodic_memory_days,
                lite_travel_recent_message_limit,
            ],
            outputs=[
                lite_travel_departure_summary,
                lite_travel_snapshot_json,
                lite_travel_snapshot_state,
                lite_travel_operation_result,
                lite_travel_build_snapshot,
                lite_travel_start_button,
                lite_travel_progress,
            ],
        )
        lite_travel_prepare_event = lite_travel_prepare_standby.click(
            fn=ui_handlers.handle_lite_travel_preview_standby,
            inputs=[
                lite_travel_personas,
                lite_travel_parallel_personas,
                lite_travel_include_core_memory,
                lite_travel_include_episodic_memory,
                lite_travel_episodic_memory_days,
                lite_travel_recent_message_limit,
            ],
            outputs=[
                lite_travel_standby_preview,
                lite_travel_standby_snapshot_json,
                lite_travel_standby_snapshot_state,
                lite_travel_confirm_standby,
            ],
        )
        lite_travel_confirm_standby_event = lite_travel_confirm_standby.click(
            fn=ui_handlers.handle_lite_travel_confirm_standby,
            inputs=[lite_travel_standby_snapshot_state],
            outputs=[
                lite_travel_standby_status,
                lite_travel_standby_snapshot_state,
                lite_travel_confirm_standby,
            ],
        )
        lite_travel_confirm_standby_event.then(
            fn=ui_handlers.handle_lite_travel_after_operation,
            inputs=[lite_travel_focus_persona, lite_travel_standby_status],
            outputs=lite_travel_overview_outputs,
        )
        lite_travel_start_event = lite_travel_start_button.click(
            fn=ui_handlers.handle_lite_travel_start_for_ui,
            inputs=[lite_travel_snapshot_state, lite_travel_focus_persona],
            outputs=[lite_travel_operation_result, lite_travel_snapshot_state, lite_travel_focus_persona],
        )
        lite_travel_start_event.then(
            fn=ui_handlers.handle_lite_travel_after_operation,
            inputs=[lite_travel_focus_persona, lite_travel_operation_result],
            outputs=lite_travel_overview_outputs,
        )
        lite_travel_export_button.click(
            fn=ui_handlers.handle_lite_travel_export_bundle,
            inputs=[lite_travel_focus_persona],
            outputs=[lite_travel_bundle_file, lite_travel_operation_result],
        )
        lite_travel_online_return_event = lite_travel_online_return_button.click(
            fn=ui_handlers.handle_lite_travel_online_return,
            inputs=[lite_travel_focus_persona],
            outputs=[lite_travel_operation_result, lite_travel_route_proposals],
        )
        lite_travel_online_return_event.then(
            fn=ui_handlers.handle_lite_travel_after_operation,
            inputs=[lite_travel_focus_persona, lite_travel_operation_result],
            outputs=lite_travel_overview_outputs,
        )
        lite_travel_return_preview_button.click(
            fn=ui_handlers.handle_lite_travel_return_preview_ui,
            inputs=[lite_travel_focus_persona],
            outputs=[
                lite_travel_return_preview,
                lite_travel_return_preview_button,
                lite_travel_online_return_button,
                lite_travel_progress,
            ],
        )
        lite_travel_focus_persona.change(
            fn=ui_handlers.handle_lite_travel_room_change,
            inputs=[lite_travel_focus_persona],
            outputs=[
                lite_travel_departure_summary,
                lite_travel_snapshot_json,
                lite_travel_snapshot_state,
                lite_travel_standby_preview,
                lite_travel_standby_snapshot_json,
                lite_travel_standby_snapshot_state,
                lite_travel_confirm_standby,
                lite_travel_return_preview,
                lite_travel_start_button,
                lite_travel_online_return_button,
                lite_travel_status,
            ],
            queue=False,
            show_progress="hidden",
        ).then(
            fn=ui_handlers.handle_lite_travel_room_stage_change,
            inputs=[lite_travel_focus_persona],
            outputs=[lite_travel_progress, lite_travel_connection_group, lite_travel_standby_group, lite_travel_departure_group, lite_travel_return_group],
            queue=False,
            show_progress="hidden",
        )
        lite_travel_apply_routes.click(
            fn=ui_handlers.handle_lite_travel_apply_route_proposals,
            inputs=[lite_travel_route_proposals],
            outputs=[lite_travel_route_apply_status],
        )
        lite_travel_import_button.click(
            fn=ui_handlers.handle_lite_travel_import_bundle,
            inputs=[lite_travel_bundle_file, lite_travel_focus_persona],
            outputs=[lite_travel_status],
        )
        lite_travel_delete_content.click(
            fn=ui_handlers.handle_lite_travel_delete_remote_content,
            inputs=[lite_travel_focus_persona],
            outputs=[lite_travel_status],
        )
        lite_travel_emergency_button.click(
            fn=ui_handlers.handle_lite_travel_emergency_reclaim,
            inputs=[lite_travel_focus_persona, lite_travel_emergency_reason],
            outputs=[lite_travel_status],
        )

        # データ読み込み
        outing_load_button.click(
            fn=ui_handlers.handle_outing_load_all_sections,
            inputs=[
                current_room_name, outing_episode_days_slider,
                outing_log_mode, outing_log_count_slider,
                outing_auto_summary_checkbox, outing_log_summary_threshold,
                outing_logs_include_timestamp, outing_logs_include_model
            ],
            outputs=[
                outing_system_prompt_text, outing_system_prompt_chars,
                outing_permanent_text, outing_permanent_chars,
                outing_diary_text, outing_diary_chars,
                outing_episodic_text, outing_episodic_chars,
                outing_logs_text, outing_logs_chars,
                outing_preview_text,
                outing_total_char_count
            ]
        )

        # セクション別圧縮
        outing_system_prompt_compress.click(
            fn=lambda text, room: ui_handlers.handle_outing_compress_section(text, "システムプロンプト", room),
            inputs=[outing_system_prompt_text, current_room_name],
            outputs=[outing_system_prompt_text, outing_system_prompt_chars]
        )
        outing_permanent_compress.click(
            fn=lambda text, room: ui_handlers.handle_outing_compress_section(text, "永続記憶", room),
            inputs=[outing_permanent_text, current_room_name],
            outputs=[outing_permanent_text, outing_permanent_chars]
        )
        outing_diary_compress.click(
            fn=lambda text, room: ui_handlers.handle_outing_compress_section(text, "日記要約", room),
            inputs=[outing_diary_text, current_room_name],
            outputs=[outing_diary_text, outing_diary_chars]
        )
        outing_episodic_compress.click(
            fn=lambda text, room: ui_handlers.handle_outing_compress_section(text, "エピソード記憶", room),
            inputs=[outing_episodic_text, current_room_name],
            outputs=[outing_episodic_text, outing_episodic_chars]
        )
        outing_logs_compress.click(
            fn=lambda text, room: ui_handlers.handle_outing_compress_section(text, "会話ログ", room),
            inputs=[outing_logs_text, current_room_name],
            outputs=[outing_logs_text, outing_logs_chars]
        )

        # 文面コピー
        outing_copy_button.click(
            fn=None, inputs=[outing_preview_text], outputs=None,
            js="(text) => { navigator.clipboard.writeText(text); const toast = document.createElement('gradio-toast'); toast.setAttribute('description', '文面をコピーしました！'); document.querySelector('.gradio-toast-container-x-center').appendChild(toast); }"
        )

        # エクスポート
        outing_export_button.click(
            fn=ui_handlers.handle_outing_export_from_preview,
            inputs=[
                outing_preview_text,
                current_room_name
            ],
            outputs=[outing_download_file]
        )

        # フォルダを開く
        outing_open_folder_button.click(
            fn=ui_handlers.handle_open_outing_folder,
            inputs=[current_room_name],
            outputs=None
        )

        # 帰宅（インポート）- ステップ1: 読み込みとプレビュー
        outing_import_load_button.click(
            fn=ui_handlers.handle_outing_import_preview,
            inputs=[
                outing_import_file, outing_import_source,
                outing_import_user_header, outing_import_agent_header,
                outing_import_include_marker
            ],
            outputs=[outing_import_preview_text, outing_import_execute_button, outing_import_status]
        )

        # 帰宅（インポート）- ステップ2: 最終統合
        outing_import_execute_button.click(
            fn=ui_handlers.handle_outing_import_finalize,
            inputs=[
                outing_import_preview_text, current_room_name,
                outing_import_source, outing_import_include_marker,
                api_history_limit_state, room_add_timestamp_checkbox,
                room_display_thoughts_checkbox, screenshot_mode_checkbox, redaction_rules_state
            ],
            outputs=[chatbot_display, current_log_map_state, outing_import_status, outing_import_file, outing_import_preview_text, outing_import_execute_button]
        )

        # Gemini URLインポート - ステップ1: 読み込みとプレビュー
        gemini_import_load_button.click(
            fn=ui_handlers.handle_gemini_import_preview,
            inputs=[
                gemini_import_url, current_room_name,
                gemini_import_include_marker
            ],
            outputs=[outing_import_preview_text, outing_import_execute_button, gemini_import_status]
        )

        # プレビューと合計文字数のリアルタイム更新
        outing_update_inputs = [
            outing_system_prompt_text, outing_system_prompt_enabled,
            outing_permanent_text, outing_permanent_enabled,
            outing_diary_text, outing_diary_enabled,
            outing_episodic_text, outing_episodic_enabled,
            outing_logs_text, outing_logs_enabled,
            outing_logs_wrap_tags
        ]

        def update_outing_preview_and_chars(*args):
            # args[-1] は outing_logs_wrap_tags
            preview = ui_handlers.handle_outing_update_preview(*args)
            total_msg = ui_handlers.handle_outing_update_total_chars(*args[:-1])
            return preview, total_msg

        # 各入力の変更時にプレビューと合計文字数を更新
        for comp in outing_update_inputs:
            comp.change(
                fn=update_outing_preview_and_chars,
                inputs=outing_update_inputs,
                outputs=[outing_preview_text, outing_total_char_count]
            )

        # スライダー変更時にセクションを再読み込み
        outing_episode_days_slider.change(
            fn=ui_handlers.handle_outing_reload_episodic,
            inputs=[current_room_name, outing_episode_days_slider],
            outputs=[outing_episodic_text, outing_episodic_chars]
        )
        # 会話ログの構成モードによる表示切り替え
        def update_outing_log_visibility(mode):
            if mode == "最新N件":
                return gr.update(visible=True), gr.update(visible=False)
            else:
                return gr.update(visible=False), gr.update(visible=True)

        outing_log_mode.change(
            fn=update_outing_log_visibility,
            inputs=[outing_log_mode],
            outputs=[outing_log_count_slider, outing_log_today_options]
        )

        # 構成モードや閾値の変更時に再読み込み
        for comp in [outing_log_mode, outing_log_count_slider, outing_auto_summary_checkbox, outing_log_summary_threshold]:
            comp.change(
                fn=ui_handlers.handle_outing_reload_logs,
                inputs=[
                    current_room_name, outing_log_mode, outing_log_count_slider,
                    outing_auto_summary_checkbox, outing_log_summary_threshold,
                    outing_logs_include_timestamp, outing_logs_include_model
                ],
                outputs=[outing_logs_text, outing_logs_chars]
            )

        # ログ表示オプション変更時に再読み込み
        for opt in [outing_logs_include_timestamp, outing_logs_include_model]:
            opt.change(
                fn=ui_handlers.handle_outing_reload_logs,
                inputs=[
                    current_room_name, outing_log_mode, outing_log_count_slider,
                    outing_auto_summary_checkbox, outing_log_summary_threshold,
                    outing_logs_include_timestamp, outing_logs_include_model
                ],
                outputs=[outing_logs_text, outing_logs_chars]
            )

        # セクション別リセット（🔄）
        outing_system_prompt_reload.click(
            fn=ui_handlers.handle_outing_reload_system_prompt,
            inputs=[current_room_name],
            outputs=[outing_system_prompt_text, outing_system_prompt_chars]
        )

        # 永続記憶と日記要約は同じ core_memory.txt から読み込むため、同じ関数を呼び出してそれぞれの出力を更新
        outing_permanent_reload.click(
            fn=lambda room: ui_handlers.handle_outing_reload_core_memory(room)[:2],
            inputs=[current_room_name],
            outputs=[outing_permanent_text, outing_permanent_chars]
        )
        outing_diary_reload.click(
            fn=lambda room: ui_handlers.handle_outing_reload_core_memory(room)[2:],
            inputs=[current_room_name],
            outputs=[outing_diary_text, outing_diary_chars]
        )

        outing_episodic_reload.click(
            fn=ui_handlers.handle_outing_reload_episodic,
            inputs=[current_room_name, outing_episode_days_slider],
            outputs=[outing_episodic_text, outing_episodic_chars]
        )
        outing_logs_reload.click(
            fn=ui_handlers.handle_outing_reload_logs,
            inputs=[
                current_room_name, outing_log_mode, outing_log_count_slider,
                outing_auto_summary_checkbox, outing_log_summary_threshold,
                outing_logs_include_timestamp, outing_logs_include_model
            ],
            outputs=[outing_logs_text, outing_logs_chars]
        )

        # --- [Phase 2] 内的状態ダッシュボードの更新イベント ---
        refresh_internal_state_button.click(
            fn=ui_handlers.handle_refresh_internal_state,
            inputs=[current_room_name],
            outputs=[
                boredom_level_display, curiosity_level_display,
                goal_achievement_level_display, devotion_level_display,
                dominant_drive_display, open_questions_display,
                internal_state_last_update,
                user_emotion_history_plot
            ]
        )

        # 感情の設定は明示保存のみ。初期同期や選択の変更では保存しない。
        emotion_panel["refresh"].click(
            fn=ui_handlers.handle_load_emotion_panel,
            inputs=[room_dropdown], outputs=emotion_panel_outputs,
            show_progress="hidden", api_visibility="private",
            concurrency_id="emotion_panel", concurrency_limit=1,
        )
        room_dropdown.change(
            fn=ui_handlers.handle_load_emotion_panel,
            inputs=[room_dropdown], outputs=emotion_panel_outputs,
            show_progress="hidden", api_visibility="private",
            concurrency_id="emotion_panel", concurrency_limit=1,
        )
        emotion_panel["selector"].input(
            fn=ui_handlers.handle_select_emotion_definition,
            inputs=[room_dropdown, emotion_panel["selector"], emotion_panel["session"]],
            outputs=emotion_panel_outputs,
            show_progress="hidden", api_visibility="private",
            concurrency_id="emotion_panel", concurrency_limit=1,
        )
        emotion_panel["save"].click(
            fn=ui_handlers.handle_save_emotion_definition,
            inputs=[
                room_dropdown, emotion_panel["selector"], emotion_panel["name"],
                emotion_panel["description"], emotion_panel["enabled"],
                emotion_panel["half_life"], emotion_panel["max_age"], emotion_panel["session"],
            ],
            outputs=emotion_panel_outputs,
            show_progress="hidden", api_visibility="private",
            concurrency_id="emotion_panel", concurrency_limit=1,
        )

        # Room Provider Events [Phase 3]
        # （room_provider_radio.change は上で一本化済み。旧・重複配線は二重発火防止のため削除）

        # --- 外部接続 / Discord・LINE ---
        discord_bot_load_button.click(
            fn=ui_handlers.handle_load_discord_bot_settings,
            inputs=[current_room_name],
            outputs=[
                discord_bot_enabled_checkbox,
                discord_bot_token_input,
                discord_bot_auth_ids_input,
                discord_bot_allowed_channels_input,
                discord_bot_default_channel_input,
                discord_bot_mention_only_checkbox,
                discord_bot_channel_modes_input,
                discord_bot_allow_autonomous_send_checkbox,
                discord_bot_persona_webhook_input,
                discord_bot_approval_ids_input,
                discord_bot_voice_input_enabled_checkbox,
                discord_bot_voice_confirm_checkbox,
                discord_bot_voice_timeout_input,
                discord_bot_voice_stt_model_input,
                discord_bot_status,
            ]
        )
        discord_bot_save_button.click(
            fn=ui_handlers.handle_save_discord_bot_settings,
            inputs=[
                current_room_name,
                discord_bot_enabled_checkbox,
                discord_bot_token_input,
                discord_bot_auth_ids_input,
                discord_bot_allowed_channels_input,
                discord_bot_default_channel_input,
                discord_bot_mention_only_checkbox,
                discord_bot_channel_modes_input,
                discord_bot_allow_autonomous_send_checkbox,
                discord_bot_persona_webhook_input,
                discord_bot_approval_ids_input,
                discord_bot_voice_input_enabled_checkbox,
                discord_bot_voice_confirm_checkbox,
                discord_bot_voice_timeout_input,
                discord_bot_voice_stt_model_input,
            ],
            outputs=[discord_bot_status]
        )
        discord_bot_stop_button.click(
            fn=ui_handlers.handle_stop_discord_bot,
            inputs=[current_room_name],
            outputs=[discord_bot_status]
        )
        line_bot_save_button.click(
            fn=ui_handlers.handle_save_line_bot_settings,
            inputs=[
                line_bot_enabled_checkbox,
                line_channel_access_token_input,
                line_channel_secret_input,
                line_authorized_user_ids_input,
                line_linked_room_dropdown,
            ],
            outputs=[line_bot_status]
        )
        line_bot_stop_button.click(
            fn=ui_handlers.handle_stop_line_bot,
            outputs=[line_bot_status]
        )

        # --- [新規] ユーザー用画像生成機能イベント ---        # --- [新規] ユーザー用画像生成機能イベント ---
        user_gen_image_provider.change(
            fn=ui_handlers.update_user_gen_model_choices,
            inputs=[user_gen_image_provider, user_gen_image_openai_profile],
            outputs=[user_gen_image_model, user_gen_image_openai_profile, user_gen_free_only_checkbox, user_gen_openai_profile_state, user_gen_reference_status],
            show_progress="hidden"
        )

        user_gen_image_openai_profile.change(
            fn=ui_handlers.handle_user_gen_profile_change,
            inputs=[user_gen_image_openai_profile, user_gen_openai_profile_state],
            outputs=[user_gen_image_model, user_gen_free_only_checkbox, user_gen_openai_profile_state, user_gen_reference_status],
            show_progress="hidden"
        )

        user_gen_image_model.change(
            fn=ui_handlers.handle_user_gen_reference_status_change,
            inputs=[user_gen_image_provider, user_gen_image_model, user_gen_image_openai_profile],
            outputs=[user_gen_reference_status],
            show_progress="hidden"
        )

        user_gen_image_button.click(
            fn=ui_handlers.handle_user_generate_image,
            inputs=[
                user_gen_image_prompt, user_gen_image_provider,
                user_gen_image_model, user_gen_image_openai_profile,
                current_room_name, current_api_key_name_state,
                user_gen_reference_files, user_gen_use_scene_reference,
                last_sent_scenery_image_state
            ],
            outputs=[
                user_gen_image_path_state, user_gen_image_display,
                user_gen_image_attach_button, user_gen_image_status
            ],
            show_progress="hidden"
        )

        user_gen_image_attach_button.click(
            fn=ui_handlers.handle_attach_generated_image_to_chat,
            inputs=[user_gen_image_path_state, chat_input_multimodal],
            outputs=[chat_input_multimodal]
        )

        user_gen_image_refresh_button.click(
            fn=ui_handlers.handle_fetch_image_models,
            inputs=[user_gen_image_provider, user_gen_image_openai_profile, user_gen_free_only_checkbox],
            outputs=[gemini_image_model_dropdown, openai_image_model_dropdown, pollinations_image_model_dropdown, huggingface_image_model_dropdown, user_gen_image_model]
        ).then(
            fn=ui_handlers.handle_user_gen_reference_status_change,
            inputs=[user_gen_image_provider, user_gen_image_model, user_gen_image_openai_profile],
            outputs=[user_gen_reference_status],
            show_progress="hidden"
        )

        # --- AIプロンプト生成補助イベント ---
        user_gen_ai_instruction_dropdown.change(
            fn=ui_handlers.handle_user_gen_instruction_select,
            inputs=[user_gen_ai_instruction_dropdown],
            outputs=[user_gen_ai_instruction_editor, user_gen_ai_instruction_name_textbox]
        )

        user_gen_ai_instruction_save_btn.click(
            fn=ui_handlers.handle_user_gen_instruction_save,
            inputs=[user_gen_ai_instruction_name_textbox, user_gen_ai_instruction_editor],
            outputs=[user_gen_ai_instruction_dropdown, user_gen_ai_instruction_name_textbox, user_gen_image_status]
        )

        user_gen_ai_instruction_delete_btn.click(
            fn=ui_handlers.handle_user_gen_instruction_delete,
            inputs=[user_gen_ai_instruction_dropdown],
            outputs=[user_gen_ai_instruction_dropdown, user_gen_ai_instruction_name_textbox, user_gen_ai_instruction_editor, user_gen_image_status]
        )

        user_gen_ai_prompt_generate_btn.click(
            fn=ui_handlers.handle_generate_user_image_prompt_ai,
            inputs=[current_room_name, user_gen_ai_instruction_editor, current_api_key_name_state],
            outputs=[user_gen_image_prompt, user_gen_image_status]
        )

        # --- 外部接続設定に基づいてserver_nameを決定 ---
        allow_external = config_manager.CONFIG_GLOBAL.get("allow_external_connection", False)
        server_name_value = "0.0.0.0" if allow_external else "127.0.0.1"
        webhook_port = int(config_manager.CONFIG_GLOBAL.get("roblox_webhook_port", 7861))
        try:
            line_bot_port = int(config_manager.CONFIG_GLOBAL.get("line_bot_port", 7862))
        except (TypeError, ValueError):
            print("--- [Port Warning] line_bot_port設定が無効なため、7862を使用します ---")
            line_bot_port = 7862
        api_gateway_settings = config_manager.CONFIG_GLOBAL.get("api_gateway_settings", {}) or {}
        api_gateway_port = int(os.getenv("NEXUS_ARK_API_PORT") or api_gateway_settings.get("port", 8000))
        atelier_serve_settings = config_manager.CONFIG_GLOBAL.get("atelier_serve_settings", {}) or {}
        atelier_serve_port = int(os.getenv("NEXUS_ARK_ATELIER_SERVE_PORT") or atelier_serve_settings.get("port", 8765))
        try:
            preferred_gradio_port = int(os.getenv("NEXUS_ARK_PORT") or config_manager.CONFIG_GLOBAL.get("gradio_port", 7860))
        except (TypeError, ValueError):
            print("--- [Port Warning] gradio_port設定が無効なため、7860を使用します ---")
            preferred_gradio_port = 7860
        allow_port_fallback = _env_flag("NEXUS_ARK_ALLOW_PORT_FALLBACK", False)
        if os.environ.get("NEXUS_ARK_UPDATE_TRIAL") == "1":
            allow_external = False
            server_name_value = "127.0.0.1"
            allow_port_fallback = False
        gradio_port = _resolve_gradio_port(
            default_port=preferred_gradio_port,
            excluded_ports={webhook_port, line_bot_port, api_gateway_port, atelier_serve_port},
            allow_fallback=allow_port_fallback,
        )
        display_port = gradio_port if gradio_port is not None else "Gradioが自動選択"

        print("\n" + "="*60)
        print("アプリケーションを起動します...")
        print(f"起動後、以下のURLでアクセスしてください。")
        print(f"\n  【PCからアクセスする場合】")
        print(f"  http://127.0.0.1:{display_port}")
        print(f"  http://localhost:{display_port}")
        print(f"\nOPEN_URL=http://127.0.0.1:{display_port}")
        if gradio_port is None:
            print("  ※実際のポート番号は、起動直後にGradioが表示するURLを確認してください。")
        elif not allow_port_fallback:
            print(f"  ※スマホ用URLを固定するため、Gradioポートは {gradio_port} に固定されています。")
            print("    使用中の場合は既存プロセスを終了するか、NEXUS_ARK_PORT で固定ポートを変更してください。")
        else:
            print("  ※NEXUS_ARK_ALLOW_PORT_FALLBACK=1 のため、使用中なら別ポートへ自動変更します。")
        if allow_external:
            print(f"\n  【スマホからアクセスする場合（PCと同じWi-Fiに接続してください）】")
            print(f"  http://<お使いのPCのIPアドレス>:{display_port}")
            print("  (IPアドレスが分からない場合は、PCのコマンドプロンプトやターミナルで")
            print("   `ipconfig` (Windows) または `ifconfig` (Mac/Linux) と入力して確認できます)")
        else:
            print(f"\n  ※外部接続は無効です。共通設定で有効化できます。")
        if api_gateway_settings.get("enabled") or os.getenv("NEXUS_ARK_API_ENABLED") == "1":
            api_host = os.getenv("NEXUS_ARK_API_HOST") or api_gateway_settings.get("host", "0.0.0.0")
            print(f"\n  【REST API】")
            print(f"  http://{api_host}:{api_gateway_port}/api/v1")
        if atelier_serve_settings.get("enabled") or os.getenv("NEXUS_ARK_ATELIER_SERVE_ENABLED") == "1":
            atelier_host = os.getenv("NEXUS_ARK_ATELIER_SERVE_HOST") or atelier_serve_settings.get("host", "0.0.0.0")
            print(f"\n  【アトリエアプリ配信】")
            print(f"  http://{atelier_host}:{atelier_serve_port}/atelier/<room>/<app>/")
        print("="*60 + "\n")

        # --- [Hotfix] v0.2.3.0 誤配布データのクリーンアップ ---
        # v0.2.3.0 で開発者の個人アイテムデータ (data/items/) が誤って配布された。
        # この処理はアプリ起動時に毎回チェックし、残留していれば削除する。
        _leaked_dir = os.path.join(script_dir, "data", "items")
        if os.path.exists(_leaked_dir):
            # items がすべて開発者のものかを判定するため、
            # 開発者固有のアイテムIDで存在チェック
            _leaked_ids = {"938c3c7a-1b64-473e-ae1d-11d9fa976112", "45876a65-c24f-436d-a846-c8a4a803c077"}
            _leaked_images_dir = os.path.join(_leaked_dir, "images")
            _is_leaked = False
            if os.path.isdir(_leaked_images_dir):
                for fname in os.listdir(_leaked_images_dir):
                    if fname.replace(".png", "") in _leaked_ids:
                        _is_leaked = True
                        break
            if _is_leaked:
                try:
                    import shutil
                    shutil.rmtree(_leaked_dir)
                    print("  [Cleanup] v0.2.3.0 誤配布データを削除しました。")
                    # 親の data/ ディレクトリも空なら削除
                    _data_dir = os.path.join(script_dir, "data")
                    if os.path.exists(_data_dir) and not os.listdir(_data_dir):
                        os.rmdir(_data_dir)
                except Exception as _e:
                    print(f"  [Cleanup Warning] クリーンアップに失敗: {_e}")

        # --- [Phase 2] Roblox Webhook Server ---
        try:
            from tools.roblox_webhook import start_webhook_server
            start_webhook_server(port=webhook_port, daemon=True)
            print(f"  [Roblox Webhook] ポート {webhook_port} で待機中。")
        except Exception as e:
            print(f"  [Roblox Webhook Error] 起動に失敗しました: {e}")

        # --- REST API Gateway ---
        if api_gateway_settings.get("enabled") or os.getenv("NEXUS_ARK_API_ENABLED") == "1":
            try:
                from api.server import start_server as start_api_gateway_server
                api_host = os.getenv("NEXUS_ARK_API_HOST") or api_gateway_settings.get("host", "0.0.0.0")
                start_api_gateway_server(port=api_gateway_port, host=api_host, daemon=True)
                print(f"  [API Gateway] ポート {api_gateway_port} で待機中。")

                # 起動時にTailscale HTTPSを自動設定する
                if api_gateway_settings.get("auto_start_tailscale_serve") or os.getenv("NEXUS_ARK_START_TAILSCALE_SERVE") == "1":
                    import shutil
                    if shutil.which("tailscale"):
                        print("  [API Gateway] Tailscale HTTPS Serve の自動設定を非同期で開始します...")
                        import threading
                        threading.Thread(
                            target=ui_handlers.handle_configure_tailscale_lite_https,
                            daemon=True
                        ).start()
                    else:
                        print("  [API Gateway] Tailscale CLI が見つからないため、自動設定をスキップしました。")
            except Exception as e:
                print(f"  [API Gateway Error] 起動に失敗しました: {e}")

        # --- Atelier Static App Serve ---
        if atelier_serve_settings.get("enabled") or os.getenv("NEXUS_ARK_ATELIER_SERVE_ENABLED") == "1":
            try:
                from atelier_serve.server import start_server as start_atelier_serve_server
                atelier_host = os.getenv("NEXUS_ARK_ATELIER_SERVE_HOST") or atelier_serve_settings.get("host", "0.0.0.0")
                start_atelier_serve_server(port=atelier_serve_port, host=atelier_host, daemon=True)
                print(f"  [Atelier Serve] ポート {atelier_serve_port} で待機中。")

                if atelier_serve_settings.get("auto_start_tailscale_serve") or os.getenv("NEXUS_ARK_START_ATELIER_TAILSCALE_SERVE") == "1":
                    import shutil
                    if shutil.which("tailscale"):
                        print("  [Atelier Serve] Tailscale HTTPS Serve の自動設定を非同期で開始します...")
                        import threading
                        threading.Thread(
                            target=ui_handlers.handle_configure_tailscale_atelier_https,
                            daemon=True
                        ).start()
                    else:
                        print("  [Atelier Serve] Tailscale CLI が見つからないため、自動設定をスキップしました。")
            except Exception as e:
                print(f"  [Atelier Serve Error] 起動に失敗しました: {e}")

        # --- [Discord Bot] ---
        if discord_manager:
            try:
                discord_manager.start_bot()
            except Exception as e:
                print(f"  [Discord Bot Error] 起動に失敗しました: {e}")
        else:
            print("--- [Discord Bot] discord.py が未インストールのため、Discord Bot は無効です ---")

        # --- [LINE Bot] ---
        if line_manager:
            try:
                line_manager.start_bot(port=line_bot_port, daemon=True)
            except Exception as e:
                print(f"  [LINE Bot Error] 起動に失敗しました: {e}")
        else:
            print("--- [LINE Bot] line-bot-sdk が未インストールのため、LINE Bot は無効です ---")

        # 許可するパスを絶対パスで指定
        allowed_paths = [
            os.path.abspath("."),
            os.path.abspath(constants.ROOMS_DIR),
            os.path.abspath("data"),
            os.path.abspath(os.path.join(script_dir, "assets"))
        ]
        launch_kwargs = {
            "server_name": server_name_value,
            "server_port": gradio_port,
            "share": False,
            "allowed_paths": allowed_paths,
            "inbrowser": False,
            "quiet": True,
            "theme": active_theme_object,
            "css": effective_custom_css,
            "js": effective_custom_js,
            # Gradio 6 checks localhost with an internal HEAD request after
            # binding. In local/proxy/WSL environments this check can fail even
            # when the server is usable, causing a fatal startup error.
            "_frontend": False,
        }
        _ensure_localhost_no_proxy()
        queued_demo = demo.queue()
        ui_handlers.log_memory_diagnostics("app_launch:before_queue_launch")
        launch_hosts = [server_name_value]
        if server_name_value == "0.0.0.0":
            launch_hosts.append("127.0.0.1")

        base_port = gradio_port if gradio_port is not None else preferred_gradio_port
        launch_error = None
        launched = False
        port_candidates = (
            range(base_port, base_port + 20)
            if allow_port_fallback
            else [base_port]
        )
        for host in launch_hosts:
            for port in port_candidates:
                launch_kwargs["server_name"] = host
                launch_kwargs["server_port"] = port
                try:
                    print(f"--- [Launch] Gradio を http://{host}:{port} で起動します ---")
                    print(f"--- [Open] ブラウザでは http://127.0.0.1:{port} を開いてください ---")
                    print(f"OPEN_URL=http://127.0.0.1:{port}")
                    _start_update_trial_ready_monitor(port)
                    _open_local_browser_later(port)
                    queued_demo.launch(**launch_kwargs)
                    launched = True
                    break
                except OSError as err:
                    launch_error = err
                    if "Cannot find empty port" in str(err):
                        if allow_port_fallback:
                            print(f"--- [Launch Warning] ポート {port} が使用中のため、{port + 1} を試します ---")
                            continue
                        print(f"--- [Launch Error] 固定ポート {port} が使用中です。スマホ用URL維持のため自動変更しません ---")
                        print("--- [Launch Hint] 既存のNexus Arkを終了するか、NEXUS_ARK_PORT=別番号 を指定してください ---")
                        break
                    if host == "0.0.0.0":
                        print("--- [Launch Warning] 外部接続(0.0.0.0)で起動できないため、127.0.0.1で再試行します ---")
                        break
                    raise
            if launched:
                break
        if not launched and launch_error is not None:
            raise launch_error

except Exception as e:
    print("\n" + "X"*60); print("!!! [致命的エラー] アプリケーションの起動中に、予期せぬ例外が発生しました。"); print("X"*60); traceback.print_exc()

finally:
    # 起動中のエラーでクラッシュした場合でも、ゾンビ化したアラームスレッドが
    # メッセージを出し続けないよう確実に停止をリクエストする
    try:
        alarm_manager.stop_alarm_scheduler_thread()
    except Exception:
        pass
    try:
        import google_calendar_service
        google_calendar_service.stop_calendar_sync_thread()
    except Exception:
        pass
    try:
        import gemini_explicit_cache_manager
        gemini_explicit_cache_manager.delete_all_known_caches()
    except Exception as cleanup_error:
        print(f"--- [Gemini Explicit Cache] 終了時クリーンアップ失敗: {cleanup_error} ---")

    utils.release_lock()
    if os.name == "nt": os.system("pause")
    else: input("続行するにはEnterキーを押してください...")
