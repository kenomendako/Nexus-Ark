from __future__ import annotations

import asyncio
import base64
import datetime
import hashlib
import json
import logging
import math
import mimetypes
import os
import re
import tempfile
import uuid
from pathlib import Path
import threading
from typing import Any, Dict, List, Optional

import filetype
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

import config_manager
import constants
import gemini_api
import letterbox_manager
import lite_travel
import note_storage
import room_manager
import utils
from agent.scenery_image_context import (
    SceneryImageContext,
    commit_scenery_image_context,
    get_scenery_image_context,
)
from api import capabilities as api_capabilities
from file_lock_utils import safe_json_read, safe_json_write, safe_text_read
from api.schemas import (
    ApiCapabilitiesResponse,
    AutonomyPresetRequest,
    AutonomyPresetResponse,
    CalendarEventCreateRequest,
    CalendarEventCreateResponse,
    CalendarEventSummary,
    CalendarEventsResponse,
    AutonomyStatusResponse,
    ChatHistoryMessage,
    ChatHistoryResponse,
    ChatRegenerateRequest,
    ChatRequest,
    ChatResponse,
    EventNotificationSettingsRequest,
    EventNotificationSettingsResponse,
    EventRequest,
    EventResponse,
    LetterDetailResponse,
    LetterListResponse,
    LetterSummary,
    ItemActionRequest,
    ItemActionResponse,
    ItemListResponse,
    ItemSummary,
    LocationListResponse,
    LocationSetRequest,
    LocationSetResponse,
    LocationSummary,
    MemorySearchResponse,
    NoteResponse,
    NoteUpdateRequest,
    PushPublicKeyResponse,
    PushSendResponse,
    PushStatusResponse,
    PushSubscriptionSummary,
    PushSubscriptionRequest,
    PushSubscriptionResponse,
    PushTestRequest,
    PersistentEmotionStatus,
    RoomStatus,
    RoomSummary,
    TranscriptionResponse,
    TtsRequest,
    TtsResponse,
    TwitterDraftActionRequest,
    TwitterDraftActionResponse,
    TwitterDraftListResponse,
    TwitterDraftSummary,
    UploadResponse,
)
from tts_key_rotation import generate_audio_with_key_rotation
from tts_text_policy import prepare_tts_text_plan

logger = logging.getLogger(__name__)
_room_locks: Dict[str, threading.RLock] = {}
_ALLOWED_UPLOAD_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
_ALLOWED_AUDIO_EXTENSIONS = {".wav", ".mp3", ".m4a", ".mp4", ".webm", ".ogg"}
_ALLOWED_TTS_EXTENSIONS = {".wav", ".mp3", ".m4a", ".mp4", ".ogg", ".pcm"}
_MAX_UPLOAD_BYTES = 8 * 1024 * 1024
_MAX_AUDIO_UPLOAD_BYTES = 20 * 1024 * 1024
_DEFAULT_EVENT_NOTIFICATION_DEDUPE_SECONDS = 300
_DEFAULT_WEB_PUSH_SUBSCRIPTION_TTL_DAYS = 90
_PUSH_RESPONSE_EXCERPT_CHARS = 42
_EVENT_IMPORTANCE_ORDER = {"low": 0, "normal": 1, "high": 2, "critical": 3}
_event_notification_last_sent: Dict[tuple[str, str, str], datetime.datetime] = {}


class NoteConflictError(ValueError):
    """Raised when a Lite note update is based on an outdated content hash."""


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(value: str) -> bytes:
    padding = "=" * ((4 - len(value) % 4) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def _room_exists(room_id: str) -> bool:
    return any(folder == room_id for _, folder in room_manager.get_room_list_for_ui())


def _require_room(room_id: str) -> None:
    if not _room_exists(room_id):
        raise ValueError(f"Room not found: {room_id}")


def _get_room_lock(room_id: str) -> threading.RLock:
    if room_id not in _room_locks:
        _room_locks[room_id] = threading.RLock()
    return _room_locks[room_id]


def _api_gateway_settings() -> dict:
    return dict(config_manager.CONFIG_GLOBAL.get("api_gateway_settings", {}) or {})


def _api_gateway_settings_from_file() -> dict:
    try:
        with open(constants.CONFIG_FILE, "r", encoding="utf-8") as f:
            config = json.load(f)
    except Exception:
        return {}
    settings = config.get("api_gateway_settings") if isinstance(config, dict) else {}
    return dict(settings or {}) if isinstance(settings, dict) else {}


def _save_api_gateway_settings(settings: dict) -> None:
    merged = _api_gateway_settings_from_file()
    merged.update(_api_gateway_settings())
    merged.update(settings)
    config_manager.save_config_if_changed("api_gateway_settings", merged)


def _generate_vapid_keys() -> tuple[str, str]:
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives import serialization

    private_key = ec.generate_private_key(ec.SECP256R1())
    public_key = private_key.public_key()
    private_value = private_key.private_numbers().private_value.to_bytes(32, "big")
    public_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.UncompressedPoint,
    )
    return _b64url_encode(public_bytes), _b64url_encode(private_value)


def _valid_vapid_keys(public_key: str, private_key: str) -> bool:
    try:
        public_bytes = _b64url_decode(public_key)
        private_bytes = _b64url_decode(private_key)
    except Exception:
        return False
    return len(public_bytes) == 65 and public_bytes[:1] == b"\x04" and len(private_bytes) == 32


def get_push_public_key() -> PushPublicKeyResponse:
    settings = _api_gateway_settings()
    public_key = str(settings.get("web_push_public_key") or "").strip()
    private_key = str(settings.get("web_push_private_key") or "").strip()
    if not _valid_vapid_keys(public_key, private_key):
        public_key, private_key = _generate_vapid_keys()
        settings["web_push_public_key"] = public_key
        settings["web_push_private_key"] = private_key
        settings["web_push_subscriptions"] = {}
        _save_api_gateway_settings(settings)
    return PushPublicKeyResponse(public_key=public_key)


def get_room_push_public_key(room_id: str) -> PushPublicKeyResponse:
    _require_room(room_id)
    return get_push_public_key()


def _push_subscriptions_by_room(settings: Optional[dict] = None) -> dict:
    settings = settings or _api_gateway_settings()
    subscriptions = settings.get("web_push_subscriptions") or {}
    return subscriptions if isinstance(subscriptions, dict) else {}


def _utc_now() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc)


def _parse_iso_datetime(value: Any) -> Optional[datetime.datetime]:
    if not value:
        return None
    try:
        parsed = datetime.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=datetime.timezone.utc)
    return parsed.astimezone(datetime.timezone.utc)


def _coerce_positive_int(value: Any, fallback: int) -> int:
    try:
        coerced = int(value)
    except (TypeError, ValueError):
        return fallback
    return max(0, coerced)


def _event_notification_settings(settings: Optional[dict] = None) -> EventNotificationSettingsResponse:
    settings = settings or _api_gateway_settings()
    minimum_importance = str(settings.get("event_notification_minimum_importance") or "high").strip().lower()
    if minimum_importance not in {"high", "critical"}:
        minimum_importance = "high"
    cooldowns = settings.get("event_notification_cooldowns") or {}
    normalized_cooldowns: dict[str, int] = {}
    if isinstance(cooldowns, dict):
        for key, value in cooldowns.items():
            source = str(key or "").strip()
            if source:
                normalized_cooldowns[source] = min(_coerce_positive_int(value, 0), 86400)
    return EventNotificationSettingsResponse(
        enabled=bool(settings.get("event_notifications_enabled", True)),
        minimum_importance=minimum_importance,
        default_cooldown_seconds=min(
            _coerce_positive_int(
                settings.get("event_notification_default_cooldown_seconds", _DEFAULT_EVENT_NOTIFICATION_DEDUPE_SECONDS),
                _DEFAULT_EVENT_NOTIFICATION_DEDUPE_SECONDS,
            ),
            86400,
        ),
        source_cooldowns=normalized_cooldowns,
        response_preview_enabled=bool(settings.get("response_notification_preview_enabled", True)),
    )


def get_event_notification_settings() -> EventNotificationSettingsResponse:
    return _event_notification_settings()


def update_event_notification_settings(request: EventNotificationSettingsRequest) -> EventNotificationSettingsResponse:
    source_cooldowns = {
        str(source).strip(): min(_coerce_positive_int(seconds, 0), 86400)
        for source, seconds in (request.source_cooldowns or {}).items()
        if str(source).strip()
    }
    settings = _api_gateway_settings()
    settings["event_notifications_enabled"] = bool(request.enabled)
    settings["event_notification_minimum_importance"] = request.minimum_importance
    settings["event_notification_default_cooldown_seconds"] = min(
        _coerce_positive_int(request.default_cooldown_seconds, _DEFAULT_EVENT_NOTIFICATION_DEDUPE_SECONDS),
        86400,
    )
    settings["event_notification_cooldowns"] = source_cooldowns
    settings["response_notification_preview_enabled"] = bool(request.response_preview_enabled)
    _save_api_gateway_settings(settings)
    response = _event_notification_settings(settings)
    response.status = "saved"
    return response


def _web_push_subscription_ttl_days(settings: dict) -> int:
    return _coerce_positive_int(
        settings.get("web_push_subscription_ttl_days", _DEFAULT_WEB_PUSH_SUBSCRIPTION_TTL_DAYS),
        _DEFAULT_WEB_PUSH_SUBSCRIPTION_TTL_DAYS,
    )


def _push_subscription_id(endpoint: str) -> str:
    return hashlib.sha256(endpoint.encode("utf-8")).hexdigest()[:16]


def _push_endpoint_host(endpoint: str) -> str:
    if "://" not in endpoint:
        return endpoint[:80]
    try:
        return endpoint.split("/")[2]
    except IndexError:
        return endpoint[:80]


def _normalize_push_subscription(item: dict, now: Optional[datetime.datetime] = None) -> dict:
    now = now or _utc_now()
    endpoint = str(item.get("endpoint") or "").strip()
    created_at = str(item.get("created_at") or item.get("updated_at") or now.isoformat())
    updated_at = str(item.get("updated_at") or created_at)
    return {
        "id": str(item.get("id") or _push_subscription_id(endpoint)),
        "endpoint": endpoint,
        "keys": item.get("keys") if isinstance(item.get("keys"), dict) else {},
        "user_agent": str(item.get("user_agent") or ""),
        "created_at": created_at,
        "updated_at": updated_at,
        "last_success_at": str(item.get("last_success_at") or ""),
        "last_failure_at": str(item.get("last_failure_at") or ""),
        "failure_count": _coerce_positive_int(item.get("failure_count", 0), 0),
    }


def _clean_push_subscriptions(settings: dict, now: Optional[datetime.datetime] = None) -> tuple[dict, int]:
    now = now or _utc_now()
    ttl_days = _web_push_subscription_ttl_days(settings)
    cutoff = now - datetime.timedelta(days=ttl_days) if ttl_days > 0 else None
    subscriptions = _push_subscriptions_by_room(settings)
    cleaned: dict[str, list[dict]] = {}
    removed_count = 0
    for room_id, items in subscriptions.items():
        room_items = items if isinstance(items, list) else []
        kept: list[dict] = []
        for item in room_items:
            if not isinstance(item, dict):
                removed_count += 1
                continue
            normalized = _normalize_push_subscription(item, now)
            if not normalized["endpoint"] or not normalized["keys"].get("p256dh") or not normalized["keys"].get("auth"):
                removed_count += 1
                continue
            last_seen = _parse_iso_datetime(normalized.get("updated_at") or normalized.get("created_at"))
            if cutoff and last_seen and last_seen < cutoff:
                removed_count += 1
                continue
            kept.append(normalized)
        if kept:
            cleaned[room_id] = kept[-20:]
    return cleaned, removed_count


def _save_push_subscriptions(settings: dict, subscriptions: dict) -> None:
    settings["web_push_subscriptions"] = subscriptions
    _save_api_gateway_settings(settings)


def _is_expired_push_failure(detail: str) -> bool:
    normalized = str(detail or "").lower()
    return normalized.startswith("404 ") or normalized.startswith("410 ") or "expired" in normalized or "gone" in normalized


def _response_push_body(room_id: str, reply: str) -> str:
    speaker = _room_display_name(room_id)
    settings = _api_gateway_settings()
    if not bool(settings.get("response_notification_preview_enabled", True)):
        return f"{speaker}からのメッセージがあります。"
    cleaned = re.sub(r"\s+", " ", utils.clean_persona_text(reply or "")).strip()
    if not cleaned:
        return f"{speaker}からのメッセージがあります。"
    if len(cleaned) > _PUSH_RESPONSE_EXCERPT_CHARS:
        cleaned = cleaned[:_PUSH_RESPONSE_EXCERPT_CHARS].rstrip() + "..."
    return f"{speaker}「{cleaned}」"


def subscribe_push(room_id: str, request: PushSubscriptionRequest) -> PushSubscriptionResponse:
    _require_room(room_id)
    get_push_public_key()
    endpoint = (request.endpoint or "").strip()
    keys = request.keys or {}
    if not endpoint or not keys.get("p256dh") or not keys.get("auth"):
        raise ValueError("valid push subscription endpoint and keys are required")

    settings = _api_gateway_settings()
    subscriptions, cleaned_count = _clean_push_subscriptions(settings)
    room_subscriptions = [item for item in subscriptions.get(room_id, []) if isinstance(item, dict)]
    now = _utc_now().isoformat()
    existing_by_endpoint = {str(item.get("endpoint") or ""): item for item in room_subscriptions}
    existing = existing_by_endpoint.get(endpoint) or {}
    subscription = {
        "id": _push_subscription_id(endpoint),
        "endpoint": endpoint,
        "keys": {"p256dh": keys.get("p256dh", ""), "auth": keys.get("auth", "")},
        "user_agent": request.user_agent or "",
        "created_at": existing.get("created_at") or now,
        "updated_at": now,
        "last_success_at": existing.get("last_success_at") or "",
        "last_failure_at": existing.get("last_failure_at") or "",
        "failure_count": _coerce_positive_int(existing.get("failure_count", 0), 0),
    }
    replaced = False
    for index, item in enumerate(room_subscriptions):
        if item.get("endpoint") == endpoint:
            room_subscriptions[index] = subscription
            replaced = True
            break
    if not replaced:
        room_subscriptions.append(subscription)
    subscriptions[room_id] = room_subscriptions[-20:]
    _save_push_subscriptions(settings, subscriptions)
    detail = f"cleaned={cleaned_count}" if cleaned_count else ""
    return PushSubscriptionResponse(status="saved", subscription_count=len(subscriptions[room_id]), detail=detail)


def unsubscribe_push(room_id: str, subscription_id: str) -> PushSubscriptionResponse:
    _require_room(room_id)
    target_id = (subscription_id or "").strip()
    if not target_id:
        raise ValueError("push subscription id is required")

    settings = _api_gateway_settings()
    all_subscriptions, cleaned_count = _clean_push_subscriptions(settings)
    room_subscriptions = list(all_subscriptions.get(room_id, []) or [])
    kept = []
    removed = 0
    for item in room_subscriptions:
        endpoint = str(item.get("endpoint") or "")
        item_id = str(item.get("id") or _push_subscription_id(endpoint))
        if item_id == target_id:
            removed += 1
            continue
        kept.append(item)

    if kept:
        all_subscriptions[room_id] = kept[-20:]
    else:
        all_subscriptions.pop(room_id, None)
    _save_push_subscriptions(settings, all_subscriptions)

    detail_parts = []
    if removed:
        detail_parts.append(f"removed={removed}")
    if cleaned_count:
        detail_parts.append(f"cleaned={cleaned_count}")
    status = "deleted" if removed else "not_found"
    return PushSubscriptionResponse(
        status=status,
        subscription_count=len(all_subscriptions.get(room_id, []) or []),
        detail="; ".join(detail_parts),
    )


def get_push_status(room_id: str) -> PushStatusResponse:
    _require_room(room_id)
    settings = _api_gateway_settings()
    all_subscriptions, cleaned_count = _clean_push_subscriptions(settings)
    if cleaned_count:
        _save_push_subscriptions(settings, all_subscriptions)
    subscriptions = list(all_subscriptions.get(room_id, []) or [])
    endpoints = []
    summaries: list[PushSubscriptionSummary] = []
    for index, item in enumerate(subscriptions[:10], start=1):
        endpoint = str(item.get("endpoint") or "")
        endpoint_host = f"Push端末 {index}"
        endpoints.append(endpoint_host)
        summaries.append(
            PushSubscriptionSummary(
                id=str(item.get("id") or _push_subscription_id(endpoint)),
                endpoint_host=endpoint_host,
                user_agent=str(item.get("user_agent") or ""),
                created_at=str(item.get("created_at") or ""),
                updated_at=str(item.get("updated_at") or ""),
                last_success_at=str(item.get("last_success_at") or ""),
                last_failure_at=str(item.get("last_failure_at") or ""),
                failure_count=_coerce_positive_int(item.get("failure_count", 0), 0),
            )
        )
    return PushStatusResponse(
        room_id=room_id,
        has_vapid_keys=bool(settings.get("web_push_public_key") and settings.get("web_push_private_key")),
        subscription_count=len(subscriptions),
        endpoints=endpoints,
        subscriptions=summaries,
        cleaned_count=cleaned_count,
    )


def _send_web_push(subscription: dict, payload: dict) -> tuple[bool, str]:
    settings = _api_gateway_settings()
    private_key = str(settings.get("web_push_private_key") or "").strip()
    public_key = str(settings.get("web_push_public_key") or "").strip()
    if not private_key or not public_key:
        get_push_public_key()
        settings = _api_gateway_settings()
        private_key = str(settings.get("web_push_private_key") or "").strip()

    try:
        from pywebpush import WebPushException, webpush
    except Exception:
        return False, "dependency_missing: pywebpush is not installed"

    vapid_claims = {
        "sub": str(settings.get("web_push_vapid_subject") or "mailto:nexus-ark@example.invalid"),
    }
    try:
        webpush(
            subscription_info={
                "endpoint": subscription.get("endpoint", ""),
                "keys": subscription.get("keys", {}),
            },
            data=json.dumps(payload, ensure_ascii=False),
            vapid_private_key=private_key,
            vapid_claims=vapid_claims,
            ttl=60 * 60,
            timeout=5,
        )
        return True, "sent"
    except WebPushException as e:
        response = getattr(e, "response", None)
        if response is not None:
            return False, f"{response.status_code} {response.reason}: {response.text[:500]}"
        return False, str(e)
    except Exception as e:
        return False, str(e)


def send_push_to_room(room_id: str, title: str, body: str, url: str = "/lite/") -> PushSendResponse:
    _require_room(room_id)
    settings = _api_gateway_settings()
    all_subscriptions, cleaned_count = _clean_push_subscriptions(settings)
    subscriptions = list(all_subscriptions.get(room_id, []) or [])
    if not subscriptions:
        if cleaned_count:
            _save_push_subscriptions(settings, all_subscriptions)
        logger.info("Lite PWA web push skipped for %s: no subscriptions", room_id)
        detail = "no push subscriptions for room"
        if cleaned_count:
            detail = f"{detail}; cleaned={cleaned_count}"
        return PushSendResponse(status="no_subscriptions", subscription_count=0, detail=detail)

    payload = {"title": title, "body": body, "url": url}
    sent = 0
    failed = 0
    details = []
    kept_subscriptions: list[dict] = []
    now = _utc_now().isoformat()
    for subscription in subscriptions:
        ok, detail = _send_web_push(subscription, payload)
        if ok:
            sent += 1
            subscription["last_success_at"] = now
            subscription["last_failure_at"] = ""
            subscription["failure_count"] = 0
            kept_subscriptions.append(subscription)
        else:
            failed += 1
            subscription["last_failure_at"] = now
            subscription["failure_count"] = _coerce_positive_int(subscription.get("failure_count", 0), 0) + 1
            details.append(detail)
            if not _is_expired_push_failure(detail):
                kept_subscriptions.append(subscription)
    all_subscriptions[room_id] = kept_subscriptions[-20:]
    if not all_subscriptions[room_id]:
        all_subscriptions.pop(room_id, None)
    _save_push_subscriptions(settings, all_subscriptions)
    status = "sent" if sent and not failed else "partial" if sent else "failed"
    detail = "; ".join(details[:3])
    if cleaned_count:
        detail = f"{detail}; cleaned={cleaned_count}" if detail else f"cleaned={cleaned_count}"
    logger.info(
        "Lite PWA web push result for %s: status=%s subscriptions=%s sent=%s failed=%s detail=%s",
        room_id,
        status,
        len(subscriptions),
        sent,
        failed,
        detail,
    )
    return PushSendResponse(
        status=status,
        subscription_count=len(subscriptions),
        sent=sent,
        failed=failed,
        detail=detail,
    )


def send_push_test(room_id: str, request: PushTestRequest) -> PushSendResponse:
    return send_push_to_room(room_id, request.title, request.body)


def _room_display_name(room_id: str) -> str:
    config = room_manager.get_room_config(room_id) or {}
    display_name = str(config.get("room_name") or "").strip()
    return display_name or room_manager.get_character_name(room_id) or room_id


def list_rooms() -> List[RoomSummary]:
    rooms: List[RoomSummary] = []
    for display_name, folder_name in room_manager.get_room_list_for_ui():
        config = room_manager.get_room_config(folder_name) or {}
        rooms.append(
            RoomSummary(
                room_id=folder_name,
                display_name=config.get("room_name") or display_name or folder_name,
                description=config.get("description", ""),
                current_location=utils.get_current_location(folder_name) or "",
            )
        )
    return rooms


def _status_unit_float(value: Any) -> Optional[float]:
    """状態APIへ出す0〜1の有限値だけを許可する。"""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return value if math.isfinite(value) and 0.0 <= value <= 1.0 else None


def _status_drive_float(value: Any) -> float:
    """壊れた内部値で状態GET全体を失敗させず、従来の0.0へ戻す。"""
    if isinstance(value, bool):
        return 0.0
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError):
        return 0.0
    return value if math.isfinite(value) else 0.0


def _read_status_json_dict(path: Path) -> Dict[str, Any]:
    """状態表示用のJSONを修復せず読み取る。"""
    try:
        value = safe_json_read(str(path), default={})
    except Exception as exc:
        logger.warning("Failed to read status JSON %s: %s", path, exc)
        return {}
    return value if isinstance(value, dict) else {}


def _read_room_config_for_status(room_id: str) -> Dict[str, Any]:
    """ルーム設定を自己修復なしで読み取る。"""
    config_path = Path(constants.ROOMS_DIR) / room_id / "room_config.json"
    return _read_status_json_dict(config_path) if config_path.exists() else {}


def _read_motivation_status_snapshot(room_id: str) -> tuple[Dict[str, Any], float]:
    """内部状態を読み取り専用でスナップショット化する。"""
    from motivation_manager import MotivationManager

    state_path = Path(constants.ROOMS_DIR) / room_id / "memory" / "internal_state.json"
    state = _read_status_json_dict(state_path)
    drives = state.get("drives", {})
    drives = drives if isinstance(drives, dict) else {}
    relatedness = drives.get("relatedness", {})
    relatedness = relatedness if isinstance(relatedness, dict) else {}
    intentions = relatedness.get("intentions", [])
    relatedness_level = MotivationManager._relationship_level(intentions)
    return (
        {
            "boredom": _status_drive_float((drives.get("boredom") or {}).get("level", 0.0)
                                            if isinstance(drives.get("boredom"), dict) else 0.0),
            "curiosity": _status_drive_float((drives.get("curiosity") or {}).get("level", 0.0)
                                              if isinstance(drives.get("curiosity"), dict) else 0.0),
            "goal_achievement": _status_drive_float(
                (drives.get("goal_achievement") or {}).get("level", 0.0)
                if isinstance(drives.get("goal_achievement"), dict) else 0.0
            ),
            "persona_emotion": relatedness.get("persona_emotion", "neutral"),
        },
        relatedness_level,
    )


def _read_active_plan_status(room_id: str) -> int:
    """行動計画を作成せず、既存ファイルだけを読む。"""
    plan_path = Path(constants.ROOMS_DIR) / room_id / "memory" / "action_plan.json"
    plan = _read_status_json_dict(plan_path)
    return 1 if plan.get("status") == "scheduled" else 0


def _persistent_emotion_presentation_status(entry: Dict[str, Any], status: str) -> str:
    """内部カタログの詳細をLite向けの表示状態へ要約する。"""
    if status == "unsupported":
        return "unsupported"
    if status == "invalid" or entry.get("definition_valid") is False:
        return "invalid"
    if entry.get("enabled") is not True:
        return "disabled"
    if status == "unreported":
        return "unreported"
    if status == "settled":
        return "settled"
    if status != "active":
        return "invalid"

    current = _status_unit_float(entry.get("current_intensity"))
    elapsed = entry.get("elapsed_hours")
    if current is None or isinstance(elapsed, bool) or not isinstance(elapsed, (int, float)):
        return "invalid"
    try:
        elapsed = float(elapsed)
    except (TypeError, ValueError, OverflowError):
        return "invalid"
    if not math.isfinite(elapsed) or elapsed < 0:
        return "invalid"

    policy = entry.get("decay_policy")
    max_age = policy.get("max_age_hours") if isinstance(policy, dict) else None
    if isinstance(max_age, bool) or not isinstance(max_age, (int, float)):
        return "invalid"
    try:
        max_age = float(max_age)
    except (TypeError, ValueError, OverflowError):
        return "invalid"
    if not math.isfinite(max_age) or max_age <= 0:
        return "invalid"
    if elapsed >= max_age:
        return "expired"
    from motivation_manager import MotivationManager

    if current < MotivationManager.EMOTION_MIN_CONTEXT_INTENSITY:
        return "below_threshold"
    return "active"


def _persistent_emotion_status_from_catalog(entry: Dict[str, Any]) -> PersistentEmotionStatus:
    category = entry.get("category")
    category = category if isinstance(category, str) else ""
    status = entry.get("status")
    if status not in {"active", "settled", "unreported", "invalid", "unsupported"}:
        status = "invalid"
    name = entry.get("name")
    name = name if isinstance(name, str) and name else category
    enabled = entry.get("enabled") is True
    started_at = entry.get("started_at")
    started_at = started_at if isinstance(started_at, str) and started_at else None
    return PersistentEmotionStatus(
        category=category,
        name=name,
        enabled=enabled,
        status=status,
        presentation_status=_persistent_emotion_presentation_status(entry, status),
        intensity=_status_unit_float(entry.get("intensity")),
        started_at=started_at,
        current_intensity=_status_unit_float(entry.get("current_intensity")),
    )


def _read_persistent_emotion_status(room_id: str) -> tuple[bool, List[PersistentEmotionStatus]]:
    """感情カタログを自動修復なしで読み、公開項目だけに整形する。"""
    try:
        from motivation_manager import MotivationManager

        state_path = Path(constants.ROOMS_DIR) / room_id / "memory" / "internal_state.json"
        if state_path.exists():
            if not state_path.is_file() or state_path.stat().st_size == 0:
                return False, []
            state = safe_json_read(str(state_path), default={})
            if not isinstance(state, dict):
                return False, []
            drives = state.get("drives")
            if "drives" in state and not isinstance(drives, dict):
                return False, []
            if isinstance(drives, dict):
                relatedness = drives.get("relatedness")
                if "relatedness" in drives and not isinstance(relatedness, dict):
                    return False, []

        catalog = MotivationManager(room_id, initialize=False).get_emotion_catalog()
        if not isinstance(catalog, list) or any(not isinstance(row, dict) for row in catalog):
            return False, []
        return True, [_persistent_emotion_status_from_catalog(row) for row in catalog]
    except Exception as exc:
        logger.warning("Failed to read persistent emotions for %s: %s", room_id, exc)
        return False, []


def get_room_status(room_id: str) -> RoomStatus:
    _require_room(room_id)
    config = _read_room_config_for_status(room_id)
    try:
        snapshot, relatedness_level = _read_motivation_status_snapshot(room_id)
    except Exception as exc:
        logger.warning("Failed to read motivation snapshot for %s: %s", room_id, exc)
        snapshot, relatedness_level = {}, 0.0

    try:
        active_goals_count = _read_active_plan_status(room_id)
    except Exception as exc:
        logger.warning("Failed to read action plan for %s: %s", room_id, exc)
        active_goals_count = 0

    today = datetime.datetime.now().strftime("%Y-%m-%d")
    arousal_sample_count: Optional[int] = None
    arousal_date: Optional[str] = None
    arousal = 0.5
    try:
        import session_arousal_manager

        summary = session_arousal_manager.get_daily_summary(room_id, date_str=today)
        if isinstance(summary, dict):
            candidate = _status_unit_float(summary.get("average"))
            if candidate is not None:
                arousal = candidate
            count = summary.get("sample_count")
            if isinstance(count, int) and not isinstance(count, bool) and count >= 0:
                arousal_sample_count = count
            date_value = summary.get("date")
            if isinstance(date_value, str):
                arousal_date = date_value
    except Exception as exc:
        logger.warning("Failed to read arousal summary for %s: %s", room_id, exc)

    persistent_emotions_available, persistent_emotions = _read_persistent_emotion_status(room_id)

    profile_image_path = None
    candidate = Path(constants.ROOMS_DIR) / room_id / constants.PROFILE_IMAGE_FILENAME
    if candidate.is_file():
        profile_image_path = str(candidate)

    display_name = config.get("room_name") or room_id

    return RoomStatus(
        room_id=room_id,
        display_name=display_name,
        current_location=utils.get_current_location(room_id) or "",
        drives={
            "boredom": _status_drive_float(snapshot.get("boredom", 0.0)),
            "curiosity": _status_drive_float(snapshot.get("curiosity", 0.0)),
            "goal_drive": _status_drive_float(snapshot.get("goal_achievement", 0.0)),
            "relatedness": float(relatedness_level),
        },
        current_expression=str(snapshot.get("persona_emotion", "neutral") or "neutral"),
        arousal=float(arousal),
        persistent_emotions_available=persistent_emotions_available,
        persistent_emotions=persistent_emotions,
        arousal_sample_count=arousal_sample_count,
        arousal_date=arousal_date,
        active_goals_count=active_goals_count,
        profile_image_path=profile_image_path,
        updated_at=datetime.datetime.now(datetime.timezone.utc),
    )


def get_api_capabilities(room_id: str) -> ApiCapabilitiesResponse:
    _require_room(room_id)
    return ApiCapabilitiesResponse(room_id=room_id, endpoints=api_capabilities.capability_rows(room_id))


def _message_role_for_client(raw_role: str, responder: str) -> str:
    if raw_role == "USER":
        return "user"
    if raw_role == "AGENT":
        return "agent"
    return "system"


_LOG_METADATA_PATTERN = re.compile(
    r"(?:\n\n)?(?P<date>\d{4}-\d{2}-\d{2})\s*\([^)]+\)\s*"
    r"(?P<time>\d{2}:\d{2}:\d{2})(?:\s*\|\s*(?P<meta>.*))?\s*$"
)


def _message_metadata_for_client(content: str, role: str) -> tuple[Optional[datetime.datetime], Optional[str]]:
    match = _LOG_METADATA_PATTERN.search(content or "")
    if not match:
        return None, None
    timestamp = None
    try:
        timestamp = datetime.datetime.strptime(
            f"{match.group('date')} {match.group('time')}",
            "%Y-%m-%d %H:%M:%S",
        ).astimezone()
    except ValueError:
        timestamp = None
    metadata = str(match.group("meta") or "").strip()
    model = metadata if role == "agent" and metadata else None
    return timestamp, model


def _message_id_for_client(raw_role: str, responder: str, content: str) -> str:
    payload = f"{raw_role}\n{responder}\n{content}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:24]


def _message_content_for_client(content: str, role: str) -> str:
    text = utils.remove_ai_timestamp(content or "")
    text = re.sub(r"\[(?:Generated Image|ファイル添付|VIEW_IMAGE):\s*[^\]]+?\]", "", text, flags=re.DOTALL)
    if role == "agent":
        text = utils.clean_persona_text(text)
    else:
        text = re.sub(r"\n\n\d{4}-\d{2}-\d{2}\s+\([^)]+\)\s+\d{2}:\d{2}:\d{2}\s+\|.*$", "", text).strip()
    return text.strip()


def _message_thoughts_for_client(content: str, role: str, *, include_thoughts: bool) -> str:
    """Return only persisted, textual thought blocks for an authorized history opt-in."""
    if not include_thoughts or role != "agent":
        return ""

    text = utils.remove_ai_timestamp(content or "")
    text = re.sub(r"\[(?:Generated Image|ファイル添付|VIEW_IMAGE):\s*[^\]]+?\]", "", text, flags=re.DOTALL)
    thoughts = utils.extract_thoughts_from_text(text)
    if not thoughts:
        return ""
    # Keep the existing persona/tag scrubber, but do not remove the extracted thought
    # content itself a second time.
    return utils.clean_persona_text(thoughts, remove_thoughts=False).strip()


def _client_message_id_for_client(content: str) -> Optional[str]:
    match = re.search(r"\|\s*client_message_id=([A-Za-z0-9_.:-]+)", content or "")
    return match.group(1) if match else None


def _message_attachments_for_client(content: str) -> List[str]:
    paths: List[str] = []
    for match in re.finditer(r"\[(?:Generated Image|ファイル添付|VIEW_IMAGE):\s*([^\]]+?)\]", content or ""):
        path = match.group(1).strip()
        if path and path not in paths:
            paths.append(path)
    return paths


def _merge_attachment_paths(*groups: List[str]) -> List[str]:
    merged: List[str] = []
    for group in groups:
        for path in group:
            if path and path not in merged:
                merged.append(path)
    return merged


def _find_chat_response_by_client_message_id(room_id: str, log_file: str, client_message_id: str) -> Optional[ChatResponse]:
    if not client_message_id:
        return None
    try:
        messages = utils.load_chat_log(log_file)
    except Exception as e:
        logger.warning("Failed to read chat log for duplicate client_message_id check (%s): %s", room_id, e)
        return None

    user_index = -1
    for index, msg in enumerate(messages):
        if str(msg.get("role", "")).upper() != "USER":
            continue
        if _client_message_id_for_client(str(msg.get("content", ""))) == client_message_id:
            user_index = index

    if user_index < 0:
        return None

    response_text = ""
    response_attachments: List[str] = []
    model_name = None
    for msg in messages[user_index + 1:]:
        role = str(msg.get("role", "")).upper()
        if role == "USER":
            break
        if role != "AGENT":
            continue
        content = str(msg.get("content", ""))
        response_text = _message_content_for_client(content, "agent")
        response_attachments = _message_attachments_for_client(content)
        model_match = re.search(r"\|\s*([A-Za-z0-9_.:/-]+)\s*$", content)
        if model_match:
            model_name = model_match.group(1)
        break

    status = get_room_status(room_id)
    return ChatResponse(
        room_id=room_id,
        reply=response_text,
        arousal=status.arousal,
        expression=status.current_expression,
        timestamp=datetime.datetime.now(datetime.timezone.utc),
        suggested_actions=["view_generated_image"] if response_attachments else [],
        model=model_name,
        client_message_id=client_message_id,
        attachments=response_attachments,
    )


def get_recent_chat_history(
    room_id: str,
    limit: int = 12,
    *,
    include_thoughts: bool = False,
) -> ChatHistoryResponse:
    _require_room(room_id)
    log_file, _, _, _, _, _, _ = room_manager.get_room_files_paths(room_id)
    if not log_file:
        raise ValueError(f"Room log path is not available: {room_id}")

    # The default history contract stays thought-free.  Even an explicit client
    # opt-in is bounded by the room's existing display policy so the API cannot
    # bypass the desktop setting.
    thoughts_enabled = False
    if include_thoughts is True:
        try:
            effective_settings = config_manager.get_effective_settings(room_id)
            thoughts_enabled = effective_settings.get("display_thoughts", True) is True
        except Exception as exc:
            logger.warning("Failed to read thought display setting for %s: %s", room_id, exc)

    try:
        log_dir = os.path.dirname(log_file)
        room_dir = os.path.dirname(log_dir) if os.path.basename(log_dir) == constants.LOGS_DIR_NAME else log_dir
        raw_messages, _ = utils.load_chat_log_lazy(room_dir, limit=max(limit * 2, 20), min_turns=limit)
    except Exception:
        raw_messages = utils.load_chat_log(log_file)[-(limit * 2):]

    client_messages: List[ChatHistoryMessage] = []
    pending_tool_attachments: List[str] = []
    for msg in raw_messages:
        raw_role = str(msg.get("role", "")).upper()
        responder = str(msg.get("responder", ""))
        role = _message_role_for_client(raw_role, responder)
        raw_content = str(msg.get("content", ""))
        is_tool_result = role == "system" and (responder == "tool_result" or responder.startswith("tool_result:"))
        raw_marker = re.search(r"\[/?RAW_RESULT\b", raw_content)
        display_content = raw_content
        if role == "system" and raw_marker:
            # PC会話・自律行動は表示文と内部結果を同じエントリに保存する。
            # 内部結果以降は返さず、壊れた開きタグや孤立した閉じタグも保守的に扱う。
            if is_tool_result and not raw_marker.group().startswith("[/"):
                display_content = raw_content[:raw_marker.start()].strip()
            else:
                display_content = ""
        if is_tool_result:
            display_content = utils.clean_persona_text(display_content)
            if raw_marker and not re.match(
                r"^(?:🛠️|⚠️|#{1,6}\s*音楽推薦カード|新しい画像を生成しました。)(?:\s|$)",
                display_content,
            ):
                # 表示整形済みの案内だけを復元し、内部文が前置きされたログは除外。
                display_content = ""
        content = _message_content_for_client(display_content, role)
        thoughts = _message_thoughts_for_client(
            raw_content,
            role,
            include_thoughts=thoughts_enabled,
        )
        attachments = _message_attachments_for_client(raw_content)
        if is_tool_result and attachments:
            pending_tool_attachments = _merge_attachment_paths(pending_tool_attachments, attachments)
            # 案内文の行にも添付すると次のペルソナ応答と画像が二重になる。
            attachments = []
        if role == "system" and raw_marker and not display_content:
            continue
        if role == "user":
            pending_tool_attachments = []
        elif role == "agent" and pending_tool_attachments:
            attachments = _merge_attachment_paths(pending_tool_attachments, attachments)
            pending_tool_attachments = []
        if not content and not attachments and not thoughts:
            continue
        client_messages.append(
            ChatHistoryMessage(
                role=role,
                speaker=responder if role != "user" else "user",
                content=content,
                thoughts=thoughts,
                message_id=_message_id_for_client(raw_role, responder, raw_content),
                timestamp=_message_metadata_for_client(raw_content, role)[0],
                model=_message_metadata_for_client(raw_content, role)[1],
                client_message_id=_client_message_id_for_client(raw_content) if role == "user" else None,
                attachments=attachments,
            )
        )

    if pending_tool_attachments:
        attachment_payload = "\n".join(pending_tool_attachments)
        client_messages.append(
            ChatHistoryMessage(
                role="system",
                speaker="tool_result",
                content="",
                message_id=_message_id_for_client("SYSTEM", "tool_result", attachment_payload),
                attachments=pending_tool_attachments,
            )
        )

    return ChatHistoryResponse(room_id=room_id, messages=client_messages[-limit:])


def _build_agent_args_with_scenery_context(
    room_id: str,
    request: ChatRequest,
    log_file: str,
    *,
    skip_tool_execution: bool = False,
) -> tuple[Dict[str, Any], SceneryImageContext]:
    effective_settings = config_manager.get_effective_settings(room_id)
    season_en, time_of_day_en = utils._get_current_time_context(room_id)
    scenery_context = get_scenery_image_context(
        room_id,
        settings=effective_settings,
        season_en=season_en,
        time_of_day_en=time_of_day_en,
        include_virtual=False,
    )
    args = {
        "room_to_respond": room_id,
        "api_key_name": effective_settings.get("api_key_name") or config_manager.initial_api_key_name_global,
        "api_history_limit": effective_settings.get("api_history_limit") or constants.DEFAULT_API_HISTORY_LIMIT_OPTION,
        "debug_mode": False,
        "history_log_path": log_file,
        "user_prompt_parts": [*scenery_context.parts, request.message],
        "soul_vessel_room": room_id,
        "active_participants": [],
        "active_attachments": request.attachments,
        "shared_location_name": utils.get_current_location(room_id),
        "shared_scenery_text": None,
        "season_en": season_en,
        "time_of_day_en": time_of_day_en,
        "global_model_from_ui": config_manager.get_current_global_model(),
        "skip_tool_execution": skip_tool_execution,
        "enable_supervisor": False,
    }
    return args, scenery_context


def _build_agent_args(
    room_id: str,
    request: ChatRequest,
    log_file: str,
    *,
    skip_tool_execution: bool = False,
) -> Dict[str, Any]:
    """Build provider arguments without exposing scenery bookkeeping to it."""

    args, _ = _build_agent_args_with_scenery_context(
        room_id,
        request,
        log_file,
        skip_tool_execution=skip_tool_execution,
    )
    return args


def _scenery_response_succeeded(
    results: List[Any],
    response_text: str,
    response_attachments: List[str],
) -> bool:
    """Return whether the stream produced a completed, non-error response."""

    if not results:
        return False
    normalized = (response_text or "").strip()
    if normalized.startswith("[エラー") or normalized.startswith("[ERROR"):
        return False
    # A provider can complete with an attachment and no visible text.  Require
    # at least one streamed result so an empty/interrupted iterator is not
    # treated as delivery success.
    return bool(normalized or response_attachments)


def _visible_tool_result_for_client(msg: Any) -> Optional[tuple[str, str]]:
    if not isinstance(msg, ToolMessage):
        return None
    tool_name = getattr(msg, "name", "") or ""
    if not tool_name:
        return None
    formatted = utils.format_tool_result_for_ui(tool_name, str(getattr(msg, "content", "") or ""))
    if not formatted:
        return None
    header = f"## SYSTEM:tool_result:{tool_name}:{msg.tool_call_id or 'api'}"
    return header, formatted.strip()


def _extract_final_ai_response(results: List[Any]) -> tuple[str, Optional[str], List[str], List[tuple[str, str]]]:
    final_text = ""
    captured_model_name = None
    attachments: List[str] = []
    visible_tool_results: Dict[str, str] = {}
    for mode, payload in results:
        if mode != "values" or not isinstance(payload, dict):
            continue
        if payload.get("model_name"):
            captured_model_name = payload.get("model_name")
        messages = payload.get("messages") or []
        last_human_index = -1
        for idx, msg in enumerate(messages):
            if isinstance(msg, HumanMessage):
                last_human_index = idx
        current_turn_messages = messages[last_human_index + 1:] if last_human_index >= 0 else messages
        for msg in current_turn_messages:
            try:
                for path in _message_attachments_for_client(utils.get_content_as_string(msg)):
                    if path not in attachments:
                        attachments.append(path)
            except Exception:
                continue
            visible_tool_result = _visible_tool_result_for_client(msg)
            if visible_tool_result:
                header, content = visible_tool_result
                # checkpointで繰り返される同じcallは1件にし、別callは同文でも残す。
                visible_tool_results[header] = content
        ai_messages = [
            msg for msg in messages
            if isinstance(msg, AIMessage) and utils.get_content_as_string(msg).strip()
        ]
        if ai_messages:
            final_text = utils.get_content_as_string(ai_messages[-1])
    return final_text, captured_model_name, attachments, list(visible_tool_results.items())


def _reflect_response_metadata(room_id: str, response_text: str) -> None:
    persona_emotion_pattern = r'<persona_emotion\s+category=["\'](\w+)["\']\s+intensity=["\']([0-9.]+)["\']\s*/>'
    emotion_match = re.search(persona_emotion_pattern, response_text, re.IGNORECASE)
    if emotion_match:
        try:
            from motivation_manager import MotivationManager

            mm = MotivationManager(room_id)
            mm.set_persona_emotion(emotion_match.group(1).lower(), float(emotion_match.group(2)))
            mm._save_state()
        except Exception as e:
            logger.warning("Failed to reflect persona emotion for %s: %s", room_id, e)

    memory_trace_pattern = r'<memory_trace\s+id=["\']([^"\']+)["\']\s+resonance=["\']([0-9.]+)["\']\s*/>'
    trace_matches = re.findall(memory_trace_pattern, response_text, re.IGNORECASE)
    if trace_matches:
        try:
            from episodic_memory_manager import EpisodicMemoryManager

            manager = EpisodicMemoryManager(room_id)
            for episode_id, resonance_str in trace_matches:
                manager.update_arousal(episode_id, float(resonance_str))
        except Exception as e:
            logger.warning("Failed to update memory arousal for %s: %s", room_id, e)


def _run_chat(room_id: str, request: ChatRequest, *, skip_tool_execution: bool = False) -> ChatResponse:
    from api.lite_runtime_controls import lite_request_scope

    _require_room(room_id)
    with _get_room_lock(room_id):
        with lite_request_scope(room_id, request.client_message_id):
            return _run_chat_impl(room_id, request, skip_tool_execution=skip_tool_execution)


def _run_chat_impl(room_id: str, request: ChatRequest, *, skip_tool_execution: bool = False) -> ChatResponse:
    _require_room(room_id)
    if not request.message.strip():
        raise ValueError("message is required")
    if lite_travel.is_presence_locked(room_id):
        lite_travel.record_deferred_home_event(
            room_id,
            "api_chat_rejected",
            {"source": request.source or "api", "client_message_id": request.client_message_id or ""},
        )
        raise ValueError("このペルソナはLite独立お出かけ中です。帰宅統合または緊急帰還後に送信してください。")

    log_file, _, _, _, _, _, _ = room_manager.get_room_files_paths(room_id)
    if not log_file:
        raise ValueError(f"Room log path is not available: {room_id}")

    with _get_room_lock(room_id):
        timestamp_text = datetime.datetime.now().strftime("%Y-%m-%d (%a) %H:%M:%S")
        source = request.source or "api"
        client_message_id = (request.client_message_id or "").strip()
        existing_response = _find_chat_response_by_client_message_id(room_id, log_file, client_message_id)
        if existing_response is not None:
            logger.info("Skipped duplicate API chat request for %s client_message_id=%s", room_id, client_message_id)
            return existing_response
        client_id_suffix = f" | client_message_id={client_message_id}" if client_message_id else ""
        attachment_markers = []
        for attachment_path in request.attachments or []:
            if attachment_path:
                attachment_markers.append(f"[VIEW_IMAGE: {attachment_path}]")
        attachment_block = ("\n" + "\n".join(attachment_markers)) if attachment_markers else ""
        full_user_log_entry = f"{request.message}{attachment_block}\n\n{timestamp_text} | API:{source} | user_id={request.user_id}{client_id_suffix}"
        utils.save_message_to_log(log_file, "## USER:user", full_user_log_entry)

        internal_state_before = None
        try:
            from motivation_manager import MotivationManager

            internal_state_before = MotivationManager(room_id).get_state_snapshot()
        except Exception:
            internal_state_before = None

        agent_args, scenery_context = _build_agent_args_with_scenery_context(
            room_id,
            request,
            log_file,
            skip_tool_execution=skip_tool_execution,
        )
        results = list(gemini_api.invoke_nexus_agent_stream(agent_args))
        full_response, model_name, response_attachments, visible_tool_results = _extract_final_ai_response(results)
        effective_model_name = model_name or config_manager.get_current_global_model()
        for header, tool_result in visible_tool_results:
            utils.save_message_to_log(log_file, header, tool_result)
        cleaned_response = utils.remove_ai_timestamp(full_response).strip()
        if cleaned_response or response_attachments:
            if _scenery_response_succeeded(results, full_response, response_attachments):
                commit_scenery_image_context(room_id, scenery_context)
            if cleaned_response:
                _reflect_response_metadata(room_id, cleaned_response)
            ai_timestamp = datetime.datetime.now().strftime("%Y-%m-%d (%a) %H:%M:%S")
            response_attachment_block = "\n".join(
                f"[VIEW_IMAGE: {path}]" for path in response_attachments
            )
            response_body = cleaned_response
            if response_attachment_block:
                response_body = f"{response_body}\n{response_attachment_block}"
            content_to_log = f"{response_body}\n\n{ai_timestamp} | {utils.sanitize_model_name(effective_model_name)}"
            utils.save_message_to_log(log_file, f"## AGENT:{room_id}", content_to_log)

        arousal = 0.5
        try:
            from arousal_calculator import calculate_arousal
            from motivation_manager import MotivationManager
            import session_arousal_manager

            mm = MotivationManager(room_id)
            mm.update_last_interaction()
            if internal_state_before and cleaned_response:
                internal_state_after = mm.get_state_snapshot()
                arousal = float(calculate_arousal(internal_state_before, internal_state_after))
                session_arousal_manager.add_arousal_score(room_id, arousal, time_str=datetime.datetime.now().strftime("%H:%M:%S"))
        except Exception as e:
            logger.warning("Post chat metadata update failed for %s: %s", room_id, e)

    reply = utils.clean_persona_text(cleaned_response or full_response or "")
    if reply and source == "mobile_lite":
        push_result = send_push_to_room(room_id, "Nexus Ark Lite", _response_push_body(room_id, reply))
        if push_result.status not in {"sent", "no_subscriptions"}:
            logger.info("Lite PWA web push result for %s: %s", room_id, push_result)

    status = get_room_status(room_id)
    suggested_actions = ["view_generated_image"] if response_attachments else []
    return ChatResponse(
        room_id=room_id,
        reply=reply,
        arousal=arousal,
        expression=status.current_expression,
        timestamp=datetime.datetime.now(datetime.timezone.utc),
        suggested_actions=suggested_actions,
        model=effective_model_name,
        client_message_id=request.client_message_id,
        attachments=response_attachments,
    )


async def chat(room_id: str, request: ChatRequest) -> ChatResponse:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _run_chat, room_id, request)


def _run_regenerate(room_id: str, request: ChatRegenerateRequest) -> ChatResponse:
    """最新応答を、外部ツールを再実行せずに作り直す。"""
    _require_room(room_id)
    if lite_travel.is_presence_locked(room_id):
        raise ValueError("このペルソナはLite独立お出かけ中のため再生成できません。")
    log_file, _, _, _, _, _, _ = room_manager.get_room_files_paths(room_id)
    if not log_file:
        raise ValueError(f"Room log path is not available: {room_id}")

    with _get_room_lock(room_id):
        messages = utils.load_chat_log(log_file)
        target_index = next(
            (index for index in range(len(messages) - 1, -1, -1) if messages[index].get("role") == "AGENT"),
            -1,
        )
        if target_index < 0:
            raise ValueError("再生成できるAI応答がありません。")
        target = messages[target_index]
        expected_id = _message_id_for_client(
            "AGENT",
            str(target.get("responder", "")),
            str(target.get("content", "")),
        )
        if request.target_message_id != expected_id:
            raise ValueError("最新のAI応答だけ再生成できます。履歴を更新してください。")

        user_index = next(
            (index for index in range(target_index - 1, -1, -1) if messages[index].get("role") == "USER"),
            -1,
        )
        if user_index < 0:
            raise ValueError("再生成のための会話巻き戻しに失敗しました。")
        raw_user_content = str(messages[user_index].get("content", ""))
        restored_input = _message_content_for_client(raw_user_content, "user")
        room_dir = utils._get_room_dir_from_path(log_file)
        utils._create_temporary_log_backup(log_file)
        # 会話ログだけを巻き戻す。既に実行済みのツール・アイテム操作・Action Memoryは
        # 現実の状態として維持し、再生成時には skip_tool_execution で再実行しない。
        utils.truncate_chat_logs(room_dir, user_index)
        attachments = _message_attachments_for_client(raw_user_content)
        clean_input = re.sub(
            r"\[(?:Generated Image|ファイル添付|VIEW_IMAGE):\s*[^\]]+?\]",
            "",
            restored_input,
            flags=re.DOTALL,
        ).strip()
        regenerate_request = ChatRequest(
            user_id="mobile_lite",
            message=clean_input or "直前の内容にもう一度応答してください。",
            source="mobile_lite_regenerate",
            attachments=attachments,
            client_message_id=request.client_message_id or f"regen-{uuid.uuid4().hex}",
        )
        return _run_chat(room_id, regenerate_request, skip_tool_execution=True)


async def regenerate_chat(room_id: str, request: ChatRegenerateRequest) -> ChatResponse:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _run_regenerate, room_id, request)


async def save_upload(room_id: str, filename: str, content_type: str, data: bytes) -> UploadResponse:
    _require_room(room_id)
    if not data:
        raise ValueError("file is empty")
    if len(data) > _MAX_UPLOAD_BYTES:
        raise ValueError("file is too large")

    original_name = Path(filename or "upload").name
    suffix = Path(original_name).suffix.lower()
    if suffix not in _ALLOWED_UPLOAD_EXTENSIONS:
        raise ValueError("only image uploads are supported")
    if content_type and not content_type.startswith("image/"):
        raise ValueError("only image uploads are supported")

    upload_dir = Path(constants.ROOMS_DIR) / room_id / "attachments" / "api_uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", Path(original_name).stem).strip("._") or "image"
    saved_path = upload_dir / f"{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}_{safe_name}{suffix}"
    saved_path.write_bytes(data)

    return UploadResponse(
        attachment_id=str(saved_path),
        filename=original_name,
        mime_type=content_type or "application/octet-stream",
        size=len(data),
    )


def _cleanup_cached_audio(audio_dir: Path, suffix: str) -> None:
    try:
        keep_count = int(config_manager.CONFIG_GLOBAL.get("voice_input_audio_rotation_count", 10) or 10)
    except Exception:
        keep_count = 10
    try:
        audio_files = sorted(
            [path for path in audio_dir.glob(f"*{suffix}") if path.is_file()],
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
        for old_path in audio_files[max(1, keep_count):]:
            old_path.unlink(missing_ok=True)
    except Exception as e:
        logger.debug("Failed to clean API voice input cache: %s", e)


def _save_voice_input(room_id: str, filename: str, content_type: str, data: bytes) -> tuple[Path, str]:
    _require_room(room_id)
    if not data:
        raise ValueError("audio file is empty")
    if len(data) > _MAX_AUDIO_UPLOAD_BYTES:
        raise ValueError("audio file is too large")

    original_name = Path(filename or "voice.webm").name
    suffix = Path(original_name).suffix.lower()
    base_content_type = (content_type or "").split(";", 1)[0].strip().lower()
    if suffix not in _ALLOWED_AUDIO_EXTENSIONS:
        if base_content_type == "audio/webm":
            suffix = ".webm"
        elif base_content_type == "audio/wav":
            suffix = ".wav"
        elif base_content_type == "audio/mpeg":
            suffix = ".mp3"
        elif base_content_type in {"audio/mp4", "audio/x-m4a"}:
            suffix = ".m4a"
        elif base_content_type == "audio/ogg":
            suffix = ".ogg"
        else:
            raise ValueError("only audio uploads are supported")
    if base_content_type and not (base_content_type.startswith("audio/") or base_content_type == "video/webm"):
        raise ValueError("only audio uploads are supported")

    audio_dir = Path(constants.ROOMS_DIR) / room_id / "audio_cache" / "voice_input" / "api"
    audio_dir.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", Path(original_name).stem).strip("._") or "voice"
    saved_path = audio_dir / f"voice_api_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}_{safe_name}{suffix}"
    saved_path.write_bytes(data)
    _cleanup_cached_audio(audio_dir, suffix)
    normalized_mime = base_content_type or {
        ".wav": "audio/wav",
        ".mp3": "audio/mpeg",
        ".m4a": "audio/mp4",
        ".mp4": "audio/mp4",
        ".webm": "audio/webm",
        ".ogg": "audio/ogg",
    }.get(suffix, "audio/wav")
    if normalized_mime == "video/webm":
        normalized_mime = "audio/webm"
    return saved_path, normalized_mime


def _transcribe_voice_sync(room_id: str, filename: str, content_type: str, data: bytes) -> TranscriptionResponse:
    audio_path, mime_type = _save_voice_input(room_id, filename, content_type, data)
    effective_settings = config_manager.get_effective_settings(room_id)
    api_key_name = effective_settings.get("api_key_name") or config_manager.initial_api_key_name_global
    api_key = config_manager.GEMINI_API_KEYS.get(api_key_name, "")
    if not api_key:
        raise ValueError("Gemini API key is not configured")

    import stt_manager

    # Lite PWA voice input is intentionally independent from hidden Discord voice-input settings.
    # Some rooms may still have legacy values such as "openai:whisper-1" there.
    normalized_model_name = constants.DISCORD_VOICE_STT_MODEL
    try:
        result = stt_manager.transcribe_audio_file_detailed(
            str(audio_path),
            api_key,
            model_name=normalized_model_name or constants.DISCORD_VOICE_STT_MODEL,
            mime_type=mime_type,
        )
    except stt_manager.SttApiError as e:
        raise ValueError(str(e)) from e
    transcript = (getattr(result, "text", "") or "").strip()
    if not transcript:
        return TranscriptionResponse(text="", provider="gemini", model=getattr(result, "model_name", normalized_model_name), uncertain=False)
    return TranscriptionResponse(
        text=transcript,
        provider="gemini",
        model=getattr(result, "model_name", normalized_model_name),
        uncertain=bool(getattr(result, "uncertain", False)),
    )


async def transcribe_voice(room_id: str, filename: str, content_type: str, data: bytes) -> TranscriptionResponse:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _transcribe_voice_sync, room_id, filename, content_type, data)


def _resolve_tts_settings(room_id: str) -> Dict[str, Any]:
    effective_settings = config_manager.get_effective_settings(room_id)
    provider = config_manager.tts_provider_key_from_display(effective_settings.get("tts_provider", "gemini"))
    model = (effective_settings.get("tts_model") or "").strip()
    provider_models = config_manager.get_tts_model_choices(provider)
    if provider_models and model not in provider_models:
        model = provider_models[0]
    voice_source = effective_settings.get("tts_voice") or effective_settings.get("voice_id", "iapetus")
    if provider != "gemini" and voice_source in config_manager.SUPPORTED_VOICES:
        voice_choices = config_manager.get_tts_voice_map(provider)
        voice_source = next(iter(voice_choices.keys()), voice_source)
    voice_id = config_manager.resolve_tts_voice_id(provider, voice_source) or str(voice_source)
    style_prompt = effective_settings.get("tts_style_prompt", effective_settings.get("voice_style_prompt", "")) or ""
    response_format = effective_settings.get("tts_response_format") or ("wav" if provider == "gemini" else "mp3")
    api_key = None
    base_url = None
    extra_body = None

    if provider == "gemini":
        api_key_name = effective_settings.get("api_key_name") or config_manager.initial_api_key_name_global
        api_key = config_manager.GEMINI_API_KEYS.get(api_key_name)
        model = model or "gemini-3.1-flash-tts-preview"
        response_format = "wav"
    elif provider == "openai":
        openai_setting = (
            config_manager.get_openai_setting_by_name("OpenAI Official")
            or config_manager.get_openai_setting_by_name("OpenAI")
            or config_manager.get_active_openai_setting()
        )
        if openai_setting:
            api_key = openai_setting.get("api_key")
            base_url = openai_setting.get("base_url") or None
        model = model or "gpt-4o-mini-tts"
        response_format = response_format or "mp3"
    elif provider == "openai_compatible":
        openai_setting = config_manager.get_active_openai_setting()
        if openai_setting:
            api_key = openai_setting.get("api_key")
            base_url = openai_setting.get("base_url") or None
            if not model:
                model = openai_setting.get("tts_model") or openai_setting.get("default_model") or "canopylabs/orpheus-v1-english"
            extra_body = openai_setting.get("tts_extra_body")
        response_format = response_format or "wav"
    elif provider == "elevenlabs":
        api_key = config_manager.CONFIG_GLOBAL.get("elevenlabs_api_key")
        model = model or "eleven_flash_v2_5"
        response_format = "mp3" if response_format == "wav" else (response_format or "mp3")
    elif provider in {"aivisspeech", "voicevox", "coeiroink"}:
        api_key = "LOCAL_VOICEVOX_COMPATIBLE"
        model = model or (config_manager.get_tts_model_choices(provider)[0] if config_manager.get_tts_model_choices(provider) else "")
        response_format = "wav"

    return {
        "provider": provider,
        "model": model,
        "voice_id": voice_id,
        "style_prompt": style_prompt,
        "api_key": api_key,
        "api_key_name": api_key_name if provider == "gemini" else None,
        "base_url": base_url,
        "response_format": response_format,
        "extra_body": extra_body,
    }


def _synthesize_speech_sync(room_id: str, request: TtsRequest) -> TtsResponse:
    _require_room(room_id)
    text_plan = prepare_tts_text_plan(request.text, request.mode, request.max_chars)
    if not text_plan.segments:
        raise ValueError("text is required")

    settings = _resolve_tts_settings(room_id)
    resolved_paths: List[Path] = []
    partial_notice = ""
    for index, segment in enumerate(text_plan.segments, start=1):
        audio_path = generate_audio_with_key_rotation(segment, room_id, settings)
        if not audio_path or str(audio_path).startswith("【エラー】"):
            if text_plan.mode == "split" and resolved_paths:
                partial_notice = (
                    f"{text_plan.notice or ''} "
                    f"{index}分割目の音声生成に失敗したため、生成済みの{len(resolved_paths)}分割だけ再生できます。"
                ).strip()
                logger.warning("Partial TTS response for %s: %s", room_id, audio_path or "no audio path")
                break
            raise ValueError(str(audio_path or "音声の生成に失敗しました。"))
        resolved_paths.append(resolve_audio_path(str(audio_path)))

    audio_ids = [str(path) for path in resolved_paths]
    mime_type = mimetypes.guess_type(str(resolved_paths[0]))[0] or "audio/wav"
    return TtsResponse(
        audio_id=audio_ids[0],
        audio_ids=audio_ids,
        mime_type=mime_type,
        provider=settings["provider"],
        model=settings["model"],
        voice=settings["voice_id"],
        mode=text_plan.mode,
        segment_count=len(audio_ids),
        truncated=text_plan.truncated or bool(partial_notice),
        notice=partial_notice or text_plan.notice or None,
    )


async def synthesize_speech(room_id: str, request: TtsRequest) -> TtsResponse:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _synthesize_speech_sync, room_id, request)


def resolve_asset_path(path: str) -> Path:
    requested = Path(path or "").expanduser()
    if not requested.exists() or not requested.is_file():
        raise ValueError("asset not found")

    try:
        resolved = requested.resolve()
        cwd = Path.cwd().resolve()
        tmp = Path(tempfile.gettempdir()).resolve()
        if not (resolved.is_relative_to(cwd) or resolved.is_relative_to(tmp)):
            raise ValueError("asset path is not allowed")
    except AttributeError:
        resolved_str = str(requested.resolve())
        if not (resolved_str.startswith(str(Path.cwd().resolve())) or resolved_str.startswith(str(Path(tempfile.gettempdir()).resolve()))):
            raise ValueError("asset path is not allowed")

    kind = filetype.guess(str(requested))
    if not (kind and kind.mime.startswith("image/")):
        raise ValueError("asset is not an image")
    return requested


def resolve_room_asset_path(room_id: str, path: str) -> Path:
    _require_room(room_id)
    requested = resolve_asset_path(path)
    resolved = requested.resolve()
    room_root = (Path(constants.ROOMS_DIR) / room_id).resolve()
    try:
        resolved.relative_to(room_root)
    except ValueError as exc:
        raise ValueError("asset does not belong to this room") from exc
    return requested


def resolve_audio_path(path: str) -> Path:
    requested = Path(path or "").expanduser()
    if not requested.exists() or not requested.is_file():
        raise ValueError("audio not found")

    try:
        resolved = requested.resolve()
        cwd = Path.cwd().resolve()
        tmp = Path(tempfile.gettempdir()).resolve()
        if not (resolved.is_relative_to(cwd) or resolved.is_relative_to(tmp)):
            raise ValueError("audio path is not allowed")
    except AttributeError:
        resolved_str = str(requested.resolve())
        if not (resolved_str.startswith(str(Path.cwd().resolve())) or resolved_str.startswith(str(Path(tempfile.gettempdir()).resolve()))):
            raise ValueError("audio path is not allowed")

    suffix = requested.suffix.lower()
    guessed_type = mimetypes.guess_type(str(requested))[0] or ""
    if suffix not in _ALLOWED_TTS_EXTENSIONS and not guessed_type.startswith("audio/"):
        raise ValueError("asset is not audio")
    return requested


def resolve_room_audio_path(room_id: str, path: str) -> Path:
    _require_room(room_id)
    requested = resolve_audio_path(path)
    resolved = requested.resolve()
    audio_root = (Path(constants.ROOMS_DIR) / room_id / "audio_cache").resolve()
    try:
        resolved.relative_to(audio_root)
    except ValueError as exc:
        raise ValueError("audio does not belong to this room") from exc
    return requested


def record_event(room_id: str, request: EventRequest) -> EventResponse:
    _require_room(room_id)
    log_file, _, _, _, _, _, _ = room_manager.get_room_files_paths(room_id)
    if not log_file:
        raise ValueError(f"Room log path is not available: {room_id}")

    timestamp_text = datetime.datetime.now().strftime("%Y-%m-%d (%a) %H:%M:%S")
    summary_line = f"- summary: {request.summary}\n" if request.summary else ""
    attachments_line = f"- attachments: {request.attachments}\n" if request.attachments else ""
    event_text = (
        f"外部イベントを受信しました。\n"
        f"- type: {request.event_type}\n"
        f"- source: {request.source}\n"
        f"- importance: {request.importance}\n"
        f"{summary_line}"
        f"{attachments_line}"
        f"- data: {request.event_data}\n\n"
        f"{timestamp_text} | API:event"
    )
    utils.save_message_to_log(log_file, "## SYSTEM:external_event", event_text)

    notification_status = "not_requested"
    notification_text = None
    if request.trigger_notification:
        notification_status, notification_text = _handle_event_notification(room_id, request, log_file)

    return EventResponse(
        status="success",
        should_interact=bool(request.trigger_notification),
        notification_text=notification_text,
        notification_status=notification_status,
    )


def _event_notification_candidate(request: EventRequest) -> bool:
    settings = _event_notification_settings()
    if not settings.enabled:
        return False
    minimum = _EVENT_IMPORTANCE_ORDER.get(settings.minimum_importance, _EVENT_IMPORTANCE_ORDER["high"])
    importance = _EVENT_IMPORTANCE_ORDER.get(request.importance, 0)
    return bool(request.trigger_notification and importance >= minimum)


def _coerce_event_notification_cooldown(value: Any, fallback: int) -> int:
    try:
        seconds = int(value)
    except (TypeError, ValueError):
        return fallback
    return max(0, min(seconds, 24 * 60 * 60))


def _get_event_notification_cooldown_seconds(source: str) -> int:
    settings = config_manager.CONFIG_GLOBAL.get("api_gateway_settings", {}) or {}
    default_seconds = _coerce_event_notification_cooldown(
        settings.get("event_notification_default_cooldown_seconds", _DEFAULT_EVENT_NOTIFICATION_DEDUPE_SECONDS),
        _DEFAULT_EVENT_NOTIFICATION_DEDUPE_SECONDS,
    )
    cooldowns = settings.get("event_notification_cooldowns") or {}
    if not isinstance(cooldowns, dict):
        return default_seconds

    source_key = (source or "").strip()
    raw_value = None
    for candidate in (source_key, source_key.lower(), "*"):
        if candidate and candidate in cooldowns:
            raw_value = cooldowns[candidate]
            break
    if raw_value is None:
        return default_seconds
    return _coerce_event_notification_cooldown(raw_value, default_seconds)


def _build_event_notification_text(room_id: str, request: EventRequest) -> str:
    summary = (request.summary or "").strip() or f"外部イベント「{request.event_type}」を受信しました。"
    metadata = f"source={request.source} / importance={request.importance} / room={room_id}"
    return f"{summary}\n\n{metadata}"


def _build_event_push_body(request: EventRequest) -> str:
    return (request.summary or "").strip() or f"外部イベント「{request.event_type}」を受信しました。"


def _save_event_notification_audit(log_file: str, request: EventRequest, status: str, detail: str = "") -> None:
    timestamp_text = datetime.datetime.now().strftime("%Y-%m-%d (%a) %H:%M:%S")
    detail_line = f"- detail: {detail}\n" if detail else ""
    audit_text = (
        f"外部イベント通知判定。\n"
        f"- type: {request.event_type}\n"
        f"- source: {request.source}\n"
        f"- importance: {request.importance}\n"
        f"- notification_status: {status}\n"
        f"{detail_line}\n"
        f"{timestamp_text} | API:event_notification"
    )
    utils.save_message_to_log(log_file, "## SYSTEM:external_event_notification", audit_text)


def _handle_event_notification(room_id: str, request: EventRequest, log_file: str) -> tuple[str, str]:
    settings = _event_notification_settings()
    if not settings.enabled:
        status = "skipped_disabled"
        detail = "外部イベント通知設定がOFFのため通知しません。"
        _save_event_notification_audit(log_file, request, status, detail)
        return status, detail

    if not _event_notification_candidate(request):
        status = "skipped_importance"
        detail = f"trigger_notification=true ですが importance が {settings.minimum_importance} 以上ではないため通知しません。"
        _save_event_notification_audit(log_file, request, status, detail)
        return status, detail

    now = datetime.datetime.now(datetime.timezone.utc)
    dedupe_key = (room_id, request.source, request.event_type)
    last_sent = _event_notification_last_sent.get(dedupe_key)
    cooldown_seconds = _get_event_notification_cooldown_seconds(request.source)
    if cooldown_seconds > 0 and last_sent and (now - last_sent).total_seconds() < cooldown_seconds:
        status = "suppressed_duplicate"
        detail = f"{cooldown_seconds}秒以内の重複イベントのため通知を抑制しました。"
        _save_event_notification_audit(log_file, request, status, detail)
        return status, detail

    notification_text = _build_event_notification_text(room_id, request)
    delivery_details: list[str] = []
    delivered = False
    failure_details: list[str] = []

    try:
        import alarm_manager

        result = alarm_manager.send_notification(
            room_manager.get_character_name(room_id),
            notification_text,
            {"source": "api_event", "importance": request.importance, "event_type": request.event_type},
            notification_kind="notification",
        )
        success = bool(result.get("success")) if isinstance(result, dict) else bool(result)
        if success:
            delivered = True
            delivery_details.append("notification_service=sent")
        else:
            failure_details.append(f"notification_service={result}")
    except Exception as e:
        logger.warning("API event notification failed for %s/%s: %s", room_id, request.event_type, e)
        failure_details.append(f"notification_service={e}")

    try:
        push_result = send_push_to_room(
            room_id,
            "Nexus Ark Lite",
            _build_event_push_body(request),
            url="/lite/",
        )
        if push_result.sent > 0:
            delivered = True
            delivery_details.append(f"web_push={push_result.status} sent={push_result.sent} failed={push_result.failed}")
        elif push_result.status != "no_subscriptions":
            failure_details.append(f"web_push={push_result.status} {push_result.detail}".strip())
        else:
            delivery_details.append("web_push=no_subscriptions")
    except Exception as e:
        logger.warning("API event web push failed for %s/%s: %s", room_id, request.event_type, e)
        failure_details.append(f"web_push={e}")

    if delivered:
        _event_notification_last_sent[dedupe_key] = now
        status = "sent"
        detail = "; ".join(delivery_details + failure_details)
        _save_event_notification_audit(log_file, request, status, detail)
        return status, notification_text

    status = "failed"
    detail = "; ".join(failure_details) or "no notification delivery succeeded"
    _save_event_notification_audit(log_file, request, status, detail)
    return status, f"通知送信に失敗しました: {detail}"


def search_memory(room_id: str, query: str, limit: int = 5) -> MemorySearchResponse:
    _require_room(room_id)
    results: List[Dict[str, Any]] = []
    api_key_name = config_manager.get_effective_settings(room_id).get("api_key_name") or config_manager.initial_api_key_name_global
    api_key = config_manager.GEMINI_API_KEYS.get(api_key_name, "")
    try:
        from rag_manager import RAGManager

        manager = RAGManager(room_id, api_key)
        for doc in manager.search(query, k=max(1, min(limit, 20)), scope="memory")[:limit]:
            results.append(
                {
                    "type": doc.metadata.get("source_type", doc.metadata.get("type", "rag")),
                    "content": doc.page_content,
                    "metadata": doc.metadata,
                }
            )
    except Exception as e:
        logger.warning("RAG search failed for %s: %s", room_id, e)
        log_file, _, _, _, _, _, _ = room_manager.get_room_files_paths(room_id)
        recent_messages = utils.load_chat_log(log_file)[-100:] if log_file and os.path.exists(log_file) else []
        query_lower = query.lower()
        for msg in recent_messages:
            content = msg.get("content", "")
            if query_lower in content.lower():
                results.append({"type": "chat_log", "content": content[:1000], "metadata": {"role": msg.get("role")}})
            if len(results) >= limit:
                break
    return MemorySearchResponse(query=query, results=results)


def _parse_notes_entries(content: str) -> List[Dict[str, Any]]:
    """タイムスタンプセクションでノートをパースしてエントリリストを返す。"""
    import re
    entries = []
    # 区切り線(---)の後にタイムスタンプが続く場合のみ分割
    sections = re.split(r'\n---+\n\s*(?=📝|\[)', content)

    for section in sections:
        section = section.strip()
        if not section:
            continue

        match1 = re.search(r'📝\s*(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})', section)
        match2 = re.search(r'\[(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\]', section)

        if match1:
            date_str = match1.group(1)
            time_str = match1.group(2)
            timestamp = f"{date_str} {time_str}"
            content_start = match1.end()
            entry_content = section[content_start:].strip()
        elif match2:
            date_str = match2.group(1)
            time_str = match2.group(2)
            timestamp = f"{date_str} {time_str}"
            content_start = match2.end()
            entry_content = section[content_start:].strip()
        else:
            timestamp = "日付なし"
            date_str = ""
            entry_content = section

        if entry_content:
            entries.append({
                "timestamp": timestamp,
                "date": date_str,
                "content": entry_content,
                "raw_section": section
            })

    return entries[::-1]


def list_letters(room_id: str, limit: int = 100) -> LetterListResponse:
    """手紙箱の一覧を返す（新しい順・既定100通）。"""
    _require_room(room_id)
    letters = letterbox_manager.list_letters(room_id, limit=limit)
    return LetterListResponse(
        room_id=room_id,
        unread_count=letterbox_manager.unread_count(room_id),
        letters=[
            LetterSummary(
                id=letter.get("id", ""),
                title=letter.get("title", ""),
                created_at=letter.get("created_at", ""),
                read=bool(letter.get("read_at")),
            )
            for letter in letters
        ],
    )


def get_letter(room_id: str, letter_id: str, *, mark_read: bool = True) -> LetterDetailResponse:
    """手紙の本文を返す。既定では本体UIと同様に開いた時点で既読化する。"""
    _require_room(room_id)
    if mark_read:
        letter = letterbox_manager.mark_read(room_id, letter_id)
    else:
        letter = letterbox_manager.get_letter(room_id, letter_id)
    if not letter:
        raise ValueError(f"Letter not found: {letter_id}")
    return LetterDetailResponse(
        room_id=room_id,
        id=letter.get("id", ""),
        title=letter.get("title", ""),
        body=letter.get("body", ""),
        created_at=letter.get("created_at", ""),
        read_at=letter.get("read_at"),
    )


def get_note(room_id: str, note_type: str, *, headings_only: bool = False, heading: str = "") -> NoteResponse:
    _require_room(room_id)
    normalized_type = str(note_type or "").strip().lower()
    if normalized_type not in {"research", "creative", "diary", "notepad"}:
        raise ValueError("note_type must be research, creative, diary or notepad")
    paths = room_manager.get_room_files_paths(room_id)
    if normalized_type == "research":
        note_path = Path(paths[6]) if paths and paths[6] else None
        title = "研究ノート"
    elif normalized_type == "creative":
        note_path = Path(room_manager.get_creative_notes_path(room_id))
        title = "創作ノート"
    elif normalized_type == "diary":
        note_path = Path(paths[4]) if paths and paths[4] else None
        title = "日記"
    else:
        note_path = Path(paths[5]) if paths and paths[5] else None
        title = "メモ帳"

    content = ""
    full_content = ""
    current_hash = note_storage.content_hash(full_content)
    updated_at = None
    size = 0
    headings: List[str] = []
    if note_path and note_path.exists():
        size = note_path.stat().st_size
        full_content = safe_text_read(note_path.as_posix())
        current_hash = note_storage.content_hash(full_content)
        updated_at = datetime.datetime.fromtimestamp(note_path.stat().st_mtime, datetime.timezone.utc)
        
        entries = _parse_notes_entries(full_content)
        
        # エントリのラベル（ヘッダー）を作成
        headings = []
        for entry in entries:
            preview = entry["content"][:30].replace("\n", " ")
            if len(entry["content"]) > 30:
                preview += "..."
            label = f"{entry['timestamp']} - {preview}" if entry['timestamp'] != "日付なし" else preview[:30]
            headings.append(label)

        if headings_only:
            content = ""
        elif heading:
            matched_content = ""
            # 完全一致での探索
            for entry, label in zip(entries, headings):
                if label == heading or entry['timestamp'] == heading:
                    matched_content = entry["content"]
                    break
            
            # 部分一致（タイムスタンプ一致など）での探索
            if not matched_content:
                for entry, label in zip(entries, headings):
                    if heading.startswith(entry['timestamp']) or entry['timestamp'].startswith(heading):
                        matched_content = entry["content"]
                        break
            
            content = matched_content if matched_content else f"指定されたエントリ「{heading}」が見つかりませんでした。"
        else:
            content = full_content

    return NoteResponse(
        room_id=room_id,
        note_type=normalized_type,
        title=title,
        content=content,
        content_hash=current_hash,
        updated_at=updated_at,
        size=size,
        headings=headings,
        editable=normalized_type in {"research", "creative"},
    )


def update_note(room_id: str, note_type: str, request: NoteUpdateRequest) -> NoteResponse:
    """Replace a user-editable Lite note.

    Only the GET-supported research/creative notes are writable here. Append-only
    or system-managed notes such as diaries are excluded because full replacement
    would contradict their data model.
    """
    _require_room(room_id)
    normalized_type = note_storage.normalize_note_type(note_type)
    current_content = note_storage.read_note_content(room_id, normalized_type)
    current_hash = note_storage.content_hash(current_content)
    if request.base_hash and request.base_hash != current_hash:
        raise NoteConflictError("Note was updated elsewhere. Reload before saving.")
    try:
        note_storage.write_note_content(room_id, normalized_type, request.content, expected_hash=request.base_hash)
    except note_storage.NoteWriteConflictError as e:
        raise NoteConflictError(str(e)) from e
    return get_note(room_id, normalized_type)


def _item_summary(item: Dict[str, Any], target: str, location: str = "") -> ItemSummary:
    item_type = "food" if "taste_profile" in item else "standard"
    return ItemSummary(
        id=str(item.get("id") or ""),
        name=str(item.get("name") or ""),
        amount=max(0, int(item.get("amount") or 0)),
        category=str(item.get("category") or ""),
        item_type=item_type,
        description=str(item.get("flavor_text") or item.get("description") or ""),
        image_path=str(item.get("image_path") or "") or None,
        target=target,
        location=location,
        furniture=str(item.get("placed_at_furniture") or ""),
    )


def list_items(room_id: str, target: str = "user", location: str = "") -> ItemListResponse:
    _require_room(room_id)
    normalized_target = str(target or "user").strip().lower()
    if normalized_target not in {"user", "persona", "location"}:
        raise ValueError("target must be user, persona or location")
    from src.features.item_manager import ItemManager

    manager = ItemManager(room_id)
    effective_location = str(location or "").strip()
    if normalized_target == "location":
        effective_location = effective_location or (utils.get_current_location(room_id) or "")
        raw_items = manager.list_placed_items(room_id, effective_location)
    else:
        raw_items = manager.get_inventory(is_user=normalized_target == "user")
    return ItemListResponse(
        room_id=room_id,
        target=normalized_target,
        location=effective_location,
        items=[_item_summary(item, normalized_target, effective_location) for item in raw_items],
    )


def _item_action_receipts_path(room_id: str) -> Path:
    return Path(constants.ROOMS_DIR) / room_id / "memory" / "api_item_action_receipts.json"


def _load_item_action_receipt(room_id: str, client_action_id: str) -> Optional[ItemActionResponse]:
    store = safe_json_read(_item_action_receipts_path(room_id).as_posix(), default={})
    raw = store.get(client_action_id) if isinstance(store, dict) else None
    if not isinstance(raw, dict):
        return None
    raw = dict(raw)
    raw["replayed"] = True
    return ItemActionResponse.model_validate(raw)


def _save_item_action_receipt(room_id: str, response: ItemActionResponse) -> None:
    path = _item_action_receipts_path(room_id)
    store = safe_json_read(path.as_posix(), default={})
    if not isinstance(store, dict):
        store = {}
    store[response.client_action_id] = response.model_dump(mode="json")
    if len(store) > 100:
        store = dict(list(store.items())[-100:])
    safe_json_write(path.as_posix(), store)


def _item_action_context(action: str, item: Dict[str, Any], amount: int, location: str = "") -> str:
    if action in {"gift", "place", "pickup"}:
        # 贈与・配置・拾得は本体同様、ユーザー入力へ本文を追加しない。
        return ""
    if action == "consume_location" and "taste_profile" not in item:
        # 本体の場所消費UIは食べ物だけチャット入力へ詳細を追加する。
        return ""
    if action in {"consume", "consume_location"}:
        # 本体の所持品消費UIは、通常アイテムを含む選択肢すべてで本文・画像を返す。
        from src.features.item_manager import build_consumed_item_chat_input

        return build_consumed_item_chat_input(
            item,
            amount,
            include_amount=action == "consume_location",
        )
    return ""


def _item_system_notification(action: str, item: Dict[str, Any], amount: int, location: str = "") -> str:
    """本体チャットに記録する、操作結果の短いシステム通知を返す。"""
    name = str(item.get("name") or "アイテム")
    if action == "gift":
        amount_text = f"（{amount}個）" if amount != 1 else ""
        return f"【システム通知】ユーザーがアイテム「{name}」{amount_text}をあなたに贈りました。"
    return ""


def _item_action_log_context(action: str, item: Dict[str, Any], amount: int, location: str = "") -> str:
    """本体のアクションログに相当する、操作結果の短い記録を返す。"""
    if action == "gift":
        name = str(item.get("name") or "アイテム")
        return f"ユーザーから「{name}」を受け取りました。"
    return ""


def perform_item_action(room_id: str, request: ItemActionRequest) -> ItemActionResponse:
    _require_room(room_id)
    with _get_room_lock(room_id):
        replay = _load_item_action_receipt(room_id, request.client_action_id)
        if replay:
            return replay

        from src.features.item_manager import ItemManager

        manager = ItemManager(room_id)
        action = request.action
        amount = int(request.amount)
        location = str(request.location or utils.get_current_location(room_id) or "").strip()
        furniture = str(request.furniture or "").strip()
        source_is_location = action in {"pickup", "consume_location"}
        if source_is_location:
            source_items = manager.list_placed_items(room_id, location)
            item = next(
                (
                    value for value in source_items
                    if value.get("id") == request.item_id
                    and str(value.get("placed_at_furniture") or "") == furniture
                ),
                None,
            )
        else:
            item = manager.get_item(request.item_id, is_user=True)
        if not item:
            raise ValueError("アイテムが見つかりません。")
        if int(item.get("amount") or 0) < amount:
            raise ValueError("アイテムの数量が不足しています。")
        item_snapshot = dict(item)

        success = False
        if action == "gift":
            success = all(manager.transfer_item(request.item_id, from_user=True) for _ in range(amount))
        elif action == "consume":
            success = all(manager.consume_item(request.item_id, is_user=True) is not None for _ in range(amount))
        elif action == "place":
            if not location:
                raise ValueError("配置先の現在地がありません。")
            success = manager.place_item(
                request.item_id,
                room_id,
                location,
                furniture_name=furniture,
                amount=amount,
                is_user=True,
            )
        elif action == "pickup":
            success = manager.pickup_item(
                request.item_id,
                room_id,
                location,
                furniture_name=furniture,
                amount=amount,
                is_user=True,
            )
        elif action == "consume_location":
            success = manager.consume_item_at_location(
                request.item_id,
                room_id,
                location,
                furniture_name=furniture,
                amount=amount,
                is_user=True,
            ) is not None
        if not success:
            raise ValueError("アイテム操作に失敗しました。")

        chat_context = _item_action_context(action, item_snapshot, amount, location)
        # 贈与だけは本体同様にシステム通知と受取アクションログを残す。
        # 配置・拾得は本体のUIと同じく永続化だけで、消費は入力本文へ返す。
        if action == "gift":
            utils.append_system_message_to_log(
                room_id,
                _item_system_notification(action, item_snapshot, amount, location),
            )
            try:
                import action_logger

                action_logger.append_action_log(
                    room_id,
                    "system_event",
                    {"event": f"item_{action}", "client_action_id": request.client_action_id},
                    _item_action_log_context(action, item_snapshot, amount, location),
                )
            except Exception as exc:
                logger.warning("Failed to write item action log for %s: %s", room_id, exc)

        response = ItemActionResponse(
            room_id=room_id,
            action=action,
            detail="アイテム操作を完了しました。",
            item=_item_summary(item_snapshot, "location" if source_is_location else "user", location),
            chat_context=chat_context,
            client_action_id=request.client_action_id,
        )
        _save_item_action_receipt(room_id, response)
        return response


def get_calendar_events(room_id: str, days: int = 7) -> CalendarEventsResponse:
    _require_room(room_id)
    try:
        import google_calendar_service
        import pytz
    except Exception:
        return CalendarEventsResponse(room_id=room_id, events=[])

    settings = google_calendar_service._get_settings()
    if not settings.get("enabled") or not settings.get("refresh_token"):
        return CalendarEventsResponse(room_id=room_id, events=[])

    room_cfg = google_calendar_service.get_room_calendar_override(room_id)
    if not room_cfg.get("inject_context", True):
        return CalendarEventsResponse(room_id=room_id, events=[])

    try:
        tz = pytz.timezone("Asia/Tokyo")
    except Exception:
        tz = datetime.timezone(datetime.timedelta(hours=9))

    now = datetime.datetime.now(datetime.timezone.utc)
    horizon = now + datetime.timedelta(days=max(1, min(int(days or 7), 31)))
    visible = room_cfg.get("visible_calendars")
    if visible is None:
        visible = settings.get("selected_calendars") or None
    privacy_filter = room_cfg.get("privacy_filter") or settings.get("privacy_filter_default")
    try:
        cache = google_calendar_service.load_cache()
        raw_events = google_calendar_service.get_events_in_range(cache, now, horizon, visible, tz)
        raw_events = google_calendar_service.apply_privacy_filter(raw_events, privacy_filter)
    except Exception as e:
        logger.warning("Calendar event read failed for %s: %s", room_id, e)
        return CalendarEventsResponse(room_id=room_id, events=[])

    events: list[CalendarEventSummary] = []
    for event in raw_events[:100]:
        title = str(event.get("summary") or "(無題)")
        events.append(
            CalendarEventSummary(
                id=str(event.get("id") or ""),
                calendar_id=str(event.get("calendar_id") or ""),
                title=title,
                start=str(event.get("start") or event.get("start_date") or ""),
                end=str(event.get("end") or event.get("end_date") or ""),
                is_all_day=bool(event.get("is_all_day")),
                location=str(event.get("location") or ""),
            )
        )
    return CalendarEventsResponse(room_id=room_id, events=events)


def _parse_calendar_event_datetime(value: str, *, all_day: bool) -> datetime.datetime:
    raw = str(value or "").strip()
    if not raw:
        raise ValueError("calendar event start/end is required")
    try:
        if all_day and len(raw) == 10:
            parsed_date = datetime.date.fromisoformat(raw)
            return datetime.datetime.combine(parsed_date, datetime.time.min, tzinfo=datetime.timezone.utc)
        parsed = datetime.datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError as e:
        raise ValueError("calendar event start/end must be ISO8601") from e
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=datetime.timezone.utc)
    return parsed.astimezone(datetime.timezone.utc)


def create_calendar_event(room_id: str, request: CalendarEventCreateRequest) -> CalendarEventCreateResponse:
    _require_room(room_id)
    try:
        import google_calendar_service
    except Exception as e:
        raise ValueError("calendar service is not available") from e

    room_cfg = google_calendar_service.get_room_calendar_override(room_id)
    calendar_id = str(room_cfg.get("persona_write_calendar_id") or "").strip()
    if not calendar_id:
        raise PermissionError("calendar write not configured")

    title = str(request.title or "").strip()
    if not title:
        raise ValueError("calendar event title is required")
    start_dt = _parse_calendar_event_datetime(request.start, all_day=bool(request.all_day))
    end_dt = _parse_calendar_event_datetime(request.end, all_day=bool(request.all_day))
    if end_dt <= start_dt:
        raise ValueError("calendar event end must be after start")

    try:
        raw_event = google_calendar_service.GoogleCalendarService().insert_event(
            calendar_id=calendar_id,
            summary=title,
            start_dt=start_dt,
            end_dt=end_dt,
            description=str(request.description or ""),
            all_day=bool(request.all_day),
        )
    except Exception as e:
        logger.warning("Calendar event create failed for %s: %s", room_id, e)
        raise ValueError(f"calendar event create failed: {e}") from e
    return CalendarEventCreateResponse(
        room_id=room_id,
        calendar_id=calendar_id,
        event_id=str(raw_event.get("id") or ""),
        event=raw_event if isinstance(raw_event, dict) else {},
    )


def _twitter_manager():
    from twitter_manager import twitter_manager

    twitter_manager.reload()
    return twitter_manager


def _find_room_twitter_draft(manager: Any, room_id: str, draft_id: str) -> Dict[str, Any]:
    for draft in manager.get_pending_list():
        if str(draft.get("id", "")) == draft_id and str(draft.get("room_name", "")) == room_id:
            return draft
    raise ValueError("Twitter draft not found for this room")


def list_twitter_drafts(room_id: str) -> TwitterDraftListResponse:
    _require_room(room_id)
    manager = _twitter_manager()
    limit = int(manager.get_twitter_post_limit(room_id) or 280)
    drafts: List[TwitterDraftSummary] = []
    for draft in manager.get_pending_list():
        if str(draft.get("room_name", "")) != room_id:
            continue
        content = str(draft.get("filtered_content") or draft.get("final_content") or draft.get("original_content") or "")
        drafts.append(
            TwitterDraftSummary(
                id=str(draft.get("id", "")),
                timestamp=str(draft.get("timestamp", "")),
                room_name=room_id,
                content=content,
                warnings=list(draft.get("warnings") or []),
                reply_to_url=draft.get("reply_to_url") or None,
                reply_to_id=draft.get("reply_to_id") or None,
                media_paths=list(draft.get("media_paths") or []),
                twitter_length=int(manager.calculate_twitter_length(content)),
                limit=limit,
            )
        )
    drafts.sort(key=lambda item: item.timestamp, reverse=True)
    return TwitterDraftListResponse(room_id=room_id, drafts=drafts)


def approve_twitter_draft(room_id: str, draft_id: str, request: TwitterDraftActionRequest) -> TwitterDraftActionResponse:
    _require_room(room_id)
    manager = _twitter_manager()
    draft = _find_room_twitter_draft(manager, room_id, draft_id)
    content = (request.content or "").strip()
    if not content:
        raise ValueError("Twitter draft content is required")
    limit = int(manager.get_twitter_post_limit(room_id) or 280)
    length = int(manager.calculate_twitter_length(content))
    if length > limit:
        raise ValueError(f"Twitter draft is too long: {length}/{limit}")
    media_paths = request.media_paths if request.media_paths else list(draft.get("media_paths") or [])
    reply_to_url = request.reply_to_url if request.reply_to_url is not None else draft.get("reply_to_url")
    if not manager.approve_tweet(draft_id, content, reply_to_url, media_paths):
        raise ValueError("Failed to approve Twitter draft")
    result = manager.execute_post(draft_id, room_name=room_id)
    if result.get("success"):
        return TwitterDraftActionResponse(
            status="posted",
            detail="Twitter下書きを承認して投稿しました。",
            posted=True,
            post_url=result.get("post_url") or None,
        )
    manager.move_back_to_drafts(draft_id)
    return TwitterDraftActionResponse(
        status="failed",
        detail="Twitter下書きは承認されましたが、投稿に失敗したため下書きへ戻しました。",
        posted=False,
        error=str(result.get("error") or "投稿に失敗しました。"),
    )


def reject_twitter_draft(room_id: str, draft_id: str) -> TwitterDraftActionResponse:
    _require_room(room_id)
    manager = _twitter_manager()
    _find_room_twitter_draft(manager, room_id, draft_id)
    manager.reject_tweet(draft_id)
    return TwitterDraftActionResponse(status="rejected", detail="Twitter下書きを却下しました。")


def list_locations(room_id: str) -> LocationListResponse:
    _require_room(room_id)
    world_path = room_manager.get_world_settings_path(room_id)
    world_data = utils.parse_world_file(world_path) if world_path else {}
    locations: List[LocationSummary] = []
    for area_name, area_data in (world_data or {}).items():
        if str(area_name).startswith("__") or not isinstance(area_data, dict):
            continue
        for place_name, place_data in area_data.items():
            if str(place_name).startswith("__"):
                continue
            location_id = str(place_name)
            locations.append(LocationSummary(id=location_id, name=str(place_name), area=str(area_name)))
    locations.sort(key=lambda item: (item.area, item.name))
    return LocationListResponse(
        room_id=room_id,
        current_location=utils.get_current_location(room_id) or "",
        locations=locations,
    )


def set_location(room_id: str, request: LocationSetRequest) -> LocationSetResponse:
    _require_room(room_id)
    available = list_locations(room_id)
    location_ids = {location.id for location in available.locations}
    if request.location_id not in location_ids:
        raise ValueError("Location not found")
    from tools.space_tools import set_current_location

    result = set_current_location.func(location_id=request.location_id, room_name=room_id)
    if not str(result).startswith("Success:"):
        raise ValueError(str(result))
    return LocationSetResponse(
        room_id=room_id,
        current_location=utils.get_current_location(room_id) or request.location_id,
        status="success",
    )


def _autonomy_status(room_id: str, status: str | None = None) -> AutonomyStatusResponse | AutonomyPresetResponse:
    effective_settings = config_manager.get_effective_settings(room_id)
    settings = effective_settings.get("autonomous_settings", {}) or {}
    enabled = bool(settings.get("enabled", False))
    payload = {
        "room_id": room_id,
        "enabled": enabled,
        "inactivity_minutes": int(settings.get("inactivity_minutes", 120) or 120),
        "schedule_cooldown_minutes": int(settings.get("schedule_cooldown_minutes", 60) or 60),
        "quiet_hours_start": str(settings.get("quiet_hours_start", "00:00") or "00:00"),
        "quiet_hours_end": str(settings.get("quiet_hours_end", "07:00") or "07:00"),
        "preset": "normal" if enabled else "quiet",
    }
    if status is not None:
        return AutonomyPresetResponse(**payload, status=status)
    return AutonomyStatusResponse(**payload)


def get_autonomy_status(room_id: str) -> AutonomyStatusResponse:
    _require_room(room_id)
    return _autonomy_status(room_id)


def set_autonomy_preset(room_id: str, request: AutonomyPresetRequest) -> AutonomyPresetResponse:
    _require_room(room_id)
    enabled = request.preset == "normal"
    # Liteの停止・再開は稼働フラグだけを変更する。
    # 本体や別ブラウザで設定した時間・予約許可をプリセット操作で上書きしない。
    updates = {"enabled": enabled}
    result = room_manager.update_room_override_nested(room_id, "autonomous_settings", updates)
    if result is False:
        raise ValueError("Failed to save autonomy preset")
    status = "自律行動を通常モードに戻しました。" if enabled else "自律行動を静かにしました。"
    return _autonomy_status(room_id, status=status)
