# gemini_api.py (Dual-State Architecture Implementation)

import tiktoken
import traceback
from typing import Any, List, Union, Optional, Dict, Iterator
import os
import json
import re
import time
import datetime
import base64
import io
import filetype
import httpx
from PIL import Image

import google.genai as genai
from google.api_core.exceptions import ResourceExhausted, ServiceUnavailable, InternalServerError
import google.genai.errors

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, ToolMessage, AIMessageChunk
from langchain_google_genai import HarmCategory, HarmBlockThreshold, ChatGoogleGenerativeAI
from langchain_google_genai.chat_models import ChatGoogleGenerativeAIError

import config_manager
import constants
import room_manager
import utils
import signature_manager
from gemini_model_features import (
    normalize_model_name,
    supports_native_thinking_parts,
    uses_argon_request_rules,
    tool_signature_map,
)
import closet_manager
from episodic_memory_manager import EpisodicMemoryManager, is_daily_episodic_memory


def _get_gemini_connection_module():
    """Gemini の資格情報を一元管理する境界を遅延 import する。"""

    import gemini_connection
    return gemini_connection


def _is_vertex_connection(connection=None) -> bool:
    """接続辞書の backend だけを見て Vertex 経路を判定する。"""

    if not connection:
        return False
    module = _get_gemini_connection_module()
    if module is not None:
        try:
            return bool(module.is_vertex(connection=connection))
        except (AttributeError, TypeError, ValueError):
            pass
    return (
        isinstance(connection, dict)
        and str(connection.get("backend", "")).strip().lower() == "vertex"
    )


def _get_connection(*, room_name=None, force_global=False):
    module = _get_gemini_connection_module()
    if module is None:
        return None
    return module.normalize_connection(
        module.get_connection(room_name=room_name, force_global=force_global), require_valid=True,
    )


def _create_google_client(connection=None, api_key=None, http_options=None):
    """Developer/Vertex の秘密値を混ぜずに GenAI Client を生成する。"""

    module = _get_gemini_connection_module()
    if connection is not None and module is not None:
        return module.create_client(
            connection,
            api_key=api_key,
            http_options=http_options,
        )
    if http_options is None:
        return genai.Client(vertexai=False, api_key=api_key)
    return genai.Client(vertexai=False, api_key=api_key, http_options=http_options)

def _is_gemini_3_family_model(model_name: str) -> bool:
    return re.search(r"gemini[-_\s]?3(?:[.\-_]?\d+)?", (model_name or "").lower()) is not None

def _is_gemini_3_flash_family(model_name: str) -> bool:
    model_name_lower = (model_name or "").lower()
    return _is_gemini_3_family_model(model_name_lower) and "flash" in model_name_lower

def _is_gemini_3_pro_family(model_name: str) -> bool:
    model_name_lower = (model_name or "").lower()
    return _is_gemini_3_family_model(model_name_lower) and "pro" in model_name_lower


def _cap_sequence_for_all_history(items: list) -> list:
    """UIの「最大表示(400件)」と送信上限を一致させる。"""
    if len(items) > constants.UI_HISTORY_MAX_LIMIT:
        return items[-constants.UI_HISTORY_MAX_LIMIT:]
    return items


def _classify_gemini_429_limit(err_str: str) -> str:
    """Gemini 429の制限種別を、可能な範囲でRPD/RPM/TPMへ分類する。"""
    text = (err_str or "").upper()
    if (
        "PERDAY" in text
        or "DAILY" in text
        or "GENERATEREQUESTSPERDAY" in text
        or "REQUESTS_PER_DAY" in text
    ):
        return "RPD"
    if (
        "TOKEN" in text
        or "INPUT_TOKEN_COUNT" in text
        or "TOKENS_PER" in text
        or "GENERATECONTENTINPUTTOKENS" in text
    ):
        return "TPM"
    if (
        "PERMINUTE" in text
        or "PER_MINUTE" in text
        or "REQUESTSPERMINUTE" in text
        or "GENERATEREQUESTSPERMINUTE" in text
    ):
        return "RPM"
    return "RPM"


def _is_gemini_503_error(err_str: str, *, is_429: bool = False) -> bool:
    """429として確定したエラーを503再試行ルートへ誤分類しないための判定。"""
    if is_429:
        return False
    text = (err_str or "").upper()
    return "503" in text or "UNAVAILABLE" in text or "OVERLOADED" in text


def _gemini_503_outer_retry_policy(*, autonomous_action_mode: bool) -> tuple[int, bool]:
    """
    invoke_nexus_agent_stream 外側の503リトライ方針。

    agent_node 内でも同一キー短期リトライを行うため、UIから止めにくい自律行動では
    外側の再実行を最小限にし、503でキー総当たりしない。
    """
    if autonomous_action_mode:
        return 1, False
    return 3, True


VOICE_SENSITIVE_CAPABILITY_CATEGORIES = {
    "twitter",
    "notes",
    "memory",
    "items",
    "procedure",
    "image",
}

LIGHTWEIGHT_SAFE_CAPABILITY_CATEGORIES = {
    "world",
    "web",
    "time",
    "watchlist",
    "chess",
    "autonomy",
}

VOICE_SENSITIVE_TOOL_NAMES = {
    "draft_tweet",
    "post_tweet",
    "plan_notepad_edit",
    "update_working_memory",
    "patch_working_memory",
    "plan_creative_notes_edit",
    "plan_research_notes_edit",
    "plan_identity_memory_edit",
    "plan_diary_append",
    "plan_secret_diary_edit",
    "write_entity_memory",
    "save_procedure",
    "create_procedure_from_timeline",
    "create_food_item",
    "create_standard_item",
    "create_and_gift_item",
    "gift_item_to_user",
    "generate_image",
}


def _extract_recent_capability_category(messages: List[Any]) -> str:
    """現在のユーザーターン内で最後に要求された能力カテゴリを抽出する。"""
    for msg in reversed(messages or []):
        if isinstance(msg, HumanMessage):
            break
        if isinstance(msg, ToolMessage) and getattr(msg, "name", "") == "request_capability":
            content = msg.content if isinstance(msg.content, str) else str(msg.content)
            match = re.search(r"\{.*?\}", content, re.DOTALL)
            if not match:
                return ""
            try:
                payload = json.loads(match.group(0))
            except Exception:
                return ""
            return str(payload.get("category", "")).strip().lower()
    return ""


def _tool_names_since_last_human(messages: List[Any]) -> List[str]:
    names: List[str] = []
    for msg in reversed(messages or []):
        if isinstance(msg, HumanMessage):
            break
        if isinstance(msg, ToolMessage):
            names.append(getattr(msg, "name", ""))
        elif isinstance(msg, AIMessage):
            for call in getattr(msg, "tool_calls", []) or []:
                if isinstance(call, dict):
                    names.append(str(call.get("name", "")))
    return list(reversed([name for name in names if name]))


def _can_use_lightweight_429_fallback(latest_state_values: Dict[str, Any], *, autonomous_action_mode: bool) -> bool:
    """
    429時に軽量モデルへ逃がしてよいかを判定する。

    Twitter下書き、日記/ノート/記憶本文、Procedure本文などはペルソナ本人の
    声が重要なため、軽量モデルへの退避対象から外す。
    """
    if not autonomous_action_mode:
        return False

    messages = latest_state_values.get("messages", [])
    category = _extract_recent_capability_category(messages)
    if category in VOICE_SENSITIVE_CAPABILITY_CATEGORIES:
        return False
    if category in LIGHTWEIGHT_SAFE_CAPABILITY_CATEGORIES:
        return True

    tool_names = _tool_names_since_last_human(messages)
    if not tool_names:
        return False
    if any(name in VOICE_SENSITIVE_TOOL_NAMES for name in tool_names):
        return False
    return all(name.startswith(("read_", "search_", "list_", "get_", "check_")) for name in tool_names)


def _get_autonomous_429_fallback_model() -> str:
    """自律行動の429時に逃がす軽量モデル名を返す。"""
    try:
        settings = config_manager.get_internal_model_settings()
        fallback = settings.get("processing_model") or constants.INTERNAL_PROCESSING_MODEL
        return str(fallback).strip() or constants.INTERNAL_PROCESSING_MODEL
    except Exception:
        return constants.INTERNAL_PROCESSING_MODEL

# --- トークン計算関連 (変更なし) ---
def get_model_token_limits(
    model_name: str,
    api_key: str = None,
    provider: str = None,
    connection: dict | None = None,
) -> Optional[Dict[str, int]]:
    # 注釈（かっこ書き）を除去
    model_name = model_name.split(" (")[0].strip() if model_name else model_name

    if model_name in utils._model_token_limits_cache: return utils._model_token_limits_cache[model_name]

    # 【マルチモデル対応】OpenAIモデルの場合はGemini APIを呼び出さない
    # gpt-、o1-、claude-などGemini以外のモデルはGemini APIで情報取得不可
    if not provider:
        provider = config_manager.get_active_provider()

    if connection is None and provider in {"google", "Google (Gemini)", "Google (Gemini Native)"}:
        connection = _get_connection(force_global=True)
    if connection is None and (not api_key or api_key.startswith("YOUR_API_KEY")):
        return None

    # '/'が含まれる場合（例: mistralai/mistral-7b...）もOpenAI互換とみなす
    is_openai_model = (
        provider == "openai" or
        model_name.startswith(("gpt-", "o1-", "claude-", "llama-", "mixtral-", "mistral-")) or
        "/" in model_name
    )

    if is_openai_model:
        # OpenAI互換モデルのトークン制限は一般的なデフォルト値を返す
        # 正確な値が必要な場合は、各プロバイダのAPIを呼び出す必要があるが、
        # トークンカウントはあくまで参考値なので概算で十分
        return {"input": 128000, "output": 8192}  # GPT-4o相当のデフォルト値

    try:
        client = _create_google_client(
            connection=connection,
            api_key=None if _is_vertex_connection(connection) else api_key,
        )
        model_info = client.models.get(model=model_name if _is_vertex_connection(connection) else f"models/{model_name}")
        if model_info and hasattr(model_info, 'input_token_limit') and hasattr(model_info, 'output_token_limit'):
            limits = {"input": model_info.input_token_limit, "output": model_info.output_token_limit}
            utils._model_token_limits_cache[model_name] = limits
            return limits
        return None
    except Exception as e:
        detail = type(e).__name__ if _is_vertex_connection(connection) else str(e)
        print(f"モデル情報の取得中にエラー: {detail}")
        return None

def _convert_lc_to_gg_for_count(messages: List[Union[SystemMessage, HumanMessage, AIMessage]]) -> List[Dict]:
    contents = []
    for msg in messages:
        role = "model" if isinstance(msg, AIMessage) else "user"
        sdk_parts = []
        if isinstance(msg.content, str):
            sdk_parts.append({"text": msg.content})
        elif isinstance(msg.content, list):
            for part_data in msg.content:
                if not isinstance(part_data, dict): continue
                part_type = part_data.get("type")
                if part_type == "text": sdk_parts.append({"text": part_data.get("text", "")})
                elif part_type == "image_url":
                    url_data = part_data.get("image_url", {}).get("url", "")
                    if url_data.startswith("data:"):
                        try:
                            header, encoded = url_data.split(",", 1); mime_type = header.split(":")[1].split(";")[0]
                            sdk_parts.append({"inline_data": {"mime_type": mime_type, "data": encoded}})
                        except: pass
                elif part_type == "media_url":
                    url_data = part_data.get("media_url", "")
                    if url_data.startswith("data:"):
                        try:
                            header, encoded = url_data.split(",", 1)
                            mime_type = header.split(":")[1].split(";")[0]
                            sdk_parts.append({"inline_data": {"mime_type": mime_type, "data": encoded}})
                        except: pass
                elif part_type == "media": sdk_parts.append({"inline_data": {"mime_type": part_data.get("mime_type", "application/octet-stream"),"data": part_data.get("data", "")}})
        if sdk_parts: contents.append({"role": role, "parts": sdk_parts})
    return contents

def count_tokens_from_lc_messages(messages: List, model_name: str, api_key: str) -> int:
    """
    メッセージリストのトークン数を計算する。
    見積もり（入力前計算）を高速化するため、Geminiモデルも含めローカルの tiktoken で概算する。
    """
    if not messages: return 0
    # 注釈（かっこ書き）を除去
    model_name = model_name.split(" (")[0].strip() if model_name else model_name

    try:
        # OpenAI互換のトークナイザー(cl100k_base)で概算する
        # APIを叩かずに済む安全策として十分
        encoding = tiktoken.get_encoding("cl100k_base")
        total_tokens = 0
        for msg in messages:
            content = ""
            if isinstance(msg.content, str):
                content = msg.content
            elif isinstance(msg.content, list):
                # マルチモーダルのテキスト部分だけ抽出
                for part in msg.content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        content += part.get("text", "") + " "

            if content:
                total_tokens += len(encoding.encode(content))

        # 安全係数
        # tiktoken (cl100k_base) は Gemini のトークナイザーとは異なるが、
        # 余裕を持って 1.15倍 程度を見積もる。
        return int(total_tokens * 1.15) + 500

    except Exception as e:
        print(f"ローカル・トークン計算エラー: {e}")
        # 最悪の場合、文字数/2 程度で返す
        return sum(len(str(m.content)) for m in messages) // 2


def _compose_working_memory_token_section(
    active_slot: str,
    content: str,
    available_slots: List[str],
) -> str:
    """Gemini見積もり用WM節。terminal本文を含めず、他slot概要は保持する。"""
    body = str(content or "").strip()
    slots = [str(slot).strip() for slot in (available_slots or []) if str(slot).strip()]
    section = ""
    if body:
        section = (
            f"\n### 現在のプラン・ワーキングメモリ "
            f"(アクティブスロット: {active_slot})\n{body}\n"
        )
    if slots:
        section += f"\n※ 他の利用可能なスロット: {', '.join(slots)}\n"
    return section


# --- 日付ベースフィルタリング関数 ---

def _get_effective_today_cutoff(room_name: str, silent: bool = False) -> str:
    """
    「本日分」の切り捨て日付を決定する。

    昨日のエピソード記憶が存在する場合は今日以降のみ（昨日分は記憶化済み）。
    存在しない場合は昨日以降も含める（エピソード記憶が生成されるまでは前日のログも必要）。

    Returns:
        YYYY-MM-DD形式の日付文字列
    """
    import os
    import json
    from constants import ROOMS_DIR

    today = datetime.datetime.now()
    today_str = today.strftime('%Y-%m-%d')
    yesterday_str = (today - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    yesterday_month = (today - datetime.timedelta(days=1)).strftime('%Y-%m')

    # エピソード記憶ファイルを確認
    # 新形式: characters/[room_name]/memory/episodic/YYYY-MM.json
    # 旧形式: characters/[room_name]/memory/episodic_memory.json (フォールバック)
    memory_dir = os.path.join(ROOMS_DIR, room_name, "memory")
    new_format_file = os.path.join(memory_dir, "episodic", f"{yesterday_month}.json")
    old_format_file = os.path.join(memory_dir, "episodic_memory.json")

    has_yesterday_memory = False

    def check_episodes_for_date(episodes: list, target_date: str) -> bool:
        """指定日付の日次要約が存在するかチェック（特殊記憶は除外）。"""
        return any(is_daily_episodic_memory(ep, target_date) for ep in episodes)

    # 1. まず新形式（月別ファイル）をチェック
    if os.path.exists(new_format_file):
        try:
            with open(new_format_file, 'r', encoding='utf-8') as f:
                episodes = json.load(f)
            if isinstance(episodes, list):
                has_yesterday_memory = check_episodes_for_date(episodes, yesterday_str)
        except Exception as e:
            print(f"Warning: Failed to check episodic memory (new format) for {yesterday_str}: {e}")

    # 2. 新形式で見つからなければ旧形式にフォールバック
    if not has_yesterday_memory and os.path.exists(old_format_file):
        try:
            with open(old_format_file, 'r', encoding='utf-8') as f:
                episodes = json.load(f)
            if isinstance(episodes, list):
                has_yesterday_memory = check_episodes_for_date(episodes, yesterday_str)
        except Exception as e:
            print(f"Warning: Failed to check episodic memory (old format) for {yesterday_str}: {e}")

    if has_yesterday_memory:
        if not silent:
            print(
                f"  - [Cutoff] 昨日({yesterday_str})の日次エピソード要約: あり "
                f"→ カットオフ={today_str}",
                flush=True,
            )
        return today_str  # 昨日分は記憶化済み → 今日以降のみ
    else:
        if not silent:
            print(
                f"  - [Cutoff] 昨日({yesterday_str})の日次エピソード要約: なし "
                f"（特殊記憶のみの場合を含む）→ カットオフ={yesterday_str}",
                flush=True,
            )
        return yesterday_str  # 昨日分は未処理 → 昨日以降も含める

def _filter_messages_from_today(messages: list, today_str: str) -> list:
    """
    本日（today_str）以降の最初のメッセージを見つけ、そこから最後まで全て返す。
    タイムスタンプがないメッセージも、本日分の開始以降であれば含まれる。

    Args:
        messages: LangChainメッセージのリスト
        today_str: 本日の日付文字列 (YYYY-MM-DD形式)

    Returns:
        本日分の開始から末尾までのメッセージリスト
    """
    date_pattern = re.compile(r'(\d{4}-\d{2}-\d{2})')

    # 本日分の開始インデックスを探す
    today_start_index = 0  # デフォルトは先頭（何も見つからない場合は全て含める）

    for i, msg in enumerate(messages):
        # 1. コンテンツから日付を探す
        content = getattr(msg, 'content', '')
        if isinstance(content, list):
            content = ' '.join(p.get('text', '') if isinstance(p, dict) else str(p) for p in content)

        msg_date = None
        if isinstance(content, str):
            match = date_pattern.search(content)
            if match:
                msg_date = match.group(1)

        # 2. コンテンツにない場合、メタデータから探す
        if not msg_date:
            # additional_kwargs や timestamp フィールドをチェック
            ts = msg.additional_kwargs.get("timestamp") if hasattr(msg, "additional_kwargs") else None
            if not ts and hasattr(msg, "timestamp"):
                ts = msg.timestamp

            if ts and isinstance(ts, str):
                match = date_pattern.search(ts)
                if match:
                    msg_date = match.group(1)

        # 判定
        if msg_date and msg_date >= today_str:
            today_start_index = i
            break

    return messages[today_start_index:]

def _filter_raw_history_from_today(raw_history: list, today_str: str) -> list:
    """
    生の履歴辞書リストから本日分の開始以降を抽出する。
    トークン計算用。
    """
    date_pattern = re.compile(r'(\d{4}-\d{2}-\d{2})')

    # 本日分の開始インデックスを探す
    today_start_index = 0

    for i, item in enumerate(raw_history):
        # 1. コンテンツから探す
        content = item.get('content', '')
        msg_date = None
        if isinstance(content, str):
            match = date_pattern.search(content)
            if match:
                msg_date = match.group(1)

        # 2. コンテンツにない場合、timestamp フィールドから探す
        if not msg_date:
            ts = item.get('timestamp') # raw_history に timestamp がある場合
            if ts and isinstance(ts, str):
                match = date_pattern.search(ts)
                if match:
                    msg_date = match.group(1)

        if msg_date and msg_date >= today_str:
            today_start_index = i
            break

    return raw_history[today_start_index:]

def _apply_auto_summary(
    messages: list,
    room_name: str,
    api_key: str,
    threshold: int,
    allow_generation: bool = True,
    debug_mode: bool = False
) -> list:
    """
    自動会話要約を適用する。
    閾値を超えている場合、直近N往復を除いた部分を要約に置き換える。
    """
    import summary_manager
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

    def _msg_len(msg) -> int:
        return len(utils.get_content_as_string(msg))

    def _debug(message: str) -> None:
        if debug_mode:
            print(f"  - [Auto Summary Debug] {message}")

    if not messages:
        return messages

    # SystemMessage は会話履歴ではないため、要約対象から外して先頭に保持する。
    leading_system_messages = []
    body_messages = list(messages)
    while body_messages and isinstance(body_messages[0], SystemMessage):
        leading_system_messages.append(body_messages.pop(0))

    # メッセージの総文字数を計算
    total_chars = sum(_msg_len(msg) for msg in body_messages)
    _debug(
        f"入力={len(messages)}件 / 会話本文={len(body_messages)}件 / "
        f"system={len(leading_system_messages)}件 / chars={total_chars:,} / threshold={threshold:,} / allow_generation={allow_generation}"
    )

    if total_chars <= threshold:
        # 閾値以下なら何もしない
        _debug("閾値以下のため要約なし")
        return messages

    if allow_generation:
        print(f"  - [Auto Summary] 閾値超過: {total_chars:,} > {threshold:,}文字")

    # 直近N往復を保持
    keep_count = constants.AUTO_SUMMARY_KEEP_RECENT_TURNS * 2  # 往復なので×2

    if len(body_messages) <= keep_count:
        # メッセージ数が少なすぎる場合は要約しない
        _debug(f"保持対象件数以下のため要約なし: body={len(body_messages)} <= keep={keep_count}")
        return messages

    recent_messages = body_messages[-keep_count:]
    older_messages = body_messages[:-keep_count]

    # 既存の要約を読み込み
    existing_data = summary_manager.load_today_summary(room_name)
    existing_summary = existing_data.get("summary") if existing_data else None
    chars_summarized = existing_data.get("chars_summarized", 0) if existing_data else 0
    _debug(
        f"既存要約={'あり' if existing_summary else 'なし'} / "
        f"chars_summarized={chars_summarized:,} / older={len(older_messages)}件 / recent={len(recent_messages)}件"
    )

    # 1. メッセージを分類
    # older_messages: 直近以外 (要約対象候補), recent_messages: 直近 (常に生で送る)
    recent_messages = body_messages[-keep_count:]
    older_messages = body_messages[:-keep_count]

    # older_messages 内で「すでに要約に含まれている分」と「まだ含まれていない分 (pending)」を分ける
    pending_messages = []
    cumulative_len = 0
    for msg in older_messages:
        msg_len = _msg_len(msg)
        if cumulative_len >= chars_summarized:
            pending_messages.append(msg)
        cumulative_len += msg_len

    # 2. 要約の実行判断
    pending_chars = sum(_msg_len(m) for m in pending_messages)

    # 判定A: 初めて閾値を超えた場合、または pending 分が閾値を超えた場合に要約/マージを実行
    should_summarize = False
    if not existing_summary:
        if total_chars > threshold:
            should_summarize = True
    else:
        if pending_chars > threshold:
            should_summarize = True
    _debug(
        f"pending={len(pending_messages)}件 / pending_chars={pending_chars:,} / "
        f"should_summarize={should_summarize}"
    )

    new_summary = existing_summary
    if should_summarize:
        if not allow_generation:
            # トークン計算時は生成しない
            new_summary = existing_summary or "（要約生成待ち...）"
            # 実送信時に要約される範囲は、推定時にも生ログから外す。
            pending_messages = []
            _debug("生成禁止モードのため要約プレースホルダーを使用")
        else:
            # pending 分を辞書形式に変換
            to_summarize_dicts = []
            for msg in pending_messages:
                c_str = utils.get_content_as_string(msg)
                role = "USER" if isinstance(msg, HumanMessage) else "AGENT"
                resp = getattr(msg, 'name', room_name) if role == "AGENT" else "user"
                to_summarize_dicts.append({"role": role, "responder": resp, "content": c_str})

            print(f"  - [Auto Summary] 要約/マージ実行: pending {pending_chars:,}文字 > 閾値 {threshold:,}文字")
            # 新しい要約を生成 (内部で既存要約とマージされる)
            new_summary = summary_manager.generate_summary(
                to_summarize_dicts, existing_summary, room_name, api_key
            )

            if new_summary:
                # 累計要約文字数を更新して保存
                # older_messages 全体が要約済みとなったとみなす
                total_older_len = sum(_msg_len(m) for m in older_messages)
                summary_manager.save_today_summary(room_name, new_summary, total_older_len)
                # 要約が更新されたので、pending は空になる
                pending_messages = []
            else:
                new_summary = existing_summary or "（要約生成失敗）"

    # 3. メッセージリストの構築
    result_messages = list(leading_system_messages)
    recent_already_included = False

    # 要約が存在すれば最初に入れる
    if new_summary:
        if allow_generation:
            # 要約の内容をコンソールに表示して、視認性を高める
            summary_preview = new_summary[:60].replace('\n', ' ') + "..." if len(new_summary) > 60 else new_summary
            print(f"  - [Auto Summary] 要約をメッセージの冒頭に挿入しました: \"{summary_preview}\"")

        summary_message = HumanMessage(
            content=f"【本日のこれまでの会話の要約】\n{new_summary}\n\n---\n（以下は、要約以降および直近の会話です）"
        )
        result_messages.append(summary_message)
        # 要約された後に残っている未要約分 (pending) を追加
        result_messages.extend(pending_messages)
    else:
        # 初回閾値到達前、または要約が不要な場合
        if not allow_generation and should_summarize:
            # 【2026-01-18 FIX】既存の要約があればそれを使用し、より正確なトークン推定を行う
            if existing_summary:
                placeholder_summary = HumanMessage(
                    content=f"【本日のこれまでの会話の要約】\n{existing_summary}\n\n---\n（以下は、要約以降および直近の会話です）"
                )
            else:
                # 既存の要約がない場合は、推定文字数でプレースホルダーを生成
                estimated_summary_chars = min(total_chars // 3, 3000)  # 元の文字数の約1/3程度と推定
                placeholder_summary = HumanMessage(
                    content=f"【本日のこれまでの会話の要約】\n（要約生成待ち... 推定{estimated_summary_chars}文字）\n{'x' * estimated_summary_chars}\n\n---\n（以下は、要約以降および直近の会話です）"
                )
            result_messages.append(placeholder_summary)
            # pending_messages が空でない場合は追加（古いメッセージは older_messages として除外済み）
            result_messages.extend(pending_messages)
        else:
            result_messages = list(messages)
            recent_already_included = True

    # 常に直近分を追加
    if not recent_already_included:
        result_messages.extend(recent_messages)

    if should_summarize and allow_generation:
        print(f"  - [Auto Summary] 要約更新完了: 累計 {cumulative_len:,}文字を圧縮")
    _debug(f"出力={len(result_messages)}件")

    return result_messages

# --- 履歴構築 (Dual-Stateの核心) ---
def convert_raw_log_to_lc_messages(
    raw_history: list,
    responding_character_id: str,
    add_timestamp: bool,
    send_thoughts: bool,
    provider: str = "google",
    model_name: Optional[str] = None,
    connection_id: Optional[str] = None,
) -> list:
    """
    ログ(テキスト)からメッセージを復元し、signature_manager(JSON) から
    最新の思考署名とツール呼び出し情報を注入して、完全な状態のオブジェクトを返す。
    (v2: ツール実行後の履歴でも正しく注入できるように修正)

    Args:
        provider: "google" または "openai"。OpenAI互換の場合は履歴平滑化を無効にする。
        model_name: 署名の生成元と照合する送信対象モデル名。
    """
    from langchain_core.messages import HumanMessage, AIMessage
    lc_messages = []
    timestamp_pattern = re.compile(r'\n\n\d{4}-\d{2}-\d{2} \(...\) \d{2}:\d{2}:\d{2}(?: \| .*)?$')

    # 1. JSONファイルから最新のターンコンテキストを取得
    # これらは「直近にAIが行ったツール呼び出し」の情報。
    # 署名はGoogleのgenerateContentだけで意味を持つため、他プロバイダへ
    # 誤って再利用しない。model_name指定時は保存元モデルを厳密照合する。
    turn_context = {}
    if provider == "google":
        signature_filter = {}
        if model_name is not None:
            signature_filter["model_name"] = model_name
        if connection_id is not None:
            signature_filter["connection_id"] = connection_id
        turn_context = signature_manager.get_turn_context(responding_character_id, **signature_filter)
    # Gemini 3形式の署名を優先、なければ古い形式にフォールバック
    stored_signature = turn_context.get("gemini_function_call_thought_signatures") or turn_context.get("last_signature")
    stored_tool_calls = turn_context.get("last_tool_calls")
    stored_signature_model = turn_context.get("signature_model_name")
    stored_signature_connection = turn_context.get("signature_connection_id", "developer")

    # --- フェーズ1: 基本的なメッセージリストの構築 ---
    # 【追加項目】履歴の平滑化 (History Flattening)
    # 過去のツール使用履歴をプレーンテキストに変換し、Gemini 3 の推論負荷を軽減する。
    # 【重要】OpenAI互換API は tool_calls を持つ AIMessage の後に ToolMessage が必須のため、
    #        OpenAIプロバイダでは平滑化を無効にする。
    if provider == "openai":
        flatten_historical_tools = False  # OpenAI互換は tool_calls-ToolMessage の対応必須
    else:
        flatten_historical_tools = "gemini-3" in responding_character_id or "thinking" in responding_character_id.lower() or True


    for idx, h_item in enumerate(raw_history):
        content = h_item.get('content', '').strip()
        responder_id = h_item.get('responder', '')
        role = h_item.get('role', '')
        if not responder_id or not role: continue

        # タイムスタンプの抽出（メタデータ保持用）
        ts_match = timestamp_pattern.search(content)
        extracted_ts = ts_match.group(0).strip() if ts_match else None

        # タイムスタンプ除去
        if not add_timestamp:
            content = utils.remove_ai_timestamp(content)

        is_user = (role == 'USER')
        is_self = (responder_id == responding_character_id)

        common_kwargs = {"timestamp": extracted_ts} if extracted_ts else {}

        if is_user:
            text_only_content = re.sub(r"\[ファイル添付:.*?\]", "", content, flags=re.DOTALL).strip()
            if text_only_content:
                lc_messages.append(HumanMessage(content=text_only_content, additional_kwargs=common_kwargs))
        elif is_self:
            # AIメッセージ。後続の履歴を確認し、これが「完了したツール呼び出し」かどうかを判定。
            is_historical_tool_call = False
            if flatten_historical_tools:
                # このメッセージより後に「ユーザーの発言」または「別の自分の発言」があれば、
                # このツール呼び出しは過去の会話の一部として平滑化しても良い。
                for next_item in raw_history[idx+1:]:
                    if next_item.get('role') == 'USER' or (next_item.get('responder') == responding_character_id and next_item.get('role') == 'AGENT'):
                        is_historical_tool_call = True
                        break

            # 歴史的な思考ログは、推論の混乱を招くため常に除去する。
            clean_content = utils.remove_thoughts_from_text(content)

            content_for_api = clean_content
            if not send_thoughts:
                # 明示的に非表示設定の場合は再確認して除去
                content_for_api = utils.remove_thoughts_from_text(clean_content)

            if content_for_api:
                # 過去のツール呼び出しを含むメッセージは、属性としての tool_calls を持たない
                # 純粋なテキストの AIMessage として追加することで「平滑化」を実現する。
                ai_msg = AIMessage(content=content_for_api, name=responder_id, additional_kwargs=common_kwargs)
                lc_messages.append(ai_msg)

        elif role == 'SYSTEM' and responder_id.startswith('tool_result'):
            # 【OpenAI互換対応】OpenAI APIはtool_calls→ToolMessageの厳密な対応が必須。
            # テキストログからはtool_callsを完全に復元できないため、OpenAI互換では
            # ツール履歴を完全に除外して純粋な対話のみを送信する。
            if provider == "openai":
                continue  # OpenAI互換ではツール履歴を完全スキップ

            # 形式: ## SYSTEM:tool_result:<tool_name>:<tool_call_id>
            parts = responder_id.split(':')
            tool_name = parts[1] if len(parts) > 1 else "unknown"
            tool_call_id = parts[2] if len(parts) > 2 else "unknown"

            raw_match = re.search(r'\[RAW_RESULT\]\n(.*?)\n\[/RAW_RESULT\]', content, re.DOTALL)
            tool_content = raw_match.group(1) if raw_match else content

            # 【重要】これが「過去のツール結果」かどうかを判定。
            # 直後（またはそれ以降）に AI の返答があれば、それは過去の記録。
            is_historical_result = False
            if flatten_historical_tools:
                for next_item in raw_history[idx+1:]:
                    if next_item.get('responder') == responding_character_id and next_item.get('role') == 'AGENT':
                        is_historical_result = True
                        break

            # ただし、直前の AIMessage がまだ tool_calls を持っている（平滑化されていない）場合は
            # プロトコル維持のため、この結果を消してはならない。
            if is_historical_result:
                last_ai_flat = True
                for i in range(len(lc_messages)-1, -1, -1):
                    if isinstance(lc_messages[i], AIMessage) and lc_messages[i].name == responding_character_id:
                        if hasattr(lc_messages[i], 'tool_calls') and lc_messages[i].tool_calls:
                            last_ai_flat = False
                        break
                if not last_ai_flat:
                    is_historical_result = False

            if is_historical_result:
                # 【Phase 7】過去のツール実行結果は履歴から完全に除外する。
                # これにより、ユーザーとAIの純粋な対話のみが維持され、プロンプトの肥大化や文脈の混乱を防ぐ。
                continue
            else:
                prev_msg = lc_messages[-1] if lc_messages else None
                can_emit_tool_message = (
                    tool_call_id
                    and tool_call_id != "unknown"
                    and isinstance(prev_msg, AIMessage)
                    and prev_msg.name == responding_character_id
                )

                if can_emit_tool_message:
                    # 最新の（まだ返答されていない）ツール結果のみを構造化メッセージとして保持
                    if not hasattr(prev_msg, 'tool_calls') or not prev_msg.tool_calls:
                        prev_msg.tool_calls = []
                    if not any(tc.get('id') == tool_call_id for tc in prev_msg.tool_calls):
                        prev_msg.tool_calls.append({"id": tool_call_id, "name": tool_name, "args": {}})

                    tool_msg = ToolMessage(content=tool_content, tool_name=tool_name, tool_call_id=tool_call_id)
                    lc_messages.append(tool_msg)
                else:
                    # Anthropic/OpenAI系は tool_use の直後に対応 tool_result が必須。
                    # テキストログから隣接ペアを復元できない場合は、構造化せず通常文脈へ畳み込む。
                    lc_messages.append(
                        HumanMessage(
                            content=f"【ツール実行結果: {tool_name}】\n{tool_content}",
                            additional_kwargs=common_kwargs,
                        )
                    )
        else:
            other_agent_config = room_manager.get_room_config(responder_id)
            display_name = other_agent_config.get("room_name", responder_id) if other_agent_config else responder_id
            clean_content = utils.remove_thoughts_from_text(content)
            lc_messages.append(HumanMessage(content=f"（{display_name}の発言）:\n{clean_content}"))

    # --- フェーズ2: 最新ターンの署名とツールコールの注入 ---
    # JSONから取得したコンテキスト（未解決の呼び出し等）を、末尾のAIMessageに注入する。
    # 【OpenAI互換対応】OpenAI APIはtool_calls-ToolMessageの厳密な対応が必須。
    #                   テキストログからは完全に復元できないため、OpenAI互換ではこの注入をスキップ。
    if provider == "openai":
        # OpenAI互換ではtool_calls注入をスキップ（APIエラー回避）
        pass
    elif stored_tool_calls or stored_signature:
        for i in range(len(lc_messages) - 1, -1, -1):
            msg = lc_messages[i]
            if isinstance(msg, AIMessage) and msg.name == responding_character_id:
                if stored_tool_calls:
                    next_msg = lc_messages[i + 1] if i + 1 < len(lc_messages) else None
                    next_tool_call_id = getattr(next_msg, "tool_call_id", None) if isinstance(next_msg, ToolMessage) else None
                    matched_tool_calls = [
                        tc for tc in stored_tool_calls
                        if tc.get("id") and tc.get("id") != "unknown" and tc.get("id") == next_tool_call_id
                    ]
                    if matched_tool_calls:
                        # 既に tool_calls がある場合は、重複しなければマージ
                        if not msg.tool_calls: msg.tool_calls = []
                        for tc in matched_tool_calls:
                            if not any(existing.get('id') == tc.get('id') for existing in msg.tool_calls):
                                msg.tool_calls.append(tc)

                if stored_signature or stored_signature_model:
                    if not msg.additional_kwargs:
                        msg.additional_kwargs = {}

                    # SDKが期待する {tool_call_id: signature} へ変換する。
                    # 実ツールIDが分かる場合はIDで絞り込み、単一署名を
                    # 並列tool callへ複製しない。古い履歴でtool call自体が
                    # まだ復元されていない場合だけ、既存の辞書を保つ。
                    if isinstance(stored_signature, dict) and not msg.tool_calls:
                        final_sig_dict = stored_signature
                    else:
                        final_sig_dict = tool_signature_map(stored_signature, msg.tool_calls)

                    if final_sig_dict:
                        msg.additional_kwargs[
                            "__gemini_function_call_thought_signatures__"
                        ] = final_sig_dict

                    # graph側が送信直前にモデル境界を確認できるよう、由来を
                    # AIMessageへ明示する。由来不明の旧形式には付与しない。
                    signature_model = normalize_model_name(stored_signature_model or "")
                    if signature_model:
                        msg.additional_kwargs["__nexus_gemini_signature_model__"] = signature_model
                    if stored_signature_connection:
                        msg.additional_kwargs["__nexus_gemini_signature_connection__"] = str(
                            stored_signature_connection
                        )
                break

    return merge_consecutive_messages(lc_messages, add_timestamp=add_timestamp)

def merge_consecutive_messages(lc_messages: list, add_timestamp: bool = False) -> list:
    """
    同一ロール（AI同士、Human同士）が連続するメッセージリストを、1つのメッセージに統合する。
    Gemini API プロトコル遵守のためのユーティリティ。
    """
    if not lc_messages:
        return []

    merged_messages = []
    curr_msg = lc_messages[0]

    for next_msg in lc_messages[1:]:
        # 同じクラス（HumanMessage, AIMessage）が連続し、かつ名前(name)も一致する場合、内容を結合する。
        # ToolMessage は結合対象外（AI->Tool->AIの順を保つため）。
        from langchain_core.messages import ToolMessage
        is_same_role = type(curr_msg) == type(next_msg) and not isinstance(curr_msg, ToolMessage)
        is_same_name = getattr(curr_msg, 'name', None) == getattr(next_msg, 'name', None)

        if is_same_role and is_same_name:
            # 結合部にタイムスタンプを注入して、AIが時間経過を把握できるようにする。
            # ただしユーザー設定でタイムスタンプがオフの場合は、詳細な時刻は伏せる。
            next_ts = next_msg.additional_kwargs.get("timestamp")
            if add_timestamp and next_ts:
                sep = f"\n\n--- (別タイミングの発言 / タイムスタンプ: {next_ts}) ---\n\n"
            else:
                sep = f"\n\n--- (別のタイミングの発言) ---\n\n" if next_ts else "\n\n"

            # コンテンツの結合 (Multipart リスト対応)
            def to_parts(content):
                if isinstance(content, list): return content
                return [{"type": "text", "text": str(content)}]

            c_parts = to_parts(curr_msg.content)
            n_parts = to_parts(next_msg.content)

            if isinstance(curr_msg.content, str) and isinstance(next_msg.content, str):
                # 両方文字列なら文字列として結合（シンプルさを維持）
                new_content = curr_msg.content + sep + next_msg.content
            else:
                # どちらかがリストなら、リストとして結合
                sep_part = [{"type": "text", "text": sep}] if sep.strip() else []
                new_content = c_parts + sep_part + n_parts

            # 属性（tool_calls, signatures 等）のマージ
            m_kwargs = {**curr_msg.additional_kwargs, **next_msg.additional_kwargs}
            m_tool_calls = []
            if hasattr(curr_msg, "tool_calls") and curr_msg.tool_calls:
                m_tool_calls.extend(curr_msg.tool_calls)
            if hasattr(next_msg, "tool_calls") and next_msg.tool_calls:
                for tc in next_msg.tool_calls:
                    if not any(existing.get('id') == tc.get('id') for existing in m_tool_calls):
                        m_tool_calls.append(tc)

            # 更新（in-place）
            curr_msg.content = new_content
            curr_msg.additional_kwargs = m_kwargs
            if hasattr(curr_msg, "tool_calls"):
                curr_msg.tool_calls = m_tool_calls
        else:
            merged_messages.append(curr_msg)
            curr_msg = next_msg

    merged_messages.append(curr_msg)
    return merged_messages

def invoke_nexus_agent_stream(agent_args: dict) -> Iterator[Dict[str, Any]]:
    from agent.graph import app
    from api.lite_runtime_controls import (
        LiteRequestStopped,
        bind_lite_request_scope,
        checkpoint_lite_request,
        get_current_lite_request_scope,
        mark_lite_external_request_finished,
        mark_lite_external_request_started,
        wait_lite_retry,
    )

    # 引数展開
    room_to_respond = agent_args["room_to_respond"]
    api_key_name = agent_args["api_key_name"]
    api_history_limit = agent_args["api_history_limit"]
    debug_mode = agent_args["debug_mode"]
    history_log_path = agent_args["history_log_path"]
    user_prompt_parts = agent_args["user_prompt_parts"]
    soul_vessel_room = agent_args["soul_vessel_room"]
    active_participants = agent_args["active_participants"]
    active_attachments = agent_args["active_attachments"]
    shared_location_name = agent_args["shared_location_name"]
    shared_scenery_text = agent_args["shared_scenery_text"]
    season_en = agent_args["season_en"]
    time_of_day_en = agent_args["time_of_day_en"]
    global_model_from_ui = agent_args.get("global_model_from_ui")
    skip_tool_execution_flag = agent_args.get("skip_tool_execution", False)
    enable_supervisor_flag = agent_args.get("enable_supervisor", False)
    suppress_history_image_memory = agent_args.get("suppress_history_image_memory", False)
    shared_history_log_path = agent_args.get("shared_history_log_path")
    force_user_prompt_parts = agent_args.get("force_user_prompt_parts", False)
    autonomous_action_mode = bool(agent_args.get("autonomous_action", False))
    lite_scope = agent_args.get("lite_request_scope") or get_current_lite_request_scope()

    all_participants_list = [soul_vessel_room] + active_participants

    effective_settings = config_manager.get_effective_settings(
        room_to_respond,
        global_model_from_ui=global_model_from_ui,
        use_common_prompt=(len(all_participants_list) <= 1)
    )
    display_thoughts = effective_settings.get("display_thoughts", True)
    send_thoughts_final = display_thoughts and effective_settings.get("send_thoughts", True)
    model_name = effective_settings["model_name"]
    # APIキーの初期化
    current_retry_api_key_name = api_key_name
    room_api_key_name = effective_settings.get("api_key_name")
    if room_api_key_name:
        current_retry_api_key_name = room_api_key_name

    # 履歴構築（ここでJSONからの署名注入が行われる）
    # [2026-02-10 FIX] 冒頭の枯渇チェックで messages を使用するため、定義を上に移動
    messages = []
    add_timestamp = effective_settings.get("add_timestamp", False)

    # 【OpenAI互換対応】プロバイダを取得して履歴変換に渡す
    current_provider = config_manager.get_active_provider(room_to_respond)
    gemini_connection = agent_args.get("_gemini_connection")
    if gemini_connection is None and current_provider in {"google", "Google (Gemini)", "Google (Gemini Native)"}:
        # 主応答の接続はこのターンで固定し、ストリームの再試行中に
        # ルーム設定を読み直して別 backend へ切り替えない。
        gemini_connection = _get_connection(room_name=room_to_respond, force_global=False)
    is_vertex_connection = _is_vertex_connection(gemini_connection)
    if is_vertex_connection:
        # Vertex は Developer API キー台帳と独立するため、キー名も空にする。
        current_retry_api_key_name = None
    gemini_signature_connection_id = "developer"
    if current_provider in {"google", "Google (Gemini)", "Google (Gemini Native)"}:
        connection_module = _get_gemini_connection_module()
        if connection_module is not None:
            try:
                gemini_signature_connection_id = str(
                    connection_module.connection_id(gemini_connection)
                )
            except (AttributeError, TypeError, ValueError):
                gemini_signature_connection_id = "vertex" if is_vertex_connection else "developer"

    # 自身のログ
    responding_ai_log_f, _, _, _, _, _, _ = room_manager.get_room_files_paths(room_to_respond)
    if responding_ai_log_f and os.path.exists(responding_ai_log_f):
        # [2026-02-14 FIX] 全件読み込みによるフリーズ回避のため Lazy Loading を使用
        # APIコンテキスト等で必要なのは直近の会話のみであるため limit=2000 で十分
        try:
            # responding_ai_log_f は full path なので、そこから room_dir を逆算
            # .../characters/{name}/logs/{file} -> directory -> parent -> room_dir
            log_dir_path = os.path.dirname(responding_ai_log_f)
            if os.path.basename(log_dir_path) == "logs":
                 room_dir_path = os.path.dirname(log_dir_path)
            else:
                 # log.txt が直下にある旧構成などの場合
                 room_dir_path = log_dir_path

            own_history_raw, _ = utils.load_chat_log_lazy(room_dir_path, limit=2000, min_turns=50)
        except Exception as e:
            print(f"  [Warning] Lazy load failed, falling back to full load: {e}")
            own_history_raw = utils.load_chat_log(responding_ai_log_f)

        messages = convert_raw_log_to_lc_messages(
            own_history_raw,
            room_to_respond,
            add_timestamp,
            send_thoughts_final,
            provider=current_provider,
            model_name=model_name,
            connection_id=gemini_signature_connection_id,
        )

    # 【重要】最終的なメッセージリストを走査し、ロールの重複を排除
    messages = merge_consecutive_messages(messages, add_timestamp=add_timestamp)

    # スナップショット
    # スナップショット (history_log_path が responding_ai_log_f と異なる場合のみ)
    if history_log_path and os.path.exists(history_log_path) and history_log_path != responding_ai_log_f:
        # [2026-02-14 FIX] フリーズ回避のため Lazy Loading
        try:
            h_dir = os.path.dirname(history_log_path)
            if os.path.basename(h_dir) == "logs":
                 h_room_dir = os.path.dirname(h_dir)
            else:
                 h_room_dir = h_dir
            snapshot_history_raw, _ = utils.load_chat_log_lazy(h_room_dir, limit=2000, min_turns=50)
        except Exception:
            snapshot_history_raw = utils.load_chat_log(history_log_path)

        snapshot_messages = convert_raw_log_to_lc_messages(
            snapshot_history_raw,
            room_to_respond,
            add_timestamp,
            send_thoughts_final,
            provider=current_provider,
            model_name=model_name,
            connection_id=gemini_signature_connection_id,
        )
        if snapshot_messages:
             messages.extend(snapshot_messages)

    # Discordグループ会話など、個別ログとは別管理の共有会話ログ。
    # 応答者本人の記憶・履歴に、グループ開始後の共有発言だけを合成する。
    if shared_history_log_path and os.path.exists(shared_history_log_path) and shared_history_log_path != responding_ai_log_f:
        shared_history_raw = utils.load_chat_log(shared_history_log_path, single_file_only=True)
        shared_messages = convert_raw_log_to_lc_messages(
            shared_history_raw,
            room_to_respond,
            add_timestamp,
            send_thoughts_final,
            provider=current_provider,
            model_name=model_name,
            connection_id=gemini_signature_connection_id,
        )
        if shared_messages:
            messages.extend(shared_messages)

    # ユーザー入力の調整
    is_first_responder = (room_to_respond == soul_vessel_room)
    if is_first_responder and messages and isinstance(messages[-1], HumanMessage):
        messages.pop()

    # プロンプトパーツの結合（添付ファイル等）
    final_prompt_parts = []

    # --- [v32 画像メモリシステム] 過去の履歴から VIEW_IMAGE タグを抽出 ---
    import re
    view_image_pattern = re.compile(r'\[VIEW_IMAGE:\s*(.*?)\]')
    history_loaded_images = []  # List of tuples: (img_path, source_role)

    if not suppress_history_image_memory:
        for i, msg in enumerate(reversed(messages[-15:])): # 最新15メッセージを後ろからスキャン
            role = "unknown"
            if isinstance(msg, HumanMessage):
                role = "human"
            elif isinstance(msg, AIMessage):
                role = "ai"
            elif isinstance(msg, ToolMessage):
                role = "tool"

            if isinstance(msg.content, str):
                found_images = view_image_pattern.findall(msg.content)
                for img_path in reversed(found_images): # 見つかった順（＝新しい順）に処理
                    if not any(img[0] == img_path for img in history_loaded_images) and os.path.exists(img_path):
                        history_loaded_images.append((img_path, role, i))
                        if len(history_loaded_images) >= 3: # 最大3枚に制限
                            break
            elif isinstance(msg.content, list):
                for part in reversed(msg.content):
                    if isinstance(part, dict) and part.get("type") == "text":
                        found = view_image_pattern.findall(part.get("text", ""))
                        for img_path in reversed(found):
                            if not any(img[0] == img_path for img in history_loaded_images) and os.path.exists(img_path):
                                history_loaded_images.append((img_path, role, i))
                                if len(history_loaded_images) >= 3:
                                    break
                    if len(history_loaded_images) >= 3: break
            if len(history_loaded_images) >= 3: break

    # 古い順に戻す（モデルへの提示順序を自然にするため）
    history_loaded_images.reverse()

    if history_loaded_images:
        for img_path, role, dist in history_loaded_images:
            try:
                display_name = os.path.basename(img_path)
                kind = filetype.guess(img_path)
                if kind and kind.mime.startswith('image/'):
                    # リマインダー用画像はさらに小さく (512px) 制限
                    resize_result = utils.resize_image_for_api(img_path, max_size=512, return_image=False)
                    if resize_result:
                        encoded_string, output_format = resize_result
                        mime_type = f"image/{output_format}"
                    else:
                        with open(img_path, "rb") as f:
                            encoded_string = base64.b64encode(f.read()).decode("utf-8")
                        mime_type = kind.mime

                    # 時間情報の構築 (dist は逆順インデックスなので、0が直近のメッセージ)
                    # メッセージ履歴は [..., AI(dist=1), Human(dist=0)] のような並び
                    time_label = "（直近のやり取り）" if dist <= 1 else f"（{dist}件前のやり取り）"

                    # ロールに応じたラベル付与
                    label = "画像"
                    if role == "human":
                        label = "ユーザーからの添付画像"
                    elif role == "ai":
                        label = "以前に自分が生成した画像"
                    elif role == "tool":
                        label = "ツールが生成・出力した画像"

                    final_prompt_parts.append({"type": "text", "text": f"- [{time_label}{label} {display_name}]"})
                    final_prompt_parts.append({"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{encoded_string}"}})
            except Exception as e:
                print(f"Past image memory load error: {e}")
    # -------------------------------------------------------------------------
    if active_attachments:
        from pathlib import Path
        for file_path_str in active_attachments:
            try:
                path_obj = Path(file_path_str)
                display_name = '_'.join(path_obj.name.split('_')[1:]) or path_obj.name
                kind = filetype.guess(file_path_str)
                if kind and kind.mime.startswith('image/'):
                    with open(file_path_str, "rb") as f:
                        encoded_string = base64.b64encode(f.read()).decode("utf-8")
                    final_prompt_parts.append({"type": "text", "text": f"- [{display_name}]"})
                    final_prompt_parts.append({"type": "image_url", "image_url": {"url": f"data:{kind.mime};base64,{encoded_string}"}})
                elif kind and (kind.mime.startswith('audio/') or kind.mime.startswith('video/')):
                    with open(file_path_str, "rb") as f:
                        encoded_string = base64.b64encode(f.read()).decode("utf-8")
                    final_prompt_parts.append({"type": "text", "text": f"- [{display_name}]"})
                    final_prompt_parts.append({"type": "file", "source_type": "base64", "mime_type": kind.mime, "data": encoded_string})
                else:
                    content = path_obj.read_text(encoding='utf-8', errors='ignore')
                    final_prompt_parts.append({"type": "text", "text": f"- [{display_name}]:\n{content}"})
            except Exception as e:
                print(f"添付ファイル処理エラー: {e}")

    if (is_first_responder or force_user_prompt_parts) and user_prompt_parts:
        final_prompt_parts.extend(user_prompt_parts)

    if final_prompt_parts:
        has_images = any(isinstance(p, dict) and p.get('type') in ('file', 'image_url') for p in final_prompt_parts)
        if not has_images:
            flat_content = "\n".join([p.get('text', '') if isinstance(p, dict) else str(p) for p in final_prompt_parts])
            messages.append(HumanMessage(content=flat_content))
        else:
            messages.append(HumanMessage(content=final_prompt_parts))

    # 【重要】最終的なメッセージリストを走査し、ロールの重複を排除
    messages = merge_consecutive_messages(messages, add_timestamp=add_timestamp)

    # 履歴制限
    if api_history_limit == "today":
        cutoff_date = _get_effective_today_cutoff(room_to_respond, silent=False)
        original_messages = messages.copy()
        today_messages = _filter_messages_from_today(messages, cutoff_date)

        # 【2026-04-16 FIX】Auto Summary は「カットオフ日以降のメッセージ（本日分）」のみを対象にする
        # 以前はフォールバック後のメッセージリスト（昨日分を含む）に対して要約が走り、
        # エピソード記憶と会話要約で昨日分が二重送信されていた。
        auto_summary_applied = False  # Auto Summary が実際に適用されたかどうかのフラグ
        auto_summary_enabled = effective_settings.get("auto_summary_enabled", False)
        if auto_summary_enabled:
            if is_vertex_connection:
                # Vertex ADC/API-key は Developer キー台帳に存在しない。要約生成は
                # 内部ロールの共通 Vertex 接続へ委譲するため、キーを要求しない。
                summary_api_key = None
            else:
                temp_clean_key_name = config_manager._clean_api_key_name(current_retry_api_key_name)
                summary_api_key = config_manager.GEMINI_API_KEYS.get(temp_clean_key_name)

            if summary_api_key or is_vertex_connection:
                pre_summary_count = len(today_messages)
                today_messages = _apply_auto_summary(
                    today_messages,
                    room_to_respond,
                    summary_api_key,
                    effective_settings.get("auto_summary_threshold", constants.AUTO_SUMMARY_DEFAULT_THRESHOLD),
                    allow_generation=True,
                    debug_mode=debug_mode
                )
                # 要約が挿入された場合は、件数が増えるケース（既存要約 + pending）でもフォールバックを抑制する。
                has_summary_message = any(
                    "【本日のこれまでの会話の要約】" in str(getattr(m, "content", ""))
                    for m in today_messages
                )
                if len(today_messages) < pre_summary_count or has_summary_message:
                    auto_summary_applied = True
            elif debug_mode:
                print("  - [Auto Summary Debug] 要約用APIキーが見つからないためスキップ")

        # フォールバック: Auto Summary 適用後の本日分が最低件数に満たない場合、
        # カットオフ日より前のメッセージを「文脈バッファ」として先頭に追加する
        # 【2026-04-17 FIX】Auto Summary が適用された場合はフォールバックを抑制する。
        # 要約で圧縮した会話を生テキストで復活させてしまうと、要約の意味がなくなるため。
        fallback_count = 0
        min_messages = constants.MIN_TODAY_LOG_FALLBACK_TURNS * 2
        if not auto_summary_applied and len(today_messages) < min_messages and len(original_messages) > len(today_messages):
            needed = min_messages - len(today_messages)
            # original_messages の末尾から today_messages の開始位置を推定
            today_filtered_count = len(_filter_messages_from_today(original_messages, cutoff_date))
            fallback_pool_end = len(original_messages) - today_filtered_count
            fallback_start = max(0, fallback_pool_end - needed)
            fallback_messages = original_messages[fallback_start:fallback_pool_end]
            fallback_count = len(fallback_messages)
            messages = fallback_messages + today_messages
        else:
            messages = today_messages

        print(f"  - [History Limit] 本日分モード: {len(messages)}件のメッセージを送信 (カットオフ: {cutoff_date})")
        if auto_summary_applied:
            print(f"    -> 構成: [Auto Summary 1件] + [直近ログ {len(messages) - 1}件]")
        elif fallback_count > 0:
            print(f"    -> 構成: [フォールバック {fallback_count}件] + [本日分 {len(messages) - fallback_count}件]")
    elif api_history_limit == "all":
        original_count = len(messages)
        messages = _cap_sequence_for_all_history(messages)
        if original_count != len(messages):
            print(f"  - [History Limit] 最大表示モード: {original_count}件 -> {len(messages)}件に制限")
    elif api_history_limit.isdigit():
        limit = int(api_history_limit)
        if limit > 0 and len(messages) > limit * 2:
            messages = messages[-(limit * 2):]

    # --- [Debug Mode] 送信メッセージ構成の最終確認ログ ---
    if debug_mode:
        # 要約メッセージの位置を事前に特定
        summary_idx = None
        for i, m in enumerate(messages):
            m_content = str(getattr(m, 'content', ''))
            if "【本日のこれまでの会話の要約】" in m_content:
                summary_idx = i
                break

        print("\n  [Debug] --- 送信メッセージ構成確認 ---")
        for i, m in enumerate(messages):
            role = "USER" if isinstance(m, HumanMessage) else "AGENT"
            m_content = getattr(m, 'content', '')
            if isinstance(m_content, list):
                text_part = ""
                for p in m_content:
                    if isinstance(p, dict) and p.get('type') == 'text':
                        text_part += p.get('text', '')
                preview = text_part[:60].replace('\n', ' ') + "..."
            else:
                preview = str(m_content)[:60].replace('\n', ' ') + "..."

            # セクション境界の表示
            if summary_idx is not None:
                if i == 0 and summary_idx > 0:
                    print(f"  --- フォールバック（文脈補填: {summary_idx}件） ---")
                if i == summary_idx:
                    print(f"  --- 会話要約（Auto Summary） ---")
                if i == summary_idx + 1:
                    print(f"  --- 直近の会話ログ（{len(messages) - i}件） ---")

            is_summary = (i == summary_idx)
            label = " [SUMMARY]" if is_summary else ""
            print(f"    {i:02d}: {role}{label} | {preview}")
        print("  [Debug] ------------------------------\n")

    # 現在のチャット欄にあるメッセージ数（新規追加分を除く）をUIに伝える
    # [Note] 早期リターン時にスライス不備で過去ログが再表示されるのを防ぐため、ここで確定させる
    yield ("initial_count", len(messages))

    # --- [Phase 1.1] 枯渇チェック (以前の [2026-01-31 FIX] 部分) ---
    # [2026-02-15 FIX] Clean key name before checking exhaustion
    clean_current_retry_api_key_name = (
        config_manager._clean_api_key_name(current_retry_api_key_name)
        if not is_vertex_connection else None
    )
    if not is_vertex_connection and config_manager.is_key_exhausted(
        clean_current_retry_api_key_name,
        model_name=model_name,
    ):
        # Rotation有効確認
        enable_rotation = effective_settings.get("enable_api_key_rotation")
        if enable_rotation is None: # 個別未設定なら共通設定
             enable_rotation = config_manager.CONFIG_GLOBAL.get("enable_api_key_rotation", True)

        if not enable_rotation:
            print(f"  [Rotation] 指定キー '{current_retry_api_key_name}' はモデル '{model_name}' で枯渇状態ですが、ローテーションが無効なためエラーとします")
            error_msg = AIMessage(content=f"[エラー: 指定されたAPIキー '{current_retry_api_key_name}' がモデル '{model_name}' で枯渇しています。設定でローテーションが無効なため、処理を中断しました。]")
            yield ("initial_count", len(messages))
            yield ("values", {"messages": messages + [error_msg]})
            return

        print(f"  [Rotation] 指定キー '{current_retry_api_key_name}' はモデル '{model_name}' で枯渇状態。代替キーを探索中...")
        alternative_key = config_manager.get_next_available_gemini_key(
            current_exhausted_key=current_retry_api_key_name,
            model_name=model_name
        )
        if alternative_key:
            print(f"  [Rotation] 代替キー '{alternative_key}' に切り替えます")
            current_retry_api_key_name = alternative_key
            # [2026-02-11 FIX] last_api_key_name の永続保存を削除
            # ローテーションはセッション内のみで管理し、ユーザーの選択キーを保護
        else:
            error_msg = AIMessage(content="[エラー: 利用可能なAPIキーがありません。しばらく時間をおいてから再試行してください。]")
            yield ("initial_count", len(messages))
            yield ("values", {"messages": messages + [error_msg]})
            return

    tried_keys = set() if is_vertex_connection else {current_retry_api_key_name}
    if is_vertex_connection:
        # ADC は API キーなしで動作する。API-key express も値は接続辞書内に保持される。
        api_key = None
    else:
        # [2026-02-15 FIX] Clean key name before fetching from GEMINI_API_KEYS
        clean_key_name = config_manager._clean_api_key_name(current_retry_api_key_name)
        api_key = config_manager.GEMINI_API_KEYS.get(clean_key_name)

    if not is_vertex_connection and (not api_key or api_key.startswith("YOUR_API_KEY")):
        error_msg = AIMessage(content=f"[エラー: APIキー '{current_retry_api_key_name}' が無効です。]")
        yield ("initial_count", len(messages))
        yield ("values", {"messages": messages + [error_msg]})
        return

    # Agent State 初期化 (messages は確定済み、初期カウント yield 済み)
    initial_state = {
        "messages": messages, "room_name": room_to_respond,
        "api_key": api_key, "api_key_name": current_retry_api_key_name,
        "model_name": model_name,
        # グラフ内の全ノードで同一接続を使う。Vertex 接続辞書自体は
        # 外部ログへ出さず、状態引き渡し専用とする。
        "_gemini_connection": gemini_connection,
        "generation_config": effective_settings,
        "send_core_memory": effective_settings.get("send_core_memory", True),
        "send_scenery": effective_settings.get("send_scenery", True),
        "send_notepad": effective_settings.get("send_notepad", True),
        "send_thoughts": send_thoughts_final,
        "send_current_time": effective_settings.get("send_current_time", False),
        "debug_mode": debug_mode,
        "display_thoughts": effective_settings.get("display_thoughts", True),
        "location_name": shared_location_name,
        "scenery_text": shared_scenery_text,
        "all_participants": all_participants_list,
        "loop_count": 0,
        "season_en": season_en, "time_of_day_en": time_of_day_en,
        "skip_tool_execution": skip_tool_execution_flag,
        "tool_use_enabled": config_manager.is_tool_use_enabled(room_to_respond),
        "autonomous_action": autonomous_action_mode,
        "autonomous_trigger_source": str(agent_args.get("autonomous_trigger_source") or "autonomous"),
        "autonomous_timeline_id": str(agent_args.get("autonomous_timeline_id") or ""),
        "autonomy_finalization_pending": False,
        "autonomy_finalization_reason": "",
        "enable_supervisor": enable_supervisor_flag,
        "speakers_this_turn": []
    }

    # --- 【2026-01-19 FIX】Gemini 3 Flash デッドロック対策 ---
    # Gemini 3 Flash Preview + ツール使用 + ストリーミングの組み合わせで
    # APIがハングアップする問題への対策として、該当モデル使用時はストリーミングを無効化
    # 参考: docs/plans/research/Gemini 3 Flash API 応答遅延問題調査.md
    is_gemini_3_flash = _is_gemini_3_flash_family(model_name)
    tool_use_enabled = initial_state.get("tool_use_enabled", True)

    # --- [Phase 1.5] API Key Rotation Loop ---
    max_retries = 10
    retry_count = 0
    local_503_retry_count = 0 # 503エラー専用の再試行カウンタ
    max_local_503_retries, rotate_after_503_exhausted = _gemini_503_outer_retry_policy(
        autonomous_action_mode=autonomous_action_mode
    )
    autonomous_fallback_used = False

    # [2026-02-21 FIX] リトライ時に成功済みの状態（RAG検索結果等）を引き継ぐための変数
    latest_state_values = initial_state.copy()
    retry_room = room_to_respond

    while retry_count <= max_retries:
        try:
            checkpoint_lite_request(lite_scope)
            # 情景描写が未取得の場合は、現在のAPIキーで取得を試みる（ローテーション対象にするため）
            if not latest_state_values.get("scenery_text") or not latest_state_values.get("location_name"):
                print(f"  - [Invoke] 情景描写を遅延生成中... (Key: {current_retry_api_key_name})")
                from agent.scenery_manager import generate_scenery_context
                loc_name, _, scen_text = generate_scenery_context(
                    latest_state_values.get("room_name", room_to_respond), api_key,
                    season_en=season_en, time_of_day_en=time_of_day_en,
                )
                latest_state_values["location_name"] = loc_name
                latest_state_values["scenery_text"] = scen_text

            # 実行前にAPIキーをStateに再設定（ローテーション反映）
            latest_state_values["api_key"] = api_key
            latest_state_values["api_key_name"] = current_retry_api_key_name

            # [2026-02-21 FIX] Gemini 3 Flash でも中間状態を保存できるように app.stream を常に使用する。
            # (LLM側のストリーミングは agent_node 内部で適切に制御される)

            # --- 初期デバッグ表示 ---
            if is_gemini_3_flash and tool_use_enabled and retry_count == 0:
                 print(f"  - [Gemini 3 Flash] グラフ実行をストリームモードで開始（中間状態の保存を有効化）")

            # --- 通常のストリーム実行とコンテキストの保存 ---
            # Graphから返ってくるチャンクを監視する
            import threading
            import queue

            q = queue.Queue()
            thread_error = []

            def run_stream():
                try:
                    with bind_lite_request_scope(lite_scope):
                        checkpoint_lite_request(lite_scope)
                        mark_lite_external_request_started(lite_scope)
                        try:
                            for s_mode, s_payload in app.stream(latest_state_values, stream_mode=["messages", "values"]):
                                checkpoint_lite_request(lite_scope)
                                q.put((s_mode, s_payload))
                            checkpoint_lite_request(lite_scope)
                            q.put(("DONE", None))
                        finally:
                            mark_lite_external_request_finished(lite_scope)
                except Exception as stream_e:
                    thread_error.append(stream_e)
                    q.put(("ERROR", None))

            t = threading.Thread(target=run_stream, daemon=True)
            t.start()

            while True:
                try:
                    mode, payload = q.get(timeout=0.5)

                    if mode == "DONE":
                        break
                    elif mode == "ERROR":
                        if thread_error:
                            raise thread_error[0]
                        else:
                            raise RuntimeError("Unknown error in background thread")

                    if mode == "values":
                        # [2026-02-21 FIX] 最新の状態（コンテキスト検索結果など）を記録
                        # これにより RAG 完了後に agent_node で 429 が出た場合でも RAG を再実行せずに済む
                        latest_state_values.update(payload)

                    if mode == "messages":
                         msgs = payload if isinstance(payload, list) else [payload]
                         for msg in msgs:
                             if isinstance(msg, AIMessage):
                                 # 署名を抽出（Gemini 3形式を優先）
                                 sig = msg.additional_kwargs.get("__gemini_function_call_thought_signatures__")
                                 if not sig:
                                     sig = msg.additional_kwargs.get("thought_signature")
                                 if not sig and hasattr(msg, "response_metadata"):
                                     sig = msg.response_metadata.get("thought_signature")

                                 # ツールコールがあれば抽出
                                 t_calls = msg.tool_calls if hasattr(msg, "tool_calls") else []

                                 # Googleの署名だけを、実際に応答したモデル由来で永続化する。
                                 # graphがfactoryの実モデルをmarkerへ記録している場合は、
                                 # outer stateの要求モデルよりAIMessageの由来を優先する。
                                 message_kwargs = getattr(msg, "additional_kwargs", {}) or {}
                                 signature_model_marker = normalize_model_name(
                                     str(message_kwargs.get("__nexus_gemini_signature_model__", "") or "")
                                 )
                                 response_model_name = (
                                     signature_model_marker
                                     or latest_state_values.get("model_name")
                                     or model_name
                                 )
                                 signature_room = latest_state_values.get("room_name", room_to_respond)
                                 signature_connection = latest_state_values.get("_gemini_connection", gemini_connection)
                                 signature_id = _get_gemini_connection_module().connection_id(signature_connection)
                                 signature_provider = config_manager.get_active_provider(signature_room)
                                 origin_id = message_kwargs.get("__nexus_gemini_signature_connection__", signature_id)
                                 if signature_provider in {"google", "Google (Gemini)", "Google (Gemini Native)"} and (sig or t_calls) and origin_id == signature_id:
                                     signature_manager.save_turn_context(
                                         signature_room, sig, t_calls,
                                         model_name=response_model_name,
                                         connection_id=signature_id,
                                     )

                    checkpoint_lite_request(lite_scope)
                    if mode == "values" and isinstance(payload, dict):
                        # Vertex API key を含む接続スナップショットはグラフ内部だけで
                        # 使用し、ストリーム利用者へ状態全体を返さない。
                        public_payload = dict(payload)
                        public_payload.pop("_gemini_connection", None)
                        public_payload.pop("api_key", None)
                        if isinstance(public_payload.get("generation_config"), dict):
                            public_payload["generation_config"] = dict(public_payload["generation_config"])
                            public_payload["generation_config"].pop("gemini_connection", None)
                        yield (mode, public_payload)
                    else:
                        yield (mode, payload)
                except queue.Empty:
                    checkpoint_lite_request(lite_scope)
                    yield ("heartbeat", None)

            break # Success

        except Exception as e:
            if isinstance(e, LiteRequestStopped):
                raise
            active_room = latest_state_values.get("room_name", room_to_respond)
            gemini_connection = latest_state_values.get("_gemini_connection", gemini_connection)
            is_vertex_connection = _is_vertex_connection(gemini_connection)
            current_provider = config_manager.get_active_provider(active_room)
            model_name = latest_state_values.get("model_name") or model_name
            effective_settings = latest_state_values.get("generation_config") or effective_settings
            current_retry_api_key_name = latest_state_values.get("api_key_name")
            api_key = latest_state_values.get("api_key")
            if active_room != retry_room:
                tried_keys = set() if is_vertex_connection else {current_retry_api_key_name}
                retry_count = 0
                local_503_retry_count = 0
                retry_room = active_room
            if current_provider not in {"google", "Google (Gemini)", "Google (Gemini Native)"}:
                yield ("values", {"messages": latest_state_values.get("messages", []) + [
                    AIMessage(content="[エラー: 応答モデルの実行に失敗しました。接続先を確認してください。]"),
                ]})
                return
            # 429 エラーハンドリング（ローテーション）。
            # 判定を確実にし、SDKラップされた例外からも救い出す。
            from google.api_core.exceptions import ResourceExhausted
            import time
            import traceback

            # [2026-02-17 NEW] モデル特定例外の処理
            failed_model = model_name
            if isinstance(e, utils.ModelSpecificResourceExhausted):
                failed_model = e.model_name
                original_e = e.original_exception
                err_str = str(original_e).upper()
                is_429 = True # この例外自体が 429 前提
                e = original_e # 以降の処理のためにオリジナルの例外に戻す
            else:
                err_str = str(e).upper()
                is_429 = isinstance(e, (ResourceExhausted, ChatGoogleGenerativeAIError)) or "429" in err_str or "RESOURCE_EXHAUSTED" in err_str

            # 503 UNAVAILABLE / Overloaded の判定
            is_503 = _is_gemini_503_error(err_str, is_429=is_429)
            limit_type = _classify_gemini_429_limit(err_str) if is_429 else "RPM"

            if is_vertex_connection:
                diagnostic = _get_gemini_connection_module().vertex_error_message(e)
                # Vertex の失敗は同一 project/location の接続エラーとして返す。
                # Developer API キーの有料待機・枯渇記録・回転・モデル退避は行わない。
                if is_429:
                    msg_text = (
                        f"[エラー: Vertex AI の割り当て制限(429)により応答できませんでした。"
                        f" (モデル: {failed_model})]\n{diagnostic}"
                    )
                elif is_503:
                    msg_text = (
                        f"[エラー: Vertex AI が一時的に利用不可(503)です。"
                        f" (モデル: {failed_model})]\n{diagnostic}"
                    )
                else:
                    msg_text = f"[エラー: {diagnostic}]"
                yield ("initial_count", len(latest_state_values.get("messages", [])))
                yield (
                    "values",
                    {"messages": latest_state_values.get("messages", []) + [AIMessage(content=msg_text)]},
                )
                return

            if not is_429 and not is_503:
                # 429以外のエラーは通常のエラーハンドリングへ
                err_content = f"[エラー: AIモデル実行中にエラーが発生しました: {e}]"
                full_messages = latest_state_values.get("messages", []) + [AIMessage(content=err_content)]
                yield ("initial_count", len(latest_state_values.get("messages", []))) # Ensure initial_count is yielded
                yield ("values", {"messages": full_messages})
                return

            if is_503 and local_503_retry_count < max_local_503_retries:
                local_503_retry_count += 1
                wait_time = local_503_retry_count * 2 # 2, 4, 6秒と待機を増やす
                print(f"  [Warning] 503 UNAVAILABLE (Overloaded) detected. Retrying on SAME key '{current_retry_api_key_name}' (attempt {local_503_retry_count}/{max_local_503_retries}) after {wait_time}s...")
                wait_lite_retry(wait_time, lite_scope)
                continue # 同一キーで再試行

            if is_503 and not rotate_after_503_exhausted:
                msg_text = (
                    f"[エラー: Gemini APIが一時的に利用不可(503)です。"
                    f"自律行動の長時間リトライを避けるため、今回の処理を中断しました。"
                    f" (モデル: {failed_model} / キー: {current_retry_api_key_name})]"
                )
                print(
                    "  [Autonomy 503 Guard] 自律行動中の503がリトライ上限に達したため、"
                    "キー切替へ進まず今回の処理を中断します。"
                )
                yield ("initial_count", len(latest_state_values.get("messages", [])))
                yield ("values", {"messages": latest_state_values.get("messages", []) + [AIMessage(content=msg_text)]})
                return

            # --- [2026-02-18 NEW] 有料キーの最終防波堤ロジック ---
            paid_key_names = config_manager.CONFIG_GLOBAL.get("paid_api_key_names", [])
            clean_current_key = config_manager._clean_api_key_name(current_retry_api_key_name)
            is_paid_key = clean_current_key in paid_key_names

            # 429エラーかつ有料キーの場合、即座にローテーションせず少し粘る
            if is_429 and is_paid_key and retry_count < 3:
                retry_count += 1
                wait_time = 5 * retry_count
                print(f"  [Paid Key Backoff] 有料キー '{current_retry_api_key_name}' で 429 エラー。{wait_time}秒待機して再試行します... ({retry_count}/3)")
                wait_lite_retry(wait_time, lite_scope)
                continue

            retry_count += 1
            if is_429:
                print(f"  [Error] ResourceExhausted (429) for model '{failed_model}': {e}")
            else:
                print(f"  [Error] Service Unavailable (503) - Final attempt reached: {e}")

            # ローテーションへ進む前にカウンタをリセット
            local_503_retry_count = 0

            # Rotation有効確認 (グローバル設定をベースにし、個別設定が明示的にある場合のみ上書き)
            enable_rotation = config_manager.CONFIG_GLOBAL.get("enable_api_key_rotation", True)
            room_rotation_override = effective_settings.get("enable_api_key_rotation")

            # [2026-02-19 FIX] ルームのプロバイダ設定が「共通設定(None)」の場合は、
            # 個別ローテーション設定(False等)が残っていてもグローバルに従う
            room_provider = effective_settings.get("provider") # これは get_effective_settings で解決済み
            # 実際には get_effective_settings 側でルーム設定に provider がない場合はグローバルが返るが、
            # room_config.json の生の override_settings を確認する必要があるかもしれない。
            # しかし、より安全なのは global を優先し、明らかに個別設定が生きている時だけ override すること。
            if room_rotation_override is not None:
                enable_rotation = room_rotation_override

            if not enable_rotation:
                # ローテーションOFF時に沈黙しないよう、エラーを通知
                yield ("initial_count", len(latest_state_values.get("messages", [])))
                if is_429:
                    error_msg = f"[エラー: API割り当て制限(429)を超過しました。モデル: {failed_model} / キー: {current_retry_api_key_name}]"
                else:
                    error_msg = f"[エラー: サーバーが一時的に利用不可(503)です。モデル: {failed_model} / キー: {current_retry_api_key_name}]"
                yield ("values", {"messages": latest_state_values.get("messages", []) + [AIMessage(content=error_msg)]})
                return

            # 429 の場合のみキーを枯渇済みとしてマーク
            if is_429:
                # 有料キーは永続的な枯渇マークを付けない（config_manager側でハンドリングされるが明示的に）
                config_manager.mark_key_as_exhausted(
                    clean_current_key,
                    model_name=failed_model,
                    limit_type=limit_type
                )
                print(f"  [Rotation] Key '{current_retry_api_key_name}' marked as exhausted ({limit_type}) for model '{failed_model}'.")
            else:
                print(f"  [Rotation] 503 Error rotation - Rotating to NEXT key without marking '{current_retry_api_key_name}' as exhausted.")

            # 次のキーを取得
            next_key_name = config_manager.get_next_available_gemini_key(
                current_exhausted_key=current_retry_api_key_name,
                excluded_keys=tried_keys,
                model_name=failed_model
            )

            if not next_key_name:
                 if is_429 and autonomous_action_mode and not autonomous_fallback_used:
                     if not _can_use_lightweight_429_fallback(latest_state_values, autonomous_action_mode=autonomous_action_mode):
                         print(
                             "  [Autonomy 429 Fallback] 本人の声が重要なツール/応答に関わる可能性があるため、"
                             "軽量モデルへの退避を見送ります。"
                         )
                     else:
                         fallback_model = _get_autonomous_429_fallback_model()
                         if fallback_model and fallback_model != failed_model:
                             fallback_key_name = config_manager.get_active_gemini_api_key_name(
                                 active_room,
                                 model_name=fallback_model,
                                 excluded_keys=set(),
                             )
                             clean_fallback_key_name = config_manager._clean_api_key_name(fallback_key_name)
                             fallback_api_key = config_manager.GEMINI_API_KEYS.get(clean_fallback_key_name)
                             if fallback_key_name and fallback_api_key and not fallback_api_key.startswith("YOUR_API_KEY"):
                                 print(
                                     f"  [Autonomy 429 Fallback] 全キー枯渇後の最終手段として、"
                                     f"モデルを '{failed_model}' から '{fallback_model}' へ切り替えて続行します。"
                                 )
                                 autonomous_fallback_used = True
                                 model_name = fallback_model
                                 is_gemini_3_flash = _is_gemini_3_flash_family(model_name)
                                 current_retry_api_key_name = fallback_key_name
                                 api_key = fallback_api_key
                                 tried_keys = {fallback_key_name}
                                 retry_count = 0
                                 latest_state_values["model_name"] = fallback_model
                                 latest_state_values["api_key"] = api_key
                                 latest_state_values["api_key_name"] = fallback_key_name
                                 continue
                             else:
                                 print(f"  [Autonomy 429 Fallback] フォールバックモデル '{fallback_model}' 用のAPIキーが見つかりません。")

                 if is_429:
                     msg_text = f"[エラー: API割り当て制限(429)を超過しました。利用可能なすべてのAPIキーを試しましたが、成功しませんでした。 (モデル: {failed_model})]"
                 else:
                     msg_text = f"[エラー: サーバーが一時的に利用不可(503)です。利用可能なすべてのAPIキーを試しましたが、成功しませんでした。 (モデル: {failed_model})]"
                 error_msg = AIMessage(content=msg_text)
                 yield ("initial_count", len(latest_state_values.get("messages", [])))
                 yield ("values", {"messages": latest_state_values.get("messages", []) + [error_msg]})
                 return

            tried_keys.add(next_key_name)

            checkpoint_lite_request(lite_scope)

            # [2026-02-15 FIX] バックオフ待機を入れて安定化させる
            wait_time = 1.0 + (retry_count * 0.5)
            print(f"  [Rotation] Switching key: '{current_retry_api_key_name}' -> '{next_key_name}' (Wait {wait_time}s...)")
            wait_lite_retry(wait_time, lite_scope)

            # 次の試行のために変数を更新
            current_retry_api_key_name = next_key_name
            clean_next_key_name = config_manager._clean_api_key_name(next_key_name)
            api_key = config_manager.GEMINI_API_KEYS.get(clean_next_key_name)

            # [2026-02-19 FIX] ステートを同期（後続ノードが新しいキーを認識できるようにする）
            latest_state_values["api_key"] = api_key
            latest_state_values["api_key_name"] = next_key_name

            continue


        except Exception as e:
            if isinstance(e, LiteRequestStopped):
                raise
            traceback.print_exc()
            yield ("initial_count", len(latest_state_values.get("messages", [])))
            yield ("values", {"messages": [AIMessage(content=f"[エラー: 予期せぬ例外が発生しました: {e}]")]})
            return


def count_input_tokens(**kwargs):
    room_name = kwargs.get("room_name")
    api_key_name = kwargs.get("api_key_name")
    api_history_limit_arg = kwargs.get("api_history_limit") # Rename to avoid conflict with local variable
    lookback_days_arg = kwargs.get("lookback_days")
    enable_self_awareness_arg = kwargs.get("enable_self_awareness")
    parts = kwargs.get("parts", [])

    api_key = config_manager.GEMINI_API_KEYS.get(api_key_name)
    token_connection = None
    try:
        if config_manager.get_active_provider(room_name) in {"google", "Google (Gemini)", "Google (Gemini Native)"}:
            token_connection = _get_connection(room_name=room_name, force_global=False)
    except Exception:
        token_connection = None
    is_vertex_token_connection = _is_vertex_connection(token_connection)
    if not is_vertex_token_connection and (not api_key or api_key.startswith("YOUR_API_KEY")):
        return "トークン数: (APIキーエラー)"

    try:
        kwargs_for_settings = kwargs.copy()
        kwargs_for_settings.pop("room_name", None)
        kwargs_for_settings.pop("api_key_name", None)
        kwargs_for_settings.pop("api_history_limit", None)
        kwargs_for_settings.pop("lookback_days", None)
        kwargs_for_settings.pop("enable_self_awareness", None)
        kwargs_for_settings.pop("parts", None)

        effective_settings = config_manager.get_effective_settings(room_name, **kwargs_for_settings)

        # UIからの引数で設定を上書き
        if lookback_days_arg is not None:
            effective_settings["episodic_memory_lookback_days"] = lookback_days_arg
        if enable_self_awareness_arg is not None:
            effective_settings["enable_self_awareness"] = enable_self_awareness_arg

        api_history_limit = api_history_limit_arg or effective_settings.get("api_history_limit", "today")

        model_name = effective_settings.get("model_name") or config_manager.DEFAULT_MODEL_GLOBAL

        messages: List[Union[SystemMessage, HumanMessage, AIMessage]] = []

        # --- [Step 1: 先に履歴を読み込む] ---
        # エピソード記憶の注入範囲を決めるために、履歴の「最古の日付」が必要なため
        log_file, _, _, _, _, _, _ = room_manager.get_room_files_paths(room_name)

        # [2026-02-14 FIX] トークン計算時の全件読み込み回避 (Lazy Loading)
        try:
            l_dir = os.path.dirname(log_file)
            r_dir = os.path.dirname(l_dir) if os.path.basename(l_dir) == "logs" else l_dir
            raw_history, _ = utils.load_chat_log_lazy(r_dir, limit=2000, min_turns=50)
        except Exception:
            raw_history = utils.load_chat_log(log_file)

        # 履歴制限の適用
        # 【2026-04-16 FIX】フォールバックとAuto Summaryの分離
        # invoke_nexus_agent_stream と同じ方式: Auto Summary → フォールバック の順
        today_raw_history = None  # Auto Summary用に本日分を分離
        fallback_raw_history = []  # フォールバック分（要約対象外）
        if api_history_limit == "today":
            cutoff_date = _get_effective_today_cutoff(room_name, silent=True)
            original_raw_history = raw_history.copy()
            today_raw_history = _filter_raw_history_from_today(raw_history, cutoff_date)

            # 【2026-04-17 FIX】Auto Summary 有効時はフォールバックを抑制
            # （invoke_nexus_agent_stream 側と同じ方針）
            auto_summary_enabled_tk = effective_settings.get("auto_summary_enabled", False)
            auto_summary_threshold_tk = effective_settings.get("auto_summary_threshold", constants.AUTO_SUMMARY_DEFAULT_THRESHOLD)
            total_chars_today = sum(len(item.get('content', '')) for item in today_raw_history if isinstance(item.get('content'), str))
            auto_summary_will_apply = auto_summary_enabled_tk and total_chars_today > auto_summary_threshold_tk

            # フォールバック: 本日分が最低件数に満たない場合、カットオフ前のメッセージを補填
            # ただし Auto Summary が適用される場合はスキップ（要約済み内容を復活させないため）
            min_messages = constants.MIN_TODAY_LOG_FALLBACK_TURNS * 2
            if not auto_summary_will_apply and len(today_raw_history) < min_messages and len(original_raw_history) > len(today_raw_history):
                needed = min_messages - len(today_raw_history)
                today_count = len(_filter_raw_history_from_today(original_raw_history, cutoff_date))
                pool_end = len(original_raw_history) - today_count
                fb_start = max(0, pool_end - needed)
                fallback_raw_history = original_raw_history[fb_start:pool_end]
            raw_history = today_raw_history  # Auto Summary 用は本日分のみ
        elif api_history_limit == "all":
            raw_history = _cap_sequence_for_all_history(raw_history)
        elif api_history_limit and api_history_limit.isdigit():
            limit = int(api_history_limit)
            if limit > 0 and len(raw_history) > limit * 2:
                raw_history = raw_history[-(limit * 2):]

        # --- [Step 2: エピソード記憶の取得] ---
        # エピソード記憶（中期記憶）の推定文字数
        lookback_days_str = effective_settings.get("episodic_memory_lookback_days", "なし（無効）")

        # EPISODIC_MEMORY_OPTIONS の値形式（「なし（無効）」「過去 1日」「過去 2週間」等）に対応
        episodic_memory_section = ""
        days_num = 0

        # lookback_days_str が dict などの場合は無効として扱う
        if not isinstance(lookback_days_str, str):
            lookback_days_str = "なし（無効）"

        if lookback_days_str in ("なし（無効）", "なし", "", "0", None):
            episodic_memory_section = ""
        else:
            # 「過去 X日」「過去 X週間」「過去 Xヶ月」形式をパース
            try:
                import re
                # "過去 1日" -> 1, "過去 2週間" -> 14, "過去 1ヶ月" -> 30
                match = re.search(r"(\d+)\s*(日|週間|ヶ月)", lookback_days_str)
                if match:
                    num = int(match.group(1))
                    unit = match.group(2)
                    if unit == "日":
                        days_num = num
                    elif unit == "週間":
                        days_num = num * 7
                    elif unit == "ヶ月":
                        days_num = num * 30
            except Exception as parse_e:
                print(f"エピソード記憶期間のパースエラー: {parse_e}")

            if days_num > 0:
                # 推定文字数の算出（安全のため少し多めに見積もる）
                estimated_chars = min(500 + days_num * 50, 3000)
                episodic_memory_section = f"\n### エピソード記憶（直近{lookback_days_str}の要約）\n" + "x" * estimated_chars + "\n"

                # 実際の日付ベースの検索を試みる（見積もり精度向上のため）
                try:
                    oldest_log_date_str = None
                    date_pattern = re.compile(r"(\d{4}-\d{2}-\d{2})")

                    for msg in raw_history:
                        content = msg.get("content", "")
                        match_date = date_pattern.search(content)
                        if match_date:
                            oldest_log_date_str = match_date.group(1)
                            break

                    if not oldest_log_date_str:
                        oldest_log_date_str = datetime.datetime.now().strftime('%Y-%m-%d')

                    manager = EpisodicMemoryManager(room_name)
                    episodic_text = manager.get_episodic_context(oldest_log_date_str, days_num)

                    if episodic_text:
                        episodic_memory_section = (
                            f"\n### エピソード記憶（中期記憶: {oldest_log_date_str}以前の{days_num}日間）\n"
                            f"以下は、現在の会話ログより前の出来事の要約です。文脈として参照してください。\n"
                            f"{episodic_text}\n"
                        )
                except Exception as e:
                    print(f"トークン計算時のエピソード記憶取得エラー: {e}")

        # --- [Step 3: システムプロンプトの構築] ---
        from agent.prompts import CORE_PROMPT_TEMPLATE
        from agent.graph import all_tools
        room_prompt_path = os.path.join(constants.ROOMS_DIR, room_name, "SystemPrompt.txt")
        character_prompt = ""
        if os.path.exists(room_prompt_path):
            with open(room_prompt_path, 'r', encoding='utf-8') as f: character_prompt = f.read().strip()

        core_memory = ""
        if effective_settings.get("send_core_memory", True):
            core_memory_path = os.path.join(constants.ROOMS_DIR, room_name, "core_memory.txt")
            if os.path.exists(core_memory_path):
                with open(core_memory_path, 'r', encoding='utf-8') as f: core_memory = f.read().strip()

        notepad_section = ""
        if effective_settings.get("send_notepad", True):
            _, _, _, _, _, notepad_path, _ = room_manager.get_room_files_paths(room_name)
            if notepad_path and os.path.exists(notepad_path):
                with open(notepad_path, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                    notepad_content = content if content else "（メモ帳は空です）"
                    notepad_section = f"\n### 短期記憶（メモ帳）\n{notepad_content}\n"

        working_memory_section = ""
        active_wm_slot = room_manager.get_active_working_memory_slot(room_name)
        from tools.working_memory_tools import (
            get_working_memory_metadata,
            is_working_memory_injectable,
            load_injectable_working_memory,
        )
        wm_metadata = get_working_memory_metadata(room_name)
        wm_dir = os.path.join(constants.ROOMS_DIR, room_name, constants.NOTES_DIR_NAME, constants.WORKING_MEMORY_DIR_NAME)
        working_memory_path = os.path.join(wm_dir, f"{active_wm_slot}{constants.WORKING_MEMORY_EXTENSION}")

        available_slots = []
        if os.path.exists(wm_dir):
            available_slots = [
                slot_name
                for slot_name in (
                    f.replace(constants.WORKING_MEMORY_EXTENSION, "")
                    for f in os.listdir(wm_dir)
                    if f.endswith(constants.WORKING_MEMORY_EXTENSION)
                    and f != f"{active_wm_slot}{constants.WORKING_MEMORY_EXTENSION}"
                )
                if is_working_memory_injectable(wm_metadata, slot_name)
            ]
        if os.path.exists(working_memory_path):
            content = load_injectable_working_memory(
                room_name, active_wm_slot, mark_read=False
            )
            working_memory_section = _compose_working_memory_token_section(
                active_wm_slot, content, available_slots
            )
            if content:
                try:
                    import memory_steward_observer
                    memory_steward_observer.observe_working_memory(
                        room_name,
                        active_wm_slot,
                        content,
                        wm_metadata,
                        event_type="wm_token_estimate",
                        route="gemini_token_estimate",
                    )
                except Exception:
                    pass
        else:
            working_memory_section = _compose_working_memory_token_section(
                active_wm_slot, "", available_slots
            )


        # --- [2026-01-18 FIX] より正確なコンテキスト見積もり ---
        # context_generator_node で実際に生成される内容に近いプレースホルダーを使用

        # 研究ノートの目次を実際に読み込む
        research_notes_section = ""
        try:
            _, _, _, _, _, _, research_notes_path = room_manager.get_room_files_paths(room_name)
            if research_notes_path and os.path.exists(research_notes_path):
                with open(research_notes_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                headlines = [line.strip() for line in lines if line.strip().startswith("## ")]
                if headlines:
                    latest_headlines = headlines[-10:]
                    headlines_str = "\n".join(latest_headlines)
                    research_notes_section = (
                        "\n### 研究・分析ノート（目次）\n"
                        "以下は最近の研究・分析トピックの目次です。\n\n"
                        f"{headlines_str}\n"
                    )
        except Exception:
            pass

        # --- [Phase 2] ペンディングシステムメッセージ（影の僕からの提案）の見積もり ---
        pending_messages_section = ""
        try:
            from dreaming_manager import DreamingManager
            # トークン計算時は読み込むだけでクリアしないように注意（本来は get_pending_system_messages ではなく閲覧のみが良いが、
            # 簡易化のためここでは静的な長いテキストで代用するか、ロジックを共通化する）
            # ここでは「ペンディングメッセージがあった場合」の平均的な長さ（約500文字）で見積もる
            pending_messages_section = "\n\n【影の僕からの提案：記憶の記録について】\n" + "x" * 500 + "\n"
        except Exception:
            pass

        # 情景プロンプトの見積もり（場所リスト含む）
        situation_prompt_estimate = ""
        current_time_block = "<current_time>\n【現在時刻】\n- 現在時刻: 2026-02-02(月) 12:00\n</current_time>"
        if effective_settings.get("send_scenery", True):
            # 移動可能な場所リストを取得
            try:
                from utils import parse_world_file
                world_settings_path = room_manager.get_world_settings_path(room_name)
                world_data = parse_world_file(world_settings_path) if world_settings_path else {}
                locations = []
                if isinstance(world_data, dict):
                    for area, places in world_data.items():
                        if isinstance(places, dict):
                            locations.extend([p for p in places.keys() if not p.startswith("__")])
                location_list_str = "\n".join([f"- {loc}" for loc in sorted(set(locations))]) if locations else "（移動先なし）"
            except Exception:
                location_list_str = "（移動先の取得エラー）"

            situation_prompt_estimate = (
                "【現在の状況】\n"
                "- 季節: 冬\n"
                "- 時間帯: 昼\n\n"
                "【現在の場所と情景】\n"
                "- 場所: 自室\n"
                "- 今の情景: 陽光が差し込む静かな部屋。\n"
                "- 場所の設定（自由記述）:\n"
                "（場所の詳細設定が入ります）\n\n"
                "【移動可能な場所】\n"
                f"{location_list_str}"
            )
        else:
            current_time_block = "<current_time>\n【現在時刻】\n- 現在時刻: （非表示）\n</current_time>"
            situation_prompt_estimate = "【現在の状況】\n【現在の場所と情景】\n（無効化）"

        # 記憶想起のプレースホルダー（RAG検索結果）
        retrieved_info_placeholder = ""
        if effective_settings.get("enable_auto_retrieval", True):
            # 実際のRAG検索結果を模倣（安全のため長めに見積もる）
            retrieved_info_placeholder = (
                "\n### 想起された関連情報\n"
                "【記憶検索の結果：日記・エピソード記憶から3件程度】\n"
                "--- エピソード記憶 (YYYY-MM-DD) ---\n"
                "過去の出来事の要約（約1000文字程度）。\n\n"
                "--- 日記 (YYYY-MM-DD) ---\n"
                "日記からの記録（約500文字程度）。\n\n"
                "【過去の会話ログからの検索結果】\n"
                "--- [log.txt(過去分)] ---\n"
                "過去の会話の一部（約1000文字程度）。\n"
            )
            if effective_settings.get("include_knowledge_in_auto_retrieval", False):
                retrieved_info_placeholder += (
                    "\n【ナレッジからの関連情報】\n"
                    "--- [ナレッジ / 出典: example.md] ---\n"
                    "会話に関連する登録済みナレッジ（最大3件・合計約1800文字）。\n"
                )

        # 自己意識コンテキストの見積もり
        dream_insights_text = ""
        if effective_settings.get("enable_self_awareness", True):
            # 実際の context_generator_node で注入される内容を模倣
            dream_insights_text = (
                "\n### 深層意識（今日の指針）\n"
                "（指針の短いテキスト）\n\n"
                "### あなたの目標\n"
                "（目標リスト）\n\n"
                "### 今のあなたの気持ち\n"
                "- 最も強い動機: 好奇心\n\n"
                "### あなたが今気になっていること\n"
                "（未解決の問い）\n"
            )

        # 思考ログマニュアル
        from agent.prompts import (
            THOUGHT_MANUAL_DISABLED_TEXT,
            THOUGHT_MANUAL_NATIVE_TEXT,
            THOUGHT_MANUAL_TAGGED_TEXT,
        )
        display_thoughts = effective_settings.get("display_thoughts", True)
        is_native_thinking_prompt = supports_native_thinking_parts(model_name)
        if not display_thoughts:
             thought_generation_manual_text = THOUGHT_MANUAL_DISABLED_TEXT
        elif is_native_thinking_prompt:
             thought_generation_manual_text = THOUGHT_MANUAL_NATIVE_TEXT
        else:
             thought_generation_manual_text = THOUGHT_MANUAL_TAGGED_TEXT

        # ツール一覧
        # 【2026-01-18 FIX】LangChainがツールをバインドする際に追加するJSONスキーマのオーバーヘッドを考慮
        # 各ツールは名前、説明、引数スキーマを含むJSONとして送信される（約300〜500トークン/ツール）
        tool_use_enabled = effective_settings.get("tool_use_enabled", True)
        tool_schema_overhead = 0
        if tool_use_enabled:
            tools_list_str = "\n".join([f"- `{tool.name}`: {tool.description[:50]}..." for tool in sorted(all_tools, key=lambda tool: getattr(tool, "name", ""))])
            # ツールスキーマのオーバーヘッドを推定（実測値: 約160 / 安全のため 250 で計算）
            tool_schema_overhead = len(all_tools) * 250
        else:
            tools_list_str = "（現在、利用可能なツールはありません）"

        if kwargs.get("use_common_prompt", True) == False:
            tools_list_str = "（共通ツールプロンプトは送信されません）"
            tool_schema_overhead = 0  # 共通プロンプト無効時はツールもなし

        # アクションログの見積もり
        action_log_section = ""
        action_log_estimate = "  - [14:00] action: xxxxxxxxxxxxxxxxxxxxxxxx\n" * 5
        action_log_section = f"\n### 最近のアクション履歴\n{action_log_estimate}\n"

        # 行動計画（空のプレースホルダー）
        action_plan_context = ""

        current_outfit_section = ""
        try:
            current_outfit_section = closet_manager.build_current_outfit_section(room_name)
        except Exception as e:
            print(f"トークン計算時の現在の装い取得エラー: {e}")
            current_outfit_section = ""

        letterbox_section = ""
        try:
            import letterbox_manager
            letterbox_section = letterbox_manager.build_letterbox_section(room_name)
        except Exception as e:
            print(f"トークン計算時の手紙箱状況取得エラー: {e}")
            letterbox_section = ""

        class SafeDict(dict):
            def __missing__(self, key): return f'{{{key}}}'

        prompt_vars = {
            'situation_prompt': situation_prompt_estimate,
            'current_time_block': current_time_block,
            'character_prompt': character_prompt,
            'core_memory': core_memory,
            'working_memory_section': working_memory_section,
            'action_log_section': action_log_section,
            'notepad_section': notepad_section,
            'research_notes_section': research_notes_section,
            'pending_messages_section': pending_messages_section,
            'current_outfit_section': current_outfit_section,
            'letterbox_section': letterbox_section,
            'episodic_memory': episodic_memory_section,
            'thought_generation_manual': thought_generation_manual_text,
            'image_generation_manual': '',
            'tools_list': tools_list_str,
            'action_plan_context': action_plan_context,
            'retrieved_info': retrieved_info_placeholder,
            'dream_insights': dream_insights_text
        }
        system_prompt_text = CORE_PROMPT_TEMPLATE.format_map(SafeDict(prompt_vars))

        messages.append(SystemMessage(content=system_prompt_text))

        # --- [Step 4: 履歴メッセージの追加] ---
        # 【2026-01-18 FIX】invoke_nexus_agent_stream と同じロジックを使用してトークン推定の精度を向上
        # 以前は直接ループしていたため、思考ログ除去やメッセージ統合が適用されず、
        # 実送信時と推定時でトークン数に乖離が発生していた。
        send_thoughts_final = display_thoughts and effective_settings.get("send_thoughts", True)
        add_timestamp = effective_settings.get("add_timestamp", False)

        # 【OpenAI互換対応】プロバイダを取得
        current_provider = config_manager.get_active_provider(room_name)

        # convert_raw_log_to_lc_messages を使用して一貫した履歴構築
        history_messages = convert_raw_log_to_lc_messages(
            raw_history,
            room_name,
            add_timestamp,
            send_thoughts_final,
            provider=current_provider,
            model_name=model_name,
        )

        # メッセージ統合を適用（invoke_nexus_agent_stream と同様）
        history_messages = merge_consecutive_messages(history_messages, add_timestamp=add_timestamp)

        messages.extend(history_messages)

        # 【自動会話要約】本日分のみを対象に要約処理
        # 【2026-04-16 FIX】フォールバック分は要約対象外にする（invoke_nexus_agent_stream と同じ方式）
        auto_summary_enabled = effective_settings.get("auto_summary_enabled", False)
        if api_history_limit == "today" and auto_summary_enabled:
            messages = _apply_auto_summary(
                messages,
                room_name,
                api_key,
                effective_settings.get("auto_summary_threshold", constants.AUTO_SUMMARY_DEFAULT_THRESHOLD),
                allow_generation=False
            )
            # フォールバック分を先頭に追加（要約対象外の文脈バッファ）
            if fallback_raw_history:
                fb_lc_messages = convert_raw_log_to_lc_messages(
                    fallback_raw_history,
                    room_name,
                    add_timestamp,
                    send_thoughts_final,
                    provider=current_provider,
                    model_name=model_name,
                )
                fb_lc_messages = merge_consecutive_messages(fb_lc_messages, add_timestamp=add_timestamp)
                # messages の先頭（SystemMessage の直後）にフォールバック分を挿入
                sys_msgs = [m for m in messages if isinstance(m, SystemMessage)]
                non_sys_msgs = [m for m in messages if not isinstance(m, SystemMessage)]
                messages = sys_msgs + fb_lc_messages + non_sys_msgs

        if parts:
            formatted_parts = []
            for part in parts:
                if isinstance(part, str): formatted_parts.append({"type": "text", "text": part})
                elif isinstance(part, Image.Image):
                    try:
                        # ▼▼▼【APIコスト削減】送信前に画像をリサイズ（768px上限）▼▼▼
                        resized_image = utils.resize_image_for_api(part, max_size=768)
                        if resized_image:
                            part = resized_image

                        img_byte_arr = io.BytesIO()
                        part.save(img_byte_arr, format='PNG')
                        formatted_parts.append({
                            "type": "image",
                            "image": img_byte_arr.getvalue()
                        })
                    except Exception as e:
                        print(f"トークン計算中の画像処理エラー: {e}")

            # partsがある場合は、直近メッセージとして追加
            messages.append(HumanMessage(content=formatted_parts))

        # トークン計算実行
        total_tokens = count_tokens_from_lc_messages(messages, model_name, api_key)

        # 【2026-01-18 FIX】LangChainがツールをバインドする際のオーバーヘッドを追加
        # 各ツールのJSONスキーマ（名前、説明、引数の型・説明）が送信される分
        total_tokens += tool_schema_overhead

        return total_tokens

    except httpx.ReadError as e:
        print(f"トークン計算中にネットワーク読み取りエラー: {e}")
        return 0
    except httpx.ConnectError as e:
        print(f"トークン計算中にAPI接続エラー: {e}")
        return 0
    except Exception as e:
        print(f"トークン計算中に予期せぬエラー: {e}")
        traceback.print_exc()
        return 0

def correct_punctuation_with_ai(
    text_to_fix: str,
    api_key: str = None,
    context_type: str = "body",
    connection: dict | None = None,
) -> Optional[str]:
    """
    読点が除去されたテキストを受け取り、AIを使って適切な読点を再付与する。
    """
    if not text_to_fix:
        return None

    if connection is None:
        connection = _get_connection(force_global=True)
    is_vertex_connection = _is_vertex_connection(connection)
    if not is_vertex_connection and not api_key:
        return None

    context_instruction = "これはユーザーへの応答文です。自然な会話になるように読点を付与してください。"
    if context_type == "thoughts":
        context_instruction = "これはAI自身の思考ログです。思考の流れや内省的なモノローグとして自然になるように読点を付与してください。"

    prompt = f"""あなたは、日本語の文章を校正する専門家です。あなたの唯一の任務は、以下の【読点除去済みテキスト】に対して、文脈が自然になるように読点（「、」）のみを追加することです。

【コンテキスト】
{context_instruction}

【最重要ルール】
- テキストの内容、漢字、ひらがな、カタカナ、句点（「。」）など、読点以外の文字は一切変更してはいけません。
- `【` や `】` のような記号も、変更したり削除したりせず、そのまま保持してください。
- 出力は必ず `<result>` タグで囲んでください。挨拶や説明は不要です。

【入力例】
<result>
ここに修正後のテキストが入ります。
</result>

【読点除去済みテキスト】
---
{text_to_fix}
---

【修正後のテキスト】
"""
    if is_vertex_connection:
        try:
            from llm_factory import LLMFactory
            response, _used_key = LLMFactory.invoke_internal_llm(
                internal_role="processing", prompt=prompt,
            )
            response_text = utils.extract_text_from_llm_content(response.content)
            match = re.search(r"<result>(.*?)</result>", response_text, re.DOTALL)
            return (match.group(1) if match else response_text.replace("【修正後のテキスト】", "")).strip()
        except Exception:
            print("--- Vertex AIで読点を修正できませんでした。接続設定と認証を確認してください。 ---")
            return None

    model_name = constants.INTERNAL_PROCESSING_MODEL
    current_api_key = None if is_vertex_connection else api_key
    tried_keys = set()

    # 元のキー名を特定（ローテーション用）
    current_key_name = (
        "Vertex"
        if is_vertex_connection
        else config_manager.get_key_name_by_value(current_api_key)
    )
    if current_key_name != "Unknown":
        tried_keys.add(current_key_name)

    max_rotation_attempts = 5
    for rotation_attempt in range(max_rotation_attempts):
        client = _create_google_client(
            connection=connection,
            api_key=None if is_vertex_connection else current_api_key,
        )
        max_retries = 3
        base_retry_delay = 5

        for attempt in range(max_retries):
            try:
                response = client.models.generate_content(
                    model=f"models/{model_name}",
                    contents=[prompt]
                )

                # Post-processing: Extract content within <result> tags
                response_text = response.text
                match = re.search(r"<result>(.*?)</result>", response_text, re.DOTALL)
                if match:
                    return match.group(1).strip()

                # Fallback (Safety net): Remove common artifacts if tags are missing
                cleaned = response_text.replace("【修正後のテキスト】", "")
                return cleaned.strip()

            except (google.genai.errors.ClientError, google.genai.errors.ServerError) as e:
                err_str = str(e).upper()
                is_429 = "429" in err_str or "RESOURCE_EXHAUSTED" in err_str

                if is_vertex_connection:
                    # Vertex の割り当てエラーを Developer キーへ漏らさず終了する。
                    return None

                # 有料キーの判定
                paid_key_names = config_manager.CONFIG_GLOBAL.get("paid_api_key_names", [])
                clean_current_key_name = config_manager._clean_api_key_name(current_key_name)
                is_paid_key = clean_current_key_name in paid_key_names

                if is_429:
                    # 有料キーならその場で少し粘る
                    if is_paid_key and attempt < max_retries - 1:
                        wait_time = base_retry_delay * (attempt + 1) * 2
                        print(f"--- [Punctuation Paid Backoff] 有料キー '{current_key_name}' で429。{wait_time}秒待機して再試行... ---")
                        time.sleep(wait_time)
                        continue

                    limit_type = "RPD" if ("QUOTA EXCEEDED" in err_str or "PERDAY" in err_str or "DAILY" in err_str) else "RPM"
                    # 枯渇マーク（有料キーは永続化されない）
                    config_manager.mark_key_as_exhausted(clean_current_key_name, model_name=model_name, limit_type=limit_type)

                    # ローテーション試行
                    print(f"--- [Punctuation Rotation] キー '{current_key_name}' が枯渇。代替キーを探索中... ---")
                    next_key = config_manager.get_active_gemini_api_key(model_name=model_name, excluded_keys=tried_keys)
                    next_key_name = config_manager.get_key_name_by_value(next_key)

                    if next_key and next_key_name not in tried_keys:
                        current_api_key = next_key
                        current_key_name = next_key_name
                        tried_keys.add(next_key_name)
                        print(f"--- [Punctuation Rotation] 新しいキー '{current_key_name}' で再開します。 ---")
                        break # 内側のリトライループを抜けて、外側のローテーションループでクライアント再作成
                    else:
                        print(f"--- [Punctuation Rotation] 利用可能な代替キーがありません。 ---")
                        return None

                # 429以外、またはリトライ上限
                wait_time = 0
                if isinstance(e, google.genai.errors.ClientError):
                    try:
                        match = re.search(r"({.*})", str(e))
                        if match:
                            error_json = json.loads(match.group(1))
                            for detail in error_json.get("error", {}).get("details", []):
                                if detail.get("@type") == "type.googleapis.com/google.rpc.RetryInfo":
                                    delay_str = detail.get("retryDelay", "60s")
                                    delay_match = re.search(r"(\d+)", delay_str)
                                    if delay_match:
                                        wait_time = int(delay_match.group(1)) + 1
                                        break
                    except Exception: pass

                if wait_time == 0:
                    wait_time = base_retry_delay * (2 ** attempt)

                if attempt < max_retries - 1:
                    print(f"--- APIエラー ({e.__class__.__name__})。{wait_time}秒待機してリトライします... ({attempt + 1}/{max_retries}) ---")
                    time.sleep(wait_time)
                else:
                    print(f"--- APIエラー: 最大リトライ回数 ({max_retries}) に達しました。 ---")
                    return None

            except Exception as e:
                print(f"--- 読点修正中に予期せぬエラー: {e} ---")
                traceback.print_exc()
                return None

    return None


def translate_thought_log_with_ai(thought_text: str, agent_name: str, api_key: str = None) -> Optional[str]:
    """
    思考ログ（英語等）を日本語の独白調に翻訳する。
    LLMFactoryを経由して、ユーザーが設定した「思考ログ翻訳用」のモデルを使用する。
    """
    if not thought_text:
        return None

    try:
        from llm_factory import LLMFactory
        from langchain_core.messages import HumanMessage

        # 思考ログ翻訳用のプロンプト
        prompt = f"""以下のAI（{agent_name}）による思考ログの内容を、自然な日本語の「独り言（だ・である調）」に翻訳してください。

【重要なルール】
1. **翻訳対象が既に日本語の場合は、絶対に書き換えずにそのまま出力してください。** (日本語の修正や再翻訳は禁止)
2. 英語の部分のみを日本語に翻訳してください。
3. **口調は「〜だ」「〜である」といった、淡々とした独白調にしてください。** (過度なキャラ作りや「です・ます」調は禁止)
4. **一人称は原則「私」を使用してください。** (「僕」「俺」などは使用禁止)
5. 固有名詞に勝手に敬称（「さん」「くん」など）を付けないでください。呼び捨てのままにしてください。
6. 出力は必ず `<result>` タグで囲んでください。挨拶や説明は不要です。

思考ログ:
{thought_text}"""

        messages = [HumanMessage(content=prompt)]

        # LLMFactoryを使用してモデルを初期化（internal_role="translation"）
        from config_manager import get_effective_internal_model
        provider, model_name_raw, _ = get_effective_internal_model("translation")
        sanitized_model_name = utils.sanitize_model_name(model_name_raw or "")
        translation_connection = None
        is_vertex_translation = False
        if provider in {"google", "Google (Gemini)", "Google (Gemini Native)"}:
            translation_connection = _get_connection(force_global=True)
            is_vertex_translation = _is_vertex_connection(translation_connection)

        # 初期キーの取得とセットアップ
        current_api_key = None if is_vertex_translation else api_key
        tried_keys = set()
        current_key_name = "Vertex" if is_vertex_translation else "Unknown"

        if provider in {"google", "Google (Gemini)", "Google (Gemini Native)"} and not is_vertex_translation:
            if current_api_key:
                current_key_name = config_manager.get_key_name_by_value(current_api_key)
            else:
                current_api_key = config_manager.get_active_gemini_api_key(model_name=sanitized_model_name)
                current_key_name = config_manager.get_active_gemini_api_key_name(model_name=sanitized_model_name)

            if current_key_name != "Unknown":
                tried_keys.add(current_key_name)

        max_rotation_attempts = 5
        for rotation_attempt in range(max_rotation_attempts):
            llm = LLMFactory.create_chat_model_with_fallback(
                internal_role="translation",
                temperature=0.2, # 翻訳タスクなので少し低めに設定
                api_key=current_api_key,
                gemini_connection_config=translation_connection,
            )

            max_retries = 3
            base_retry_delay = 5

            for attempt in range(max_retries):
                try:
                    # モデル呼び出し
                    if rotation_attempt == 0 and attempt == 0:
                        print(f"--- [Translation] 思考ログ翻訳を実行します (Role: translation) ---")
                    response = llm.invoke(messages)
                    response_text = utils.get_content_as_string(response)

                    # Post-processing: Extract content within <result> tags
                    match = re.search(r"<result>(.*?)</result>", response_text, re.DOTALL)
                    if match:
                        return match.group(1).strip()

                    # Fallback
                    return response_text.strip()

                except Exception as e:
                    import google.genai.errors
                    from langchain_google_genai.chat_models import ChatGoogleGenerativeAIError

                    err_str = str(e).upper()
                    # 429かどうかの判定。langchainのエラーラッパーも考慮
                    is_429 = "429" in err_str or "RESOURCE_EXHAUSTED" in err_str

                    if is_vertex_translation:
                        # Vertex の失敗は Developer キーの枯渇・有料待機・回転へ流さない。
                        return None

                    if provider in {"google", "Google (Gemini)", "Google (Gemini Native)"} and is_429:
                        # 有料キーの判定
                        paid_key_names = config_manager.CONFIG_GLOBAL.get("paid_api_key_names", [])
                        clean_current_key_name = config_manager._clean_api_key_name(current_key_name)
                        is_paid_key = clean_current_key_name in paid_key_names

                        # 有料キーならその場で少し粘る
                        if is_paid_key and attempt < max_retries - 1:
                            wait_time = base_retry_delay * (attempt + 1) * 2
                            print(f"--- [Translation Paid Backoff] 有料キー '{current_key_name}' で429。{wait_time}秒待機して再試行... ---")
                            time.sleep(wait_time)
                            continue

                        limit_type = "RPD" if ("QUOTA EXCEEDED" in err_str or "PERDAY" in err_str or "DAILY" in err_str) else "RPM"
                        # 枯渇マーク（有料キーは永続化されない。特定のモデルに対してのみマーク）
                        config_manager.mark_key_as_exhausted(clean_current_key_name, model_name=sanitized_model_name, limit_type=limit_type)

                        # ローテーション試行
                        print(f"--- [Translation Rotation] キー '{current_key_name}' が枯渇。翻訳用代替キーを探索中... ---")
                        next_key = config_manager.get_active_gemini_api_key(model_name=sanitized_model_name, excluded_keys=tried_keys)
                        next_key_name = config_manager.get_key_name_by_value(next_key)

                        if next_key and next_key_name not in tried_keys:
                            current_api_key = next_key
                            current_key_name = next_key_name
                            tried_keys.add(next_key_name)
                            print(f"--- [Translation Rotation] 新しいキー '{current_key_name}' で翻訳を再開します。 ---")
                            break # 内側のリトライループを抜けて、外側のローテーションループでLLM再作成
                        else:
                            print(f"--- [Translation Rotation] 利用可能な代替キーがありません。翻訳をスキップします。 ---")
                            return None

                    # 429以外のエラー、あるいは他のプロバイダの場合、または429でリトライ上限
                    wait_time = base_retry_delay * (2 ** attempt)

                    if attempt < max_retries - 1:
                        print(f"--- 翻訳APIエラー ({e.__class__.__name__})。{wait_time}秒待機してリトライします... ({attempt + 1}/{max_retries}) ---")
                        time.sleep(wait_time)
                    else:
                        print(f"--- 翻訳APIエラー: 最大リトライ回数 ({max_retries}) に達しました。 ---")
                        print(f"詳細: {e}")
                        return None

        return None

    except Exception as e:
        print(f"--- 翻訳中に予期せぬエラー: {e} ---")
        import traceback
        traceback.print_exc()
        return None


def get_configured_llm(
    model_name: str,
    api_key: str = None,
    generation_config: dict = None,
    cached_content: str | None = None,
    connection: dict | None = None,
):
    """
    LangChain/LangGraph用の、設定済みChatGoogleGenerativeAIインスタンスを生成する。
    パッチを除去し、最もシンプルな初期化に戻す。
    """
    threshold_map = {
        "BLOCK_NONE": HarmBlockThreshold.BLOCK_NONE,
        "BLOCK_LOW_AND_ABOVE": HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
        "BLOCK_MEDIUM_AND_ABOVE": HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        "BLOCK_ONLY_HIGH": HarmBlockThreshold.BLOCK_ONLY_HIGH,
    }
    config = generation_config or {}

    # 推論モデル (Gemini 3/3.1系、2.0 Thinking等) のための特別な処理
    model_name_lower = (model_name or "").lower()
    is_reasoning_model = _is_gemini_3_family_model(model_name) or "thinking" in model_name_lower or "gemini-2.5-pro" in model_name_lower

    if is_reasoning_model:
        # Gemini 3/3.1 Previewは非常に厳しいため、デバッグ中は安全設定を最小にする
        safety_settings = {
            HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
            HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
            HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
            HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
        }
    else:
        safety_settings = {
            HarmCategory.HARM_CATEGORY_HARASSMENT: threshold_map.get(config.get("safety_block_threshold_harassment", "BLOCK_ONLY_HIGH")),
            HarmCategory.HARM_CATEGORY_HATE_SPEECH: threshold_map.get(config.get("safety_block_threshold_hate_speech", "BLOCK_ONLY_HIGH")),
            HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: threshold_map.get(config.get("safety_block_threshold_sexually_explicit", "BLOCK_ONLY_HIGH")),
            HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: threshold_map.get(config.get("safety_block_threshold_dangerous_content", "BLOCK_ONLY_HIGH")),
        }

    # --- Thinking Level Mapping (Gemini 3 / 3.1) ---
    # 【2026-04-14 更新】SDK v4.2+ で thinking_level / include_thoughts は第一級パラメータ。
    # extra_params で渡すのではなく、コンストラクタ引数として直接指定する。
    # 署名（Thought Signatures）の循環は minimal 設定時でも必須（公式ドキュメント）。
    # 参照: https://ai.google.dev/gemini-api/docs/thinking
    response_reasoning_effort = config.get("_response_reasoning_effort")
    explicit_provider_default = response_reasoning_effort == "default"
    thinking_level = config.get("thinking_level", "auto")
    if response_reasoning_effort and not explicit_provider_default:
        # 応答モデルの明示levelは、legacy family判定から分離して
        # Gemini 4 Argon等にも同じ第一級thinking_levelを適用する。
        thinking_level = response_reasoning_effort

    # Gemini 3 / 3.1 / 2.5 判定
    effective_temp = config.get("temperature", 0.8)
    is_pro_reasoning = _is_gemini_3_pro_family(model_name)
    is_flash_reasoning = _is_gemini_3_flash_family(model_name)
    is_gemini_25_thinking = "gemini-2.5" in model_name_lower and not ("lite" in model_name_lower or "flash" in model_name_lower)
    is_explicit_thinking = "thinking" in model_name_lower

    # 第一級パラメータとして渡す値（None = SDK のデフォルトに任せる）
    param_thinking_level = None
    param_include_thoughts = None

    if explicit_provider_default:
        # 未登録（sentinelなし）の既存挙動と区別し、明示defaultだけ
        # thinkingConfigをSDKへ送らず、providerの既定値へ委ねる。
        if is_reasoning_model:
            effective_temp = 1.0
            print("  - [Thinking] Gemini provider default selected; thinkingConfig is omitted.")
    elif response_reasoning_effort in {"minimal", "low", "medium", "high"}:
        # 新しい応答設定はSDKの既存family変換に依存しない。未登録の
        # 旧generation_configはこの分岐へ入らず、従来の挙動を保つ。
        param_thinking_level = response_reasoning_effort
        param_include_thoughts = True
        effective_temp = 1.0
        if is_reasoning_model or response_reasoning_effort:
            print(
                f"  - [Thinking] Response model level={response_reasoning_effort}, "
                "include_thoughts=True, temp=1.0"
            )
    elif is_flash_reasoning:
        # Gemini 3 Flash: thinking 制御
        # 署名の循環は必須（even when set to minimal）。
        # 以前は安定性優先で minimal 固定にしていたが、minimal では
        # include_thoughts=True でも可視の thinking part が返らないことがある。
        # UI設定を尊重し、auto は低レイテンシと可視性のバランスを取って low にする。
        if thinking_level == "none":
            param_include_thoughts = False
        else:
            param_include_thoughts = True
            param_thinking_level = thinking_level if thinking_level in ["minimal", "low", "medium", "high"] else "low"
        effective_temp = 1.0  # thinking設定がどうであれ、Gemini3系は1.0推奨

        if is_reasoning_model:
            print(f"  - [Thinking] Gemini 3 Flash: thinking_level={param_thinking_level}, include_thoughts={param_include_thoughts}, temp={effective_temp}")
    elif is_pro_reasoning:
        # Gemini 3 Pro: thinking パラメータをフルサポート
        if thinking_level == "auto" or thinking_level == "high":
            param_include_thoughts = True
            param_thinking_level = "high"
            effective_temp = 1.0
        elif thinking_level == "none":
            param_include_thoughts = False
        elif thinking_level in ["minimal", "low", "medium"]:
            param_include_thoughts = True
            param_thinking_level = thinking_level
            effective_temp = 1.0
        if is_reasoning_model:
            print(f"  - [Thinking] Gemini 3 Pro: level='{thinking_level}', thinking_level='{param_thinking_level}', include_thoughts={param_include_thoughts}, temp={effective_temp}")
    elif is_explicit_thinking:
        # Gemini 2.0 Flash Thinking 等
        if thinking_level != "none":
            param_include_thoughts = True
            effective_temp = 1.0
        if is_reasoning_model:
            print(f"  - [Thinking] Explicit Thinking Model: include_thoughts={param_include_thoughts}, temp={effective_temp}")
    elif is_gemini_25_thinking:
        # Gemini 2.5 Pro 等: thinking パラメータは送らず、トークン上限引き上げのみ適用。
        effective_temp = 1.0
        if is_reasoning_model:
            print(f"  - [Note] Gemini 2.5 Pro recognized as reasoning model (high tokens enabled, params skipped for stability). Temp: {effective_temp}")

    # ===== Preview特有の暴走カンスト対応 =====
    flash_loop_guard_max_tokens = config.get("max_output_tokens", 8192)
    if is_flash_reasoning:
        # Flash 3 推論モデルは暴走ループで63,000トークン消費するバグがあるため、
        # 強制的に 8192 (あるいは現状のmax_output_tokensの小さい方) を上限とする
        flash_loop_guard_max_tokens = min(config.get("max_output_tokens", 8192), 8192)
    else:
        flash_loop_guard_max_tokens = config.get("max_output_tokens", 65536) if is_reasoning_model else config.get("max_output_tokens")

    if connection is not None:
        connection = _get_gemini_connection_module().normalize_connection(connection, require_valid=True)
    chat_kwargs = dict(
        vertexai=False,
        model=model_name,
        google_api_key=api_key,
        # LangGraphのmessages callbackはinvokeでも暗黙streamを選ぶ。
        # Flashの既存単発実行方針をモデル属性で固定し、停止scope・署名・
        # 最終メッセージ通知を保ったままSDKのstream応答変換エラーを避ける。
        disable_streaming=is_flash_reasoning,
        cached_content=cached_content,
        convert_system_message_to_human=False,
        max_retries=1,
        temperature=effective_temp,
        top_p=config.get("top_p", 0.95),
        max_output_tokens=flash_loop_guard_max_tokens,
        safety_settings=safety_settings,
        timeout=600,
        thinking_level=param_thinking_level,
        include_thoughts=param_include_thoughts,
    )

    # Vertex は connection 境界の SDK/client を使う。Developer 経路で
    # ChatGoogleGenerativeAI を monkeypatch する既存テストと互換を保つため、
    # connection 未指定時は従来の直接コンストラクタを維持する。
    if connection is not None and _is_vertex_connection(connection):
        module = _get_gemini_connection_module()
        if module is not None:
            # 明示キャッシュは Developer 接続専用のため Vertex へ送らない。
            chat_kwargs["google_api_key"] = None
            chat_kwargs["cached_content"] = None
            return module.build_chat_model(connection, **chat_kwargs)

    if uses_argon_request_rules(model_name):
        # Developerにも同じ送信制約を適用する。旧モデルの直接constructorは保持。
        module = _get_gemini_connection_module()
        chat_kwargs["cached_content"] = None
        return module.build_chat_model(connection or {"backend": "developer"}, **chat_kwargs)

    return ChatGoogleGenerativeAI(**chat_kwargs)

