# room_manager.py

import os
import json
import hashlib
import re
import shutil
import filecmp
import traceback
import datetime
import threading
import time
from contextlib import contextmanager
from typing import Any, Dict, Optional, List, Tuple
from filelock import Timeout
from send2trash import send2trash
import constants
import file_lock_utils
from file_lock_utils import locked_file
from settings_backup_manager import create_layered_settings_backup

# スレッドセーフなファイル操作のためのロック
# 版照合を保持したまま既存保存処理へ再入する呼び出しも排他する。
_room_config_lock = threading.RLock()
SYSTEM_ROOM_DIR_NAMES = {"_shared"}
OLIVIE_ROOM_NAME_ALIASES = {"オリヴェ", "オリベ", "Olivie", "olivie"}
EMOTION_DEFINITIONS_KEY = "emotion_definitions"
ROOM_OVERRIDE_STRING_OR_NONE_KEYS = {
    "provider",
    "model_name",
    "api_key_name",
    "zhipu_model",
    "tts_profile_name",
}


@contextmanager
def room_config_write_guard(room_name: str):
    """ルーム設定のread/modify/write区間をthread・プロセス間で排他する。"""
    with _room_config_lock:
        room_dir = os.path.join(constants.ROOMS_DIR, room_name) if room_name else ""
        if room_dir and os.path.isdir(room_dir):
            config_file = os.path.join(room_dir, "room_config.json")
            with file_lock_utils.get_file_lock(config_file):
                yield
        else:
            # 初期作成時は、room_config.jsonのロックファイルを先に作らない。
            yield


def _sanitize_room_override_updates(room_name: str, updates: Dict[str, Any]) -> Dict[str, Any]:
    """Drop invalid AI string override values before they can overwrite saved settings."""
    sanitized: Dict[str, Any] = {}
    for key, value in updates.items():
        if key in ROOM_OVERRIDE_STRING_OR_NONE_KEYS and value is not None and not isinstance(value, str):
            print(
                f"[room_manager.update_room_config] Warning: ルーム '{room_name}' の "
                f"override_settings.{key} に不正な型 {type(value).__name__} を検出したため保存をスキップします。"
            )
            continue
        sanitized[key] = value
    return sanitized

def _infer_month_from_log_backup(backup_path: str) -> Optional[str]:
    """バックアップファイル名または本文の日付から対象月(YYYY-MM)を推定する。"""
    basename = os.path.basename(backup_path)
    filename_match = re.search(r"(\d{4}-\d{2})\.txt", basename)
    if filename_match:
        return filename_match.group(1)

    try:
        # 巨大ログでも起動時の負荷を抑えるため、末尾側だけ読む。通常ログは各発言末尾に日付を持つ。
        with open(backup_path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - 1024 * 1024))
            sample = f.read().decode("utf-8", errors="ignore")
        date_matches = re.findall(r"(\d{4})[-/](\d{2})[-/]\d{2}", sample)
        if date_matches:
            year, month = date_matches[-1]
            return f"{year}-{month}"
    except Exception as e:
        print(f"--- [REPAIR_LOG] バックアップ月推定に失敗: {backup_path} ({e}) ---")

    try:
        return datetime.datetime.fromtimestamp(os.path.getmtime(backup_path)).strftime("%Y-%m")
    except OSError:
        return None

def restore_missing_monthly_logs_from_backups(room_name: str) -> List[str]:
    """
    backups/logs のバックアップから、欠落または空の月次ログだけを自動復元する。
    既に非空の月次ログがある場合は上書きしない。
    """
    if not room_name or ".." in room_name or "/" in room_name or "\\" in room_name:
        return []

    base_path = os.path.abspath(os.path.join(constants.ROOMS_DIR, room_name))
    return _restore_missing_monthly_logs_from_backups(base_path)

def _restore_missing_monthly_logs_from_backups(abs_base: str) -> List[str]:
    logs_dir = os.path.join(abs_base, constants.LOGS_DIR_NAME)
    backup_logs_dir = os.path.join(abs_base, "backups", "logs")
    restored: List[str] = []

    if not os.path.isdir(backup_logs_dir):
        return restored

    os.makedirs(logs_dir, exist_ok=True)
    latest_backup_by_month: Dict[str, str] = {}

    for name in os.listdir(backup_logs_dir):
        backup_path = os.path.join(backup_logs_dir, name)
        if not os.path.isfile(backup_path) or os.path.getsize(backup_path) == 0:
            continue
        if not (name.endswith(".bak") or name.endswith(".txt")):
            continue

        month = _infer_month_from_log_backup(backup_path)
        if not month or not re.match(r"^\d{4}-\d{2}$", month):
            continue

        current = latest_backup_by_month.get(month)
        if current is None or os.path.getmtime(backup_path) > os.path.getmtime(current):
            latest_backup_by_month[month] = backup_path

    for month, backup_path in sorted(latest_backup_by_month.items()):
        target_path = os.path.join(logs_dir, f"{month}.txt")
        clear_marker_path = os.path.join(logs_dir, f".cleared-{month}")
        if os.path.exists(clear_marker_path):
            print(f"--- [REPAIR_LOG] 明示的に全削除された月次ログの自動復元をスキップ: {target_path} ---")
            continue
        if os.path.exists(target_path) and os.path.getsize(target_path) > 0:
            continue

        if os.path.exists(target_path):
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            empty_backup_path = f"{target_path}.empty_before_restore_{timestamp}.bak"
            try:
                shutil.copy2(target_path, empty_backup_path)
            except Exception:
                pass

        shutil.copy2(backup_path, target_path)
        restored.append(target_path)
        print(f"--- [REPAIR_LOG] 月次ログをバックアップから自動復元: {os.path.basename(backup_path)} -> {target_path} ---")

    return restored

def generate_safe_folder_name(room_name: str) -> str:
    """
    ユーザーが入力したルーム名から、安全でユニークなフォルダ名を生成する。
    仕様:
    - 空白をアンダースコア `_` に置換
    - OSのファイル名として不正な文字 (`\\/:*?\"<>|`) を除去
    - 重複をチェックし、末尾に `_2`, `_3` ... と連番を付与
    """
    # 1. 空白をアンダースコアに置換
    safe_name = room_name.replace(" ", "_")

    # 2. OSのファイル名として不正な文字を除去
    safe_name = re.sub(r'[\\/:*?"<>|]', '', safe_name)

    # 3. 重複をチェックし、連番を付与
    base_path = constants.ROOMS_DIR
    if not os.path.exists(base_path):
        os.makedirs(base_path)

    final_name = safe_name
    counter = 2
    while os.path.exists(os.path.join(base_path, final_name)):
        final_name = f"{safe_name}_{counter}"
        counter += 1

    return final_name

def is_system_room_dir(folder_name: str) -> bool:
    """ユーザーが切り替える通常ルームではない管理用ディレクトリかを判定する。"""
    return bool(folder_name) and (folder_name.startswith(".") or folder_name in SYSTEM_ROOM_DIR_NAMES)

def normalize_room_folder_for_migration(folder_name: str) -> str:
    """旧環境からの移行時に、既知の標準ペルソナ表記ゆれを現在のフォルダ名へ寄せる。"""
    if not isinstance(folder_name, str):
        return folder_name
    import unicodedata

    normalized_name = unicodedata.normalize("NFC", folder_name)
    if normalized_name in OLIVIE_ROOM_NAME_ALIASES:
        return "Olivie"
    return folder_name

def normalize_migrated_config_room_references(config: dict, room_name_map: Dict[str, str]) -> bool:
    """
    移行時にフォルダ名を正規化した場合、config.json内のルーム参照も同じ名前へ更新する。
    戻り値は変更有無。
    """
    if not isinstance(config, dict) or not room_name_map:
        return False

    changed = False

    def mapped_room(value):
        if not isinstance(value, str):
            return value
        return room_name_map.get(value, normalize_room_folder_for_migration(value))

    for key in ("last_room", "line_bot_linked_room"):
        old_value = config.get(key)
        new_value = mapped_room(old_value)
        if new_value != old_value:
            config[key] = new_value
            changed = True

    discord_settings = config.get("discord_bot_settings")
    if isinstance(discord_settings, dict):
        old_value = discord_settings.get("linked_room")
        new_value = mapped_room(old_value)
        if new_value != old_value:
            discord_settings["linked_room"] = new_value
            changed = True

    return changed

def is_auto_generated_default_room(folder_name: str = "Default") -> bool:
    """
    初回起動時のフォールバックで作られた、実質空のDefaultルームかを判定する。
    ユーザーが編集したDefaultはサンプル補填の対象外にするため、主要ファイルが空かだけを見る。
    """
    if folder_name != "Default":
        return False

    room_path = os.path.join(constants.ROOMS_DIR, folder_name)
    config_file = os.path.join(room_path, "room_config.json")
    if not os.path.isfile(config_file):
        return False

    try:
        with open(config_file, "r", encoding="utf-8") as f:
            config = json.load(f)
    except (json.JSONDecodeError, OSError):
        return False

    if config.get("room_name", folder_name) != folder_name:
        return False
    if config.get("description"):
        return False
    if config.get("agent_display_name"):
        return False

    content_files = [
        os.path.join(room_path, "SystemPrompt.txt"),
        os.path.join(room_path, constants.NOTEPAD_FILENAME),
        os.path.join(room_path, "memory", constants.IDENTITY_FILENAME),
        os.path.join(room_path, "memory", constants.DIARY_FILENAME),
    ]
    for file_path in content_files:
        if os.path.isfile(file_path) and os.path.getsize(file_path) > 0:
            return False

    logs_dir = os.path.join(room_path, constants.LOGS_DIR_NAME)
    if os.path.isdir(logs_dir):
        for name in os.listdir(logs_dir):
            log_path = os.path.join(logs_dir, name)
            if name.endswith(".txt") and os.path.isfile(log_path) and os.path.getsize(log_path) > 0:
                return False

    return True

def should_install_sample_persona_on_startup(sample_room_name: str = "Olivie") -> bool:
    """
    新規配布環境に同梱される管理用データ（例: characters/_shared）だけで、
    サンプルペルソナ展開がスキップされないようにする。
    """
    sample_path = os.path.join(constants.ROOMS_DIR, sample_room_name)
    if os.path.exists(sample_path):
        return False

    room_folders = [folder for _display, folder in get_room_list_for_ui() if not is_system_room_dir(folder)]
    if not room_folders:
        return True

    if room_folders == ["Default"] and is_auto_generated_default_room("Default"):
        return True

    return False


def sync_installed_olivie_official_knowledge() -> Dict[str, Any]:
    """既存Olivieへ公式ガイドを同期し、安全な場合だけ配布用索引も更新する。"""
    source_room = os.path.join(constants.SAMPLE_PERSONA_DIR, "Olivie")
    target_room = os.path.join(constants.ROOMS_DIR, "Olivie")
    source_knowledge = os.path.join(source_room, "knowledge")
    target_knowledge = os.path.join(target_room, "knowledge")
    source_index = os.path.join(source_room, "rag_data", "faiss_index_dynamic")
    target_index = os.path.join(target_room, "rag_data", "faiss_index_dynamic")

    if not os.path.isdir(target_room) or not os.path.isdir(source_knowledge):
        return {"status": "skipped", "reason": "Olivie or bundled knowledge not found"}

    official_files = sorted(
        name for name in os.listdir(source_knowledge) if name.endswith(".md")
    )
    if not official_files:
        return {"status": "skipped", "reason": "bundled official knowledge is empty"}

    digest = hashlib.sha256()
    for filename in official_files:
        digest.update(filename.encode("utf-8"))
        with open(os.path.join(source_knowledge, filename), "rb") as f:
            digest.update(f.read())
    source_model_info = os.path.join(source_index, "model_info.json")
    if os.path.isfile(source_model_info):
        with open(source_model_info, "rb") as f:
            digest.update(f.read())
    bundle_id = digest.hexdigest()

    sync_marker = os.path.join(target_room, "rag_data", "official_knowledge_sync.json")
    if os.path.isfile(sync_marker):
        try:
            with open(sync_marker, "r", encoding="utf-8") as f:
                if json.load(f).get("bundle_id") == bundle_id:
                    return {"status": "unchanged", "bundle_id": bundle_id}
        except (OSError, json.JSONDecodeError):
            pass

    os.makedirs(target_knowledge, exist_ok=True)
    legacy_official_files = {"NEXUS_ARK_SPECIFICATION.md"}
    existing_md = {name for name in os.listdir(target_knowledge) if name.endswith(".md")}
    personal_files = sorted(existing_md - set(official_files) - legacy_official_files)

    for filename in official_files:
        shutil.copy2(
            os.path.join(source_knowledge, filename),
            os.path.join(target_knowledge, filename),
        )
    for filename in legacy_official_files:
        legacy_path = os.path.join(target_knowledge, filename)
        if os.path.isfile(legacy_path):
            os.remove(legacy_path)

    index_updated = False
    needs_rebuild = bool(personal_files)
    if not personal_files and os.path.isdir(source_index):
        if os.path.exists(target_index):
            shutil.rmtree(target_index)
        os.makedirs(os.path.dirname(target_index), exist_ok=True)
        shutil.copytree(source_index, target_index)
        index_updated = True
    elif personal_files and os.path.exists(target_index):
        # 公式ガイドだけの配布索引で個人文書の索引を上書きしない。
        # 古い索引を使い続ける誤検索も避け、UIからの再構築を要求する。
        shutil.rmtree(target_index)

    os.makedirs(os.path.dirname(sync_marker), exist_ok=True)
    with open(sync_marker, "w", encoding="utf-8") as f:
        json.dump(
            {
                "bundle_id": bundle_id,
                "official_files": official_files,
                "synced_at": datetime.datetime.now().isoformat(),
                "needs_rebuild": needs_rebuild,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    return {
        "status": "updated",
        "official_files": len(official_files),
        "index_updated": index_updated,
        "needs_rebuild": needs_rebuild,
        "personal_files": personal_files,
        "bundle_id": bundle_id,
    }

def ensure_room_files(room_name: str) -> bool:
    """
    指定されたルーム名のディレクトリと、その中に必要なファイル群を生成・保証する。
    """
    if not room_name or not isinstance(room_name, str) or not room_name.strip(): return False
    if ".." in room_name or "/" in room_name or "\\" in room_name: return False
    try:
        base_path = os.path.join(constants.ROOMS_DIR, room_name)
        spaces_dir = os.path.join(base_path, "spaces")
        cache_dir = os.path.join(base_path, "cache")

        dirs_to_create = [
            base_path,
            os.path.join(base_path, "attachments"),
            os.path.join(base_path, "audio_cache"),
            os.path.join(base_path, "generated_images"),
            spaces_dir,
            os.path.join(spaces_dir, "images"),
            cache_dir,
            os.path.join(base_path, constants.LOGS_DIR_NAME), # [NEW] チャットログ分割
            os.path.join(base_path, "log_archives", "processed"),
            os.path.join(base_path, "log_import_source", "processed"),
            os.path.join(base_path, "memory"),
            os.path.join(base_path, "private"),
            os.path.join(base_path, "workspace"),
            os.path.join(base_path, constants.NOTES_DIR_NAME),
            os.path.join(base_path, constants.NOTES_DIR_NAME, "archives"),
            os.path.join(base_path, constants.NOTES_DIR_NAME, constants.WORKING_MEMORY_DIR_NAME) # 新ワーキングメモリ
        ]
        # ▼▼▼【ここから下のブロックをまるごと追加】▼▼▼
        # バックアップ用のサブディレクトリを追加
        backup_base_dir = os.path.join(base_path, "backups")
        backup_sub_dirs = [
            os.path.join(backup_base_dir, "logs"),
            os.path.join(backup_base_dir, "memories"),
            os.path.join(backup_base_dir, "notepads"),
            os.path.join(backup_base_dir, "world_settings"),
            os.path.join(backup_base_dir, "system_prompts"),
            os.path.join(backup_base_dir, "core_memories"),
            os.path.join(backup_base_dir, "secret_diaries"),
            os.path.join(backup_base_dir, "configs"),
            os.path.join(backup_base_dir, "research_notes"),
            os.path.join(backup_base_dir, "creative_notes"),
            os.path.join(backup_base_dir, "working_memories"),
        ]
        dirs_to_create.append(backup_base_dir)
        dirs_to_create.extend(backup_sub_dirs)
        # ▲▲▲【追加はここまで】▲▲▲

        for path in dirs_to_create:
            os.makedirs(path, exist_ok=True)

        # テキストベースのファイル
        world_settings_content = "## 共有リビング\n\n### リビング\n広々としたリビングルーム。大きな窓からは柔らかな光が差し込み、快適なソファが置かれている。\n"

        memory_template_content = (
            "## 永続記憶 (Permanent)\n"
            "### 自己同一性 (Self Identity)\n\n\n"
            "## 日記 (Diary)\n"
            f"### {datetime.datetime.now().strftime('%Y-%m-%d')}\n\n\n"
            "## アーカイブ要約 (Archive Summary)\n"
        )

        text_files_to_create = {
            os.path.join(base_path, "SystemPrompt.txt"): "",
            # 注意: log.txt はここで作成しない。logs/ ディレクトリに月次ファイルとして直接書き込む。
            # 空の log.txt が存在すると _migrate_chat_logs が毎回トリガーされ、既存ログを破壊するため。
            os.path.join(base_path, constants.NOTEPAD_FILENAME): "",
            os.path.join(base_path, "current_location.txt"): "リビング",
            os.path.join(spaces_dir, "world_settings.txt"): world_settings_content,
            os.path.join(base_path, "memory", constants.IDENTITY_FILENAME): "", # [NEW]
            os.path.join(base_path, "memory", constants.DIARY_FILENAME): "",    # [NEW]
            os.path.join(base_path, "private", "secret_diary.txt"): ""
        }
        for file_path, content in text_files_to_create.items():
            if not os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)

        # レガシーなノートファイルを新しい場所へ移動
        _migrate_legacy_notes(room_name)
        # 記憶ファイルの分割移行 (v2026-02-19)
        _migrate_memory_files(room_name)
        # ワーキングメモリのスロット化移行
        _migrate_working_memory_to_slots(room_name)

        # --- [NEW] ログの自己修復 (Self-Healing) ---
        try:
            import traceback
            import re
            
            # 絶対パスで確実に判定
            abs_base = os.path.abspath(base_path)
            logs_dir = os.path.join(abs_base, constants.LOGS_DIR_NAME)
            backup_logs_dir = os.path.join(abs_base, "backups", "logs")
            
            l_exists = os.path.exists(logs_dir)
            b_exists = os.path.exists(backup_logs_dir)
            
            if l_exists and b_exists:
                # logsが空かチェック
                c_logs = [f for f in os.listdir(logs_dir) if f.endswith(".txt")]
                leg_log = os.path.join(abs_base, "log.txt")
                mig_log = leg_log + ".migrating"
                
                has_legacy_log = os.path.exists(leg_log)
                has_migrating_log = os.path.exists(mig_log)
                needs_repair = not c_logs and (has_legacy_log or has_migrating_log or b_exists)
                if needs_repair:
                    print(f"--- [REPAIR_LOG] 状態確認: {room_name} (logs_dir={len(c_logs)}件, legacy={has_legacy_log}) ---")

                if not c_logs and has_legacy_log:
                    print(f"--- [REPAIR_LOG] legacy logを検知。月次ログへ移行します: {room_name} ---")
                    try:
                        import utils
                        utils.invalidate_log_migration_cache(abs_base)
                        utils._migrate_chat_logs(abs_base)
                        c_logs = [f for f in os.listdir(logs_dir) if f.endswith(".txt")]
                        print(f"--- [REPAIR_LOG] legacy移行後: {room_name} (logs_dir={len(c_logs)}件) ---")
                    except Exception as migrate_error:
                        print(f"--- [REPAIR_LOG] legacy logの月次移行に失敗: {migrate_error} ---")

                restored_monthly_logs = _restore_missing_monthly_logs_from_backups(abs_base)
                if restored_monthly_logs:
                    c_logs = [f for f in os.listdir(logs_dir) if f.endswith(".txt")]
                
                if not c_logs and not has_legacy_log and not has_migrating_log:
                    print(f"--- [REPAIR_LOG] ログ消失を検知。バックアップをスキャンします... ---")
                    
                    b_files = [f for f in os.listdir(backup_logs_dir) if os.path.isfile(os.path.join(backup_logs_dir, f))]
                    print(f"--- [REPAIR_LOG] バックアップ候補: {len(b_files)} 件 ---")
                    
                    backups = sorted(
                        [os.path.join(backup_logs_dir, f) for f in b_files], 
                        key=os.path.getmtime
                    )
                    
                    if backups:
                        latest = backups[-1]
                        fname = os.path.basename(latest)
                        
                        target_name = "log.txt"
                        # 月次形式 (YYYY-MM.txt) を優先
                        m = re.search(r'(\d{4}-\d{2}\.txt)', fname)
                        if m:
                            target_name = m.group(1)
                        elif "log" in fname.lower():
                            target_name = "log.txt"
                        
                        target_path = os.path.join(logs_dir if target_name != "log.txt" else abs_base, target_name)
                        print(f"--- [REPAIR_LOG] 復元実行: {fname} -> {target_path} ---")
                        shutil.copy2(latest, target_path)
                        if target_name == "log.txt":
                            try:
                                import utils
                                utils.invalidate_log_migration_cache(abs_base)
                                utils._migrate_chat_logs(abs_base)
                            except Exception as migrate_error:
                                print(f"--- [REPAIR_LOG] 復元ログの月次移行に失敗: {migrate_error} ---")
                    else:
                        print(f"--- [REPAIR_LOG] バックアップファイル自体が見つかりませんでした ---")
            elif b_exists:
                print(f"--- [REPAIR_LOG] パスが見つかりません: logs={l_exists}, backups={b_exists} ({backup_logs_dir}) ---")
        except Exception as e:
            print(f"--- [REPAIR_LOG] 重大なエラー: {e} ---")
            traceback.print_exc()

        # JSONベースのファイル
        json_files_to_create = {
            os.path.join(cache_dir, "scenery.json"): {},
            os.path.join(cache_dir, "image_prompts.json"): {"prompts": {}},
        }
        for file_path, content in json_files_to_create.items():
            if not os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(content, f, indent=2, ensure_ascii=False)

        # room_config.json の設定（後方互換性も考慮）
        config_file_path = os.path.join(base_path, "room_config.json")
        if not os.path.exists(config_file_path) or os.path.getsize(config_file_path) == 0:
            default_config = {
                "room_name": room_name, # デフォルトはフォルダ名
                "user_display_name": "ユーザー",
                "description": "",
                "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "version": 1,
                "override_settings": dict(constants.NEW_ROOM_DEFAULT_OVERRIDES)
            }
            with open(config_file_path, "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=2, ensure_ascii=False)

        return True
    except Exception as e:
        print(f"ルーム '{room_name}' ファイル作成/確認エラー: {e}"); traceback.print_exc()
        return False

def get_room_list_for_ui() -> List[Tuple[str, str]]:
    """
    UIのドロップダウン表示用に、有効なルームのリストを `[('表示名', 'フォルダ名'), ...]` の形式で返す。
    room_config.json が存在するフォルダのみを有効なルームとみなす。
    """
    rooms_dir = constants.ROOMS_DIR
    if not os.path.exists(rooms_dir) or not os.path.isdir(rooms_dir):
        return []

    valid_rooms = []
    for folder_name in os.listdir(rooms_dir):
        # ドット/アンダースコアで始まる管理用フォルダは通常ルームとして扱わない
        if is_system_room_dir(folder_name):
            continue
        room_path = os.path.join(rooms_dir, folder_name)
        if os.path.isdir(room_path):
            config_file = os.path.join(room_path, "room_config.json")
            if os.path.exists(config_file):
                try:
                    with open(config_file, "r", encoding="utf-8") as f:
                        config = json.load(f)
                        display_name = config.get("room_name", folder_name)
                        valid_rooms.append((display_name, folder_name))
                except (json.JSONDecodeError, IOError) as e:
                    print(f"警告: ルーム '{folder_name}' の設定ファイルが読めません: {e}")


    # 表示名でソートして返す
    return sorted(valid_rooms, key=lambda x: x[0])


def _restore_room_config_from_backup(folder_name: str) -> bool:
    """最も新しいバックアップからroom_config.jsonを復元する。"""
    backup_dir = os.path.join(constants.ROOMS_DIR, folder_name, "backups", "configs")
    config_file = os.path.join(constants.ROOMS_DIR, folder_name, "room_config.json")
    
    if not os.path.isdir(backup_dir):
        return False

    try:
        backups = sorted(
            [f for f in os.listdir(backup_dir) if f.endswith(".bak")],
            key=lambda f: os.path.getmtime(os.path.join(backup_dir, f)),
            reverse=True
        )
        if not backups:
            return False

        latest_backup = os.path.join(backup_dir, backups[0])
        print(f"--- [自己修復] 破損したルーム設定をバックアップ '{backups[0]}' から復元します ---")
        shutil.copy2(latest_backup, config_file)
        return True
    except Exception as e:
        print(f"!!! エラー: バックアップからの復元に失敗しました ({folder_name}): {e}")
        return False

def get_room_config(folder_name: str) -> Optional[dict]:
    """
    指定されたフォルダ名のルーム設定ファイル(room_config.json)を安全に読み込み、辞書として返す。
    破損している場合はバックアップからの復元を試みる。
    """
    if not folder_name:
        return None

    config_file = os.path.join(constants.ROOMS_DIR, folder_name, "room_config.json")
    
    def _read_json():
        if os.path.exists(config_file):
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    content = f.read()
                if not content.strip():
                    raise json.JSONDecodeError("File is empty", "", 0)
                return json.loads(content)
            except (json.JSONDecodeError, IOError) as e:
                print(f"警告: ルーム '{folder_name}' の設定ファイルが破損しています: {e}")
                return None
        return None

    # 1. 通常の読み込み試行
    config = _read_json()
    if config is not None:
        return config

    # 2. 破損している場合、復元を試みる
    if os.path.exists(config_file):
        if _restore_room_config_from_backup(folder_name):
            return _read_json()
            
    return None


    return config
    

def get_character_name(folder_name: str) -> str:
    """
    指定されたフォルダ名のキャラクター(ルーム)の表示名を返す。
    設定ファイルが見つからない場合はフォルダ名をそのまま返す。
    """
    config = get_room_config(folder_name)
    if config:
        return config.get("room_name", folder_name)
    return folder_name


def get_room_files_paths(room_name: str) -> Optional[Tuple[str, str, Optional[str], str, str, str, str]]:
    """
    ルームの主要ファイルパスを取得する。
    
    Returns:
        (log_file, system_prompt_file, profile_image_path, memory_identity_path, memory_diary_path, notepad_path, research_notes_path)
    """
    if not room_name or not ensure_room_files(room_name): return None, None, None, None, None, None, None
    base_path = os.path.join(constants.ROOMS_DIR, room_name)
    current_month = datetime.datetime.now().strftime("%Y-%m")
    log_file = os.path.join(base_path, constants.LOGS_DIR_NAME, f"{current_month}.txt")
    system_prompt_file = os.path.join(base_path, "SystemPrompt.txt")
    profile_image_path = os.path.join(base_path, constants.PROFILE_IMAGE_FILENAME)
    # [v2026-02-19] メイン記憶を分割後のパスに変更
    memory_identity_path = os.path.join(base_path, "memory", constants.IDENTITY_FILENAME)
    memory_diary_path = os.path.join(base_path, "memory", constants.DIARY_FILENAME)
    
    # ノート類を notes/ フォルダへ集約 (v2026-02-02)
    notes_base = os.path.join(base_path, constants.NOTES_DIR_NAME)
    notepad_path = os.path.join(notes_base, constants.NOTEPAD_FILENAME)
    research_notes_path = os.path.join(notes_base, constants.RESEARCH_NOTES_FILENAME)
    
    if not os.path.exists(profile_image_path): profile_image_path = None
    return log_file, system_prompt_file, profile_image_path, memory_identity_path, memory_diary_path, notepad_path, research_notes_path

def get_creative_notes_path(room_name: str) -> str:
    """創作ノートの最新ファイルパスを返す"""
    return os.path.join(constants.ROOMS_DIR, room_name, constants.NOTES_DIR_NAME, constants.CREATIVE_NOTES_FILENAME)

def _migrate_legacy_notes(room_name: str):
    """ルーム直下の古いノートファイルを notes/ へ移動する"""
    base_path = os.path.join(constants.ROOMS_DIR, room_name)
    notes_dir = os.path.join(base_path, constants.NOTES_DIR_NAME)
    
    legacy_files = [
        constants.NOTEPAD_FILENAME,
        constants.RESEARCH_NOTES_FILENAME,
        constants.CREATIVE_NOTES_FILENAME
    ]
    
    for filename in legacy_files:
        old_path = os.path.join(base_path, filename)
        new_path = os.path.join(notes_dir, filename)
        if os.path.exists(old_path) and not os.path.exists(new_path):
            print(f"--- [移行] {filename} を {constants.NOTES_DIR_NAME}/ へ移動します ---")
            shutil.move(old_path, new_path)

def _migrate_memory_files(room_name: str):
    """
    memory_main.txt を解析し、永続記憶と日記に分割する。
    """
    base_path = os.path.join(constants.ROOMS_DIR, room_name)
    memory_dir = os.path.join(base_path, "memory")
    old_memory_path = os.path.join(memory_dir, "memory_main.txt")
    new_identity_path = os.path.join(memory_dir, constants.IDENTITY_FILENAME)
    new_diary_path = os.path.join(memory_dir, constants.DIARY_FILENAME)

    if not os.path.exists(old_memory_path):
        return

    # すでに移行済みの場合はスキップ
    if os.path.exists(new_identity_path) and os.path.getsize(new_identity_path) > 0:
        if os.path.exists(new_diary_path) and os.path.getsize(new_diary_path) > 0:
            return

    print(f"--- [移行] memory_main.txt を分割移行します: {room_name} ---")
    try:
        with open(old_memory_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # セクション分割
        sections = re.split(r'^##\s+', content, flags=re.MULTILINE)
        
        identity_parts = []
        diary_parts = []
        
        for section in sections:
            section = section.strip()
            if not section: continue
            
            lines = section.split('\n')
            header = lines[0].strip().lower()
            body = '\n'.join(lines[1:]).strip()
            
            if "永続記憶" in header or "permanent" in header or "自己同一性" in header or "self identity" in header:
                identity_parts.append(f"## {lines[0].strip()}\n{body}")
            elif "日記" in header or "diary" in header:
                diary_parts.append(f"## {lines[0].strip()}\n{body}")
            elif "アーカイブ" in header or "archive" in header:
                # アーカイブは日記側に含めるか、別途考えるが、一旦日記へ
                diary_parts.append(f"## {lines[0].strip()}\n{body}")
            else:
                # 分類不能なものはIdentityへ（安全のため）
                identity_parts.append(f"## {lines[0].strip()}\n{body}")

        # 書き込み
        with open(new_identity_path, 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(identity_parts))
        with open(new_diary_path, 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(diary_parts))

        # 元ファイルをリネームしてバックアップ
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        shutil.move(old_memory_path, f"{old_memory_path}.migrated_{timestamp}.bak")
        print(f"--- [移行完了] {room_name} ---")

    except Exception as e:
        print(f"!!! [移行失敗] {room_name}: {e}")
        traceback.print_exc()

def _migrate_working_memory_to_slots(room_name: str):
    """
    これまでの notes/working_memory.md を notes/working_memories/main.md へ移行する。
    """
    base_path = os.path.join(constants.ROOMS_DIR, room_name)
    notes_dir = os.path.join(base_path, constants.NOTES_DIR_NAME)
    old_wm_path = os.path.join(notes_dir, constants.WORKING_MEMORY_FILENAME)
    
    wm_dir = os.path.join(notes_dir, constants.WORKING_MEMORY_DIR_NAME)
    new_wm_path = os.path.join(wm_dir, f"{constants.WORKING_MEMORY_DEFAULT_SLOT}{constants.WORKING_MEMORY_EXTENSION}")

    if not os.path.exists(old_wm_path):
        return

    # 既に新ファイルが存在する、あるいは空なら旧ファイルを削除して終了
    if os.path.exists(new_wm_path) and os.path.getsize(new_wm_path) > 0:
        if os.path.getsize(old_wm_path) == 0:
            os.remove(old_wm_path)
        return

    print(f"--- [移行] working_memory.md をスロット化構成へ移行します: {room_name} ---")
    try:
        os.makedirs(wm_dir, exist_ok=True)
        shutil.move(old_wm_path, new_wm_path)
    except Exception as e:
        print(f"!!! [移行失敗] ワーキングメモリのスロット化: {e}")
        traceback.print_exc()

def get_note_files(room_name: str, note_type: str) -> List[str]:
    """
    指定されたノート種別のファイルリスト（最新 + アーカイブ）を返す。
    最新がリストの先頭になります。
    note_type: 'notepad', 'research', 'creative'
    """
    if not room_name: return []
    notes_dir = os.path.join(constants.ROOMS_DIR, room_name, constants.NOTES_DIR_NAME)
    archives_dir = os.path.join(notes_dir, "archives")
    
    filename_map = {
        'notepad': constants.NOTEPAD_FILENAME,
        'research': constants.RESEARCH_NOTES_FILENAME,
        'creative': constants.CREATIVE_NOTES_FILENAME
    }
    base_filename = filename_map.get(note_type)
    if not base_filename: return []
    
    files = []
    # 最新
    main_file = os.path.join(notes_dir, base_filename)
    if os.path.exists(main_file):
        files.append(base_filename)
        
    # アーカイブ
    if os.path.exists(archives_dir):
        # archive_YYYYMMDD_HHMMSS_filename.md のような形式を想定
        prefix = f"archive_"
        suffix = f"_{base_filename}"
        archives = [f for f in os.listdir(archives_dir) if f.startswith(prefix) and f.endswith(suffix)]
        # 新しい順にソート
        archives.sort(reverse=True)
        files.extend(archives)
        
    return files

def archive_large_note(room_name: str, filename: str) -> bool:
    """
    指定されたノートファイルが上限サイズを超えている場合、
    内容をアーカイブフォルダへ移動（分割）する。
    """
    if not room_name or not filename: return False
    
    notes_dir = os.path.join(constants.ROOMS_DIR, room_name, constants.NOTES_DIR_NAME)
    archives_dir = os.path.join(notes_dir, "archives")
    file_path = os.path.join(notes_dir, filename)
    
    if not os.path.exists(file_path):
        return False
        
    if os.path.getsize(file_path) < constants.NOTES_MAX_SIZE_BYTES:
        return False
        
    try:
        os.makedirs(archives_dir, exist_ok=True)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        archive_name = f"archive_{timestamp}_{filename}"
        archive_path = os.path.join(archives_dir, archive_name)
        
        print(f"--- [アーカイブ] {filename} が制限を超えたため、{archive_name} へ退避します ---")
        shutil.copy2(file_path, archive_path)
        
        # 元ファイルをクリア（またはヘッダーだけ残すなどの処理も検討可能だが、基本は空にする）
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("")
            
        return True
    except Exception as e:
        print(f"!!! アーカイブ処理失敗: {e}")
        return False

def get_world_settings_path(room_name: str):
    if not room_name or not ensure_room_files(room_name): return None
    return os.path.join(constants.ROOMS_DIR, room_name, "spaces", "world_settings.txt")

def get_all_personas_in_log(main_room_name: str, api_history_limit_key: str) -> list[str]:
    """
    指定されたルームのログを解析し、指定された履歴範囲内に登場するすべての
    ペルソナ名（ユーザー含む）のユニークなリストを返す。
    """
    import utils # 循環参照を避けるため、ここでローカルインポート
    if not main_room_name:
        return []

    log_file_path, _, _, _, _, _ = get_room_files_paths(main_room_name)
    if not log_file_path or not os.path.exists(log_file_path):
        # ログファイルがない場合、ルーム名自体をペルソナと見なす
        # これは、room_config.json の main_persona_name を参照する将来の実装への布石
        return [main_room_name]

    # utils.load_chat_log を呼び出す
    full_log = utils.load_chat_log(log_file_path)

    # 履歴制限を適用
    limit = constants.API_HISTORY_LIMIT_OPTIONS.get(api_history_limit_key)
    if limit is not None and limit.isdigit():
        display_turns = int(limit)
        limited_log = full_log[-(display_turns * 2):]
    else: # "全ログ" or other cases
        limited_log = full_log

    # 登場ペルソナを収集
    personas = set()
    for message in limited_log:
        responder = message.get("responder")
        if responder:
            personas.add(responder)

    # メインのペルソナがリストに含まれていることを保証する
    # ここも将来的には room_config.json から取得する
    personas.add(main_room_name)

    # "ユーザー"はペルソナではないので除外
    return sorted([p for p in list(personas) if p != "ユーザー"])


# ▼▼▼【ここから下のブロックを、ファイルの末尾にまるごと追加してください】▼▼▼
def create_backup(room_name: str, file_type: str, new_data: Any = None) -> Optional[str]:
    """
    指定されたファイルタイプのバックアップを作成し、古いバックアップをローテーションする汎用関数。
    成功した場合はバックアップパスを、失敗した場合はNoneを返す。
    """
    import config_manager
    if not room_name:
        return None

    # 現行の主要ファイルパスを取得（月次ログ対応を含む）
    current_paths = get_room_files_paths(room_name)
    if not current_paths:
        return None
    
    log_path_current, system_prompt_path, _, memory_identity_path, memory_diary_path, notepad_path, research_notes_path = current_paths

    file_map = {
        'log': ("log.txt", log_path_current),
        'memory': (constants.IDENTITY_FILENAME, memory_identity_path),
        'diary': (constants.DIARY_FILENAME, memory_diary_path),
        'notepad': (constants.NOTEPAD_FILENAME, notepad_path),
        'world_setting': ("world_settings.txt", get_world_settings_path(room_name)),
        'system_prompt': ("SystemPrompt.txt", system_prompt_path),
        'core_memory': ("core_memory.txt", os.path.join(constants.ROOMS_DIR, room_name, "core_memory.txt")),
        'secret_diary': ("secret_diary.txt", os.path.join(constants.ROOMS_DIR, room_name, "private", "secret_diary.txt")),
        'room_config': ("room_config.json", os.path.join(constants.ROOMS_DIR, room_name, "room_config.json")),
        'creative_notes': (constants.CREATIVE_NOTES_FILENAME, get_creative_notes_path(room_name)),
        'research_notes': (constants.RESEARCH_NOTES_FILENAME, research_notes_path),
        'working_memory': (constants.WORKING_MEMORY_FILENAME, os.path.join(constants.ROOMS_DIR, room_name, constants.NOTES_DIR_NAME, constants.WORKING_MEMORY_FILENAME))
    }
    folder_map = {
        'log': "logs", 'memory': "memories", 'diary': "memories", 'notepad': "notepads",
        'world_setting': "world_settings", 'system_prompt': "system_prompts",
        'core_memory': "core_memories", 'secret_diary': "secret_diaries",
        'room_config': "configs",
        'creative_notes': "creative_notes",
        'research_notes': "research_notes",
        'working_memory': "working_memories"
    }

    if file_type not in file_map:
        error_msg = f"致命的エラー: 不明なバックアップファイルタイプです: {file_type}"
        print(error_msg)
        raise ValueError(error_msg)

    original_filename, source_path = file_map[file_type]
    backup_subdir = folder_map[file_type]
    backup_dir = os.path.join(constants.ROOMS_DIR, room_name, "backups", backup_subdir)

    try:
        # ディレクトリの存在を確認・作成
        os.makedirs(backup_dir, exist_ok=True)

        # ソースファイルが存在しない場合はバックアップを作成しない
        if not source_path or not os.path.exists(source_path):
            print(f"情報: バックアップ対象ファイルが見つかりません（初回作成時など）: {source_path}")
            return None

        try:
            with locked_file(source_path, timeout=0.2):
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                if file_type == 'room_config':
                    rotation_count = config_manager.CONFIG_GLOBAL.get("backup_rotation_count", 10)
                    backup_path = create_layered_settings_backup(
                        source_path,
                        backup_dir,
                        original_filename,
                        rotation_count=rotation_count,
                        new_data=new_data,
                        timestamp=timestamp,
                    )
                else:
                    # 変更検知: 最新のバックアップと内容が同一ならスキップ
                    existing_backups = sorted(
                        [f for f in os.listdir(backup_dir) if f.endswith(".bak")],
                        key=lambda f: os.path.getmtime(os.path.join(backup_dir, f))
                    )
                    if existing_backups:
                        latest_backup_path = os.path.join(backup_dir, existing_backups[-1])
                        try:
                            if filecmp.cmp(source_path, latest_backup_path, shallow=False):
                                return None  # 変更なし → スキップ
                        except OSError:
                            pass  # 比較失敗時はバックアップを作成する

                    # バックアップファイル名の生成
                    backup_filename = f"{timestamp}_{original_filename}.bak"
                    backup_path = os.path.join(backup_dir, backup_filename)

                    # バックアップの実行
                    shutil.copy2(source_path, backup_path)
        except Timeout:
            print(f"警告: バックアップ対象ファイルのロック取得に失敗したためスキップします: {source_path}")
            return None

        if file_type == 'room_config':
            return backup_path

        # ローテーション処理（ログは専用の世代数を使用）
        if file_type == 'log':
            rotation_count = config_manager.CONFIG_GLOBAL.get("log_backup_rotation_count", 30)
        else:
            rotation_count = config_manager.CONFIG_GLOBAL.get("backup_rotation_count", 10)

        # バックアップ一覧を再取得（新規作成分を含む）
        existing_backups = sorted(
            [f for f in os.listdir(backup_dir) if f.endswith(".bak")],
            key=lambda f: os.path.getmtime(os.path.join(backup_dir, f))
        )

        if len(existing_backups) > rotation_count:
            files_to_delete = existing_backups[:len(existing_backups) - rotation_count]
            for f_del in files_to_delete:
                os.remove(os.path.join(backup_dir, f_del))

        return backup_path

    except Exception as e:
        error_msg = f"!!! 致命的エラー: バックアップ作成中に予期せぬエラーが発生しました ({file_type}): {e}"
        print(error_msg)
        traceback.print_exc()
        raise IOError(error_msg) from e

def update_room_config(room_name: str, updates: dict) -> bool:
    """
    ルーム設定ファイル(room_config.json)を安全に更新する。
    - 既存ルームはthreading.LockとFileLockによる排他制御
    - 感情定義は専用の版照合付き操作で更新し、汎用入力から変更しない
    - ユニークな一時ファイルによるアトミック書き込み
    - 変更がない場合は書き込まない
    """
    if not room_name: return False

    with room_config_write_guard(room_name):
        config = get_room_config(room_name)
        if not config:
            # Configがない場合（または破損して復旧不能な場合）のフォールバック
            if not ensure_room_files(room_name):
                print(f"エラー: ルーム '{room_name}' の初期化に失敗しました。")
                return False
            config = get_room_config(room_name)
            if not config: return False

        # 変更検知のために元の状態をコピー
        import copy
        old_config = copy.deepcopy(config)

        if "override_settings" not in config:
            config["override_settings"] = {}

        root_keys = ["room_name", "user_display_name", "description", "version", "last_sent_scenery_image"]
        
        overrides = config["override_settings"]
        has_emotion_definitions = EMOTION_DEFINITIONS_KEY in overrides
        preserved_emotion_definitions = (
            copy.deepcopy(overrides[EMOTION_DEFINITIONS_KEY])
            if has_emotion_definitions
            else None
        )
        
        def deep_merge(target, source):
            for k, v in source.items():
                if isinstance(v, dict) and k in target and isinstance(target[k], dict):
                    deep_merge(target[k], v)
                else:
                    target[k] = v
                    
        for k, v in updates.items():
            if k == EMOTION_DEFINITIONS_KEY:
                # 感情定義は専用の差分+revision経路だけが更新する。
                continue
            if k in root_keys:
                config[k] = v
            elif k == "override_settings" and isinstance(v, dict):
                safe_updates = _sanitize_room_override_updates(room_name, v)
                safe_updates.pop(EMOTION_DEFINITIONS_KEY, None)
                deep_merge(overrides, safe_updates)
            else:
                if k in ROOM_OVERRIDE_STRING_OR_NONE_KEYS and v is not None and not isinstance(v, str):
                    print(
                        f"[room_manager.update_room_config] Warning: ルーム '{room_name}' の "
                        f"override_settings.{k} に不正な型 {type(v).__name__} を検出したため保存をスキップします。"
                    )
                    continue
                if isinstance(v, dict) and k in overrides and isinstance(overrides[k], dict):
                    deep_merge(overrides[k], v)
                else:
                    overrides[k] = v

        # [Defensive] None値のキーを個別設定から削除（共通設定への不本意な固定化を防ぐ）
        # Deep Merge に合わせて再帰的に削除するかは別途検討の余地があるが、
        # まずは直下の None のみ削除する従来の挙動を維持
        config["override_settings"] = {k: v for k, v in overrides.items() if v is not None}
        overrides = config["override_settings"] # 以降の参照用に更新
        if has_emotion_definitions:
            config["override_settings"][EMOTION_DEFINITIONS_KEY] = preserved_emotion_definitions

        # 変更があるかチェック
        if config == old_config:
            return "no_change"

        config["last_updated"] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        config["updated_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()

        # 保存前にバックアップを作成
        try:
            create_backup(room_name, 'room_config', new_data=config)
        except Exception as e:
            print(f"Warning: Backup creation failed for room_config: {e}")

        # アトミックな書き込み処理 (ユニークな一時ファイル名を使用)
        config_file = os.path.join(constants.ROOMS_DIR, room_name, "room_config.json")
        # thread_id と pid を含めて衝突を避ける
        temp_file = f"{config_file}.{os.getpid()}.{threading.get_ident()}.tmp"
        
        max_retries = 3
        for attempt in range(max_retries):
            try:
                with open(temp_file, "w", encoding="utf-8") as f:
                    json.dump(config, f, indent=2, ensure_ascii=False)
                os.replace(temp_file, config_file)
                # print(f"ルーム '{room_name}' の設定を更新しました。")
                return True
            except PermissionError:
                if attempt < max_retries - 1:
                    time.sleep(0.1)
                else:
                    raise
            except Exception as e:
                print(f"ルーム '{room_name}' の設定保存エラー: {e}")
                if os.path.exists(temp_file):
                    try: os.remove(temp_file)
                    except: pass
                return False
        return False

def save_room_override_settings(room_name: str, settings: dict) -> bool:
    """
    [後方互換用] ルーム個別の設定を保存する。
    内部で新しい update_room_config を呼び出すように変更。
    """
    return update_room_config(room_name, {"override_settings": settings})

def update_room_override_key(room_name: str, key: str, value: Any) -> bool:
    """ルーム個別設定の指定キーだけを差分保存する。"""
    return update_room_config(room_name, {key: value})

def update_room_override_nested(room_name: str, parent_key: str, updates: Dict[str, Any]) -> bool:
    """ルーム個別設定のネスト辞書に対して、指定された子キーだけを差分マージ保存する。"""
    if not isinstance(updates, dict):
        return False
    return update_room_config(room_name, {parent_key: updates})

def get_active_working_memory_slot(room_name: str) -> str:
    """現在アクティブなワーキングメモリスロット名を取得する"""
    if not room_name:
        return constants.WORKING_MEMORY_DEFAULT_SLOT
    try:
        config = get_room_config(room_name)
        if config:
            overrides = config.get("override_settings", {})
            value = overrides.get("active_working_memory_slot", constants.WORKING_MEMORY_DEFAULT_SLOT)
            # 設定が壊れて非文字列(bool等)が入っていてもクラッシュさせず既定スロットへ自己修復する
            if not isinstance(value, str) or not value.strip():
                return constants.WORKING_MEMORY_DEFAULT_SLOT
            return value
    except Exception:
        pass
    return constants.WORKING_MEMORY_DEFAULT_SLOT

def set_active_working_memory_slot(room_name: str, slot_name: str) -> bool:
    """現在アクティブなワーキングメモリスロット名を設定する"""
    if not room_name or not slot_name:
        return False
    return update_room_config(room_name, {"override_settings": {"active_working_memory_slot": slot_name}})


def delete_room(room_name: str) -> bool:
    """
    指定されたルームのディレクトリをWindowsのゴミ箱に移動する。
    完全削除ではなく、ゴミ箱からの復元が可能。
    
    Args:
        room_name: 削除するルームのフォルダ名
        
    Returns:
        bool: ゴミ箱への移動に成功した場合はTrue、失敗した場合はFalse
    """
    if not room_name:
        print("エラー: ルーム名が指定されていません。")
        return False
    
    # セキュリティチェック: パストラバーサルを防止
    if ".." in room_name or "/" in room_name or "\\" in room_name:
        print(f"エラー: 不正なルーム名です: {room_name}")
        return False
    
    room_path = os.path.join(constants.ROOMS_DIR, room_name)
    
    if not os.path.exists(room_path):
        print(f"警告: ルーム '{room_name}' は存在しません。")
        return False
    
    if not os.path.isdir(room_path):
        print(f"エラー: '{room_name}' はディレクトリではありません。")
        return False
    
    try:
        # ディレクトリ全体をゴミ箱に移動（復元可能）
        send2trash(room_path)
        print(f"--- ルーム '{room_name}' をゴミ箱に移動しました ---")
        return True
    except PermissionError as e:
        print(f"エラー: ルーム '{room_name}' の削除に失敗しました（権限エラー）: {e}")
        traceback.print_exc()
        return False
    except Exception as e:
        print(f"エラー: ルーム '{room_name}' の削除中に予期せぬエラーが発生しました: {e}")
        traceback.print_exc()
        return False


# ===== 表情差分設定管理 =====

def get_expressions_config(room_name: str) -> dict:
    """
    ルームの表情設定を読み込む。
    expressions.json が存在しない場合はデフォルト設定を返す。
    
    Args:
        room_name: ルームのフォルダ名
        
    Returns:
        表情設定の辞書
    """
    if not room_name:
        return _get_default_expressions_config()
    
    expressions_file = os.path.join(constants.ROOMS_DIR, room_name, constants.EXPRESSIONS_FILE)
    
    if os.path.exists(expressions_file):
        try:
            with open(expressions_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            print(f"警告: ルーム '{room_name}' の表情設定ファイルが読めません: {e}")
    
    return _get_default_expressions_config()


def _get_default_expressions_config() -> dict:
    """デフォルトの表情設定を返す"""
    return {
        "expressions": constants.DEFAULT_EXPRESSIONS.copy(),
        "default_expression": "neutral"
    }


def save_expressions_config(room_name: str, config: dict) -> bool:
    """
    ルームの表情設定を保存する。
    
    Args:
        room_name: ルームのフォルダ名
        config: 保存する設定辞書
        
    Returns:
        保存に成功した場合はTrue
    """
    if not room_name:
        return False
    
    expressions_file = os.path.join(constants.ROOMS_DIR, room_name, constants.EXPRESSIONS_FILE)
    
    try:
        with open(expressions_file, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        print(f"--- 表情設定を保存しました: {room_name} ---")
        return True
    except Exception as e:
        print(f"エラー: 表情設定の保存に失敗しました: {e}")
        return False


def get_available_expression_files(room_name: str) -> dict:
    """
    avatar/ディレクトリ内の利用可能な表情ファイルを取得する。
    
    Args:
        room_name: ルームのフォルダ名
        
    Returns:
        {表情名: ファイルパス} の辞書
    """
    if not room_name:
        return {}
    
    avatar_dir = os.path.join(constants.ROOMS_DIR, room_name, constants.AVATAR_DIR)
    
    if not os.path.isdir(avatar_dir):
        return {}
    
    # サポートする拡張子
    image_exts = [".png", ".jpg", ".jpeg", ".webp"]
    video_exts = [".mp4", ".webm", ".gif"]
    all_exts = image_exts + video_exts
    
    available = {}
    
    # 【v2】登録済みの表情リストでフィルタリング
    # これにより、UIから削除された表情がプロンプトに残るのを防ぐ
    expressions_config = get_expressions_config(room_name)
    registered_names = ["idle", "thinking"] + expressions_config.get("expressions", []) + constants.DEFAULT_EXPRESSIONS
    registered_names = list(set(registered_names)) # 重複除去
    
    try:
        if os.path.exists(avatar_dir):
            for filename in os.listdir(avatar_dir):
                name, ext = os.path.splitext(filename)
                if ext.lower() in all_exts:
                    # 登録リストにある場合のみ採用
                    if name in registered_names:
                        # 同じ表情名で動画と静止画がある場合、動画を優先
                        if name not in available or ext.lower() in video_exts:
                            available[name] = os.path.join(avatar_dir, filename)
    except Exception as e:
        print(f"警告: アバターディレクトリの読み取りエラー: {e}")
    
    return available


def initialize_expressions_file(room_name: str) -> bool:
    """
    ルームに expressions.json が存在しない場合、デフォルト設定をコピーする。
    新規ルーム作成時に呼び出される。
    
    Args:
        room_name: ルームのフォルダ名
        
    Returns:
        初期化に成功した場合はTrue
    """
    if not room_name:
        return False
    
    expressions_file = os.path.join(constants.ROOMS_DIR, room_name, constants.EXPRESSIONS_FILE)
    
    # 既に存在する場合はスキップ
    if os.path.exists(expressions_file):
        return True
    
    # サンプルファイルからコピー
    sample_file = os.path.join(constants.SAMPLE_PERSONA_DIR, constants.EXPRESSIONS_FILE)
    
    if os.path.exists(sample_file):
        try:
            shutil.copy2(sample_file, expressions_file)
            print(f"--- 表情設定ファイルを初期化しました: {room_name} ---")
            return True
        except Exception as e:
            print(f"警告: 表情設定ファイルのコピーに失敗: {e}")
    
    # サンプルがない場合はデフォルト設定を生成
    return save_expressions_config(room_name, _get_default_expressions_config())

# --- 自動バックアップ・復元関連の追加機能 ---

_current_active_room: Optional[str] = None
_periodic_backup_interval: int = 3600 * 3  # デフォルト3時間

def set_active_room_for_backup(room_name: Optional[str]):
    """バックアップ対象のアクティブルームを設定する"""
    global _current_active_room
    _current_active_room = room_name

def _periodic_backup_worker():
    """バックグラウンドで定期的にログバックアップを取得するワーカー"""
    import config_manager
    global _periodic_backup_interval
    while True:
        try:
            # 常に最新の設定から間隔を取得
            interval_val = config_manager.CONFIG_GLOBAL.get("periodic_backup_interval", 10800)
            try:
                _periodic_backup_interval = int(interval_val)
            except ValueError:
                _periodic_backup_interval = 10800

            if _periodic_backup_interval <= 0:
                time.sleep(60)  # 無効化されている場合は1分待機して再確認
                continue

            time.sleep(_periodic_backup_interval)
            
            room = _current_active_room
            if room:
                result = create_backup(room, 'log')
                if result:
                    print(f"--- [定期バックアップ] {room} のログをバックアップしました: {result} ---")
        except Exception as e:
            print(f"警告: 定期バックアップスレッドでエラーが発生しました: {e}")
            time.sleep(60)

def start_periodic_backup():
    """定期バックアップスレッドを開始する"""
    t = threading.Thread(target=_periodic_backup_worker, daemon=True, name="PeriodicLogBackup")
    t.start()
    print("--- 定期ログバックアップスレッドを開始しました ---")

def list_log_backups(room_name: str) -> List[Tuple[str, str]]:
    """ログバックアップの一覧を [(表示名, ファイルパス), ...] の形式で降順（新しい順）で返す"""
    if not room_name:
        return []

    backup_dir = os.path.join(constants.ROOMS_DIR, room_name, "backups", "logs")
    if not os.path.exists(backup_dir):
        return []

    backups = []
    for f in os.listdir(backup_dir):
        if f.endswith("_log.txt.bak"):
            filepath = os.path.join(backup_dir, f)
            # ファイル名からタイムスタンプを抽出 (YYYYMMDD_HHMMSS)
            match = re.match(r"^(\d{8}_\d{6})_log\.txt\.bak$", f)
            if match:
                dt_str = match.group(1)
                try:
                    dt = datetime.datetime.strptime(dt_str, "%Y%m%d_%H%M%S")
                    display_name = dt.strftime("%Y-%m-%d %H:%M:%S")
                    backups.append((display_name, filepath))
                except ValueError:
                    backups.append((f, filepath))
            else:
                backups.append((f, filepath))

    # 新しいものが上に来るようにソート
    backups.sort(key=lambda x: x[0], reverse=True)
    return backups

def restore_log_from_backup(room_name: str, backup_path: str) -> bool:
    """指定されたバックアップからログを復元する。復元前に現在のログのバックアップを取る。"""
    if not room_name or not backup_path or not os.path.exists(backup_path):
        return False

    current_paths = get_room_files_paths(room_name)
    if not current_paths:
        return False
    
    log_path_current = current_paths[0]
    
    try:
        # 安全策: 復元する前に現在の状態を強制バックアップ（ファイル名を変えて退避）
        if os.path.exists(log_path_current):
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            pre_restore_backup = f"{log_path_current}.pre_restore_{timestamp}.bak"
            shutil.copy2(log_path_current, pre_restore_backup)
            print(f"--- 復元前の安全バックアップを作成しました: {pre_restore_backup} ---")

        # 復元の実行
        shutil.copy2(backup_path, log_path_current)
        # 手動復元は明示的な操作なので、全削除マーカーを解除する。
        import utils
        utils.clear_chat_log_month_marker(log_path_current)
        utils.invalidate_chat_log_cache(log_path_current)
        print(f"--- ログをバックアップから復元しました: {backup_path} -> {log_path_current} ---")
        return True
    except Exception as e:
        print(f"致命的エラー: ログの復元に失敗しました: {e}")
        traceback.print_exc()
        return False
