# config_manager.py (v7: The True Final Covenant - 真・最終版)

import json
import logging
import os
import time
from typing import Any, List, Dict, Tuple, Optional
import time 
import shutil 
import datetime 
import re
from urllib.parse import urlsplit, urlunsplit

import constants
import file_lock_utils
import requests
from settings_backup_manager import create_layered_settings_backup

logger = logging.getLogger(__name__)

# --- グローバル変数 ---
CONFIG_GLOBAL = {}
GEMINI_API_KEYS = {}
GEMINI_KEY_STATES = {} # {key_name: {'exhausted': bool, 'exhausted_at': timestamp}}
KEY_STATES_FILE = ".gemini_key_states.json"
CONFIG_LOCK_TIMEOUT = file_lock_utils.DEFAULT_LOCK_TIMEOUT
TAVILY_API_KEY = ""  # Tavily検索用APIキー
DISCORD_BOT_ENABLED = False
DISCORD_BOT_TOKEN = ""
DISCORD_AUTHORIZED_USER_IDS = []
DISCORD_BOT_LINKED_ROOM = None
AVAILABLE_MODELS_GLOBAL = []
DEFAULT_MODEL_GLOBAL = "gemini-3.1-flash-lite"
NOTIFICATION_SERVICE_GLOBAL = "discord"
NOTIFICATION_WEBHOOK_URL_GLOBAL = None
PUSHOVER_CONFIG = {}
ZHIPU_API_KEY = ""    # [Phase 3] Zhipu AI (GLM-4) 用APIキー
GROQ_API_KEY = ""     # [Phase 3b] Groq用APIキー
MOONSHOT_API_KEY = "" # [Phase 3d] Moonshot AI (Kimi) 用APIキー
LOCAL_MODEL_PATH = "" # [Phase 3c] ローカルLLM (llama.cpp) 用GGUFモデルパス
ANTHROPIC_API_KEY = "" # [Phase 4] Anthropic (Claude) 用APIキー
CLAUDE_SUBSCRIPTION_OAUTH_TOKEN = ""  # Claude Agent SDK サブスクリプション認証トークン
NIM_API_KEY = ""       # [Phase 4] Nvidia NIM 用APIキー
XAI_API_KEY = ""       # [Phase 4] X.ai (Grok) 用APIキー
AVAILABLE_ZHIPU_MODELS = constants.ZHIPU_MODELS


def get_lite_default_model(provider: Any = "gemini") -> str:
    """Lite初回候補を返す。利用可否の確定はWorkerで行う。

    本体の共通モデル既定値とは分離し、Lite初回設定の候補に限定する。
    使用可能と断定せず、出発前のliveカタログ照合を通過した経路のみ送信できる。
    """
    return constants.LITE_DEFAULT_GEMINI_MODEL if str(provider or "").strip().lower() == "gemini" else ""

ROOM_AI_PROVIDER_SETTING_KEYS = {
    "provider",
    "api_key_name",
    "model_name",
    "enable_api_key_rotation",
    "gemini_connection",
    "openai_settings",
    "anthropic_settings",
    "claude_subscription_settings",
    "zhipu_model",
}
# [SEALED] claude_subscription はルームプロバイダから意図的に除外。経緯: docs/decisions/010_claude_sdk_path_sealed_not_deleted.md
VALID_ROOM_PROVIDERS = {"google", "openai", "local", "anthropic", "zhipu"}


def normalize_room_provider_override(provider: Any) -> Optional[str]:
    """Return a valid room-specific provider, or None when common settings apply."""
    if provider in VALID_ROOM_PROVIDERS:
        return provider
    return None


def _is_non_empty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


SUPPORTED_VOICES = {
    "zephyr": "Zephyr (明るい)", "puck": "Puck (アップビート)", "charon": "Charon (情報が豊富)",
    "kore": "Kore (しっかりした)", "fenrir": "Fenrir (興奮した)", "leda": "Leda (若々しい)",
    "orus": "Orus (しっかりした)", "aoede": "Aoede (軽快)", "callirrhoe": "Callirrhoe (のんびりした)",
    "autonoe": "Autonoe (明るい)", "enceladus": "Enceladus (息遣いの多い)", "iapetus": "Iapetus (クリア)",
    "umbriel": "Umbriel (のんびりした)", "algieba": "Algieba (スムーズ)", "despina": "Despina (スムーズ)",
    "erinome": "Erinome (クリア)", "algenib": "Algenib (しわがれた)", "rasalgethi": "Rasalgethi (情報が豊富)",
    "laomedeia": "Laomedeia (アップビート)", "achernar": "Achernar (柔らかい)", "alnilam": "Alnilam (しっかりした)",
    "schedar": "Schedar (均一)", "gacrux": "Gacrux (成熟したt)", "pulcherrima": "Pulcherrima (前向き)",
    "achird": "Achird (フレンドリー)", "zubenelgenubi": "Zubenelgenubi (カジュアル)",
    "vindemiatrix": "Vindemiatrix (優しい)", "sadachbia": "Sadachbia (生き生きした)",
    "sadaltager": "Sadaltager (知識が豊富)", "sulafat": "Sulafat (温かい)",
}

TTS_PROVIDERS = {
    "gemini": "Gemini",
    "openai": "OpenAI公式",
    "openai_compatible": "OpenAI互換プロファイル",
    "elevenlabs": "ElevenLabs",
    "aivisspeech": "AivisSpeech (ローカル)",
    "voicevox": "VOICEVOX (ローカル)",
    "coeiroink": "COEIROINK (ローカル)",
}

TTS_MODELS = {
    "gemini": [
        "gemini-3.1-flash-tts-preview",
        "gemini-2.5-flash-preview-tts",
        "gemini-2.5-pro-preview-tts",
    ],
    "openai": ["gpt-4o-mini-tts", "tts-1", "tts-1-hd"],
    "openai_compatible": [
        "kokoro",
        "piper",
        "chatterbox",
        "fish-speech",
        "canopylabs/orpheus-v1-english",
        "canopylabs/orpheus-arabic-saudi",
        "xai/grok-tts",
    ],
    "elevenlabs": ["eleven_flash_v2_5", "eleven_multilingual_v2", "eleven_v3"],
    # VOICEVOX互換系は「TTSモデル」欄をエンジンURLとして使う。
    # AivisSpeech Engineは概ねVOICEVOX互換APIで、既定ポートは10101。
    "aivisspeech": ["http://127.0.0.1:10101"],
    "voicevox": ["http://127.0.0.1:50021"],
    "coeiroink": ["http://127.0.0.1:50032"],
}

OPENAI_COMPATIBLE_CUSTOM_TTS_MODELS = [
    "kokoro",
    "piper",
    "chatterbox",
    "fish-speech",
]

XAI_TTS_MODELS = ["xai/grok-tts"]

GROQ_TTS_MODELS = [
    "canopylabs/orpheus-v1-english",
    "canopylabs/orpheus-arabic-saudi",
    "playai-tts",
    "playai-tts-arabic",
]

OPENAI_TTS_VOICES = {
    "alloy": "Alloy",
    "ash": "Ash",
    "ballad": "Ballad",
    "coral": "Coral",
    "echo": "Echo",
    "fable": "Fable",
    "nova": "Nova",
    "onyx": "Onyx",
    "sage": "Sage",
    "shimmer": "Shimmer",
    "verse": "Verse",
    "marin": "Marin",
    "cedar": "Cedar",
}

OPENAI_COMPATIBLE_TTS_VOICES = {
    "tara": "Tara (Groq)",
    "leah": "Leah (Groq)",
    "jess": "Jess (Groq)",
    "leo": "Leo (Groq/xAI)",
    "dan": "Dan (Groq)",
    "mia": "Mia (Groq)",
    "zac": "Zac (Groq)",
    "zoe": "Zoe (Groq)",
    "ara": "Ara (xAI/Grok)",
    "eve": "Eve (xAI/Grok)",
    "rex": "Rex (xAI/Grok)",
    "sal": "Sal (xAI/Grok)",
}

XAI_TTS_VOICES = {
    "eve": "Eve (xAI/Grok)",
    "ara": "Ara (xAI/Grok)",
    "rex": "Rex (xAI/Grok)",
    "sal": "Sal (xAI/Grok)",
    "leo": "Leo (xAI/Grok)",
}

GROQ_ORPHEUS_ENGLISH_TTS_VOICES = {
    "autumn": "Autumn (Groq Orpheus)",
    "diana": "Diana (Groq Orpheus)",
    "hannah": "Hannah (Groq Orpheus)",
    "austin": "Austin (Groq Orpheus)",
    "daniel": "Daniel (Groq Orpheus)",
    "troy": "Troy (Groq Orpheus)",
}

GROQ_ORPHEUS_ARABIC_TTS_VOICES = {
    "abdullah": "Abdullah (Groq Orpheus Arabic)",
    "fahad": "Fahad (Groq Orpheus Arabic)",
    "sultan": "Sultan (Groq Orpheus Arabic)",
    "lulwa": "Lulwa (Groq Orpheus Arabic)",
    "noura": "Noura (Groq Orpheus Arabic)",
    "aisha": "Aisha (Groq Orpheus Arabic)",
}

GROQ_PLAYAI_TTS_VOICES = {
    "Aaliyah-PlayAI": "Aaliyah (Groq PlayAI)",
    "Adelaide-PlayAI": "Adelaide (Groq PlayAI)",
    "Angelo-PlayAI": "Angelo (Groq PlayAI)",
    "Arista-PlayAI": "Arista (Groq PlayAI)",
    "Atlas-PlayAI": "Atlas (Groq PlayAI)",
    "Basil-PlayAI": "Basil (Groq PlayAI)",
    "Briggs-PlayAI": "Briggs (Groq PlayAI)",
    "Calum-PlayAI": "Calum (Groq PlayAI)",
    "Celeste-PlayAI": "Celeste (Groq PlayAI)",
    "Cheyenne-PlayAI": "Cheyenne (Groq PlayAI)",
    "Chip-PlayAI": "Chip (Groq PlayAI)",
    "Cillian-PlayAI": "Cillian (Groq PlayAI)",
    "Deedee-PlayAI": "Deedee (Groq PlayAI)",
    "Eleanor-PlayAI": "Eleanor (Groq PlayAI)",
    "Fritz-PlayAI": "Fritz (Groq PlayAI)",
    "Gail-PlayAI": "Gail (Groq PlayAI)",
    "Indigo-PlayAI": "Indigo (Groq PlayAI)",
    "Jennifer-PlayAI": "Jennifer (Groq PlayAI)",
    "Judy-PlayAI": "Judy (Groq PlayAI)",
    "Mamaw-PlayAI": "Mamaw (Groq PlayAI)",
    "Mason-PlayAI": "Mason (Groq PlayAI)",
    "Mikail-PlayAI": "Mikail (Groq PlayAI)",
    "Mitch-PlayAI": "Mitch (Groq PlayAI)",
    "Nia-PlayAI": "Nia (Groq PlayAI)",
    "Quinn-PlayAI": "Quinn (Groq PlayAI)",
    "Ruby-PlayAI": "Ruby (Groq PlayAI)",
    "Thunder-PlayAI": "Thunder (Groq PlayAI)",
}

ELEVENLABS_TTS_VOICES = {
    "JBFqnCBsd6RMkjVDRZzb": "George (ElevenLabs)",
    "21m00Tcm4TlvDq8ikWAM": "Rachel (ElevenLabs)",
}

VOICEVOX_COMPATIBLE_AUTO_VOICES = {
    "auto": "自動（エンジンの最初の話者）",
}

VOICEVOX_TTS_VOICES = {
    **VOICEVOX_COMPATIBLE_AUTO_VOICES,
    "3": "ずんだもん ノーマル (VOICEVOX)",
    "2": "四国めたん ノーマル (VOICEVOX)",
    "8": "春日部つむぎ ノーマル (VOICEVOX)",
    "10": "雨晴はう ノーマル (VOICEVOX)",
    "9": "波音リツ ノーマル (VOICEVOX)",
    "11": "玄野武宏 ノーマル (VOICEVOX)",
    "12": "白上虎太郎 ノーマル (VOICEVOX)",
    "13": "青山龍星 ノーマル (VOICEVOX)",
    "14": "冥鳴ひまり ノーマル (VOICEVOX)",
    "16": "九州そら ノーマル (VOICEVOX)",
    "20": "もち子さん ノーマル (VOICEVOX)",
    "21": "剣崎雌雄 ノーマル (VOICEVOX)",
    "23": "WhiteCUL ノーマル (VOICEVOX)",
    "27": "後鬼 ノーマル (VOICEVOX)",
    "29": "No.7 ノーマル (VOICEVOX)",
    "36": "小夜/SAYO ノーマル (VOICEVOX)",
    "37": "ナースロボ＿タイプＴ ノーマル (VOICEVOX)",
}

COEIROINK_TTS_VOICES = {
    **VOICEVOX_COMPATIBLE_AUTO_VOICES,
    "0": "つくよみちゃん (COEIROINK)",
}


def get_tts_provider_choices_for_ui() -> List[str]:
    return list(TTS_PROVIDERS.values())


def tts_provider_key_from_display(value: Any) -> str:
    if value in TTS_PROVIDERS:
        return value
    return next((k for k, v in TTS_PROVIDERS.items() if v == value), "gemini")


def tts_provider_display_from_key(value: Any) -> str:
    return TTS_PROVIDERS.get(value, TTS_PROVIDERS["gemini"])


def get_tts_model_choices(provider: Any) -> List[str]:
    """TTSモデルの選択肢を返す。OpenAI互換プロファイルの場合も共通のTTSモデルリストを返す。"""
    return TTS_MODELS.get(tts_provider_key_from_display(provider), TTS_MODELS["gemini"])


def get_tts_voice_map(provider: Any) -> Dict[str, str]:
    provider_key = tts_provider_key_from_display(provider)
    if provider_key == "openai":
        return OPENAI_TTS_VOICES
    if provider_key == "openai_compatible":
        return OPENAI_COMPATIBLE_TTS_VOICES
    if provider_key == "elevenlabs":
        return ELEVENLABS_TTS_VOICES
    
    # ローカルTTSプロバイダで、キャッシュがある場合はキャッシュをマージして返す
    if provider_key in {"voicevox", "aivisspeech", "coeiroink"}:
        cached = CONFIG_GLOBAL.get("tts_speakers_cache", {}).get(provider_key)
        if cached and isinstance(cached, dict):
            res = {**VOICEVOX_COMPATIBLE_AUTO_VOICES}
            res.update({str(k): str(v) for k, v in cached.items()})
            return res
        
        # キャッシュがない場合のフォールバック
        if provider_key in {"voicevox", "aivisspeech"}:
            return VOICEVOX_TTS_VOICES
        if provider_key == "coeiroink":
            return COEIROINK_TTS_VOICES
            
    return SUPPORTED_VOICES


def save_tts_speakers_cache(provider: str, speakers_map: Dict[str, str]) -> bool:
    """
    指定されたプロバイダの話者リストキャッシュをconfig.jsonに保存し、CONFIG_GLOBALも更新する。
    """
    provider_key = tts_provider_key_from_display(provider)
    config = load_config_file()
    if "tts_speakers_cache" not in config or not isinstance(config["tts_speakers_cache"], dict):
        config["tts_speakers_cache"] = {}
    
    # 文字列変換を保証して保存
    config["tts_speakers_cache"][provider_key] = {str(k): str(v) for k, v in speakers_map.items()}
    
    # CONFIG_GLOBAL を更新して即時反映させる
    if "tts_speakers_cache" not in CONFIG_GLOBAL or not isinstance(CONFIG_GLOBAL["tts_speakers_cache"], dict):
        CONFIG_GLOBAL["tts_speakers_cache"] = {}
    CONFIG_GLOBAL["tts_speakers_cache"][provider_key] = config["tts_speakers_cache"][provider_key]
    
    return save_config_if_changed("tts_speakers_cache", CONFIG_GLOBAL["tts_speakers_cache"])


def get_tts_voice_choices(provider: Any) -> List[str]:
    return list(get_tts_voice_map(provider).values())


def _resolve_openai_profile_base_url(profile_name: Any = None, base_url: Any = None) -> str:
    resolved_base_url = str(base_url or "").strip().lower()
    if not resolved_base_url and profile_name:
        setting = get_openai_setting_by_name(str(profile_name))
        resolved_base_url = str((setting or {}).get("base_url") or "").strip().lower()
    return resolved_base_url


def get_openai_profile_tts_kind(profile_name: Any = None, base_url: Any = None) -> str:
    resolved_base_url = _resolve_openai_profile_base_url(profile_name, base_url)
    if "api.x.ai" in resolved_base_url:
        return "xai"
    if "api.groq.com" in resolved_base_url:
        return "groq"
    if "api.openai.com" in resolved_base_url:
        return "openai"
    if "openrouter.ai" in resolved_base_url:
        return "no_tts"
    if "text.pollinations.ai" in resolved_base_url:
        return "no_tts"
    if "router.huggingface.co" in resolved_base_url:
        return "no_tts"
    if "integrate.api.nvidia.com" in resolved_base_url:
        return "no_tts"
    if "localhost:11434" in resolved_base_url or "127.0.0.1:11434" in resolved_base_url:
        return "no_tts"
    return "custom"


def is_xai_openai_profile(profile_name: Any = None, base_url: Any = None) -> bool:
    return get_openai_profile_tts_kind(profile_name, base_url) == "xai"


def get_openai_compatible_tts_model_choices_for_profile(profile_name: Any = None, base_url: Any = None) -> List[str]:
    if profile_name:
        setting = get_openai_setting_by_name(str(profile_name))
        current_base_url = _resolve_openai_profile_base_url(profile_name, base_url)
        cached_models = (setting or {}).get("tts_available_models")
        cached_base_url = str((setting or {}).get("tts_cache_base_url") or "").strip().lower()
        if isinstance(cached_models, list) and cached_models and cached_base_url == current_base_url:
            return [str(model) for model in cached_models if model]
    kind = get_openai_profile_tts_kind(profile_name, base_url)
    if kind == "xai":
        return list(XAI_TTS_MODELS)
    if kind == "groq":
        return list(GROQ_TTS_MODELS)
    if kind == "openai":
        return list(TTS_MODELS["openai"])
    if kind == "no_tts":
        return []
    return list(OPENAI_COMPATIBLE_CUSTOM_TTS_MODELS)


def _normalize_tts_model_for_matching(model_name: Any) -> str:
    return str(model_name or "").strip().lower()


def get_openai_compatible_tts_voice_map_for_profile(
    profile_name: Any = None,
    base_url: Any = None,
    model_name: Any = None,
) -> Dict[str, str]:
    if profile_name:
        setting = get_openai_setting_by_name(str(profile_name))
        current_base_url = _resolve_openai_profile_base_url(profile_name, base_url)
        cached_voice_map = (setting or {}).get("tts_voice_cache", {})
        cached_base_url = str((setting or {}).get("tts_cache_base_url") or "").strip().lower()
        model_key = str(model_name or "").strip()
        if isinstance(cached_voice_map, dict) and cached_base_url == current_base_url:
            cached_for_model = cached_voice_map.get(model_key) or cached_voice_map.get("*")
            if isinstance(cached_for_model, dict) and cached_for_model:
                return {str(k): str(v) for k, v in cached_for_model.items()}

    kind = get_openai_profile_tts_kind(profile_name, base_url)
    if kind == "xai":
        return XAI_TTS_VOICES
    if kind == "groq":
        model_key = _normalize_tts_model_for_matching(model_name)
        if "arabic" in model_key:
            return GROQ_ORPHEUS_ARABIC_TTS_VOICES
        if "orpheus" in model_key:
            return GROQ_ORPHEUS_ENGLISH_TTS_VOICES
        if "playai" in model_key:
            return GROQ_PLAYAI_TTS_VOICES
        return GROQ_ORPHEUS_ENGLISH_TTS_VOICES
    if kind == "openai":
        return OPENAI_TTS_VOICES
    if kind == "no_tts":
        return {}
    return OPENAI_COMPATIBLE_TTS_VOICES


def get_openai_compatible_tts_voice_choices_for_profile(
    profile_name: Any = None,
    base_url: Any = None,
    model_name: Any = None,
) -> List[str]:
    return list(get_openai_compatible_tts_voice_map_for_profile(profile_name, base_url, model_name).values())


def _filter_tts_models_from_model_list(models: List[str]) -> List[str]:
    keywords = ("tts", "speech", "audio", "orpheus", "playai", "kokoro", "piper", "chatterbox", "fish")
    result = []
    for model in models or []:
        model_str = str(model)
        if any(keyword in model_str.lower() for keyword in keywords):
            result.append(model_str)
    return result


def _parse_tts_voice_response(data: Any) -> Dict[str, str]:
    if isinstance(data, dict):
        raw_voices = data.get("voices") or data.get("data") or data.get("items") or []
    elif isinstance(data, list):
        raw_voices = data
    else:
        raw_voices = []

    voices = {}
    for item in raw_voices:
        if isinstance(item, str):
            voices[item] = item
            continue
        if not isinstance(item, dict):
            continue
        voice_id = item.get("voice_id") or item.get("id") or item.get("name")
        if not voice_id:
            continue
        label = item.get("name") or item.get("display_name") or item.get("label") or voice_id
        voices[str(voice_id)] = str(label)
    return voices


def _fetch_xai_tts_voices(base_url: str, api_key: str) -> Dict[str, str]:
    if not api_key:
        return {}
    try:
        url = base_url.rstrip("/") + "/tts/voices"
        response = requests.get(
            url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30,
        )
        if response.status_code >= 400:
            print(f"[config_manager] xAI TTS声リスト取得失敗: Status={response.status_code}, Body={response.text[:300]}")
            return {}
        return _parse_tts_voice_response(response.json())
    except Exception as e:
        print(f"[config_manager] xAI TTS声リスト取得エラー: {e}")
        return {}


def fetch_openai_compatible_tts_capabilities(profile_name: str, base_url: str, api_key: str = "") -> Dict[str, Any]:
    """OpenAI互換プロファイルのTTSモデル/声候補を取得する。取得不可の場合は既知候補へフォールバックする。"""
    kind = get_openai_profile_tts_kind(profile_name, base_url)
    model_choices = get_openai_compatible_tts_model_choices_for_profile(None, base_url)
    voice_cache: Dict[str, Dict[str, str]] = {}

    if kind == "no_tts":
        return {"kind": kind, "models": [], "voice_cache": {}, "fetched": False}

    if kind in {"groq", "custom", "openai"}:
        fetched_models = fetch_models_from_api(base_url, api_key)
        filtered_models = _filter_tts_models_from_model_list(fetched_models)
        if kind == "openai":
            model_choices = filtered_models or list(TTS_MODELS["openai"])
        elif kind == "groq":
            model_choices = filtered_models or list(GROQ_TTS_MODELS)
        else:
            model_choices = filtered_models or list(OPENAI_COMPATIBLE_CUSTOM_TTS_MODELS)

    if kind == "xai":
        model_choices = list(XAI_TTS_MODELS)
        voices = _fetch_xai_tts_voices(base_url, api_key) or dict(XAI_TTS_VOICES)
        voice_cache["*"] = voices
    else:
        for model in model_choices:
            voice_cache[model] = get_openai_compatible_tts_voice_map_for_profile(None, base_url, model)

    return {
        "kind": kind,
        "models": model_choices,
        "voice_cache": voice_cache,
        "fetched": True,
    }


def save_openai_profile_tts_cache(profile_name: str, models: List[str], voice_cache: Dict[str, Dict[str, str]]) -> bool:
    settings_list = get_openai_settings_list()
    changed = False
    for setting in settings_list:
        if setting.get("name") == profile_name:
            setting["tts_available_models"] = list(models or [])
            setting["tts_voice_cache"] = voice_cache or {}
            setting["tts_cache_base_url"] = str(setting.get("base_url") or "").strip().lower()
            changed = True
            break
    if changed:
        save_openai_settings_list(settings_list)
    return changed


def resolve_tts_voice_id(provider: Any, voice_value: Any) -> Optional[str]:
    if not voice_value:
        return None
    voice_map = get_tts_voice_map(provider)
    if voice_value in voice_map:
        return voice_value
    return next((k for k, v in voice_map.items() if v == voice_value), str(voice_value).strip() or None)


def tts_voice_display_from_id(provider: Any, voice_id: Any) -> str:
    voice_map = get_tts_voice_map(provider)
    if voice_id in voice_map:
        return voice_map[voice_id]
    if voice_id:
        return str(voice_id)
    first = next(iter(voice_map.values()), "")
    return first

# --- 起動時の初期値を保持するグローバル変数 ---
initial_api_key_name_global = "default"
initial_room_global = "Default"
initial_model_global = DEFAULT_MODEL_GLOBAL
initial_send_thoughts_to_api_global = True
initial_api_history_limit_option_global = constants.DEFAULT_API_HISTORY_LIMIT_OPTION
initial_alarm_api_history_turns_global = constants.DEFAULT_ALARM_API_HISTORY_TURNS
initial_streaming_speed_global = constants.DEFAULT_STREAMING_SPEED


# --- [2026-02-11 FIX] APIキー名クレンジング ---
def _clean_api_key_name(key_name: Any) -> Any:
    """APIキー名から表示用などの付加情報を除去する（例: 'kenokaicoo (Paid)' -> 'kenokaicoo'）"""
    if isinstance(key_name, str) and " (Paid)" in key_name:
        return key_name.replace(" (Paid)", "").strip()
    return key_name

# --- [v8] 自己修復機能付きコンフィグ管理 ---

def _create_config_backup(new_config_data: dict | None = None):
    """config.jsonのバックアップを作成し、ローテーションする。"""
    backup_dir = os.path.join("backups", "config")
    os.makedirs(backup_dir, exist_ok=True)

    if not os.path.exists(constants.CONFIG_FILE):
        return # バックアップ対象がない場合は何もしない

    try:
        rotation_count = CONFIG_GLOBAL.get("backup_rotation_count", 10)
        create_layered_settings_backup(
            constants.CONFIG_FILE,
            backup_dir,
            "config.json",
            rotation_count=rotation_count,
            new_data=new_config_data,
        )

    except Exception as e:
        print(f"警告: config.jsonのバックアップ作成に失敗しました: {e}")

def _restore_from_backup() -> bool:
    """最も新しいバックアップからconfig.jsonを復元する。"""
    backup_dir = os.path.join("backups", "config")
    if not os.path.isdir(backup_dir):
        return False

    try:
        backups = sorted(
            [f for f in os.listdir(backup_dir) if f.endswith(".bak")],
            key=lambda f: os.path.getmtime(os.path.join(backup_dir, f)),
            reverse=True # 新しいものが先頭に来るように
        )
        if not backups:
            return False

        latest_backup = os.path.join(backup_dir, backups[0])
        print(f"--- [自己修復] 破損したconfig.jsonをバックアップ '{backups[0]}' から復元します ---")
        shutil.copy2(latest_backup, constants.CONFIG_FILE)
        return True

    except Exception as e:
        print(f"!!! エラー: バックアップからの復元に失敗しました: {e}")
        return False

def load_gemini_key_states():
    """APIキーの枯渇状態をファイルから読み込み、GEMINI_KEY_STATESにマージする。
    [2026-02-19 FIX] 起動時は全枯渇マークをクリアする（新セッション＝クリーンスタート）。
    2回目以降の呼び出し（llm_factoryからのload_config経由など）ではスキップする。
    """
    global GEMINI_KEY_STATES
    
    # [2026-02-19 FIX] 初回のみ枯渇マークをクリアし、以降はスキップ
    if hasattr(load_gemini_key_states, '_initialized'):
        return  # 既に初期化済み、枯渇状態をリセットしない
    load_gemini_key_states._initialized = True
    
    if os.path.exists(KEY_STATES_FILE):
        try:
            # 起動時は前セッションの枯渇マークを全クリア
            _update_gemini_key_states(lambda states: states.clear() or states)
            print("--- [API Key Rotation] 起動時: 前セッションの枯渇状態を全クリアしました ---")

        except Exception as e:
            print(f"警告: {KEY_STATES_FILE} の読み込みに失敗しました: {e}")


def save_gemini_key_states():
    """APIキーの枯渇状態をファイルにロック付きで保存する。"""
    try:
        file_lock_utils.safe_json_write(
            KEY_STATES_FILE,
            GEMINI_KEY_STATES,
            timeout=CONFIG_LOCK_TIMEOUT,
            indent=2,
        )
    except Exception as e:
        print(f"警告: {KEY_STATES_FILE} の保存に失敗しました: {e}")


def _update_gemini_key_states(update_func) -> bool:
    """GEMINI_KEY_STATESの更新と保存を同じファイルロック内で行う。"""
    global GEMINI_KEY_STATES
    try:
        with file_lock_utils.locked_file(KEY_STATES_FILE, timeout=CONFIG_LOCK_TIMEOUT) as path_obj:
            if path_obj.exists() and path_obj.stat().st_size > 0:
                with open(path_obj, "r", encoding="utf-8") as f:
                    loaded_states = json.load(f)
                if isinstance(loaded_states, dict):
                    GEMINI_KEY_STATES.update(loaded_states)

            updated_states = update_func(GEMINI_KEY_STATES)
            if updated_states is not GEMINI_KEY_STATES:
                GEMINI_KEY_STATES.clear()
                if isinstance(updated_states, dict):
                    GEMINI_KEY_STATES.update(updated_states)

            file_lock_utils._atomic_json_write(path_obj.as_posix(), GEMINI_KEY_STATES, indent=2)
        return True
    except Exception as e:
        print(f"警告: {KEY_STATES_FILE} の更新に失敗しました: {e}")
        return False

def load_config_file() -> dict:
    """
    config.jsonを安全に読み込む。ファイルが破損している場合はバックアップから自動復元を試みる。
    """
    # 探索対象のパスリスト（カレント -> 親ディレクトリ）
    # dist/app 構造を考慮
    candidate_paths = [
        constants.CONFIG_FILE,
        os.path.join("..", constants.CONFIG_FILE)
    ]
    
    target_path = None
    for p in candidate_paths:
        if os.path.exists(p):
            target_path = p
            break
            
    if target_path:
        try:
            with open(target_path, "r", encoding="utf-8") as f:
                content = f.read()
            if not content.strip(): # 空ファイルの場合
                raise json.JSONDecodeError("File is empty", "", 0)
            return json.loads(content)
        except (json.JSONDecodeError, IOError):
            print(f"警告: {target_path} が空または破損しています。バックアップからの復元を試みます...")
            # 注意: バックアップからの復元ロジックは常にカレントディレクトリへの復元を試みる
            if _restore_from_backup():
                try:
                    with open(constants.CONFIG_FILE, "r", encoding="utf-8") as f:
                        return json.load(f)
                except Exception as e:
                    print(f"!!! エラー: 復元後のconfig.jsonの読み込みにも失敗しました: {e}")
    # ファイルが存在しない、または復元にも失敗した場合
    return {}


def _load_config_file_unlocked(file_path: str | None = None) -> dict:
    """呼び出し元がconfigロックを保持している前提でconfig.jsonを読み込む。"""
    target_path = file_path or constants.CONFIG_FILE
    if not os.path.exists(target_path):
        return {}
    try:
        with open(target_path, "r", encoding="utf-8") as f:
            content = f.read()
        if not content.strip():
            raise json.JSONDecodeError("File is empty", "", 0)
        return json.loads(content)
    except (json.JSONDecodeError, IOError):
        print(f"警告: {target_path} が空または破損しています。バックアップからの復元を試みます...")
        if _restore_from_backup():
            try:
                with open(constants.CONFIG_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"!!! エラー: 復元後のconfig.jsonの読み込みにも失敗しました: {e}")
    return {}


def _write_config_file_unlocked(config_data: dict):
    """
    設定データを一時ファイルに書き込んでからリネームする、堅牢な保存処理。
    呼び出し元がconfigロックを保持している前提。
    """
    # ステップ1: まず現在の設定をバックアップ
    _create_config_backup(config_data)

    # ステップ2: アトミックな書き込み処理
    temp_file_path = constants.CONFIG_FILE + ".tmp"
    max_retries = 5
    retry_delay = 0.1

    for attempt in range(max_retries):
        try:
            with open(temp_file_path, "w", encoding="utf-8") as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)
            os.replace(temp_file_path, constants.CONFIG_FILE)
            return
        except PermissionError as e:
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
            else:
                print(f"'{constants.CONFIG_FILE}' 保存エラー: {e}")
                if os.path.exists(temp_file_path):
                    try:
                        os.remove(temp_file_path)
                    except OSError:
                        pass
        except Exception as e:
            print(f"'{constants.CONFIG_FILE}' 保存エラー: {e}")
            if os.path.exists(temp_file_path):
                try:
                    os.remove(temp_file_path)
                except OSError:
                    pass
            return


def _save_config_file(config_data: dict):
    """config.jsonをFileLock下でアトミックに保存する。"""
    with file_lock_utils.locked_file(constants.CONFIG_FILE, timeout=CONFIG_LOCK_TIMEOUT):
        _write_config_file_unlocked(config_data)


def save_zhipu_models(models: list[str]) -> bool:
    """
    Zhipu AIの利用可能モデルリストを保存する。
    """
    global AVAILABLE_ZHIPU_MODELS
    
    
    # デフォルトモデルリスト（優先順位保持のため先頭に）
    defaults = constants.ZHIPU_MODELS
    
    # マージ: デフォルト + (取得モデル - デフォルト)
    merged_models = list(defaults)
    for m in models:
        if m not in defaults:
            merged_models.append(m)
            
    # 既存のリストと比較して変更がなければスルー (`set`比較だと順序変更を検知できないためリスト比較も追加)
    if merged_models == AVAILABLE_ZHIPU_MODELS:
        return False
        
    if save_config_if_changed("zhipu_models", merged_models):
        # グローバル変数も更新
        AVAILABLE_ZHIPU_MODELS = list(merged_models) # コピーを保存
        # constantsは書き換えない（定数なので）
        return True
    return False

def save_config_if_changed(key: str, value: Any) -> bool:
    """
    現在の設定値と比較し、変更があった場合のみconfig.jsonに安全に保存する。
    変更があった場合は True を、変更がなかった場合は False を返す。
    【修正】メモリ上のグローバル変数(CONFIG_GLOBAL)も即座に更新する。
    """
    global CONFIG_GLOBAL # グローバル変数を参照

    if key == "last_api_key_name":
        value = _clean_api_key_name(value)
    elif key == "paid_api_key_names" and isinstance(value, list):
        value = [_clean_api_key_name(v) for v in value]

    with file_lock_utils.locked_file(constants.CONFIG_FILE, timeout=CONFIG_LOCK_TIMEOUT):
        # ファイルから最新を読み込む
        config = _load_config_file_unlocked()

        current_value = config.get(key)
        # print(f"[config_manager] save_config_if_changed: key={key}")  # DEBUG
        # print(f"[config_manager]   current_value: {current_value}")  # DEBUG
        # print(f"[config_manager]   new_value: {value}")  # DEBUG
        # print(f"[config_manager]   are_equal: {current_value == value}")  # DEBUG

        # 変更チェック
        if current_value == value:
            # print(f"[config_manager]   -> No change, skipping save")  # DEBUG
            return False  # 変更なし

        # 変更があれば保存
        config[key] = value
        _write_config_file_unlocked(config)
        print(f"[config_manager]   -> Saved to file")  # DEBUG
    
    # 【重要】メモリ上の設定も更新して、再起動なしで反映させる
    if CONFIG_GLOBAL is None:
        CONFIG_GLOBAL = {}
    CONFIG_GLOBAL[key] = value
    
    return True

def update_config_keys(updates: Dict[str, Any]) -> bool:
    """
    config.jsonを最新状態から読み直し、指定されたキーだけを差分更新する。
    複数端末で設定画面を開いている場合でも、未変更キーを古いUI値で巻き戻さないための保存API。
    """
    global CONFIG_GLOBAL

    if not updates:
        return "no_change"

    applied_updates = {}
    with file_lock_utils.locked_file(constants.CONFIG_FILE, timeout=CONFIG_LOCK_TIMEOUT):
        config = _load_config_file_unlocked()
        changed = False
        for key, value in updates.items():
            if key == "last_api_key_name":
                value = _clean_api_key_name(value)
            elif key == "paid_api_key_names" and isinstance(value, list):
                value = [_clean_api_key_name(v) for v in value]

            if config.get(key) != value:
                config[key] = value
                changed = True
            applied_updates[key] = value

        if not changed:
            return "no_change"

        _write_config_file_unlocked(config)

    if CONFIG_GLOBAL is None:
        CONFIG_GLOBAL = {}
    CONFIG_GLOBAL.update(applied_updates)
    return True


def update_nested_config_keys(parent_key: str, updates: Dict[str, Any]) -> bool:
    """最新configのネスト辞書へ指定した子キーだけを差分保存する。"""
    global CONFIG_GLOBAL

    parent = str(parent_key or "").strip()
    if not parent or not isinstance(updates, dict) or not updates:
        return "no_change"

    with file_lock_utils.locked_file(constants.CONFIG_FILE, timeout=CONFIG_LOCK_TIMEOUT):
        config = _load_config_file_unlocked()
        current = config.get(parent)
        merged = dict(current) if isinstance(current, dict) else {}
        merged.update(updates)
        if current == merged:
            if CONFIG_GLOBAL is None:
                CONFIG_GLOBAL = {}
            CONFIG_GLOBAL[parent] = merged
            return "no_change"
        config[parent] = merged
        _write_config_file_unlocked(config)

    if CONFIG_GLOBAL is None:
        CONFIG_GLOBAL = {}
    CONFIG_GLOBAL[parent] = merged
    return True

def upsert_nested_config_list_item(
    parent_key: str,
    list_key: str,
    item: Dict[str, Any],
    identity_key: str,
    *,
    merge_existing: bool = False,
) -> bool | str:
    """最新設定のネストlistへ同一IDの1件だけを原子的に追加・更新する。

    ``merge_existing=True`` の場合、同一IDの既存辞書へ渡されたキーだけを
    最新ファイル上で差分適用する。通常の置換動作は既存呼び出しとの互換性
    のため維持する。
    """
    global CONFIG_GLOBAL

    parent, child, identity = (str(value or "").strip() for value in (parent_key, list_key, identity_key))
    if not parent or not child or not identity or not isinstance(item, dict) or not item.get(identity):
        raise ValueError("設定listの更新対象が不正です。")
    replacement = dict(item)
    with file_lock_utils.locked_file(constants.CONFIG_FILE, timeout=CONFIG_LOCK_TIMEOUT):
        config = _load_config_file_unlocked()
        current = config.get(parent)
        if current is not None and not isinstance(current, dict):
            raise ValueError("更新対象の設定が辞書ではありません。")
        merged = dict(current or {})
        existing = merged.get(child)
        if existing is not None and not isinstance(existing, list):
            raise ValueError("更新対象の設定がlistではありません。")
        values = list(existing or [])
        match = [index for index, value in enumerate(values)
                 if isinstance(value, dict) and value.get(identity) == replacement[identity]]
        if len(match) > 1:
            raise ValueError("更新対象の設定IDが重複しています。")
        if match:
            if merge_existing and isinstance(values[match[0]], dict):
                values[match[0]] = {**values[match[0]], **replacement}
            else:
                values[match[0]] = replacement
        else:
            values.append(replacement)
        merged[child] = values
        changed = current != merged
        if changed:
            config[parent] = merged
            _write_config_file_unlocked(config)

        if CONFIG_GLOBAL is None:
            CONFIG_GLOBAL = {}
        CONFIG_GLOBAL[parent] = merged
    return True if changed else "no_change"


# --- 公開APIキー管理関数 ---
def add_or_update_gemini_key(key_name: str, key_value: str):
    global GEMINI_API_KEYS
    config = load_config_file()
    if "gemini_api_keys" not in config or not isinstance(config.get("gemini_api_keys"), dict):
        config["gemini_api_keys"] = {}

    existing_keys = config["gemini_api_keys"]
    if len(existing_keys) == 1 and "your_key_name" in existing_keys:
        del existing_keys["your_key_name"]

    config["gemini_api_keys"][key_name] = key_value
    _save_config_file(config)
    GEMINI_API_KEYS = config["gemini_api_keys"]

def delete_gemini_key(key_name: str):
    global GEMINI_API_KEYS
    config = load_config_file()
    if "gemini_api_keys" in config and isinstance(config.get("gemini_api_keys"), dict) and key_name in config["gemini_api_keys"]:
        del config["gemini_api_keys"][key_name]

        if not config["gemini_api_keys"]:
            config["gemini_api_keys"] = {"your_key_name": "YOUR_API_KEY_HERE"}

        # paid_api_key_names が存在すれば、削除する
        if "paid_api_key_names" in config and key_name in config["paid_api_key_names"]:
            try:
                config["paid_api_key_names"].remove(key_name)
            except ValueError:
                pass

        if config.get("last_api_key_name") == key_name:
            config["last_api_key_name"] = None
        _save_config_file(config)
        GEMINI_API_KEYS = config.get("gemini_api_keys", {})

def update_pushover_config(user_key: str, app_token: str, preserve_blank: bool = False):
    config = load_config_file()
    if preserve_blank and not user_key:
        user_key = config.get("pushover_user_key", "")
    if preserve_blank and not app_token:
        app_token = config.get("pushover_app_token", "")
    config["pushover_user_key"] = user_key
    config["pushover_app_token"] = app_token
    _save_config_file(config)
    if CONFIG_GLOBAL is not None:
        CONFIG_GLOBAL["pushover_user_key"] = user_key
        CONFIG_GLOBAL["pushover_app_token"] = app_token


# --- Theme Management Helpers ---

_file_based_themes_cache = {}

def load_file_based_themes() -> Dict[str, "gr.themes.Base"]:
    """
    `themes/` ディレクトリをスキャンし、有効なテーマファイルを読み込んでキャッシュする。
    """
    global _file_based_themes_cache
    if _file_based_themes_cache:
        return _file_based_themes_cache

    from pathlib import Path
    import importlib.util

    themes_dir = Path("themes")
    if not themes_dir.is_dir():
        return {}

    loaded_themes = {}
    for file_path in themes_dir.glob("*.py"):
        theme_name = file_path.stem
        try:
            spec = importlib.util.spec_from_file_location(theme_name, str(file_path))
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                if hasattr(module, "load") and callable(module.load):
                    theme_object = module.load()
                    import gradio as gr
                    if isinstance(theme_object, gr.themes.Base):
                        loaded_themes[theme_name] = theme_object
        except Exception as e:
            print(f"警告: テーマファイル '{file_path.name}' の読み込みに失敗しました: {e}")

    _file_based_themes_cache = loaded_themes
    return loaded_themes

def get_all_themes() -> Dict[str, str]:
    """UIのドロップダウン用に、すべての利用可能なテーマ名とソースの辞書を返す。"""
    themes = {}
    
    # 1. ファイルベースのテーマ
    file_themes = load_file_based_themes()
    for name in sorted(file_themes.keys()):
        themes[name] = "file"
        
    # 2. JSONベースのカスタムテーマ
    custom_themes_from_json = CONFIG_GLOBAL.get("theme_settings", {}).get("custom_themes", {})
    for name in sorted(custom_themes_from_json.keys()):
        if name not in themes: # ファイルテーマを優先
            themes[name] = "json"
            
    # 3. プリセットテーマ
    for name in ["Soft", "Default", "Monochrome", "Glass"]:
        if name not in themes:
            themes[name] = "preset"
            
    return themes

def get_theme_object(theme_name: str):
    """指定された名前のテーマオブジェクトを取得する。"""
    import gradio as gr
    # 1. ファイルベースのテーマから検索
    file_themes = load_file_based_themes()
    if theme_name in file_themes:
        return file_themes[theme_name]

    # 2. JSONベースのカスタムテーマから検索・構築
    custom_themes_from_json = CONFIG_GLOBAL.get("theme_settings", {}).get("custom_themes", {})
    if theme_name in custom_themes_from_json:
        params = custom_themes_from_json[theme_name]
        try:
            default_arg_keys = ["primary_hue", "secondary_hue", "neutral_hue", "text_size", "spacing_size", "radius_size", "font", "font_mono"]
            default_args = {k: v for k, v in params.items() if k in default_arg_keys}
            set_args = {k: v for k, v in params.items() if k not in default_args}

            if 'font' in default_args and isinstance(default_args['font'], list):
                 default_args['font'] = [gr.themes.GoogleFont(name) if isinstance(name, str) and ' ' in name else name for name in default_args['font']]

            theme_obj = gr.themes.Default(**default_args)
            if set_args:
                theme_obj = theme_obj.set(**set_args)
            return theme_obj
        except Exception as e:
            print(f"警告: カスタムテーマ '{theme_name}' の構築に失敗しました: {e}")

    # 3. プリセットテーマから検索
    preset_map = {"Soft": gr.themes.Soft, "Default": gr.themes.Default, "Monochrome": gr.themes.Monochrome, "Glass": gr.themes.Glass}
    if theme_name in preset_map:
        return preset_map[theme_name]()

    # 4. フォールバック
    print(f"警告: テーマ '{theme_name}' が見つかりません。デフォルトのSoftテーマを使用します。")
    return gr.themes.Soft()


# --- 応答推論metadataの取得済みcache ---
def _reasoning_metadata_from_model_info(model_info: Any) -> dict[str, Any]:
    """/models応答から推論能力に関係する安全な項目だけを抜き出す。"""

    if not isinstance(model_info, dict):
        return {}
    metadata: dict[str, Any] = {}
    for key in ("supported_efforts", "supports_max_tokens", "mandatory"):
        if key in model_info:
            metadata[key] = model_info[key]

    for key in ("reasoning", "reasoning_config"):
        value = model_info.get(key)
        if isinstance(value, dict):
            nested = {
                nested_key: value[nested_key]
                for nested_key in ("supported_efforts", "supports_max_tokens", "mandatory")
                if nested_key in value
            }
            if nested:
                metadata["reasoning"] = nested
                break
    return metadata


def _normalise_model_metadata_url(base_url: Any) -> str:
    value = str(base_url or "").strip()
    if not value:
        return ""
    try:
        parsed = urlsplit(value if "://" in value else f"//{value}")
        host = (parsed.hostname or "").lower()
        if not host:
            return value.lower().rstrip("/")
        port = parsed.port
        netloc = host
        if port is not None and not ((parsed.scheme == "https" and port == 443) or (parsed.scheme == "http" and port == 80)):
            netloc = f"{host}:{port}"
        return urlunsplit((parsed.scheme.lower(), netloc, parsed.path.rstrip("/"), "", ""))
    except ValueError:
        return value.lower().rstrip("/")


def _cache_model_reasoning_metadata(base_url: str, metadata_by_model: dict[str, dict[str, Any]]) -> None:
    """取得済みmetadataを純粋判定registryと設定profileへ同期する。"""

    if not metadata_by_model:
        return
    try:
        from response_reasoning import register_model_metadata
    except ImportError:
        register_model_metadata = None

    for model, metadata in metadata_by_model.items():
        if register_model_metadata:
            register_model_metadata(base_url, model, metadata)

    normalized_url = _normalise_model_metadata_url(base_url)
    if not normalized_url or not isinstance(CONFIG_GLOBAL, dict):
        return
    for profile in CONFIG_GLOBAL.get("openai_provider_settings", []):
        if not isinstance(profile, dict):
            continue
        if _normalise_model_metadata_url(profile.get("base_url")) != normalized_url:
            continue
        cached = profile.setdefault("reasoning_metadata", {})
        if not isinstance(cached, dict):
            cached = {}
            profile["reasoning_metadata"] = cached
        for model, metadata in metadata_by_model.items():
            cached[model] = dict(metadata)


def _hydrate_model_reasoning_metadata_registry(profiles: Any) -> None:
    """保存済みprofile cacheを、起動後の純粋能力判定registryへ戻す。"""

    try:
        from response_reasoning import register_model_metadata
    except ImportError:
        return
    if not isinstance(profiles, list):
        return
    for profile in profiles:
        if not isinstance(profile, dict):
            continue
        metadata = profile.get("reasoning_metadata")
        if not isinstance(metadata, dict):
            continue
        base_url = profile.get("base_url")
        for model, model_metadata in metadata.items():
            if isinstance(model_metadata, dict):
                register_model_metadata(base_url, model, model_metadata)


# --- モデルリスト取得（API経由） ---
def fetch_models_from_api(base_url: str, api_key: str = "", free_only: bool = False) -> list[str]:
    """
    OpenAI互換API (/v1/models) からモデルリストを取得する。
    Groq, Ollama, OpenRouter など全てに対応。
    
    Args:
        base_url: プロバイダのベースURL（例: https://api.groq.com/openai/v1）
        api_key: APIキー（Ollamaは不要）
        free_only: 無料モデルのみを取得するか（OpenRouter等で有効）
    
    Returns:
        モデルIDのリスト
    """
    import requests
    
    # URLの末尾スラッシュを除去し、/modelsを追加
    models_url = base_url.rstrip('/') + '/models'
    
    headers = {"Content-Type": "application/json"}
    if api_key and api_key != "ollama":
        headers["Authorization"] = f"Bearer {api_key}"
    
    try:
        response = requests.get(models_url, headers=headers, timeout=30)
        # エラー詳細確認のため、raise_for_statusの前に内容をチェック
        if response.status_code != 200:
            print(f"[config_manager] モデルリスト取得失敗: Status={response.status_code}, Body={response.text}")
        
        response.raise_for_status()
        data = response.json()
        
        # OpenAI互換APIのレスポンス形式: {"data": [{"id": "model-name", ...}, ...]}
        models = []
        reasoning_metadata: dict[str, dict[str, Any]] = {}
        for model_info in data.get("data", []):
            if not isinstance(model_info, dict):
                continue
            model_id = model_info.get("id", "")
            if model_id:
                models.append(model_id)
                model_metadata = _reasoning_metadata_from_model_info(model_info)
                # metadataの無い応答も負のcacheとして記録し、以前の取得で
                # 推論対応だった値を再利用し続けない。
                reasoning_metadata[model_id] = model_metadata or {"reasoning": {}}

        _cache_model_reasoning_metadata(base_url, reasoning_metadata)
        
        if free_only:
            if "openrouter.ai" in base_url.lower():
                models = [m for m in models if m.endswith(":free")]
            # 他のプロバイダで明確な判別基準があればここに追加可能
        
        return sorted(models)
    except Exception as e:
        print(f"[config_manager] モデルリスト取得エラー: {e}")
        return []


def fetch_gemini_models(api_key: str, free_only: bool = False, exclude_special: bool = False) -> list[str]:
    """Gemini API から利用可能なモデルリストを取得する"""
    import requests
    if not api_key:
        return []
    url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        data = response.json()
        models = []
        for m in data.get("models", []):
            name = m.get("name", "")
            if name.startswith("models/"):
                model_id = name.replace("models/", "")
                # 有効なモデルのみ抽出 (gemini, learnlm, gemma など)
                if any(kw in model_id.lower() for kw in ["gemini", "learnlm", "gemma"]):
                    # [2026-06-23] 廃止済みだが models.list にまだ列挙されるモデルを除外
                    # （一覧には出るが generateContent すると 404 になるもの）。
                    if model_id in getattr(constants, "DEPRECATED_GEMINI_MODELS", set()):
                        continue
                    # [2026-04-28] 特殊用途モデル（embedding, tts, computer, image, customtools, robotics）の除外オプション
                    if exclude_special:
                        if is_image_generation_model(model_id) or any(
                            kw in model_id.lower()
                            for kw in ["embedding", "tts", "computer", "customtools", "robotics"]
                        ):
                            continue
                    models.append(model_id)
        return sorted(models)
    except Exception as e:
        print(f"[config_manager] Gemini モデルリスト取得エラー: {e}")
        return []


def fetch_anthropic_models(api_key: str) -> list[str]:
    """Anthropic API から利用可能なモデルリストを取得する"""
    import requests
    if not api_key:
        return []
    url = "https://api.anthropic.com/v1/models"
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01"
    }
    try:
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        data = response.json()
        # Anthropic のレスポンス形式: {"data": [{"type": "model", "id": "...", "display_name": "..."}, ...]}
        models = [m.get("id") for m in data.get("data", []) if m.get("id")]
        return sorted(models)
    except Exception as e:
        print(f"[config_manager] Anthropic モデルリスト取得エラー: {e}")
        return []


def fetch_image_models(provider: str, base_url: str = "", api_key: str = "", free_only: bool = False) -> list[str]:
    """
    画像生成用モデルリストをAPIから取得する。
    """
    import requests
    
    if provider == "pollinations":
        try:
            # Pollinations.ai の画像モデルリストエンドポイント
            response = requests.get("https://image.pollinations.ai/models", timeout=30)
            response.raise_for_status()
            models = response.json()
            if isinstance(models, list):
                # 既知のモデルも含めてユニークにする
                known_models = ["flux", "zimage", "klein", "gptimage", "kontext", "wan-image", "qwen-image"]
                all_models = list(set(models + known_models))
                return sorted(all_models)
        except Exception as e:
            print(f"[config_manager] Pollinations モデルリスト取得エラー: {e}")
            return []
            
    elif provider == "openai":
        all_models = fetch_models_from_api(base_url, api_key, free_only=free_only)
        # 画像生成に関係ありそうなキーワードでフィルタリング
        image_keywords = ["dall-e", "stable-diffusion", "flux", "image", "sdxl", "diffusion", "pixel", "art", "canvas", "midjourney"]
        image_models = [m for m in all_models if any(kw in m.lower() for kw in image_keywords)]
        
        # フィルタリングして空になった場合は全リストを返す
        return sorted(image_models) if image_models else sorted(all_models)
    
    elif provider == "gemini":
        all_models = fetch_gemini_models(api_key, free_only=free_only, exclude_special=False)
        # 画像生成判定を共通化し、従来の vision 候補も保持する。
        image_models = [
            m for m in all_models
            if is_image_generation_model(m) or "vision" in m.lower()
        ]
        return sorted(image_models) if image_models else sorted(all_models)
        
    return []


def get_image_models_for_openai_profile(profile_name: str) -> list[str]:
    """OpenAI互換プロファイル専用の画像モデルリストを取得する"""
    available_image_models = CONFIG_GLOBAL.get("available_image_models", {})
    openai_profiles_models = available_image_models.get("openai_profiles", {})
    return openai_profiles_models.get(profile_name, [])


def save_image_models_for_openai_profile(profile_name: str, models: list[str]):
    """OpenAI互換プロファイル専用の画像モデルリストを保存する"""
    available_image_models = CONFIG_GLOBAL.get("available_image_models", {})
    if "openai_profiles" not in available_image_models:
        available_image_models["openai_profiles"] = {}
    available_image_models["openai_profiles"][profile_name] = models
    save_config_if_changed("available_image_models", available_image_models)


def toggle_favorite_model(provider_name: str, model_name: str) -> tuple[bool, str]:
    """
    モデルのお気に入り状態をトグルする（⭐ マークの付け外し）。
    
    Args:
        provider_name: プロバイダ名（例: "OpenRouter", "Groq", "Local Ollama"）
        model_name: モデル名
    
    Returns:
        (成功したか, 新しいモデル名)
    """
    global CONFIG_GLOBAL
    
    # お気に入りマーク
    FAVORITE_MARK = "⭐ "
    
    # 現在のお気に入り状態を確認
    is_favorite = model_name.startswith(FAVORITE_MARK)
    
    # トグル後の新しいモデル名
    if is_favorite:
        new_model_name = model_name[len(FAVORITE_MARK):]  # マークを削除
    else:
        new_model_name = FAVORITE_MARK + model_name  # マークを追加
    
    # 設定内のモデルリストを更新
    provider_settings = CONFIG_GLOBAL.get("openai_provider_settings", [])
    for provider in provider_settings:
        if provider.get("name") == provider_name:
            available_models = provider.get("available_models", [])
            
            # 旧モデル名を新モデル名に置換
            if model_name in available_models:
                idx = available_models.index(model_name)
                available_models[idx] = new_model_name
                
                # 設定を保存
                save_config()
                return (True, new_model_name)
    
    return (False, model_name)


def add_model_to_list(provider_name: str, model_name: str) -> bool:
    """
    プロバイダのモデルリストにモデルを追加する。
    
    Args:
        provider_name: プロバイダ名
        model_name: 追加するモデル名
    
    Returns:
        成功したか
    """
    global CONFIG_GLOBAL
    
    provider_settings = CONFIG_GLOBAL.get("openai_provider_settings", [])
    for provider in provider_settings:
        if provider.get("name") == provider_name:
            available_models = provider.get("available_models", [])
            
            # 重複チェック（⭐ マークの有無を無視して比較）
            clean_model_name = model_name.lstrip("⭐ ")
            existing_clean = [m.lstrip("⭐ ") for m in available_models]
            
            if clean_model_name not in existing_clean:
                available_models.append(model_name)
                save_config()
                return True
            else:
                print(f"[config_manager] モデル '{model_name}' は既にリストに存在します")
                return False
    
    return False


# --- デフォルト設定を取得する関数 ---
def _get_default_config() -> dict:
    """
    デフォルト設定を返す。
    OpenAI互換プロファイルのリセット機能で使用される。
    """
    return {
        "openai_provider_settings": [
            {
                "name": "OpenRouter",
                "base_url": "https://openrouter.ai/api/v1",
                "api_key": "",
                "default_model": "meta-llama/llama-3.3-70b-instruct:free",
                "available_models": [
                    "meta-llama/llama-3.3-70b-instruct:free",
                    "nvidia/nemotron-3-nano-30b-a3b:free",
                    "xiaomi/mimo-v2-flash:free",
                    "deepseek/deepseek-r1-0528:free",
                    "google/gemma-3-27b-it:free",
                    "qwen/qwen3-coder:free"
                ]
            },
            {
                "name": "Groq",
                "base_url": "https://api.groq.com/openai/v1",
                "api_key": "",
                "default_model": "llama-3.3-70b-versatile",
                "available_models": [
                    "llama-3.3-70b-versatile",
                    "llama-3.1-8b-instant",
                    "openai/gpt-oss-120b",
                    "qwen/qwen3-32b"
                ]
            },
            {
                "name": "Ollama (Local)",
                "base_url": "http://localhost:11434/v1",
                "api_key": "ollama",
                "default_model": "phi3.5",
                "tool_use_enabled": False,
                "available_models": [
                    "phi3.5",
                    "qwen2.5:3b",
                    "gemma2:2b",
                    "qwen2.5:0.5b"
                ]
            },
            {
                "name": "OpenAI Official",
                "base_url": "https://api.openai.com/v1",
                "api_key": "",
                "default_model": "gpt-5.2-2025-12-11",
                "available_models": [
                    "gpt-5.2-2025-12-11",
                    "chatgpt-4o-latest"
                ]
            },
            {
                "name": "Zhipu AI",
                "base_url": "https://open.bigmodel.cn/api/paas/v4",
                "api_key": "",
                "default_model": "glm-4.7-flash",
                "available_models": [
                    "glm-4.7-flash",
                    "glm-4.7",
                    "glm-4-plus",
                    "glm-4.5",
                    "glm-4.5-air",
                    "glm-zero-preview"
                ]
            }
        ]
    }


# --- メインの読み込み関数 (真・最終版) ---
def load_config():
    global CONFIG_GLOBAL, GEMINI_API_KEYS, TAVILY_API_KEY, initial_api_key_name_global, initial_room_global, initial_model_global
    global initial_send_thoughts_to_api_global, initial_api_history_limit_option_global, initial_alarm_api_history_turns_global
    global AVAILABLE_MODELS_GLOBAL, DEFAULT_MODEL_GLOBAL, initial_streaming_speed_global
    global NOTIFICATION_SERVICE_GLOBAL, NOTIFICATION_WEBHOOK_URL_GLOBAL, PUSHOVER_CONFIG
    global ZHIPU_API_KEY, GROQ_API_KEY, MOONSHOT_API_KEY, LOCAL_MODEL_PATH
    global ANTHROPIC_API_KEY, CLAUDE_SUBSCRIPTION_OAUTH_TOKEN, NIM_API_KEY, XAI_API_KEY
    global DISCORD_BOT_ENABLED, DISCORD_BOT_TOKEN, DISCORD_AUTHORIZED_USER_IDS, DISCORD_BOT_LINKED_ROOM
    global LINE_BOT_ENABLED, LINE_CHANNEL_ACCESS_TOKEN, LINE_CHANNEL_SECRET, LINE_AUTHORIZED_USER_IDS, LINE_BOT_LINKED_ROOM


    # [2026-02-11 FIX] APIキーの枯渇状態の読み込みは、GEMINI_KEY_STATESの初期化後に行う
    # ここでの読み込みは削除（ステップ8の直後に移動）

    # ステップ1：全てのキーを含む、理想的なデフォルト設定を定義
# ステップ1：全てのキーを含む、理想的なデフォルト設定を定義
    default_config = {
        # --- [新規] マルチプロバイダ設定 ---
        "active_provider": "google", # google, openai
        "active_openai_profile": "OpenRouter", # デフォルトで選択されるプロファイル名
        "claude_subscription_oauth_token": "",
        "claude_subscription_default_model": "sonnet",
        "agent_delegation_settings": {
            "enabled": False,
            "permission_tier": "read",
            "max_concurrent_tasks": 1,
            "max_turns": 20,
            "timeout_seconds": 600,
            "deleg_auto_tune_limits": True,
            "allow_web_tools": False,
            "native_spawn_canary_enabled": True,
            "native_spawn_canary_mode": "read",
            "model": "",
            "deleg_exec_provider_cat": "",
            "deleg_exec_openai_profile": "",
            "deleg_exec_model": "",
            "model_tiers": {},
            "task_model_tiers": {},
            "limit_profile_overrides": {},
            "wake_on_completion": False,
            "wake_chain_max_depth": 2,
            "wake_daily_cap": 10,
            "wake_min_interval_minutes": 30,
            "wake_respect_quiet_hours": True,
            "deleg_rlimit_nproc": 0,
            "deleg_rlimit_cpu_seconds": 120,
            "deleg_rlimit_as_mb": 2048,
            "deleg_rlimit_fsize_mb": 512,
            "deleg_rss_limit_mb": 3072,
            "deleg_rss_headroom_mb": 768,
        },
        "memory_watchdog_settings": {
            "enabled": True,
            "interval_seconds": 30,
            "process_rss_limit_mb": 0,
            "system_available_limit_mb": 512,
            "cancel_after_seconds": 60,
            "notice_cooldown_seconds": 300,
        },
        "persona_creative_settings": {
            "anthology_max_turns": 30,
            "anthology_timeout_seconds": 900,
            "snapshot_keep": 0,
            "attic_after_days": 21,
        },
        "openai_provider_settings": [
            {
                "name": "OpenRouter",
                "base_url": "https://openrouter.ai/api/v1",
                "api_key": "",
                "default_model": "meta-llama/llama-3.3-70b-instruct:free",
                "available_models": [
                    # 無料モデル（2025年12月時点の有効なモデル）
                    "meta-llama/llama-3.3-70b-instruct:free",     # 13万トークン、ツール対応、安定
                    "nvidia/nemotron-3-nano-30b-a3b:free",        # 25.6万トークン、NVIDIA
                    "xiaomi/mimo-v2-flash:free",                  # 26.2万トークン、Xiaomi
                    "deepseek/deepseek-r1-0528:free",             # 16.4万トークン、推論特化
                    "google/gemma-3-27b-it:free",                 # 13万トークン
                    "qwen/qwen3-coder:free"                       # 26.2万トークン、コード特化
                ]
            },
            {
                "name": "Groq",
                "base_url": "https://api.groq.com/openai/v1",
                "api_key": "",
                "default_model": "llama-3.3-70b-versatile",
                "available_models": [
                    # Production Models (無料・高速)
                    "llama-3.3-70b-versatile",              # 最新・汎用
                    "llama-3.1-8b-instant",                 # 軽量・高速
                    "openai/gpt-oss-120b",                  # OpenAI OSS
                    "qwen/qwen3-32b"                        # Qwen3 32B (Preview)
                ]
            },
            {
                "name": "Ollama (Local)",
                "base_url": "http://localhost:11434/v1",
                "api_key": "ollama",
                "default_model": "phi3.5",
                "tool_use_enabled": False,  # 【ツール不使用モード】Ollamaはデフォルトでツール無効
                "available_models": [
                    # VRAM 4GB対応モデル（低スペックPC向け）
                    "phi3.5",       # 最適！2.5GB、ツール対応
                    "qwen2.5:3b",   # バランス良、ツール対応
                    "gemma",
                    "gemma:2b",
                    "gemma:9b",
                    "gemma:27b",
                    "gemma4:e2b",
                    "gemma4:e4b",
                    "gemma4:26b",
                    "gemma4:31b",
                    "gemma2:2b",    # 超軽量
                    "qwen3.5:2b",   # Qwen3.5 小規模
                    "qwen3.5:4b",   # Qwen3.5 万能軽量
                    "qwen3.5:9b",   # Qwen3.5 中間
                    "qwen2.5:0.5b"  # 超々軽量（内部処理用候補）
                ]
            },
            {
                "name": "OpenAI Official",
                "base_url": "https://api.openai.com/v1",
                "api_key": "",
                "default_model": "gpt-5.2-2025-12-11",
                "available_models": [
                    "gpt-5.2-2025-12-11",   # 最新
                    "chatgpt-4o-latest"     # 人気（Keep4o運動）
                ]
            },
            {
                "name": "Zhipu AI",
                "base_url": "https://open.bigmodel.cn/api/paas/v4",
                "api_key": "",
                "default_model": "glm-4.7-flash",
                "available_models": [
                    "glm-4.7-flash",
                    "glm-4.7",
                    "glm-4-plus",
                    "glm-4.5",
                    "glm-4.5-air",
                    "glm-zero-preview"
                ]
            },
            {
                "name": "Moonshot AI",
                "base_url": "https://api.moonshot.ai/v1",
                "api_key": "",
                "default_model": "kimi-k2.5",
                "available_models": [
                    "kimi-k2.5",
                    "moonshot-v1-8k",
                    "moonshot-v1-32k",
                    "moonshot-v1-128k"
                ]
            }
        ],

        # ---------------------------------
        "gemini_api_keys": {"your_key_name": "YOUR_API_KEY_HERE"},
        "paid_api_key_names": [],
        "available_models": [
            "gemini-2.5-flash", 
            "gemini-2.5-pro", 
            "gemini-2.5-flash-lite",
            "gemini-3-flash-preview", 
            "gemini-3.1-pro-preview",
            "gemini-3.1-flash-lite"
        ],
        "default_model": "gemini-3.1-flash-lite",
        # --- 画像生成設定（マルチプロバイダ対応）---
        "image_generation_provider": "gemini",  # gemini | openai | pollinations | huggingface | disabled
        "image_generation_model": "gemini-2.5-flash-image",  # 使用するモデル名
        "image_generation_openai_settings": {
            "base_url": "https://api.openai.com/v1",
            "api_key": "",
            "model": "gpt-image-1"
        },
        # Pollinations.ai 設定
        "pollinations_api_key": "",
        "image_generation_pollinations_model": "flux",
        # Hugging Face 設定
        "huggingface_api_token": "",
        "image_generation_huggingface_model": "black-forest-labs/FLUX.1-schnell",
        # TTS設定
        "tts_provider": "gemini",
        "tts_model": "gemini-3.1-flash-tts-preview",
        "tts_voice": "iapetus",
        "tts_response_format": "wav",
        "elevenlabs_api_key": "",
        "available_image_models": {
            "gemini": ["gemini-2.5-flash-image", "gemini-3.1-flash-image-preview", "gemini-3-pro-image-preview"],
            "openai": ["gpt-image-1", "gpt-image-1.5", "dall-e-3", "dall-e-2"],
            "pollinations": ["flux", "zimage", "klein", "gptimage", "kontext", "wan-image", "qwen-image"],
            "huggingface": ["black-forest-labs/FLUX.1-schnell", "stabilityai/stable-diffusion-xl-base-1.0"]
        }, 
        # --- ユーザー用画像生成プロンプト補助 ---
        "user_image_gen_instruction_templates": [
            {
                "name": "今の情景を画像に",
                "instruction": "今のチャットログの会話の情景を分析し、Stable Diffusionなどの画像生成AIで利用可能な、詳細で美しい英語のプロンプトを1つ生成してください。プロンプトのみを出力してください。"
            }
        ],
        "user_image_gen_selected_template_index": 0,
        "search_provider": constants.DEFAULT_SEARCH_PROVIDER,
        "search_model": constants.SEARCH_MODEL,  # Google検索（グラウンディング）に使うGeminiモデル
        "tavily_api_key": "",  # Tavily検索用APIキー
        "custom_tools_settings": {
            "enabled": True,
            "mcp_servers": [],
            "tool_metadata": {}
        },
        "last_room": "Default",
        "last_model": "gemini-3.1-flash-lite",
        "last_api_key_name": None,
        "thinking_level": constants.DEFAULT_THINKING_LEVEL,
        "last_send_thoughts_to_api": True,
        "last_api_history_limit_option": constants.DEFAULT_API_HISTORY_LIMIT_OPTION,
        "alarm_api_history_turns": constants.DEFAULT_ALARM_API_HISTORY_TURNS,
        "notification_service": "discord",
        "alarm_notification_service": "discord",
        "user_notification_service": "discord",
        "notification_webhook_url": None,
        "pushover_app_token": "",
        "pushover_user_key": "",
        "log_archive_threshold_mb": 10,
        "log_keep_size_mb": 5,
        "backup_rotation_count": 10,
        "log_backup_rotation_count": 30,
        "voice_input_audio_rotation_count": 10,
        "periodic_backup_interval": 10800,
        "theme_settings": {
            "active_theme": "nexus_modern", # デフォルトテーマをモダン版に変更
            "custom_themes": {} # config.jsonで管理するカスタムテーマは最初は空
        },
        "watchlist_settings": {
            "notify_on_change": True  # デフォルトで通知有効
        },
        "autonomous_settings": {
            "enabled": False,
            "inactivity_minutes": 120,
            "schedule_cooldown_minutes": 60,
            "quiet_hours_start": "00:00",
            "quiet_hours_end": "07:00",
            "allow_schedule_tool": True,
            "autonomous_guidelines": ""
        },
        "internal_model_settings": {
            "processing_provider_cat": "google",
            "processing_openai_profile": "",
            "processing_model": constants.INTERNAL_PROCESSING_MODEL,
            "summarization_provider_cat": "google",
            "summarization_openai_profile": "",
            "summarization_model": constants.SUMMARIZATION_MODEL,
            "translation_provider_cat": "google",
            "translation_openai_profile": "",
            "translation_model": constants.INTERNAL_PROCESSING_MODEL,
            "embedding_provider": "google",
            "embedding_model": constants.EMBEDDING_MODEL,
            "fallback_enabled": True
        },
        "local_model_path": "",
        "discord_bot_settings": {
            "enabled": False,
            "token": "",
            "authorized_user_ids": [],
            "linked_room": None,
            "allowed_channel_ids": [],
            "default_channel_id": "",
            "mention_only": False,
            "allow_autonomous_send": False,
            "persona_webhook_url": "",
            "approval_command_allowlist": [],
            "voice_input_enabled": False,
            "voice_input_confirm_transcript": True,
            "voice_input_timeout_minutes": 10,
            "voice_input_silence_seconds": 1.8,
            "voice_input_min_seconds": 0.6,
            "voice_input_max_seconds": 12.0,
            "voice_input_stt_model": constants.DISCORD_VOICE_STT_MODEL
        },
        "line_bot_enabled": False,
        "line_channel_access_token": "",
        "line_channel_secret": "",
        "line_authorized_user_ids": [],
        "line_bot_linked_room": None,
        "line_bot_port": 7862,
        "api_gateway_settings": {
            "enabled": False,
            "host": "0.0.0.0",
            "port": 8000,
            "require_auth": True,
            "auth_token": "",
            "auto_start_tailscale_serve": False,
            "rate_limit_enabled": True,
            "rate_limit_window_seconds": 60,
            "rate_limit_general_per_minute": 240,
            "rate_limit_events_per_minute": 60,
            "rate_limit_heavy_per_minute": 30,
            "audit_enabled": True,
            "event_notification_default_cooldown_seconds": 300,
            "event_notification_cooldowns": {},
            "response_notification_preview_enabled": True
        },
        "lite_travel_settings": {
            "worker_url": "",
            "owner_token": "",
            "bundle_signing_key": "",
            "bundle_signing_key_previous": [],
            "credential_profile_id": "gemini-personal-1",
            "model_id": "",
            "retention_days": 7,
            "wrangler_config_path": "cloud/lite-relay/wrangler.phase2.jsonc",
            "standby_home_instance_id": "",
            "standby_retention_days": 7,
            "standby_refresh_on_lite_start": False,
            "standby_refresh_min_interval_hours": 6,
        },
        "atelier_serve_settings": {
            "enabled": False,
            "host": "0.0.0.0",
            "port": 8765,
            "tailscale_https_port": 8443,
            "auto_start_tailscale_serve": False,
            "api_integration_enabled": False,
            "api_origin": ""
        },
        "weather_settings": {
            "city_name": "",
            "latitude": None,
            "longitude": None,
            "enable_persona_context": False,
            "enable_scenery_reflection": False
        },
        "google_calendar_settings": {
            "enabled": False,
            "client_id": "",
            "client_secret": "",
            "refresh_token": "",
            "selected_calendars": [],
            "sync_interval_minutes": 30,
            "retention_window": {"past_days": 1, "future_days": 14},
            "privacy_filter_default": {
                "exclude_keywords": ["[Private]", "[非公開]"],
                "mask_private_events": True
            },
            "reminder_sync_enabled": True,
            "return_prediction_enabled": True
        }
    }

    # ステップ2：ユーザーの設定ファイルを読み込む
    user_config = load_config_file()

    # ステップ3：【賢いマージ】テーマ設定をディープマージする
    default_theme_settings = default_config["theme_settings"]
    user_theme_settings = user_config.get("theme_settings", {})
    # ユーザーのカスタムテーマのみを尊重する（ファイルベースのテーマはjsonにマージしない）
    final_theme_settings = {
        "active_theme": user_theme_settings.get("active_theme", default_theme_settings["active_theme"]),
        "custom_themes": user_theme_settings.get("custom_themes", {})
    }

    # ステップ4：【厳格なマージ】available_modelsを統合する
    # デフォルトを真の源泉 (Single Source of Truth) とし、ユーザー設定にある古いモデルや注釈なしの名前を排除する。
    default_models = default_config["available_models"]
    user_models = user_config.get("available_models", [])
    
    # 基本方針:
    # 1. デフォルトに含まれるモデルはそのまま採用。
    # 2. リストに含まれない「gemini-2.0」などの古いモデルは除外対象とする。
    
    merged_models = default_models.copy()
    
    # 注釈付きモデルの「ベース名」リストを作成
    annotated_base_names = [m.split(" (")[0] for m in default_models if " (" in m]
    obsolete_keywords = ["gemini-1.5", "gemini-2.0", "gemini-3-pro-preview"]

    for m in user_models:
        # すでにリストにある（完全一致）ならスキップ
        if m in merged_models:
            continue
            
        # 除外判定
        is_obsolete = any(k in m for k in obsolete_keywords)
        is_unannotated_duplicate = m in annotated_base_names
        
        if not is_obsolete and not is_unannotated_duplicate:
            # どちらにも該当せず、かつデフォルトにない（ユーザーが手動で追加したカスタムモデル等）場合のみ追加を許可
            merged_models.append(m)
        else:
            print(f"--- [Config Manager] Cleaning up obsolete/duplicate model: {m} ---")

    # ステップ4.5：【賢いマージ】OpenAI互換プロバイダのavailable_modelsを統合する
    # デフォルトのモデルリストとユーザーが追加したモデルをマージし、ユーザー追加モデルが消えないようにする
    def merge_openai_provider_models(default_providers: List[Dict], user_providers: List[Dict]) -> List[Dict]:
        """OpenAI互換プロバイダの設定をマージする。ユーザー追加モデルを保持しつつ、デフォルトモデルも追加する。"""
        merged_providers = []
        
        # デフォルトプロバイダをnameでインデックス化
        default_by_name = {p["name"]: p for p in default_providers}
        user_by_name = {p["name"]: p for p in user_providers}
        
        # 全てのプロバイダ名を収集（デフォルト優先、ユーザー追加も含む）
        all_provider_names = list(default_by_name.keys())
        for name in user_by_name.keys():
            if name not in all_provider_names:
                all_provider_names.append(name)
        
        for name in all_provider_names:
            default_p = default_by_name.get(name, {})
            user_p = user_by_name.get(name, {})
            
            if not default_p and user_p:
                # ユーザーが追加したカスタムプロバイダ
                merged_providers.append(user_p)
            elif default_p and not user_p:
                # デフォルトにしかないプロバイダ（新規追加）
                merged_providers.append(default_p)
            else:
                # 両方に存在するプロバイダ：設定をマージ
                merged_p = default_p.copy()
                # ユーザー設定を優先（api_key, default_model, base_url）
                if user_p.get("api_key"):
                    merged_p["api_key"] = user_p["api_key"]
                if user_p.get("default_model"):
                    merged_p["default_model"] = user_p["default_model"]
                if user_p.get("base_url"):
                    merged_p["base_url"] = user_p["base_url"]
                
                # available_modelsはマージ（デフォルト + ユーザー追加）
                default_models = set(default_p.get("available_models", []))
                user_models = set(user_p.get("available_models", []))
                merged_p["available_models"] = sorted(list(default_models | user_models))

                # /models取得時に保存した推論metadataは対象モデル単位で保持する。
                # APIキーやレスポンス本文はここへ入れず、ユーザー側のcacheだけを
                # デフォルト値へマージする。
                default_reasoning_metadata = default_p.get("reasoning_metadata", {})
                user_reasoning_metadata = user_p.get("reasoning_metadata", {})
                if isinstance(default_reasoning_metadata, dict) or isinstance(user_reasoning_metadata, dict):
                    merged_reasoning_metadata = {}
                    if isinstance(default_reasoning_metadata, dict):
                        merged_reasoning_metadata.update(default_reasoning_metadata)
                    if isinstance(user_reasoning_metadata, dict):
                        merged_reasoning_metadata.update(user_reasoning_metadata)
                    merged_p["reasoning_metadata"] = merged_reasoning_metadata
                
                merged_providers.append(merged_p)
        
        return merged_providers
    
    merged_openai_providers = merge_openai_provider_models(
        default_config.get("openai_provider_settings", []),
        user_config.get("openai_provider_settings", [])
    )

    # ステップ4.6：【賢いマージ】available_image_modelsを統合する
    default_image_models = default_config.get("available_image_models", {})
    user_image_models = user_config.get("available_image_models", {})
    merged_image_models = {}
    for provider, models in default_image_models.items():
        u_models = user_image_models.get(provider, [])
        # デフォルトにあるモデルはすべて含め、ユーザーが追加したモデル（もしあれば）もマージする
        merged_image_models[provider] = sorted(list(set(models) | set(u_models)))

    # ステップ5：ユーザー設定を優先しつつ、不足キーを補完
    config = default_config.copy()
    config.update(user_config)
    missing_default_keys = [key for key in default_config.keys() if key not in user_config]
    legacy_notification_service = config.get("notification_service", "discord")
    if "alarm_notification_service" not in user_config:
        config["alarm_notification_service"] = legacy_notification_service
    if "user_notification_service" not in user_config:
        config["user_notification_service"] = legacy_notification_service
    # 統合したモデルリストとテーマ設定で、最終的な設定を上書き
    config["available_models"] = merged_models
    config["theme_settings"] = final_theme_settings
    config["openai_provider_settings"] = merged_openai_providers
    config["available_image_models"] = merged_image_models
    config_keys_changed = False
    
    # ステップ4.7：【賢いマージ】内部モデル設定をディープマージ
    default_internal = default_config.get("internal_model_settings", {})
    user_internal = user_config.get("internal_model_settings", {})
    merged_internal = default_internal.copy()
    merged_internal.update(user_internal)
    if _migrate_legacy_embedding_default(merged_internal):
        config_keys_changed = True
        print(
            "--- [Config Manager] 旧Google出荷デフォルトを "
            f"{constants.EMBEDDING_MODEL} へ移行しました ---"
        )
    config["internal_model_settings"] = merged_internal

    # エージェント委任 Phase 1 の初期既定値 8 は実タスクで不足することが分かったため、
    # 既存 config に残る 8 以下の値は新しい既定値 20 へ移行する。
    default_agent_delegation = default_config.get("agent_delegation_settings", {})
    user_agent_delegation = user_config.get("agent_delegation_settings", {})
    merged_agent_delegation = default_agent_delegation.copy()
    if isinstance(user_agent_delegation, dict):
        merged_agent_delegation.update(user_agent_delegation)
    if _migrate_agent_delegation_memory_settings(merged_agent_delegation, user_agent_delegation):
        config_keys_changed = True
    if _migrate_native_spawn_canary_defaults(merged_agent_delegation, user_agent_delegation):
        config_keys_changed = True
    try:
        if int(merged_agent_delegation.get("max_turns") or 20) <= 8:
            merged_agent_delegation["max_turns"] = 20
            config_keys_changed = True
    except (TypeError, ValueError):
        merged_agent_delegation["max_turns"] = 20
        config_keys_changed = True
    config["agent_delegation_settings"] = merged_agent_delegation

    default_memory_watchdog = default_config.get("memory_watchdog_settings", {})
    user_memory_watchdog = user_config.get("memory_watchdog_settings", {})
    merged_memory_watchdog = default_memory_watchdog.copy()
    if isinstance(user_memory_watchdog, dict):
        merged_memory_watchdog.update(user_memory_watchdog)
    config["memory_watchdog_settings"] = merged_memory_watchdog

    default_persona_creative = default_config.get("persona_creative_settings", {})
    user_persona_creative = user_config.get("persona_creative_settings", {})
    merged_persona_creative = default_persona_creative.copy()
    if isinstance(user_persona_creative, dict):
        merged_persona_creative.update(user_persona_creative)
    config["persona_creative_settings"] = merged_persona_creative

    # ステップ5.5：【移行処理】Zhipu AI APIキーの移行
    # 既存の zhipu_api_key があり、かつ Zhipu AI プロファイルのキーが空の場合に移行
    zhipu_legacy_key = config.get("zhipu_api_key", "")
    if zhipu_legacy_key:
        for p in config["openai_provider_settings"]:
            if p.get("name") == "Zhipu AI" and not p.get("api_key"):
                print(f"--- [Config Manager] Migrating Zhipu AI API Key to OpenAI profile ---")
                p["api_key"] = zhipu_legacy_key
                break

    # [Patch] Moonshot API Key Injection
    moonshot_legacy_key = config.get("moonshot_api_key")
    if moonshot_legacy_key and "openai_provider_settings" in config:
        for p in config["openai_provider_settings"]:
            if p["name"] == "Moonshot AI" and not p.get("api_key"):
                p["api_key"] = moonshot_legacy_key
                break

    # ステップ6：不要なキーをクリーンアップ
    keys_to_remove = ["memos_config", "api_keys", "default_api_key_name"]
    for key in keys_to_remove:
        if key in config:
            config.pop(key)
            config_keys_changed = True

    # ステップ7：キー構成の変化、またはモデルリスト/テーマ設定の変化があった場合のみファイルを更新
    if (config_keys_changed or
        bool(missing_default_keys) or
        set(user_config.get("available_models", [])) != set(config["available_models"]) or
        user_config.get("theme_settings") != config["theme_settings"] or # テーマ設定の変更もチェック
        not os.path.exists(constants.CONFIG_FILE)):
        print("--- [情報] 設定ファイルに新しいキーやモデル、テーマを追加、または不要なキーを削除しました。config.jsonを更新します。 ---")
        _save_config_file(config)

    # ステップ8：グローバル変数を更新
    CONFIG_GLOBAL = config
    _hydrate_model_reasoning_metadata_registry(config.get("openai_provider_settings", []))
    GEMINI_API_KEYS = config.get("gemini_api_keys", {})
    GEMINI_KEY_STATES = {k: {'exhausted': False} for k in GEMINI_API_KEYS}
    # [2026-02-11 FIX] 初期化後にファイルから枯渇状態を復元
    load_gemini_key_states()
    TAVILY_API_KEY = config.get("tavily_api_key", "")
    ZHIPU_API_KEY = config.get("zhipu_api_key", "")
    GROQ_API_KEY = config.get("groq_api_key", "")
    MOONSHOT_API_KEY = config.get("moonshot_api_key", "")
    LOCAL_MODEL_PATH = config.get("local_model_path", "")
    ANTHROPIC_API_KEY = config.get("anthropic_api_key", "")
    CLAUDE_SUBSCRIPTION_OAUTH_TOKEN = config.get("claude_subscription_oauth_token", "")
    NIM_API_KEY = config.get("nim_api_key", "")
    XAI_API_KEY = config.get("xai_api_key", "")
    
    discord_settings = config.get("discord_bot_settings", {})
    DISCORD_BOT_ENABLED = discord_settings.get("enabled", False)
    DISCORD_BOT_TOKEN = discord_settings.get("token", "")
    DISCORD_AUTHORIZED_USER_IDS = discord_settings.get("authorized_user_ids", [])
    DISCORD_BOT_LINKED_ROOM = discord_settings.get("linked_room", None)
    
    LINE_BOT_ENABLED = config.get("line_bot_enabled", False)
    LINE_CHANNEL_ACCESS_TOKEN = config.get("line_channel_access_token", "")
    LINE_CHANNEL_SECRET = config.get("line_channel_secret", "")
    LINE_AUTHORIZED_USER_IDS = config.get("line_authorized_user_ids", [])
    LINE_BOT_LINKED_ROOM = config.get("line_bot_linked_room", None)
    
    # OpenAI互換プロバイダーのデフォルト設定を生成・補完
    AVAILABLE_MODELS_GLOBAL = config.get("available_models", [])
    DEFAULT_MODEL_GLOBAL = config.get("default_model", DEFAULT_MODEL_GLOBAL)
    initial_room_global = config.get("last_room")
    initial_model_global = config.get("last_model")
    initial_send_thoughts_to_api_global = config.get("last_send_thoughts_to_api")
    initial_api_history_limit_option_global = config.get("last_api_history_limit_option")
    initial_alarm_api_history_turns_global = config.get("alarm_api_history_turns")
    initial_streaming_speed_global = config.get("last_streaming_speed")
    NOTIFICATION_SERVICE_GLOBAL = config.get("notification_service")
    NOTIFICATION_WEBHOOK_URL_GLOBAL = config.get("notification_webhook_url")
    PUSHOVER_CONFIG = {
        "user_key": config.get("pushover_user_key"),
        "app_token": config.get("pushover_app_token")
    }

    valid_api_keys = [k for k, v in GEMINI_API_KEYS.items() if isinstance(v, str) and v and v != "YOUR_API_KEY_HERE"]
    last_key = config.get("last_api_key_name")
    if last_key and last_key in valid_api_keys:
        initial_api_key_name_global = last_key
    elif valid_api_keys:
        initial_api_key_name_global = valid_api_keys[0]
    else:
        initial_api_key_name_global = list(GEMINI_API_KEYS.keys())[0] if GEMINI_API_KEYS else "your_key_name"


# --- [モデルリスト管理関数] ---

def get_default_available_models() -> List[str]:
    """
    デフォルトのGeminiモデルリストを返す。
    リセット機能で使用される。
    """
    return [
        "gemini-2.5-flash", 
        "gemini-2.5-pro", 
        "gemini-2.5-flash-lite",
        "gemini-3-flash-preview", 
        "gemini-3.1-pro-preview",
        "gemini-3.1-flash-lite"
    ]


def remove_model_from_list(model_name: str) -> bool:
    """
    指定されたモデルをavailable_modelsから削除して保存する。
    成功した場合はTrue、モデルが見つからない場合はFalseを返す。
    """
    global AVAILABLE_MODELS_GLOBAL
    
    current_models = list(AVAILABLE_MODELS_GLOBAL)
    if model_name not in current_models:
        return False
    
    current_models.remove(model_name)
    AVAILABLE_MODELS_GLOBAL = current_models
    save_config_if_changed("available_models", current_models)
    return True


def reset_models_to_default() -> List[str]:
    """
    モデルリストをデフォルト状態にリセットして保存する。
    リセット後のモデルリストを返す。
    """
    global AVAILABLE_MODELS_GLOBAL
    
    default_models = get_default_available_models()
    AVAILABLE_MODELS_GLOBAL = default_models
    save_config_if_changed("available_models", default_models)
    return default_models


def get_effective_settings(room_name: str, **kwargs) -> dict:
    """
    ルームのファイル設定と、UIからのリアルタイムな設定（kwargs）をマージして、
    最終的に適用される設定値を返す。
    """
    effective_settings = {
        "model_name": DEFAULT_MODEL_GLOBAL,
        "voice_id": "iapetus",
        "voice_style_prompt": "",
        "tts_provider": "gemini",
        "tts_model": "gemini-3.1-flash-tts-preview",
        "tts_voice": "iapetus",
        "tts_response_format": "wav",
        "add_timestamp": True, "send_thoughts": False,
        "send_notepad": True, "use_common_prompt": True,
        "send_core_memory": True,
        "enable_scenery_system": False, 
        "enable_auto_retrieval": False,
        "include_knowledge_in_auto_retrieval": False,
        "send_scenery": True,
        "scenery_send_mode": "変更時のみ",  # 情景画像送信タイミング: 「変更時のみ」or「毎ターン」
        "send_current_time": True,
        "auto_memory_enabled": False,
        "thinking_level": "auto",
        "enable_typewriter_effect": True,
        "streaming_speed": constants.DEFAULT_STREAMING_SPEED,
        "temperature": 1.0, "top_p": 0.95,
        "safety_block_threshold_harassment": "BLOCK_ONLY_HIGH",
        "safety_block_threshold_hate_speech": "BLOCK_ONLY_HIGH",
        "safety_block_threshold_sexually_explicit": "BLOCK_ONLY_HIGH",
        "safety_block_threshold_dangerous_content": "BLOCK_ONLY_HIGH",
        "api_history_limit": constants.DEFAULT_API_HISTORY_LIMIT_OPTION,
        # 自動会話要約
        "auto_summary_enabled": False,
        "auto_summary_threshold": constants.AUTO_SUMMARY_DEFAULT_THRESHOLD,
        "sleep_consolidation": {
            "update_episodic_memory": True,
            "update_memory_index": True,
            "update_current_log_index": True,
            "update_entity_memory": True,
            "compress_old_episodes": True
        },
        "watchlist_settings": {
            "notify_on_change": True
        },
        "project_explorer": {
            "root_path": "",
            "exclude_dirs": [".git", "venv", "__pycache__", "node_modules", ".agent", ".gemini"],
            "exclude_files": ["*.pyc", ".env", "config.json"]
        },
        "persona_workspace": {
            "enabled": True,
            "permission_tier": "write",
            "exclude_dirs": [".git", "__pycache__"],
            "exclude_files": ["*.pyc"]
        },
        "agent_delegation_settings": {
            "enabled": False,
            "permission_tier": "read",
            "allow_web_tools": False,
            "native_spawn_canary_enabled": True,
            "native_spawn_canary_mode": "read",
            "wake_on_completion": False,
            "wake_respect_quiet_hours": True,
            "deleg_exec_provider_cat": "default",
            "deleg_exec_openai_profile": "",
            "deleg_exec_model": "",
            "model_tiers": {},
            "task_model_tiers": {},
            "limit_profile_overrides": {},
        },
        "memory_watchdog_settings": {
            "enabled": True,
            "interval_seconds": 30,
            "process_rss_limit_mb": 0,
            "system_available_limit_mb": 512,
            "cancel_after_seconds": 60,
            "notice_cooldown_seconds": 300,
        },
        "autonomous_settings": {
            "enabled": False,
            "inactivity_minutes": 120,
            "schedule_cooldown_minutes": 60,
            "quiet_hours_start": "00:00",
            "quiet_hours_end": "07:00",
            "allow_schedule_tool": True,
            "autonomous_guidelines": ""
        }
    }

    for tts_key in ("tts_provider", "tts_model", "tts_voice", "tts_response_format"):
        if CONFIG_GLOBAL.get(tts_key):
            effective_settings[tts_key] = CONFIG_GLOBAL.get(tts_key)
    if CONFIG_GLOBAL.get("thinking_level"):
        effective_settings["thinking_level"] = CONFIG_GLOBAL.get("thinking_level")
    
    
    room_config_path = os.path.join(constants.ROOMS_DIR, room_name, "room_config.json")
    room_model_name = None  # ルーム個別モデル設定（Google用）
    room_zhipu_model = None # ルーム個別モデル設定（Zhipu用）
    room_provider = None  # ルーム個別プロバイダ設定（Noneは共通設定に従う）
    if os.path.exists(room_config_path):
        try:
            with open(room_config_path, "r", encoding="utf-8") as f:
                room_config = json.load(f)
            override_settings = room_config.get("override_settings", {})
            # ルーム個別のプロバイダ設定を先に取得する。
            # None/"default"/不明値は「共通設定に従う」として扱い、保存済みのAI設定値は編集用ドラフトに留める。
            room_provider = normalize_room_provider_override(override_settings.get("provider"))
            
            for k, v in override_settings.items():
                if (
                    v is not None
                    # 認証辞書は専用resolverと内部stateに限定し、汎用設定へ混ぜない。
                    and k not in {"model_name", "gemini_connection"}
                    and not (
                        room_provider is None
                        and k in ROOM_AI_PROVIDER_SETTING_KEYS
                    )
                ):
                    effective_settings[k] = v
            
            # プロバイダ固有のTTS設定キャッシュをマージする
            current_tts_provider = override_settings.get("tts_provider", effective_settings.get("tts_provider", "gemini"))
            provider_cache = override_settings.get("tts_provider_settings", {}).get(current_tts_provider, {})
            for pk, pv in provider_cache.items():
                if pv is not None:
                    effective_settings[pk] = pv

            # ルーム個別のモデル設定を一時保存（後のロジックで使用）
            raw_room_model_name = override_settings.get("model_name")
            raw_room_zhipu_model = override_settings.get("zhipu_model")
            room_model_name = raw_room_model_name.strip() if _is_non_empty_string(raw_room_model_name) else None
            room_zhipu_model = raw_room_zhipu_model.strip() if _is_non_empty_string(raw_room_zhipu_model) else None
        except Exception as e:
            print(f"ルーム設定ファイル '{room_config_path}' の読み込みエラー: {e}")

    for key, value in kwargs.items():
        # "global_model_from_ui" はモデル決定ロジックで使うので、ここでは除外
        if key not in ["global_model_from_ui"] and value is not None:
            effective_settings[key] = value

    # TTS新設定の後方互換:
    # 既存ルームは voice_id / voice_style_prompt だけを持つため、Gemini TTS設定へ昇格して扱う。
    if not effective_settings.get("tts_voice"):
        effective_settings["tts_voice"] = effective_settings.get("voice_id", "iapetus")
    if not effective_settings.get("tts_style_prompt"):
        effective_settings["tts_style_prompt"] = effective_settings.get("voice_style_prompt", "")

# --- モデル選択の最終決定ロジック ---
    global_model_from_ui = kwargs.get("global_model_from_ui")
    
    active_provider = get_active_provider(room_name)
    
    if active_provider == "openai":
        # OpenAI互換モード: ルーム個別のopenai_settings > グローバルなアクティブプロファイル の優先度
        room_openai_settings = effective_settings.get("openai_settings")
        
        # [Dynamic Injection] ルーム個別設定の場合も、APIキーはグローバル設定の最新値を注入する
        # これにより、ルーム設定保存後にAPIキーが変更された場合でも認証エラーを防ぐ
        if room_openai_settings:
            provider_name = room_openai_settings.get("name")
            if provider_name == "Zhipu AI":
                global_key = CONFIG_GLOBAL.get("zhipu_api_key")
                if global_key:
                    room_openai_settings["api_key"] = global_key
            elif provider_name == "Moonshot AI":
                global_key = CONFIG_GLOBAL.get("moonshot_api_key")
                if global_key:
                    room_openai_settings["api_key"] = global_key
        
        if room_openai_settings and room_openai_settings.get("model"):
            # ルーム個別のOpenAI設定でモデルが指定されている場合
            effective_settings["model_name"] = room_openai_settings["model"]
        else:
            # フォールバック: グローバルなアクティブプロファイルのデフォルトモデル
            openai_setting = get_active_openai_setting()
            if openai_setting:
                effective_settings["model_name"] = openai_setting.get("default_model", "gpt-3.5-turbo")

    elif active_provider == "zhipu":
        # Zhipu AI (GLM-4) モード
        # ルーム個別設定 > デフォルト (AVAILABLE_ZHIPU_MODELS[0])
        if room_zhipu_model and room_provider is not None:
             effective_settings["model_name"] = room_zhipu_model
        else:
             # フォールバック: available_settings の先頭
             effective_settings["model_name"] = AVAILABLE_ZHIPU_MODELS[0] if AVAILABLE_ZHIPU_MODELS else "glm-4.7-flash"
    
    elif active_provider == "anthropic":
        # Anthropic (Claude) モード
        room_anthropic_settings = effective_settings.get("anthropic_settings")
        if room_anthropic_settings and room_anthropic_settings.get("model"):
            effective_settings["model_name"] = room_anthropic_settings["model"]
        else:
            effective_settings["model_name"] = CONFIG_GLOBAL.get("anthropic_default_model", "claude-3-7-sonnet-20250219")

    elif active_provider == "claude_subscription":
        # Claude サブスクリプション (Agent SDK) モード
        room_claude_subscription_settings = effective_settings.get("claude_subscription_settings")
        if room_claude_subscription_settings and room_claude_subscription_settings.get("model"):
            effective_settings["model_name"] = room_claude_subscription_settings["model"]
        else:
            effective_settings["model_name"] = CONFIG_GLOBAL.get("claude_subscription_default_model", "sonnet")
            
    else:
        # Googleモード: ルーム個別設定 > UI指定 > デフォルト の優先度でモデルを決定
        # 明示 "default" や provider キー欠落は共通設定を使い、保存済みモデルは編集用ドラフトに留める。
        if room_model_name and room_provider is not None:
            final_model_name = room_model_name
        elif global_model_from_ui:
            final_model_name = global_model_from_ui
        else:
            final_model_name = DEFAULT_MODEL_GLOBAL
        effective_settings["model_name"] = final_model_name

        # 念の為のフォールバック
        if not effective_settings.get("model_name"):
            effective_settings["model_name"] = DEFAULT_MODEL_GLOBAL

    # 【重要】プロバイダ情報を明示的に含める（gemini_apiなどで参照するため）
    effective_settings["provider"] = active_provider
            
    return effective_settings

from typing import Tuple

def get_api_key_choices_for_ui() -> List[Tuple[str, str]]:
    """UI用の選択肢リストを (表示名, 値) のタプルで返す。表示名には Paid ラベルを付与する。"""
    paid_key_names = CONFIG_GLOBAL.get("paid_api_key_names", []) if isinstance(CONFIG_GLOBAL, dict) else []
    choices: List[Tuple[str, str]] = []
    for key_name in sorted(GEMINI_API_KEYS.keys()):
        display = f"{key_name} (Paid)" if key_name in paid_key_names else key_name
        choices.append((display, key_name))
    
    # [2026-02-11 FIX] allow_custom_value=False のため、選択肢が空だとエラーになるのを防ぐ
    if not choices:
        choices.append(("（APIキー未設定）", ""))
        
    return choices

DEFAULT_REDACTION_RULES: List[Dict[str, object]] = [
    {
        "find": r"sk-ant-oat01-[A-Za-z0-9_-]+",
        "replace": "[CLAUDE_OAUTH_TOKEN]",
        "color": "#f59e0b",
        "regex": True,
    }
]


def _with_default_redaction_rules(rules: List[Dict[str, str]]) -> List[Dict[str, str]]:
    merged: List[Dict[str, str]] = [dict(rule) for rule in rules]
    existing = {str(rule.get("find", "")) for rule in merged}
    for default_rule in DEFAULT_REDACTION_RULES:
        if str(default_rule.get("find", "")) not in existing:
            merged.append(dict(default_rule))
    return merged


def load_redaction_rules() -> List[Dict[str, str]]:
    """redaction_rules.jsonから置換ルールを読み込む。"""
    if os.path.exists(constants.REDACTION_RULES_FILE):
        try:
            with open(constants.REDACTION_RULES_FILE, "r", encoding="utf-8") as f:
                content = f.read()
                if not content.strip():
                    return _with_default_redaction_rules([])
                rules = json.loads(content)
                if isinstance(rules, list) and all(isinstance(r, dict) and "find" in r and "replace" in r for r in rules):
                    return _with_default_redaction_rules(rules)
        except (json.JSONDecodeError, IOError):
            print(f"警告: {constants.REDACTION_RULES_FILE} の読み込みに失敗しました。")
    return _with_default_redaction_rules([])

def save_redaction_rules(rules: List[Dict[str, str]]):
    """置換ルールをredaction_rules.jsonに保存する。"""
    try:
        with open(constants.REDACTION_RULES_FILE, "w", encoding="utf-8") as f:
            json.dump(rules, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"エラー: {constants.REDACTION_RULES_FILE} の保存に失敗しました: {e}")


def apply_redaction_rules_to_text(text: str, rules: List[Dict[str, str]] | None) -> str:
    """Apply literal and regex redaction rules to plain text."""
    if not text or not rules:
        return text
    modified_text = text
    for rule in rules:
        find_str = str(rule.get("find", ""))
        replace_str = str(rule.get("replace", ""))
        if not find_str:
            continue
        if rule.get("regex"):
            try:
                modified_text = re.sub(find_str, replace_str, modified_text)
            except re.error:
                modified_text = modified_text.replace(find_str, replace_str)
        else:
            modified_text = modified_text.replace(find_str, replace_str)
    return modified_text

def save_theme_settings(active_theme: str, custom_themes: Dict):
    """
    アクティブなテーマ名とカスタムテーマの定義をconfig.jsonに保存する。
    """
    config = load_config_file()
    if "theme_settings" not in config:
        config["theme_settings"] = {}
    config["theme_settings"]["active_theme"] = active_theme
    config["theme_settings"]["custom_themes"] = custom_themes
    _save_config_file(config)

from typing import Optional

def get_latest_api_key_name_from_config() -> Optional[str]:
    """
    config.jsonを直接読み込み、最後に選択された有効なAPIキー名を返す。
    UIの状態に依存しないため、バックグラウンドスレッドから安全に呼び出せる。
    """
    config = load_config_file()
    last_key_name = config.get("last_api_key_name")

    # 有効な（値が設定されている）APIキーのリストを取得
    api_keys_dict = config.get("gemini_api_keys", {})
    valid_keys = [
        k for k, v in api_keys_dict.items()
        if v and isinstance(v, str) and not v.startswith("YOUR_API_KEY")
    ]

    # 最後に使ったキーが今も有効なら、それを返す
    if last_key_name and last_key_name in valid_keys:
        return last_key_name

    # そうでなければ、有効なキーリストの最初のものを返す
    if valid_keys:
        return valid_keys[0]

    # 有効なキーが一つもなければ、Noneを返す
    return None

# --- [APIキーローテーション用のメモリ上変数] ---
_CURRENT_STARTING_KEY_NAME = None


def get_active_gemini_api_key(room_name: str = None, model_name: str = None, excluded_keys: set = None) -> Optional[str]:
    """
    指定されたルームの設定（またはグローバル設定）に基づいて、
    現在有効な Gemini API キーの『値（文字列）』を直接返す。
    キーが設定されていない場合は None を返す。
    """
    # model_name が指定されていない場合は、デフォルトの内部処理モデルを使用
    if not model_name:
        model_name = constants.INTERNAL_PROCESSING_MODEL

    rotation_enabled_global = CONFIG_GLOBAL.get("enable_api_key_rotation", True)
    rotation_enabled_room = True # デフォルトはTrue (有効)
    
    if room_name:
        room_config_path = os.path.join(constants.ROOMS_DIR, room_name, "room_config.json")
        if os.path.exists(room_config_path):
            try:
                with open(room_config_path, "r", encoding="utf-8") as f:
                    room_config = json.load(f)
                override_settings = room_config.get("override_settings", {})
                
                # プロバイダ設定を確認（明示 default の場合は共通設定に従うため、個別キー/ローテーション設定も無視する）
                room_provider = normalize_room_provider_override(override_settings.get("provider"))
                use_room_ai_settings = room_provider is not None

                # 個別設定でのスイッチ確認。共通設定に従う場合、保存済み値は編集用ドラフトとして扱う。
                room_rot_setting = override_settings.get("enable_api_key_rotation")
                if use_room_ai_settings and room_rot_setting is not None:
                    rotation_enabled_room = room_rot_setting
                else:
                    rotation_enabled_room = rotation_enabled_global

                # [2026-04-29] 画像生成モデルの場合、無料キーでのローテーションは意味がない（全滅するため）
                # かつ、ユーザーが意図しないキーの切り替えを防ぐため、個別設定がなければローテーションを無効化する
                if is_image_generation_model(model_name):
                    rotation_enabled_room = False

                if use_room_ai_settings:
                    room_api_key_name = _clean_api_key_name(override_settings.get("api_key_name"))
                    if room_api_key_name:
                        key_val = GEMINI_API_KEYS.get(room_api_key_name)
                        if key_val and not key_val.startswith("YOUR_API_KEY"):
                            # キーが枯渇しているかチェック
                            if rotation_enabled_room and is_key_exhausted(room_api_key_name, model_name=model_name):
                                if excluded_keys is None: excluded_keys = set()
                                excluded_keys.add(room_api_key_name)
                                print(f"Warning: Room key '{room_api_key_name}' is exhausted for model '{model_name}'. Falling back to common pool.")
                                # フォールバック: 下記の共通設定ロジックへ流れる
                            else:
                                return key_val
            except Exception:
                pass

    # 共通設定でのローテーション確認
    # ルーム指定がない、またはルーム設定でフォールバックした場合
    rotation_enabled = rotation_enabled_room if room_name else rotation_enabled_global
    
    # [2026-04-29] グローバルな画像生成モデル判定
    if is_image_generation_model(model_name):
        rotation_enabled = False

    # [2026-02-11 FIX] ユーザー選択キーを優先する
    # メモリ上の CONFIG_GLOBAL から優先的に取得（UIの状態を即座に反映）
    global _CURRENT_STARTING_KEY_NAME
    
    key_name = None
    if isinstance(CONFIG_GLOBAL, dict):
        key_name = _clean_api_key_name(CONFIG_GLOBAL.get("last_api_key_name"))
    
    if not key_name:
        key_name = _clean_api_key_name(get_latest_api_key_name_from_config())

    # --- 起点となるキーを決定 ---
    candidate_key = _CURRENT_STARTING_KEY_NAME if _CURRENT_STARTING_KEY_NAME else key_name

    if candidate_key:
        key_val = GEMINI_API_KEYS.get(candidate_key)
        if key_val and not key_val.startswith("YOUR_API_KEY"):
            if not is_key_exhausted(candidate_key, model_name=model_name):
                # 起点キーが有効
                paid_keys = set(CONFIG_GLOBAL.get("paid_api_key_names", [])) if isinstance(CONFIG_GLOBAL, dict) else set()
                if candidate_key not in paid_keys:
                    _CURRENT_STARTING_KEY_NAME = candidate_key
                else:
                    _CURRENT_STARTING_KEY_NAME = None
                return key_val
            elif rotation_enabled:
                # 起点キーが枯渇 → ローテーションで代替キーを探す
                if excluded_keys is None: excluded_keys = set()
                excluded_keys.add(candidate_key)
                print(f"--- [API Key Rotation] キー '{candidate_key}' は対象モデル({model_name})でクールダウン中のため、API呼び出しを省略して次候補へ進みます。 ---")
                
                alt_key = get_next_available_gemini_key(current_exhausted_key=candidate_key, excluded_keys=excluded_keys, model_name=model_name)
                if alt_key:
                    paid_keys = set(CONFIG_GLOBAL.get("paid_api_key_names", [])) if isinstance(CONFIG_GLOBAL, dict) else set()
                    if alt_key not in paid_keys:
                        _CURRENT_STARTING_KEY_NAME = alt_key
                    else:
                        _CURRENT_STARTING_KEY_NAME = None
                    return GEMINI_API_KEYS.get(alt_key)
                # 代替も見つからない場合、起点キーをそのまま返す（rescue strategyで対応）
                return key_val
            else:
                # ローテーション無効 → 枯渇していても起点キーを返す
                return key_val

    # キー名が設定されていない場合のフォールバック
    if rotation_enabled:
        available_key_name = get_next_available_gemini_key(excluded_keys=excluded_keys, model_name=model_name)
        if available_key_name:
            paid_keys = set(CONFIG_GLOBAL.get("paid_api_key_names", [])) if isinstance(CONFIG_GLOBAL, dict) else set()
            if available_key_name not in paid_keys:
                _CURRENT_STARTING_KEY_NAME = available_key_name
            else:
                _CURRENT_STARTING_KEY_NAME = None
            return GEMINI_API_KEYS.get(available_key_name)

    return None


def get_active_gemini_api_key_name(room_name: str = None, model_name: str = None, excluded_keys: set = None) -> Optional[str]:
    """
    指定されたルームの設定（またはグローバル設定）に基づいて、
    現在有効な Gemini API キーの『名称』を返す。
    キーが設定されていない場合は None を返す。
    """
    # model_name が指定されていない場合は、デフォルトの内部処理モデルを使用
    if not model_name:
        model_name = constants.INTERNAL_PROCESSING_MODEL

    rotation_enabled_global = CONFIG_GLOBAL.get("enable_api_key_rotation", True)
    
    # [2026-04-29] 画像生成モデル判定
    if is_image_generation_model(model_name):
        rotation_enabled_global = False

    rotation_enabled_room = rotation_enabled_global 
    
    if room_name:
        room_config_path = os.path.join(constants.ROOMS_DIR, room_name, "room_config.json")
        if os.path.exists(room_config_path):
            try:
                with open(room_config_path, "r", encoding="utf-8") as f:
                    room_config = json.load(f)
                override_settings = room_config.get("override_settings", {})
                
                # プロバイダ設定を確認（明示 default の場合は共通設定に従うため、個別キー/ローテーション設定も無視する）
                room_provider = normalize_room_provider_override(override_settings.get("provider"))
                use_room_ai_settings = room_provider is not None

                # 個別設定でのスイッチ確認。共通設定に従う場合、保存済み値は編集用ドラフトとして扱う。
                room_rot_setting = override_settings.get("enable_api_key_rotation")
                if use_room_ai_settings and room_rot_setting is not None:
                    rotation_enabled_room = room_rot_setting
                else:
                    rotation_enabled_room = rotation_enabled_global
                
                # [2026-04-29] 画像生成モデル判定（ルーム個別）
                if is_image_generation_model(model_name):
                    rotation_enabled_room = False

                if use_room_ai_settings:
                    room_api_key_name = _clean_api_key_name(override_settings.get("api_key_name"))
                    if room_api_key_name:
                        # キー自体が存在することを確認
                        key_val = GEMINI_API_KEYS.get(room_api_key_name)
                        if key_val and not key_val.startswith("YOUR_API_KEY"):
                            # キーが枯渇しているかチェック
                            if rotation_enabled_room and is_key_exhausted(room_api_key_name, model_name=model_name):
                                if excluded_keys is None: excluded_keys = set()
                                excluded_keys.add(room_api_key_name)
                                alt_key = get_next_available_gemini_key(excluded_keys=excluded_keys, model_name=model_name)
                                if alt_key:
                                    print(f"  - [Rotation] Room key '{room_api_key_name}' is exhausted for model '{model_name}'. Rotating to '{alt_key}'.")
                                    return alt_key
                                return room_api_key_name # フォールバックしても見つかららなければ元の名前を返す
                            else:
                                return room_api_key_name
            except Exception:
                pass

    rotation_enabled = rotation_enabled_room if room_name else rotation_enabled_global

    # [2026-02-11 FIX] ユーザー選択キーを優先する
    global _CURRENT_STARTING_KEY_NAME

    key_name = None
    if isinstance(CONFIG_GLOBAL, dict):
        key_name = _clean_api_key_name(CONFIG_GLOBAL.get("last_api_key_name"))
    
    if not key_name:
        key_name = _clean_api_key_name(get_latest_api_key_name_from_config())

    # --- 起点となるキーを決定 ---
    candidate_key = _CURRENT_STARTING_KEY_NAME if _CURRENT_STARTING_KEY_NAME else key_name

    if candidate_key:
        key_val = GEMINI_API_KEYS.get(candidate_key)
        if key_val and not key_val.startswith("YOUR_API_KEY"):
            if not is_key_exhausted(candidate_key, model_name=model_name):
                paid_keys = set(CONFIG_GLOBAL.get("paid_api_key_names", [])) if isinstance(CONFIG_GLOBAL, dict) else set()
                if candidate_key not in paid_keys:
                    _CURRENT_STARTING_KEY_NAME = candidate_key
                else:
                    _CURRENT_STARTING_KEY_NAME = None
                return candidate_key  # 起点キーが有効
            elif rotation_enabled:
                if excluded_keys is None: excluded_keys = set()
                excluded_keys.add(candidate_key)
                print(f"--- [API Key Rotation] キー '{candidate_key}' は対象モデル({model_name})でクールダウン中のため、API呼び出しを省略して次候補へ進みます。 ---")
                
                alt_key = get_next_available_gemini_key(current_exhausted_key=candidate_key, excluded_keys=excluded_keys, model_name=model_name)
                if alt_key:
                    paid_keys = set(CONFIG_GLOBAL.get("paid_api_key_names", [])) if isinstance(CONFIG_GLOBAL, dict) else set()
                    if alt_key not in paid_keys:
                        _CURRENT_STARTING_KEY_NAME = alt_key
                    else:
                        _CURRENT_STARTING_KEY_NAME = None
                    return alt_key
                return candidate_key  # 代替なし → 起点キーを返す
            else:
                return candidate_key  # ローテーション無効

    # キー名が設定されていない場合のフォールバック
    if rotation_enabled:
        available_key_name = get_next_available_gemini_key(excluded_keys=excluded_keys, model_name=model_name)
        if available_key_name:
            paid_keys = set(CONFIG_GLOBAL.get("paid_api_key_names", [])) if isinstance(CONFIG_GLOBAL, dict) else set()
            if available_key_name not in paid_keys:
                _CURRENT_STARTING_KEY_NAME = available_key_name
            else:
                _CURRENT_STARTING_KEY_NAME = None
            return available_key_name

    return key_name


def has_valid_api_key() -> bool:
    """
    設定ファイルに、有効な（プレースホルダではない）Gemini APIキーが一つでも存在するかどうかを返す。
    """
    if not GEMINI_API_KEYS:
        return False
    for key, value in GEMINI_API_KEYS.items():
        if value and isinstance(value, str) and value != "YOUR_API_KEY_HERE":
            return True
    return False

def get_current_global_model() -> str:
    """
    config.jsonから、現在ユーザーが共通設定で選択している
    有効なグローバルモデル名を返す。
    """
    # 常に最新の設定をファイルから読み込む
    config = load_config_file()
    
    # last_modelキーが存在し、かつ利用可能モデルリストに含まれていればそれを優先
    last_model = config.get("last_model")
    available_models = config.get("available_models", [])
    if last_model and last_model in available_models:
        return last_model
        
    # それ以外の場合は、default_modelキーを返す
    return config.get("default_model", DEFAULT_MODEL_GLOBAL)

# --- [Phase 4] 追加プロバイダのAPIキー保存関数 ---

def save_single_api_key(key_name: str, key_value: str, config_key: str):
    """
    Anthropic, Zhipu, Groqなどの単一APIキーを保存する統合ハンドラ
    """
    global ZHIPU_API_KEY, GROQ_API_KEY, MOONSHOT_API_KEY, LOCAL_MODEL_PATH
    global ANTHROPIC_API_KEY, CLAUDE_SUBSCRIPTION_OAUTH_TOKEN, NIM_API_KEY, XAI_API_KEY
    
    if config_key == "zhipu_api_key": ZHIPU_API_KEY = key_value
    elif config_key == "groq_api_key": GROQ_API_KEY = key_value
    elif config_key == "moonshot_api_key": MOONSHOT_API_KEY = key_value
    elif config_key == "anthropic_api_key": ANTHROPIC_API_KEY = key_value
    elif config_key == "claude_subscription_oauth_token": CLAUDE_SUBSCRIPTION_OAUTH_TOKEN = key_value
    elif config_key == "nim_api_key": NIM_API_KEY = key_value
    elif config_key == "xai_api_key": XAI_API_KEY = key_value
    elif config_key == "local_model_path": LOCAL_MODEL_PATH = key_value
        
    save_config_if_changed(config_key, key_value)

# --- [Multi-Provider Support Helpers] ---

def get_active_provider(room_name: str = None) -> str:
    """
    現在アクティブなプロバイダ名を返す。
    room_nameが指定された場合、ルーム個別の設定を優先する。
    """
    if room_name:
        # ルーム個別のプロバイダ設定を確認
        room_config_path = os.path.join(constants.ROOMS_DIR, room_name, "room_config.json")
        if os.path.exists(room_config_path):
            try:
                with open(room_config_path, "r", encoding="utf-8") as f:
                    room_config = json.load(f)
                override_settings = room_config.get("override_settings", {})
                room_provider = normalize_room_provider_override(override_settings.get("provider"))
                # ルーム個別に有効なプロバイダが設定されている場合はそれを使用
                if room_provider:
                    return room_provider
            except Exception:
                pass
    # フォールバック: グローバル設定。無効化済みの旧プロバイダ値は google へ落とす。
    global_provider = CONFIG_GLOBAL.get("active_provider", "google")
    return global_provider if global_provider in VALID_ROOM_PROVIDERS else "google"

def set_active_provider(provider: str):
    """アクティブなプロバイダを切り替える"""
    if provider in VALID_ROOM_PROVIDERS:
        save_config_if_changed("active_provider", provider)

def get_openai_settings_list() -> List[Dict]:
    """OpenAI互換プロバイダの設定リストを返す"""
    profiles = CONFIG_GLOBAL.get("openai_provider_settings", [])
    _hydrate_model_reasoning_metadata_registry(profiles)
    return profiles

def is_pollinations_openai_profile(profile: Dict) -> bool:
    """OpenAI互換プロファイルがPollinations.ai向けかを判定する。"""
    name = (profile or {}).get("name", "")
    base_url = (profile or {}).get("base_url", "")
    return "pollinations" in name.lower() or "pollinations.ai" in base_url.lower()

def get_image_openai_settings_list() -> List[Dict]:
    """画像生成のOpenAI互換UIに表示できるプロファイルだけを返す。"""
    return [profile for profile in get_openai_settings_list() if not is_pollinations_openai_profile(profile)]

def get_image_openai_profile_names() -> List[str]:
    """画像生成のOpenAI互換UIに表示できるプロファイル名のリストを返す。"""
    return [profile.get("name", "") for profile in get_image_openai_settings_list() if profile.get("name")]

def save_openai_settings_list(settings_list: List[Dict]):
    """OpenAI互換プロバイダの設定リストを保存する"""
    if isinstance(settings_list, list):
        save_config_if_changed("openai_provider_settings", settings_list)

def add_or_update_openai_profile(profile_data: Dict):
    """
    OpenAI互換プロファイルを新規追加、または既存のものを上書き更新する。
    profile_dataには少なくとも 'name', 'base_url', 'api_key' が必要。
    """
    if "name" not in profile_data:
        return False
        
    settings = get_openai_settings_list()
    updated = False
    
    for i, s in enumerate(settings):
        if s.get("name") == profile_data["name"]:
            # 既存の設定を上書き（available_models等は保持しつつ更新）
            merged = s.copy()
            merged.update(profile_data)
            settings[i] = merged
            updated = True
            break
            
    if not updated:
        # 新規プロファイルとして追加
        if "available_models" not in profile_data:
            profile_data["available_models"] = []
        if "default_model" not in profile_data:
            profile_data["default_model"] = ""
        settings.append(profile_data)
        
    save_openai_settings_list(settings)
    return True

def save_openai_provider_setting(name: str, base_url: str, api_key: str, available_models: list = None, default_model: str = "", tool_use_enabled: bool = True):
    """
    OpenAI互換プロファイルを設定として追加・更新する便利なラッパー関数
    """
    profile_data = {
        "name": name,
        "base_url": base_url,
        "api_key": api_key,
        "available_models": available_models or [],
        "default_model": default_model,
        "tool_use_enabled": tool_use_enabled
    }
    return add_or_update_openai_profile(profile_data)

def get_active_openai_profile_name() -> str:
    """現在選択されているOpenAIプロファイル名（例: 'OpenRouter'）を返す"""
    return CONFIG_GLOBAL.get("active_openai_profile", "OpenRouter")

def set_active_openai_profile(profile_name: str):
    """アクティブなOpenAIプロファイル名を保存する"""
    save_config_if_changed("active_openai_profile", profile_name)

def get_openai_setting_by_name(profile_name: str) -> Optional[Dict]:
    """
    指定された名前（例: 'Groq', 'Zhipu AI'）のOpenAIプロファイル設定辞書を返す。
    """
    if not profile_name: return None
    
    settings = get_openai_settings_list()
    target_setting = None
    for s in settings:
        if s.get("name") == profile_name:
            target_setting = s
            break
            
    if target_setting:
        target_setting = target_setting.copy()
        # [Dynamic Injection] 特定のプロバイダの場合はグローバルな設定からAPIキーを反映
        if target_setting.get("name") == "Zhipu AI":
            global_key = CONFIG_GLOBAL.get("zhipu_api_key")
            if global_key:
                target_setting["api_key"] = global_key
        elif target_setting.get("name") == "Moonshot AI":
            global_key = CONFIG_GLOBAL.get("moonshot_api_key")
            if global_key:
                target_setting["api_key"] = global_key
        elif target_setting.get("name") == "Groq":
            global_key = CONFIG_GLOBAL.get("groq_api_key")
            if global_key:
                target_setting["api_key"] = global_key
        elif target_setting.get("name") in {"xAI", "X.ai", "Grok"}:
            global_key = CONFIG_GLOBAL.get("xai_api_key")
            if global_key:
                target_setting["api_key"] = global_key
        elif target_setting.get("name") == "Pollinations.ai":
            global_key = CONFIG_GLOBAL.get("pollinations_api_key")
            if global_key:
                target_setting["api_key"] = global_key
                
        return target_setting
    return None

def get_active_openai_setting() -> Optional[Dict]:
    """現在アクティブなOpenAIプロファイルの設定辞書を返す"""
    profile_name = get_active_openai_profile_name()
    return get_openai_setting_by_name(profile_name)

def is_tool_use_enabled(room_name: str = None) -> bool:
    """
    【ツール不使用モード】
    現在のプロバイダ設定でツール使用が有効かどうかを返す。
    room_nameが指定された場合、ルーム個別の設定を優先する。
    - Googleプロバイダ: 常にTrue
    - OpenAI互換プロバイダ: ルーム個別またはプロファイルの`tool_use_enabled`設定に従う（デフォルトTrue）
    """
    active_provider = get_active_provider(room_name)
    
    if active_provider == "google":
        # Geminiは常にツール使用可能
        return True

    if active_provider == "claude_subscription":
        # Claudeサブスク通常会話プロバイダはAgent SDKを1ターン利用し、ツールは送らない。
        return False
    
    # OpenAI互換プロバイダの場合
    # まずルーム個別のopenai_settings.tool_use_enabledを確認
    if room_name:
        room_config_path = os.path.join(constants.ROOMS_DIR, room_name, "room_config.json")
        if os.path.exists(room_config_path):
            try:
                with open(room_config_path, "r", encoding="utf-8") as f:
                    room_config = json.load(f)
                override_settings = room_config.get("override_settings", {})
                room_openai_settings = override_settings.get("openai_settings", {})
                # ルーム個別のtool_use_enabledが明示的に設定されている場合はそれを使用
                if "tool_use_enabled" in room_openai_settings:
                    return room_openai_settings["tool_use_enabled"]
            except Exception:
                pass
    
    # フォールバック: グローバルなアクティブプロファイルの設定
    openai_setting = get_active_openai_setting()
    if openai_setting:
        # プロファイルのtool_use_enabled設定を取得（デフォルトTrue）
        return openai_setting.get("tool_use_enabled", True)
    
    return True  # フォールバック


# --- [Phase 2] 内部処理モデル設定管理 ---


def _migrate_agent_delegation_memory_settings(
    merged_settings: Dict[str, Any],
    user_settings: Any,
) -> bool:
    """旧native RSS既定を移行し、増分上限キーを永続化対象にする。"""

    if not isinstance(user_settings, dict) or "deleg_rss_headroom_mb" in user_settings:
        return False
    # 旧出荷既定の2GBだけを3GBへ移行する。0（ガード無効）やユーザー調整値は維持する。
    try:
        if int(user_settings.get("deleg_rss_limit_mb") or 0) == 2048:
            merged_settings["deleg_rss_limit_mb"] = 3072
    except (TypeError, ValueError):
        pass
    return True


def _migrate_native_spawn_canary_defaults(
    merged_settings: Dict[str, Any],
    user_settings: Any,
) -> bool:
    """Enable only a missing spawn key while preserving every explicit user choice."""

    existing = user_settings if isinstance(user_settings, dict) else {}
    changed = False
    if "native_spawn_canary_enabled" not in existing:
        merged_settings["native_spawn_canary_enabled"] = True
        changed = True
    if "native_spawn_canary_mode" not in existing:
        merged_settings["native_spawn_canary_mode"] = "read"
        changed = True
    return changed


def _migrate_legacy_embedding_default(settings: Dict[str, Any]) -> bool:
    """旧Google出荷デフォルトだけを現行既定へ移行し、ユーザー独自設定は保つ。"""
    if (
        settings.get("embedding_provider", "google") in {"google", "gemini"}
        and settings.get("embedding_model") in {
            "gemini-embedding-001",
            "gemini-embedding-2-preview",
        }
    ):
        settings["embedding_provider"] = "google"
        settings["embedding_model"] = constants.EMBEDDING_MODEL
        return True
    return False

def get_internal_model_settings() -> Dict[str, Any]:
    """
    内部処理モデルの設定を取得する。
    設定がない場合はデフォルト値を返す。
    """
    default_settings = {
        # 処理モデル設定
        "processing_provider_cat": "google",
        "processing_openai_profile": "",
        "processing_model": constants.INTERNAL_PROCESSING_MODEL,
        
        # 要約モデル設定
        "summarization_provider_cat": "google",
        "summarization_openai_profile": "",
        "summarization_model": constants.SUMMARIZATION_MODEL,
        
        # 翻訳モデル設定
        "translation_provider_cat": "google",
        "translation_openai_profile": "",
        "translation_model": constants.INTERNAL_PROCESSING_MODEL,
        
        # エンベディング設定
        "embedding_provider": "google",
        "embedding_model": constants.EMBEDDING_MODEL,
        
        # フォールバック設定
        "fallback_enabled": True,
    }
    
    user_settings = CONFIG_GLOBAL.get("internal_model_settings", {})
    
    # デフォルト値とマージ（ユーザー設定を優先）
    merged = default_settings.copy()
    merged.update(user_settings)
    
    return merged


def save_internal_model_settings(settings: Dict[str, Any]) -> bool:
    """
    内部処理モデルの設定を保存する。
    
    Returns:
        保存が成功したかどうか
    """
    try:
        print(f"[config_manager] save_internal_model_settings called with: {settings}")  # DEBUG
        result = save_config_if_changed("internal_model_settings", settings)
        print(f"[config_manager] save_config_if_changed returned: {result}")  # DEBUG
        return True  # 例外がなければ成功（変更がなかった場合もTrue）
    except Exception as e:
        print(f"[config_manager] 内部モデル設定の保存に失敗: {e}")
        return False


def reset_internal_model_settings() -> Dict[str, Any]:
    """
    内部処理モデルの設定をデフォルトにリセットする。
    
    Returns:
        リセット後の設定
    """
    default_settings = {
        "provider": "google",
        "processing_model": constants.INTERNAL_PROCESSING_MODEL,
        "summarization_model": constants.SUMMARIZATION_MODEL,
        "supervisor_model": constants.INTERNAL_PROCESSING_MODEL,
        "translation_provider": "google",
        "translation_model": constants.INTERNAL_PROCESSING_MODEL,
        "openai_profile": None,
        "embedding_provider": "google",
        "embedding_model": constants.EMBEDDING_MODEL,
        "fallback_enabled": True,
        "fallback_order": ["google"],
    }
    
    save_internal_model_settings(default_settings)
    return default_settings


def get_effective_internal_model(role: str) -> Tuple[str, str, str]:
    """
    指定されたロールに応じた内部処理モデルのプロバイダ名、モデル名、およびプロファイル名を取得する。
    
    Args:
        role: "processing", "summarization", "supervisor", "translation" のいずれか
    
    Returns:
        (provider_cat, model_name, profile_name) のタプル
    """
    settings = get_internal_model_settings()
    
    # ロールごとのキーマッピング
    cat_key_map = {
        "processing": "processing_provider_cat",
        "summarization": "summarization_provider_cat",
        "supervisor": "supervisor_provider_cat",
        "translation": "translation_provider_cat",
    }
    profile_key_map = {
        "processing": "processing_openai_profile",
        "summarization": "summarization_openai_profile",
        "supervisor": "supervisor_openai_profile",
        "translation": "translation_openai_profile",
    }
    model_key_map = {
        "processing": "processing_model",
        "summarization": "summarization_model",
        "supervisor": "supervisor_model",
        "translation": "translation_model",
    }
    
    # 旧形式の互換性維持 (provider_cat が無い場合は provider を見る)
    legacy_provider_key_map = {
        "processing": "processing_provider",
        "summarization": "summarization_provider",
        "supervisor": "supervisor_provider",
        "translation": "translation_provider",
    }

    cat_key = cat_key_map.get(role)
    profile_key = profile_key_map.get(role)
    model_key = model_key_map.get(role)
    legacy_key = legacy_provider_key_map.get(role)

    if role == "supervisor":
        has_explicit_supervisor = any(
            key in settings and settings.get(key)
            for key in ("supervisor_provider_cat", "supervisor_model", "supervisor_openai_profile", "supervisor_provider")
        )
        if not has_explicit_supervisor:
            return get_effective_internal_model("processing")
    
    provider_cat = settings.get(cat_key)
    if not provider_cat:
        # 旧形式からの移行: 旧 provider が openai なら、それをプロファイル名として扱う
        old_provider = settings.get(legacy_key, "google")
        
        # 表示名から内部値へのマッピング
        label_to_cat = {
            "Google (Gemini)": "google",
            "Google (Gemini Native)": "google",
            "OpenAI (公式)": "openai_official",
            "OpenAI互換": "openai",
            "OpenAI互換 (OpenRouter / Groq / Ollama / Zhipu AI)": "openai",
            "Anthropic (Claude)": "anthropic",
            "Claude サブスクリプション (Pro/Max)": "google",
            "ローカル (GGUF直接ロード)": "local",
            "ローカル(llama.cpp/GGUF)": "local",
            "Local (llama.cpp)": "local"
        }
        
        if old_provider in ["google", "openai", "openai_official", "anthropic", "local"]:
            provider_cat = old_provider
        elif old_provider in label_to_cat:
            provider_cat = label_to_cat[old_provider]
        else:
            # プロファイル名が入っていると推測される場合
            provider_cat = "openai"
            settings[profile_key] = old_provider
    elif provider_cat == "claude_subscription":
        # [SEALED] Claude SDK経路は封印中。委任モデルでは google へ降格する。ADR: docs/decisions/010_claude_sdk_path_sealed_not_deleted.md
        provider_cat = "google"

    profile_name = settings.get(profile_key, CONFIG_GLOBAL.get("active_openai_profile", "OpenRouter"))
    model_name = settings.get(model_key, constants.INTERNAL_PROCESSING_MODEL)
    
    return (provider_cat, model_name, profile_name)
    

DELEGATION_MODEL_PROVIDER_CATS = {"google", "openai", "openai_official", "anthropic", "local"}

# 委任実行モデルを「規模/速度」で3分類し、ReActループの上限を寄せるための limit profile。
# RSS上限は本体プロセスのメモリ（モデル非依存）なのでここでは扱わない。
DELEGATION_LIMIT_PROFILES = {
    "local": {"max_turns": 14, "timeout_seconds": 900},        # ローカルサーバは1呼び出しが遅め・能力依存。ターンは控えめ、待ち時間は長め。
    "cloud_light": {"max_turns": 20, "timeout_seconds": 600},  # flash/mini/haiku 等。高速・安価なので反復は多めに許容、待ちは標準。
    "cloud_heavy": {"max_turns": 16, "timeout_seconds": 1200}, # pro/opus/gpt-4級。少ない反復で済むが1呼び出しが遅いので待ちは長め。
}
# 「軽量クラウドモデル」と判定するモデル名トークン（区切りで分割した完全一致）。
# 部分一致にすると "gemini" 内の "mini" 等を誤検出するため、トークン単位で判定する。
# Gemma系はクラウド提供の26B/31B級が低速なため、"gemma" トークンだけでは軽量判定しない。
# 小型Gemma（4b/9b等）はサイズトークン正規表現で拾う。
_DELEGATION_LIGHT_MODEL_TOKENS = {
    "flash", "mini", "haiku", "lite", "nano", "small", "tiny", "air",
}
# 小規模パラメータ（概ね9B以下）を示す "8b" 等のサイズトークン。
_DELEGATION_LIGHT_SIZE_RE = re.compile(r"^[1-9]b$")


def _delegation_limit_profile_override(model_name: str | None, overrides: dict | None = None) -> str:
    name = str(model_name or "").strip().lower()
    if not name:
        return ""
    if overrides is None:
        settings = CONFIG_GLOBAL.get("agent_delegation_settings", {}) if isinstance(CONFIG_GLOBAL, dict) else {}
        overrides = settings.get("limit_profile_overrides") if isinstance(settings, dict) else {}
    if not isinstance(overrides, dict):
        return ""
    normalized_overrides = {str(key or "").strip().lower(): value for key, value in overrides.items()}
    raw_profile = normalized_overrides.get(name)
    if raw_profile is None:
        return ""
    limit_profile = str(raw_profile or "").strip().lower()
    if limit_profile in DELEGATION_LIMIT_PROFILES:
        return limit_profile
    logger.warning(
        "invalid delegation limit_profile override for model %s: %r",
        name,
        raw_profile,
    )
    return ""


def _classify_delegation_limit_profile(
    provider_cat: str | None,
    model_name: str | None,
    overrides: dict | None = None,
) -> str:
    """委任実行モデルを local / cloud_light / cloud_heavy に分類する。"""
    override = _delegation_limit_profile_override(model_name, overrides)
    if override:
        return override
    cat = str(provider_cat or "").strip().lower()
    if cat == "local":
        return "local"
    name = str(model_name or "").strip().lower()
    tokens = [tok for tok in re.split(r"[^a-z0-9]+", name) if tok]
    for tok in tokens:
        if tok in _DELEGATION_LIGHT_MODEL_TOKENS or _DELEGATION_LIGHT_SIZE_RE.match(tok):
            return "cloud_light"
    return "cloud_heavy"


def derive_delegation_limits(provider_cat: str | None, model_name: str | None, overrides: dict | None = None) -> dict:
    """委任実行モデルから推奨上限（max_turns / timeout_seconds）と limit profile を返す。"""
    limit_profile = _classify_delegation_limit_profile(provider_cat, model_name, overrides)
    profile = DELEGATION_LIMIT_PROFILES.get(limit_profile, DELEGATION_LIMIT_PROFILES["cloud_light"])
    return {
        "limit_profile": limit_profile,
        "max_turns": int(profile["max_turns"]),
        "timeout_seconds": int(profile["timeout_seconds"]),
    }


def _normalize_delegation_model_settings(settings: dict, *, room_scope: bool = False) -> Tuple[str, str, str] | None:
    if not isinstance(settings, dict):
        return None
    provider_cat = str(settings.get("deleg_exec_provider_cat") or "").strip()
    if room_scope and provider_cat in {"", "default"}:
        return None
    if not room_scope and provider_cat in {"", "default"}:
        return None
    if provider_cat == "claude_subscription":
        # [SEALED] Claude SDK経路は封印中。直接指定は委任モデル解決から除外する。ADR: docs/decisions/010_claude_sdk_path_sealed_not_deleted.md
        return None
    if provider_cat not in DELEGATION_MODEL_PROVIDER_CATS:
        return None
    model_name = str(settings.get("deleg_exec_model") or "").strip()
    if not model_name:
        return None
    profile_name = str(settings.get("deleg_exec_openai_profile") or CONFIG_GLOBAL.get("active_openai_profile", "OpenRouter") or "").strip()
    return (provider_cat, model_name, profile_name)


DELEGATION_MODEL_TIER_NAMES = {"fast", "balanced", "deep"}


def _normalize_delegation_model_tier(value: Any) -> str:
    model_tier = str(value or "").strip().lower()
    return model_tier if model_tier in DELEGATION_MODEL_TIER_NAMES else ""


def _normalize_delegation_model_tier_settings(settings: dict, tier_name: str) -> Tuple[str, str, str] | None:
    if not isinstance(settings, dict):
        return None
    tiers = settings.get("model_tiers") or {}
    if not isinstance(tiers, dict):
        return None
    model_tier_config = tiers.get(tier_name) or {}
    if not isinstance(model_tier_config, dict):
        return None
    provider_cat = str(model_tier_config.get("provider_cat") or "").strip()
    if provider_cat == "claude_subscription":
        # [SEALED] Claude SDK経路は封印中。model tier 設定でも委任モデル解決から除外する。ADR: docs/decisions/010_claude_sdk_path_sealed_not_deleted.md
        return None
    if provider_cat not in DELEGATION_MODEL_PROVIDER_CATS:
        return None
    model_name = str(model_tier_config.get("model") or "").strip()
    if not model_name:
        return None
    profile_name = str(
        model_tier_config.get("openai_profile")
        or model_tier_config.get("profile")
        or CONFIG_GLOBAL.get("active_openai_profile", "OpenRouter")
        or ""
    ).strip()
    return (provider_cat, model_name, profile_name)


def _resolve_delegation_model_tier_from_settings(
    settings: dict,
    *,
    model_hint: str = "",
    task_kind: str = "",
) -> Tuple[str, str, str] | None:
    if not isinstance(settings, dict):
        return None
    hinted_tier = _normalize_delegation_model_tier(model_hint)
    if hinted_tier:
        return _normalize_delegation_model_tier_settings(settings, hinted_tier)

    normalized_task_kind = str(task_kind or "").strip().lower()
    task_model_tiers = settings.get("task_model_tiers") or {}
    if normalized_task_kind and isinstance(task_model_tiers, dict):
        task_tier = _normalize_delegation_model_tier(task_model_tiers.get(normalized_task_kind))
        if task_tier:
            return _normalize_delegation_model_tier_settings(settings, task_tier)
    return None


def get_effective_delegation_model(room_name: str | None = None) -> Tuple[str, str, str] | None:
    """
    委任実行専用モデルの有効設定を返す。

    解決順は room override -> global -> None。None の場合、呼び出し側は従来どおり
    ルームの会話モデル/プロバイダへフォールバックする。
    """
    room = str(room_name or "").strip()
    if room:
        try:
            room_config_path = os.path.join(constants.ROOMS_DIR, room, "room_config.json")
            if os.path.exists(room_config_path):
                with open(room_config_path, "r", encoding="utf-8") as f:
                    room_config = json.load(f)
                room_settings = (room_config.get("override_settings", {}) or {}).get("agent_delegation_settings", {})
                resolved = _normalize_delegation_model_settings(room_settings, room_scope=True)
                if resolved:
                    return resolved
        except Exception:
            pass

    global_settings = CONFIG_GLOBAL.get("agent_delegation_settings", {}) if isinstance(CONFIG_GLOBAL, dict) else {}
    return _normalize_delegation_model_settings(global_settings, room_scope=False)


def resolve_delegation_model_for_task(
    room_name: str | None = None,
    *,
    model_hint: str = "",
    task_kind: str = "",
) -> Tuple[str, str, str] | None:
    """
    ロール/タスク種別に応じた委任実行モデルのティア設定を解決する。

    解決順は room tier settings -> global tier settings。各スコープ内では
    model_hint が task_kind より優先。解決できなければ None を返し、呼び出し側は
    従来の get_effective_delegation_model / 会話モデルフォールバックへ進む。
    """
    room = str(room_name or "").strip()
    if room:
        try:
            room_config_path = os.path.join(constants.ROOMS_DIR, room, "room_config.json")
            if os.path.exists(room_config_path):
                with open(room_config_path, "r", encoding="utf-8") as f:
                    room_config = json.load(f)
                room_settings = (room_config.get("override_settings", {}) or {}).get("agent_delegation_settings", {})
                resolved = _resolve_delegation_model_tier_from_settings(
                    room_settings,
                    model_hint=model_hint,
                    task_kind=task_kind,
                )
                if resolved:
                    return resolved
        except Exception:
            pass

    global_settings = CONFIG_GLOBAL.get("agent_delegation_settings", {}) if isinstance(CONFIG_GLOBAL, dict) else {}
    return _resolve_delegation_model_tier_from_settings(
        global_settings,
        model_hint=model_hint,
        task_kind=task_kind,
    )


# --- APIキーローテーション関連 ---


def is_key_exhausted(key_name: str, model_name: str = None) -> bool:
    """
    指定されたキー（および必要に応じて特定のモデル）が現在枯渇状態かどうかを返す。
    model_nameがNoneの場合は、そのキー自体のグローバルな枯渇状態（旧形式）または
    何らかのモデルで枯渇しているかを確認する。
    """
    key_name = _clean_api_key_name(key_name)
    
    # 探索対象のステートキーを決定
    state_keys = []
    if model_name:
        state_keys.append(f"{key_name}@{model_name}")
    state_keys.append(f"{key_name}@*") # ワイルドカード（全体）
    state_keys.append(key_name)         # 旧形式（互換性用）
    
    state = None
    applied_state_key = None
    for sk in state_keys:
        if sk in GEMINI_KEY_STATES:
            state = GEMINI_KEY_STATES[sk]
            applied_state_key = sk
            break
            
    if not state or not state.get('exhausted'):
        return False
    
    # 有料キーは枯渇マークされないはずだが、念のためチェック
    paid_keys = set()
    if isinstance(CONFIG_GLOBAL, dict):
        paid_keys = set(CONFIG_GLOBAL.get("paid_api_key_names", []))
    if key_name in paid_keys:
        if applied_state_key:
            def clear_paid_key_state(states):
                if applied_state_key in states:
                    states[applied_state_key]['exhausted'] = False
                return states
            _update_gemini_key_states(clear_paid_key_state)
        return False
    
    # 無料キーの自動復帰ロジック
    exhausted_at = state.get('exhausted_at', 0)
    limit_type = state.get('limit_type', 'RPM')
    
    if limit_type == "RPD":
        reset_timestamp = state.get('reset_at', 0)
        # 後方互換性と安全のため、reset_at が無い場合は24時間とする
        if not reset_timestamp:
            reset_timestamp = exhausted_at + 24 * 3600
            
        if time.time() < reset_timestamp:
            return True # まだRPDリセット時刻（太平洋時間0時）になっていない
        else:
            print(f"--- [API Key Rotation] Key '{applied_state_key}' auto-recovered (Daily Reset) ---")
            def recover_daily_key_state(states):
                if applied_state_key in states:
                    states[applied_state_key]['exhausted'] = False
                return states
            _update_gemini_key_states(recover_daily_key_state)
            return False
    else:
        # RPM制限の自動復帰（1分クールダウン）
        if time.time() - exhausted_at > 60:  # 1分 (GoogleのRPM制限を考慮)
            print(f"--- [API Key Rotation] Key '{applied_state_key}' auto-recovered (1分経過/RPM回復) ---")
            def recover_rpm_key_state(states):
                if applied_state_key in states:
                    states[applied_state_key]['exhausted'] = False
                return states
            _update_gemini_key_states(recover_rpm_key_state)
            return False
        
    return True

def mark_key_as_exhausted(key_name: str, model_name: str = None, limit_type: str = "RPM"):
    """キー（および特定のモデル）を枯渇状態としてマークし、制限の種類を記録する。"""
    key_name = _clean_api_key_name(key_name)
    if not key_name: return
    
    # 有料キーは枯渇マークしない（リトライのバックオフだけで対応）
    paid_keys = set()
    if isinstance(CONFIG_GLOBAL, dict):
        paid_keys = set(CONFIG_GLOBAL.get("paid_api_key_names", []))
    if key_name in paid_keys:
        print(f"--- [API Key Rotation] Key '{key_name}' is PAID - skipping exhaustion mark (backoff only) ---")
        return
    
    # [2026-04-29] 画像生成モデルの場合、無料キーは常に失敗するため、枯渇マークをスキップする
    # (他機能への影響を防ぐため)
    if is_image_generation_model(model_name):
        print(f"--- [API Key Rotation] Key '{key_name}' failed for image model, skipping exhaustion mark for FREE key ---")
        return
    
    state_key = f"{key_name}@{model_name}" if model_name else key_name
    
    import datetime
    now = datetime.datetime.now(datetime.timezone.utc)
    # Google APIのリセット時刻: 太平洋時間0時 (UTC 08:00 または 07:00)。安全のため遅い方の08:00を使用
    reset_time = now.replace(hour=8, minute=0, second=0, microsecond=0)
    if now >= reset_time:
        reset_time += datetime.timedelta(days=1)
    
    exhausted_at = time.time()

    def mark_exhausted_state(states):
        states[state_key] = {
            'exhausted': True,
            'exhausted_at': exhausted_at,
            'limit_type': limit_type,
            'reset_at': reset_time.timestamp() if limit_type == "RPD" else 0
        }
        return states
    _update_gemini_key_states(mark_exhausted_state)
    
    if limit_type == "RPD":
        print(f"--- [API Key Rotation] Key '{state_key}' marked as EXHAUSTED (RPD Limit: until {reset_time.strftime('%Y-%m-%d %H:%M:%S')} UTC) ---")
    else:
        print(f"--- [API Key Rotation] Key '{state_key}' marked as EXHAUSTED (RPM Limit: 1min cooldown) ---")

def clear_exhausted_keys():
    """すべてのキーの枯渇状態を解除する"""
    _update_gemini_key_states(lambda states: states.clear() or states)
    print("--- [API Key Rotation] All exhausted states cleared ---")

def get_next_available_gemini_key(current_exhausted_key: str = None, excluded_keys: set = None, model_name: str = None) -> Optional[str]:
    """
    有効なキーの中から、枯渇していないものを探して返す。
    探索順序（コストと安定性のバランス）:
    1. 無料キー（未試行 かつ 非枯渇）
    2. 有料キー（未試行 かつ 非枯渇） ※以前は無料枯渇後に有料だったが、ここでは「未試行」を優先
    3. 無料キー（救済: 最も古い枯渇キー）
    4. 有料キー（救済: 最も古い枯渇キー）
    """
    if excluded_keys is None:
        excluded_keys = set()
    
    # 現在の枯渇キーを明示的に除外リストに追加
    if current_exhausted_key:
        excluded_keys.add(current_exhausted_key)
        
    config = load_config_file()
    paid_key_names = set(config.get("paid_api_key_names", []))
    
    # 全有効キーのリスト
    all_valid_keys = [
        k for k, v in GEMINI_API_KEYS.items()
        if v and isinstance(v, str) and not v.startswith("YOUR_API_KEY")
    ]
    
    if not all_valid_keys:
        return None

    # current_exhausted_key があれば、その次から探索するようにリストをシフトする（巻き戻り防止）
    if current_exhausted_key and current_exhausted_key in all_valid_keys:
        idx = all_valid_keys.index(current_exhausted_key)
        all_valid_keys = all_valid_keys[idx+1:] + all_valid_keys[:idx+1]

    # --- フェーズ1: 未試行かつ非枯渇のキーを探す ---
    # (無料 -> 有料 の順で、まだ今回のリトライループで試していないものを優先)
    untried_keys = [k for k in all_valid_keys if k not in excluded_keys]
    
    # 無料キー(未試行)
    free_untried = [k for k in untried_keys if k not in paid_key_names]
    for k in free_untried:
        if not is_key_exhausted(k, model_name):
            return k
            
    # 有料キー(未試行)
    paid_untried = [k for k in untried_keys if k in paid_key_names]
    for k in paid_untried:
        if not is_key_exhausted(k, model_name):
            return k
            
    # --- フェーズ2: 救済ロジック (Rescue Strategy) ---
    # 全ての未試行キーが枯渇しているか、全てのキーを試し終えた場合
    print(f"--- [API Key Rotation] All candidates for model '{model_name}' are exhausted or tried. Attempting rescue... ---")
    
    # 無料キーの救済を最優先（コスト保護）
    candidates_free = []
    candidates_paid = []
    
    for k in all_valid_keys:
        # [2026-04-23 FIX] 今回の試行サイクル(excluded_keys)ですでに試したキーは救済対象からも外す
        if k in excluded_keys:
            continue
            
        # ステートキーを確認
        state_key = f"{k}@{model_name}" if model_name else k
        
        state = None
        if state_key in GEMINI_KEY_STATES:
            state = GEMINI_KEY_STATES[state_key]
        elif k in GEMINI_KEY_STATES: # 旧形式
            state = GEMINI_KEY_STATES[k]
            
        if state and state.get('exhausted'):
            if k in paid_key_names: candidates_paid.append((k, state.get('exhausted_at', 0)))
            else: candidates_free.append((k, state.get('exhausted_at', 0)))
        else:
            # 枯渇していない、またはステートなし (フェーズ1で見落とされた可能性のあるもの)
            if k in paid_key_names: candidates_paid.append((k, 0))
            else: candidates_free.append((k, 0))

    # --- Rescue Strategy (救済策) ---
    # 候補が全滅している場合、最後に記録された使用可能時刻が最も古いキーを強制的に1つ返す
    # (バックオフ時間が経過している可能性があるため)
    
    # 1. 無料キーの救済を最優先（コスト保護）
    if candidates_free:
        candidates_free.sort(key=lambda x: x[1])
        rescued_key = candidates_free[0][0]
        rescued_time = candidates_free[0][1]
        elapsed = time.time() - rescued_time if rescued_time > 0 else 999999
        print(f"--- [API Key Rotation] RESCUED FREE Key '{rescued_key}' (Exhausted {elapsed:.1f}s ago). ---")
        return rescued_key

    # 2. 無料キーがない場合のみ有料キーを救済（最終防波堤）
    if candidates_paid:
        candidates_paid.sort(key=lambda x: x[1])
        rescued_key = candidates_paid[0][0]
        rescued_time = candidates_paid[0][1]
        elapsed = time.time() - rescued_time if rescued_time > 0 else 999999
        print(f"--- [API Key Rotation] RESCUED PAID Key '{rescued_key}' (Exhausted {elapsed:.1f}s ago). ---")
        return rescued_key

    print(f"--- [API Key Rotation] CRITICAL: No candidates for model '{model_name}' rescue! ---")
    return None

def _normalize_discord_bot_settings(settings: dict | None) -> dict:
    """Discord Bot設定の不足キーを補完する。"""
    base = {
        "enabled": False,
        "token": "",
        "authorized_user_ids": [],
        "linked_room": None,
        "allowed_channel_ids": [],
        "default_channel_id": "",
        "mention_only": False,
        "channel_response_modes": {},
        "allow_autonomous_send": False,
        "persona_webhook_url": "",
        "approval_command_allowlist": [],
        "voice_input_enabled": False,
        "voice_input_confirm_transcript": True,
        "voice_input_timeout_minutes": 10,
        "voice_input_silence_seconds": 1.8,
        "voice_input_min_seconds": 0.6,
        "voice_input_max_seconds": 12.0,
        "voice_input_stt_model": constants.DISCORD_VOICE_STT_MODEL,
    }
    if isinstance(settings, dict):
        base.update(settings)
    for list_key in ("authorized_user_ids", "allowed_channel_ids", "approval_command_allowlist"):
        value = base.get(list_key)
        if isinstance(value, str):
            base[list_key] = [item.strip() for item in value.split(",") if item.strip()]
        elif not isinstance(value, list):
            base[list_key] = []
    modes = base.get("channel_response_modes")
    normalized_modes = {}
    if isinstance(modes, dict):
        for channel_id, mode in modes.items():
            channel_key = str(channel_id).strip()
            mode_value = str(mode).strip()
            if channel_key and mode_value in {"always", "mention", "ignore"}:
                normalized_modes[channel_key] = mode_value
    base["channel_response_modes"] = normalized_modes
    for bool_key in ("voice_input_enabled", "voice_input_confirm_transcript"):
        base[bool_key] = bool(base.get(bool_key))
    for numeric_key, default_value in {
        "voice_input_timeout_minutes": 10,
        "voice_input_silence_seconds": 1.8,
        "voice_input_min_seconds": 0.6,
        "voice_input_max_seconds": 12.0,
    }.items():
        try:
            value = float(base.get(numeric_key, default_value))
            if numeric_key == "voice_input_timeout_minutes":
                value = int(max(1, min(value, 180)))
            elif numeric_key == "voice_input_silence_seconds":
                value = max(0.3, min(value, 5.0))
            elif numeric_key == "voice_input_min_seconds":
                value = max(0.1, min(value, 5.0))
            elif numeric_key == "voice_input_max_seconds":
                value = max(2.0, min(value, 60.0))
            base[numeric_key] = value
        except Exception:
            base[numeric_key] = default_value
    if not str(base.get("voice_input_stt_model") or "").strip():
        base["voice_input_stt_model"] = constants.DISCORD_VOICE_STT_MODEL
    return base

def get_global_discord_bot_settings() -> dict:
    return _normalize_discord_bot_settings(CONFIG_GLOBAL.get("discord_bot_settings", {}))

def get_room_discord_bot_settings(room_name: str) -> dict:
    """ルーム個別のDiscord Bot設定を取得する。未設定時は無効設定を返す。"""
    if not room_name:
        return _normalize_discord_bot_settings({})
    try:
        import room_manager
        room_config = room_manager.get_room_config(room_name) or {}
        overrides = room_config.get("override_settings", {}) if isinstance(room_config, dict) else {}
        return _normalize_discord_bot_settings(overrides.get("discord_bot_settings", {}))
    except Exception as e:
        print(f"Discord Bot個別設定の取得に失敗しました ({room_name}): {e}")
        return _normalize_discord_bot_settings({})

def save_room_discord_bot_settings(
    room_name: str,
    enabled: bool = None,
    token: str = None,
    authorized_user_ids: List[str] = None,
    allowed_channel_ids: List[str] = None,
    default_channel_id: str = None,
    mention_only: bool = None,
    channel_response_modes: Dict[str, str] = None,
    allow_autonomous_send: bool = None,
    persona_webhook_url: str = None,
    approval_command_allowlist: List[str] = None,
    voice_input_enabled: bool = None,
    voice_input_confirm_transcript: bool = None,
    voice_input_timeout_minutes: int = None,
    voice_input_silence_seconds: float = None,
    voice_input_min_seconds: float = None,
    voice_input_max_seconds: float = None,
    voice_input_stt_model: str = None,
):
    """ルーム個別のDiscord Bot設定を保存する。"""
    if not room_name:
        return False
    try:
        import room_manager
        settings = get_room_discord_bot_settings(room_name)
        if enabled is not None: settings["enabled"] = bool(enabled)
        if token is not None: settings["token"] = token
        if authorized_user_ids is not None: settings["authorized_user_ids"] = authorized_user_ids
        if allowed_channel_ids is not None: settings["allowed_channel_ids"] = allowed_channel_ids
        if default_channel_id is not None: settings["default_channel_id"] = default_channel_id
        if mention_only is not None: settings["mention_only"] = bool(mention_only)
        if channel_response_modes is not None: settings["channel_response_modes"] = channel_response_modes
        if allow_autonomous_send is not None: settings["allow_autonomous_send"] = bool(allow_autonomous_send)
        if persona_webhook_url is not None: settings["persona_webhook_url"] = persona_webhook_url
        if approval_command_allowlist is not None: settings["approval_command_allowlist"] = approval_command_allowlist
        if voice_input_enabled is not None: settings["voice_input_enabled"] = bool(voice_input_enabled)
        if voice_input_confirm_transcript is not None: settings["voice_input_confirm_transcript"] = bool(voice_input_confirm_transcript)
        if voice_input_timeout_minutes is not None: settings["voice_input_timeout_minutes"] = int(voice_input_timeout_minutes)
        if voice_input_silence_seconds is not None: settings["voice_input_silence_seconds"] = float(voice_input_silence_seconds)
        if voice_input_min_seconds is not None: settings["voice_input_min_seconds"] = float(voice_input_min_seconds)
        if voice_input_max_seconds is not None: settings["voice_input_max_seconds"] = float(voice_input_max_seconds)
        if voice_input_stt_model is not None: settings["voice_input_stt_model"] = voice_input_stt_model
        settings = _normalize_discord_bot_settings(settings)
        return room_manager.update_room_override_nested(room_name, "discord_bot_settings", settings)
    except Exception as e:
        print(f"Discord Bot個別設定の保存に失敗しました ({room_name}): {e}")
        return False

def get_enabled_discord_bot_configs(include_global: bool = True) -> List[dict]:
    """起動対象のDiscord Bot設定を列挙する。"""
    configs = []
    if include_global:
        global_settings = get_global_discord_bot_settings()
        if global_settings.get("enabled") and global_settings.get("token"):
            configs.append({
                "room_name": global_settings.get("linked_room"),
                "settings": global_settings,
                "scope": "global",
            })
    try:
        import os
        import constants
        if os.path.isdir(constants.ROOMS_DIR):
            for room_name in sorted(os.listdir(constants.ROOMS_DIR)):
                room_dir = os.path.join(constants.ROOMS_DIR, room_name)
                if not os.path.isdir(room_dir):
                    continue
                settings = get_room_discord_bot_settings(room_name)
                if settings.get("enabled") and settings.get("token"):
                    configs.append({
                        "room_name": room_name,
                        "settings": settings,
                        "scope": "room",
                    })
    except Exception as e:
        print(f"Discord Bot設定の列挙に失敗しました: {e}")
    return configs

def find_duplicate_discord_bot_tokens(room_name: str, token: str) -> List[str]:
    """同じBotトークンを使っている他設定を返す。"""
    if not token:
        return []
    duplicates = []
    try:
        for cfg in get_enabled_discord_bot_configs(include_global=True):
            scope = cfg.get("scope", "global")
            if scope == "room" and cfg.get("room_name") == room_name:
                continue
            if cfg.get("settings", {}).get("token") == token:
                duplicates.append("global" if scope == "global" else (cfg.get("room_name") or "unknown"))
    except Exception:
        pass
    return duplicates

def can_migrate_global_discord_bot_token_to_room(room_name: str, token: str) -> Tuple[bool, str]:
    """旧共通Discord Bot設定を指定ルームへ移行できるか判定する。"""
    if not room_name:
        return False, "ルームが選択されていません。"
    if not token:
        return False, "Botトークンが空です。"

    global_settings = get_global_discord_bot_settings()
    if not global_settings.get("enabled") or not global_settings.get("token"):
        return False, "共通Discord Bot設定が有効ではありません。"
    if global_settings.get("token") != token:
        return False, "共通Discord Bot設定とは異なるトークンです。"

    linked_room = global_settings.get("linked_room")
    if linked_room and linked_room != room_name:
        return False, f"共通Discord Botは別ルーム「{linked_room}」に紐付いています。"

    room_settings = get_room_discord_bot_settings(room_name)
    existing_room_token = room_settings.get("token")
    if room_settings.get("enabled") and existing_room_token and existing_room_token != token:
        return False, "対象ルームには別のBotトークンが設定済みです。"

    return True, ""

def disable_global_discord_bot_settings_for_migration() -> bool:
    """ペルソナ個別Botへの移行後、旧共通Discord Bot設定を無効化する。"""
    try:
        settings = _normalize_discord_bot_settings(CONFIG_GLOBAL.get("discord_bot_settings", {}))
        settings["enabled"] = False
        CONFIG_GLOBAL["discord_bot_settings"] = settings
        _save_config_file(CONFIG_GLOBAL)
        load_config()
        return True
    except Exception as e:
        print(f"Discord Bot共通設定の移行無効化に失敗しました: {e}")
        return False

def migrate_global_discord_bot_settings_to_room(room_name: str) -> Tuple[bool, str]:
    """旧共通Discord Bot設定をユーザーが選択したルームへ移行する。"""
    if not room_name:
        return False, "移行先ルームが選択されていません。"

    global_settings = get_global_discord_bot_settings()
    global_token = global_settings.get("token")
    if not global_token:
        return False, "旧共通Discord Bot設定にBotトークンがありません。"

    room_settings = get_room_discord_bot_settings(room_name)
    room_token = room_settings.get("token")
    if room_token and room_token != global_token:
        return False, f"ルーム「{room_name}」には別のBotトークンが設定済みです。"

    saved = save_room_discord_bot_settings(
        room_name=room_name,
        enabled=global_settings.get("enabled", False),
        token=global_token,
        authorized_user_ids=global_settings.get("authorized_user_ids", []),
        allowed_channel_ids=global_settings.get("allowed_channel_ids", []),
        default_channel_id=global_settings.get("default_channel_id", ""),
        mention_only=global_settings.get("mention_only", False),
        channel_response_modes=global_settings.get("channel_response_modes", {}),
        allow_autonomous_send=global_settings.get("allow_autonomous_send", False),
        persona_webhook_url=global_settings.get("persona_webhook_url", ""),
        approval_command_allowlist=global_settings.get("approval_command_allowlist", []),
    )
    if not saved:
        return False, f"ルーム「{room_name}」への保存に失敗しました。"

    if not disable_global_discord_bot_settings_for_migration():
        return False, "ルームへの移行は完了しましたが、旧共通設定の無効化に失敗しました。"

    return True, f"旧共通Discord Bot設定をルーム「{room_name}」へ移行し、旧共通Botを無効化しました。"

def copy_global_discord_common_settings_to_room(room_name: str) -> Tuple[bool, str]:
    """旧共通Discord Bot設定から、Botトークン以外の共通項目だけをルームへコピーする。"""
    if not room_name:
        return False, "コピー先ルームが選択されていません。"

    global_settings = get_global_discord_bot_settings()
    if not CONFIG_GLOBAL.get("discord_bot_settings"):
        return False, "旧共通Discord Bot設定が見つかりません。"

    saved = save_room_discord_bot_settings(
        room_name=room_name,
        authorized_user_ids=global_settings.get("authorized_user_ids", []),
        allowed_channel_ids=global_settings.get("allowed_channel_ids", []),
        default_channel_id=global_settings.get("default_channel_id", ""),
        mention_only=global_settings.get("mention_only", False),
        channel_response_modes=global_settings.get("channel_response_modes", {}),
        allow_autonomous_send=global_settings.get("allow_autonomous_send", False),
        persona_webhook_url=global_settings.get("persona_webhook_url", ""),
        approval_command_allowlist=global_settings.get("approval_command_allowlist", []),
    )
    if not saved:
        return False, f"ルーム「{room_name}」への共通項目コピーに失敗しました。"
    return True, f"旧共通Discord Bot設定の共通項目をルーム「{room_name}」へコピーしました。Botトークンは変更していません。"

def save_discord_bot_settings(enabled: bool = None, token: str = None, authorized_user_ids: List[str] = None, linked_room: str = None, allowed_channel_ids: List[str] = None, default_channel_id: str = None, mention_only: bool = None, channel_response_modes: Dict[str, str] = None, allow_autonomous_send: bool = None, persona_webhook_url: str = None, approval_command_allowlist: List[str] = None):
    """Discord Botの設定を保存する"""
    global CONFIG_GLOBAL
    settings = _normalize_discord_bot_settings(CONFIG_GLOBAL.get("discord_bot_settings", {}))
    
    if enabled is not None: settings["enabled"] = enabled
    if token is not None: settings["token"] = token
    if authorized_user_ids is not None: settings["authorized_user_ids"] = authorized_user_ids
    if linked_room is not None: settings["linked_room"] = linked_room
    if allowed_channel_ids is not None: settings["allowed_channel_ids"] = allowed_channel_ids
    if default_channel_id is not None: settings["default_channel_id"] = default_channel_id
    if mention_only is not None: settings["mention_only"] = bool(mention_only)
    if channel_response_modes is not None: settings["channel_response_modes"] = channel_response_modes
    if allow_autonomous_send is not None: settings["allow_autonomous_send"] = bool(allow_autonomous_send)
    if persona_webhook_url is not None: settings["persona_webhook_url"] = persona_webhook_url
    if approval_command_allowlist is not None: settings["approval_command_allowlist"] = approval_command_allowlist
    
    CONFIG_GLOBAL["discord_bot_settings"] = settings
    _save_config_file(CONFIG_GLOBAL)
    load_config()
    
def save_line_bot_settings(enabled: bool = None, token: str = None, secret: str = None, authorized_user_ids: List[str] = None, linked_room: str = None):
    """LINE Botの設定を保存する"""
    global CONFIG_GLOBAL
    
    if enabled is not None: CONFIG_GLOBAL["line_bot_enabled"] = enabled
    if token is not None: CONFIG_GLOBAL["line_channel_access_token"] = token
    if secret is not None: CONFIG_GLOBAL["line_channel_secret"] = secret
    if authorized_user_ids is not None: CONFIG_GLOBAL["line_authorized_user_ids"] = authorized_user_ids
    if linked_room is not None: CONFIG_GLOBAL["line_bot_linked_room"] = linked_room
    
    _save_config_file(CONFIG_GLOBAL)
    load_config() # グローバル変数を再反映


def save_api_gateway_settings(
    enabled: bool = None,
    host: str = None,
    port: int = None,
    require_auth: bool = None,
    auth_token: str = None,
    auto_start_tailscale_serve: bool = None,
) -> bool:
    """REST API Gatewayの設定を保存する。"""
    settings = {
        "enabled": False,
        "host": "0.0.0.0",
        "port": 8000,
        "require_auth": True,
        "auth_token": "",
        "auto_start_tailscale_serve": False,
        "rate_limit_enabled": True,
        "rate_limit_window_seconds": 60,
        "rate_limit_general_per_minute": 240,
        "rate_limit_events_per_minute": 60,
        "rate_limit_heavy_per_minute": 30,
        "audit_enabled": True,
        "event_notification_default_cooldown_seconds": 300,
        "event_notification_cooldowns": {},
        "response_notification_preview_enabled": True,
    }
    settings.update(CONFIG_GLOBAL.get("api_gateway_settings", {}) or {})

    if enabled is not None:
        settings["enabled"] = bool(enabled)
    if host is not None:
        settings["host"] = (host or "").strip() or "0.0.0.0"
    if port is not None:
        settings["port"] = int(port or 8000)
    if require_auth is not None:
        settings["require_auth"] = bool(require_auth)
    if auth_token is not None:
        settings["auth_token"] = (auth_token or "").strip()
    if auto_start_tailscale_serve is not None:
        settings["auto_start_tailscale_serve"] = bool(auto_start_tailscale_serve)

    return bool(save_config_if_changed("api_gateway_settings", settings))


def save_atelier_serve_settings(
    enabled: bool = None,
    host: str = None,
    port: int = None,
    tailscale_https_port: int = None,
    auto_start_tailscale_serve: bool = None,
    api_integration_enabled: bool = None,
    api_origin: str = None,
) -> bool:
    """アトリエ静的配信サーバの設定を保存する。"""
    settings = {
        "enabled": False,
        "host": "0.0.0.0",
        "port": 8765,
        "tailscale_https_port": 8443,
        "auto_start_tailscale_serve": False,
        "api_integration_enabled": False,
        "api_origin": "",
    }
    settings.update(CONFIG_GLOBAL.get("atelier_serve_settings", {}) or {})

    if enabled is not None:
        settings["enabled"] = bool(enabled)
    if host is not None:
        settings["host"] = (host or "").strip() or "0.0.0.0"
    if port is not None:
        settings["port"] = int(port or 8765)
    if tailscale_https_port is not None:
        settings["tailscale_https_port"] = int(tailscale_https_port or 8443)
    if auto_start_tailscale_serve is not None:
        settings["auto_start_tailscale_serve"] = bool(auto_start_tailscale_serve)
    if api_integration_enabled is not None:
        settings["api_integration_enabled"] = bool(api_integration_enabled)
    if api_origin is not None:
        settings["api_origin"] = (api_origin or "").strip().rstrip("/")

    return bool(save_config_if_changed("atelier_serve_settings", settings))


def is_image_generation_model(model_name: str) -> bool:
    """画像生成用モデルを従来の image 名と Gemini の新しい系列名で判定する。"""
    if not model_name:
        return False
    normalized = model_name.strip().lower()
    if "image" in normalized:
        return True
    # Nano Banana は image を含まない。数値版と既知の版接尾辞だけを
    # 許可し、同名系列の text/embedding や他プロバイダの名前とは区別する。
    model_id = normalized.removeprefix("models/")
    return re.fullmatch(
        r"gemini-nano-banana-\d+(?:\.\d+)*(?:-(?:\d+|preview|exp|latest))*",
        model_id,
    ) is not None

def get_key_name_by_value(key_value: str) -> str:
    """APIキーの値を元に、対応するキー設定名を取得する"""
    for k, v in GEMINI_API_KEYS.items():
        if v == key_value:
            return k
    return "Unknown"


def is_paid_api_key_name(key_name: str) -> bool:
    """Gemini APIキー名が有料キーとして登録されているか返す。"""
    names = CONFIG_GLOBAL.get("paid_api_key_names", []) if isinstance(CONFIG_GLOBAL, dict) else []
    return bool(key_name) and key_name in names
