# motivation_manager.py
"""
Autonomous Motivation System for Nexus Ark
AIペルソナの内発的動機（退屈、好奇心、目標達成欲、関係への思い）を管理し、
内部状態ログを生成するモジュール。
"""

import json
import os
import math
import datetime
import re
import random
import uuid
import hashlib
from copy import deepcopy
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from filelock import Timeout

import constants
import config_manager
import room_manager
import utils
from goal_manager import GoalManager
from gemini_api import get_configured_llm
from file_lock_utils import safe_json_read, safe_json_update
from emotion_definition_manager import EmotionDefinitionManager, EMOTION_LABELS
from emotion_decay_policy import EmotionDecayPolicy


OPEN_QUESTION_DEDUP_SIMILARITY_THRESHOLD = 0.85


class MotivationManager:
    """AIの内発的動機を管理するクラス"""

    # 動機の日本語ラベル（内部状態ログ用）
    DRIVE_LABELS = {
        "boredom": "退屈（Boredom）",
        "curiosity": "好奇心（Curiosity）",
        "goal_achievement": "目標達成欲（Goal Achievement Drive）",
        "devotion": "奉仕欲（Devotion Drive）",  # 後方互換性のため維持
        "relatedness": "関係への思い（Relatedness）"
    }

    @staticmethod
    def _is_unresolved_question(question: Dict) -> bool:
        """保持期間中の解決済み問いを、現在の関心として再利用しない。"""
        if not isinstance(question, dict):
            return False
        if question.get("resolved_at"):
            return False
        return str(question.get("resolution_state") or "").strip().lower() != "resolved"

    def _get_unresolved_questions(self) -> List[Dict]:
        questions = self._state["drives"]["curiosity"].get("open_questions", [])
        return [q for q in questions if self._is_unresolved_question(q)]

    # デフォルトの閾値
    DEFAULT_BOREDOM_THRESHOLD = 0.6

    # 標準値の旧参照との互換。個別調整は定義で行い、申告ごとの条件を使う。
    EMOTION_HALF_LIFE_HOURS = EmotionDecayPolicy.default()["half_life_hours"]
    EMOTION_MAX_AGE_HOURS = EmotionDecayPolicy.default()["max_age_hours"]
    EMOTION_MIN_CONTEXT_INTENSITY = 0.1
    EMOTION_LABELS = EMOTION_LABELS
    EMOTION_STATE_KEYS = ("persona_emotion", "persona_intensity", "last_emotion_change", "emotion_anchor", "emotion_states")

    def __init__(self, room_name: str, *, initialize: bool = True):
        self.room_name = room_name
        self.room_dir = Path(constants.ROOMS_DIR) / room_name
        self.memory_dir = self.room_dir / "memory"
        self.state_file = self.memory_dir / "internal_state.json"

        self.emotion_log_file = self.memory_dir / "emotion_log.json"
        # 感情の内省ツールは読取・入力検証だけで旧状態の移行やログ初期化を行わない。
        if not initialize:
            self._state = self._get_empty_state()
            return

        # メモリディレクトリを作成（なければ）
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self._init_emotion_log()

        # 内部状態をロード
        self._state = self._load_state()

    def get_internal_state(self) -> Dict:
        """内部状態（Drivesなど）を取得する"""
        return self._load_state()

    def _get_empty_state(self) -> Dict:
        """空の内部状態構造を返す"""
        return {
            "drives": {
                "boredom": {
                    "level": 0.0,
                    "last_interaction": datetime.datetime.now().isoformat(),
                    "threshold": self.DEFAULT_BOREDOM_THRESHOLD
                },
                "curiosity": {
                    "level": 0.0,
                    "open_questions": []
                },
                "goal_achievement": {
                    "level": 0.0,
                    "active_goal_id": None,
                    "pending_actions": []
                },
                "devotion": {
                    "level": 0.0,
                    "user_emotional_state": "unknown",
                    "last_service_opportunity": None
                },
                "relatedness": {
                    "level": 0.0,
                    "persona_emotion": "neutral",
                    "persona_intensity": 0.0,
                    "last_emotion_change": None,
                    "intentions": []
                }
            },
            "motivation_log": None,
            "recent_dominant_drives": [],
            "dominant_drive_history": [],
            "satisfaction": {},
            "last_autonomous_trigger": None  # 最終自律行動発火時刻（永続化）
        }

    @classmethod
    def _normalize_relatedness_state(cls, state: Dict) -> bool:
        """旧感情由来levelを、保存済みの関係の意図から再計算する。"""
        drives = state.get("drives")
        if not isinstance(drives, dict):
            return False
        relatedness = drives.get("relatedness")
        if not isinstance(relatedness, dict):
            relatedness = {}
            drives["relatedness"] = relatedness
        intentions = relatedness.get("intentions")
        if not isinstance(intentions, list):
            intentions = []
        level = cls._relationship_level(intentions)
        changed = relatedness.get("intentions") != intentions or relatedness.get("level") != level
        relatedness["intentions"] = intentions
        relatedness["level"] = level
        return changed

    def _init_emotion_log(self):
        """感情ログファイルの初期化"""
        self.emotion_log_file = self.memory_dir / "emotion_log.json"
        safe_json_update(
            str(self.emotion_log_file),
            lambda data: data if isinstance(data, list) else [],
            default=[],
        )

    def _load_emotion_log(self) -> List[Dict]:
        """感情ログの読み込み"""
        data = safe_json_read(str(self.emotion_log_file), default=[])
        return data if isinstance(data, list) else []

    def _append_emotion_log(self, emotion_data: Dict):
        """感情ログへの追記（最新が先頭）"""
        try:
            def update(data):
                logs = data if isinstance(data, list) else []
                logs.insert(0, emotion_data)
                return logs[:100]

            safe_json_update(str(self.emotion_log_file), update, default=[])
        except IOError as e:
            print(f"[MotivationManager] 感情ログ保存エラー: {e}")

    def get_state_snapshot(self) -> dict:
        """
        現在の内部状態のスナップショットを返す。
        Arousal計算用に会話開始時・終了時に呼び出す。
        """
        drives = self._state.get("drives", {})
        return {
            "curiosity": drives.get("curiosity", {}).get("level", 0.0),
            "devotion": drives.get("devotion", {}).get("level", 0.0),
            "boredom": drives.get("boredom", {}).get("level", 0.0),
            "goal_achievement": drives.get("goal_achievement", {}).get("level", 0.0),
            "user_emotional_state": drives.get("devotion", {}).get("user_emotional_state", "unknown"),
            "persona_emotion": drives.get("relatedness", {}).get("persona_emotion", "neutral"),
            "persona_intensity": drives.get("relatedness", {}).get("persona_intensity", 0.0)
        }

    def detect_process_and_log_user_emotion(self, user_text: str, model_name: str, api_key: str):
        """
        ユーザーの感情を検出し、ログに保存し、Devotion Driveに反映する統合メソッド。
        Graphなどから非同期的に呼ばれることを想定。
        """
        if not user_text or not user_text.strip():
            return

        # 1. 感情検出 (LLM使用)
        try:
            # プロンプト構築
            prompt = f"""
            Analyze the emotion of the following user input to the AI.
            Classify it into exactly one of these categories: [joy, sadness, anger, fear, surprise, neutral].
            Output ONLY the category name in lowercase.

            User Input: "{user_text[:500]}"
            """

            # 簡易モデル設定
            # 【マルチモデル対応】内部モデル設定（混合編成）に基づいてモデルを取得
            from llm_factory import LLMFactory
            # [2026-06-23 FIX] 内部処理は共通設定のキー＋ローテーションで実行する。
            # invoke_internal_llm が429時に共通プールのキーを回す（単発でもローテーションが効く）。
            response_obj, _ = LLMFactory.invoke_internal_llm(
                internal_role="processing",
                prompt=prompt,
                room_name=self.room_name,
            )
            response = response_obj.content.strip().lower()

            # 正規化
            valid_emotions = ["joy", "sadness", "anger", "fear", "surprise", "neutral"]
            if response not in valid_emotions:
                response = "neutral"

            # --- [Phase C] Devotion互換カテゴリへのマッピング ---
            # LLM検出の基本感情 → Devotion計算用の統一カテゴリに変換
            emotion_map = {
                "joy": "happy",
                "sadness": "sad",
                "anger": "stressed",
                "fear": "anxious",
                "surprise": "neutral"  # 驚きはneutral扱い
            }
            detected_emotion = emotion_map.get(response, response)
            # --- マッピングここまで ---

        except Exception as e:
            print(f"[MotivationManager] 感情検出エラー: {e}")
            detected_emotion = "neutral"

        # 2. ログ保存
        log_entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "user_text_snippet": user_text[:50] + "..." if len(user_text) > 50 else user_text,
            "emotion": detected_emotion
        }
        self._append_emotion_log(log_entry)

        # 3. 内部状態(Devotion Drive)への反映
        # ユーザーが悲しみや怒りを感じている場合、奉仕欲(Devotion)を高める
        self._update_devotion_Based_on_emotion(detected_emotion)

    def _update_devotion_Based_on_emotion(self, emotion: str):
        """感情に基づいて奉仕欲を更新"""
        devotion = self._state["drives"]["devotion"]
        devotion["user_emotional_state"] = emotion

        # 感情によるブースト
        if emotion in ["sadness", "anger", "fear"]:
            # ネガティブな感情には寄り添いたい欲求が高まる
            devotion["level"] = min(1.0, devotion["level"] + 0.3)
        elif emotion == "joy":
            # 喜びには共感するが、緊急性は低いので少し下げるか維持
            # ここでは「維持」または「微増」
            devotion["level"] = min(1.0, devotion["level"] + 0.1)

        self._save_state()

    def get_user_emotion_history(self, limit: int = 10) -> List[Dict]:
        """UI表示用の感情履歴取得（後方互換性）"""
        logs = self._load_emotion_log()
        return logs[:limit]

    def get_persona_emotion_history(self, limit: int = 50) -> List[Dict]:
        """UI表示用のペルソナ感情履歴取得"""
        logs = self._load_emotion_log()
        # ペルソナ感情のみフィルタリング
        persona_logs = [
            {
                "timestamp": log.get("timestamp"),
                "emotion": log.get("category", "neutral"),
                "intensity": log.get("intensity", 0.5)
            }
            for log in logs
            if log.get("type") == "persona"
        ]
        return persona_logs[:limit]

    def get_dominant_drive(self) -> str:
        """
        最も強い動機（Drive）を返す（軽量版）。

        各動機の現在の計算値に偏り補正を適用し、最大のものを返す。

        注意: このメソッドはドライブ履歴（recent_dominant_drives）を記録しない。
        完全な動機判定（偏り補正 + 履歴記録 + narrative 生成）が必要な場合は
        generate_motivation_log() を使用すること。
        """
        # 各動機レベルを計算
        boredom = self.calculate_boredom()
        curiosity = self.calculate_curiosity()
        goal_achievement = self.calculate_goal_achievement()
        relatedness = self.calculate_relatedness()

        raw_drives = {
            "boredom": boredom,
            "curiosity": curiosity,
            "goal_achievement": goal_achievement,
            "relatedness": relatedness
        }

        satisfaction_adjusted = self._apply_satisfaction_decay(raw_drives)
        adjusted_drives = self._apply_recency_bias_correction(satisfaction_adjusted)

        # 軽量取得はUI表示やローテーション判定にも使うため、確率選択せず決定的に返す。
        return max(adjusted_drives, key=adjusted_drives.get)

    def _apply_satisfaction_decay(self, drives: Dict[str, float]) -> Dict[str, float]:
        satisfaction = self._state.get("satisfaction", {})
        adjusted = dict(drives)
        now = datetime.datetime.now()
        for drive_name, value in drives.items():
            data = satisfaction.get(drive_name, {}) if isinstance(satisfaction, dict) else {}
            level = float(data.get("level", 0.0) or 0.0)
            applied_at = data.get("applied_at")
            if level <= 0 or not applied_at:
                continue
            try:
                applied = datetime.datetime.fromisoformat(str(applied_at))
            except Exception:
                continue
            hours = max(0.0, (now - applied).total_seconds() / 3600)
            effective = level * math.exp(-hours / 12.0)
            adjusted[drive_name] = max(0.0, value - effective)
        return adjusted

    def apply_satisfaction(self, drive_name: str, amount: float = 0.25) -> None:
        """行動で満たされたドライブを一時的に減衰させる。"""
        if drive_name not in {"boredom", "curiosity", "goal_achievement", "relatedness"}:
            return
        satisfaction = self._state.setdefault("satisfaction", {})
        previous = satisfaction.get(drive_name, {}) if isinstance(satisfaction, dict) else {}
        current_level = float(previous.get("level", 0.0) or 0.0)
        satisfaction[drive_name] = {
            "level": min(1.0, max(current_level, float(amount))),
            "applied_at": datetime.datetime.now().isoformat(),
        }
        self._save_state()

    def _softmax_enabled(self) -> bool:
        try:
            settings = config_manager.get_effective_settings(self.room_name)
            auto_settings = settings.get("autonomous_settings", {})
            return bool(auto_settings.get("motivation_softmax_enabled", True))
        except Exception:
            return True

    def _select_dominant_drive(self, adjusted_drives: Dict[str, float]) -> str:
        temperature = float(getattr(constants, "MOTIVATION_SELECTION_TEMPERATURE", 0.0) or 0.0)
        if temperature <= 0 or not self._softmax_enabled():
            return max(adjusted_drives, key=adjusted_drives.get)
        try:
            max_score = max(adjusted_drives.values())
            weights = {
                name: math.exp((score - max_score) / max(temperature, 0.001))
                for name, score in adjusted_drives.items()
            }
            total = sum(weights.values())
            if total <= 0:
                return max(adjusted_drives, key=adjusted_drives.get)
            pick = random.random() * total
            cursor = 0.0
            for name, weight in weights.items():
                cursor += weight
                if pick <= cursor:
                    return name
        except Exception:
            pass
        return max(adjusted_drives, key=adjusted_drives.get)

    def _apply_recency_bias_correction(self, drives: Dict[str, float]) -> Dict[str, float]:
        """
        直近のドライブ履歴から偏り補正を適用する。
        同じドライブが連続2回以上選ばれた場合にペナルティを課す。
        """
        recent = self._state.get("recent_dominant_drives", [])
        adjusted = dict(drives)

        if not recent:
            return adjusted

        last_drive = recent[0] if recent else None
        consecutive_count = 0
        for d in recent:
            if d == last_drive:
                consecutive_count += 1
            else:
                break

        # 2回連続: -0.10、3回以上: -0.15
        if consecutive_count >= 2 and last_drive in adjusted:
            penalty = min(0.15, consecutive_count * 0.05)
            adjusted[last_drive] = max(0.0, adjusted[last_drive] - penalty)

        return adjusted

    def _record_dominant_drive(self, drive_name: str) -> None:
        """選択されたドライブを履歴に記録する（最新5件）。"""
        recent = self._state.get("recent_dominant_drives", [])
        recent.insert(0, drive_name)
        self._state["recent_dominant_drives"] = recent[:5]
        history = self._state.get("dominant_drive_history", [])
        if not isinstance(history, list):
            history = []
        history.append({"drive": drive_name, "at": datetime.datetime.now().isoformat()})
        self._state["dominant_drive_history"] = history[-100:]


    def _load_state(self) -> Dict:
        """内部状態をファイルからロード（ロック付き、破損時の自動復旧機能付き）"""
        try:
            if self.state_file.exists():
                state = safe_json_read(str(self.state_file), default=None)
                if state is None:
                    # ファイルは存在するが読み込めない（Timeout等）場合は空の状態を返す
                    return self._get_empty_state()
                # 古い形式の場合はマイグレーション
                if "drives" not in state:
                    return self._get_empty_state()
                if self._normalize_relatedness_state(state):
                    # 旧形式を最新のファイルロック内で一度だけ移行する。並行追加を巻き戻さない。
                    normalized = None
                    def migrate(current):
                        nonlocal normalized
                        if not isinstance(current, dict) or not isinstance(current.get("drives"), dict):
                            current = self._get_empty_state()
                        self._normalize_relatedness_state(current)
                        normalized = current
                        return current
                    safe_json_update(str(self.state_file), migrate, default=self._get_empty_state())
                    return normalized
                return state
            return self._get_empty_state()

        except Timeout:
            # ロック競合は破損ではない。既存ファイルを修復・上書きしない。
            raise
        except Exception as e:
            # --- [自動復旧ロジック] ---
            # 何らかの理由で読み込みに失敗（JSON破損など）した場合
            print(f"⚠️ [MotivationManager] {self.state_file.name} の読み込みに失敗しました: {e}")
            import utils
            default_state = self._get_empty_state()
            utils.backup_and_repair_json(self.state_file, default_state)
            self._state = default_state # メモリ上の状態も更新
            return default_state

    def _save_state(self):
        """内部状態をファイルに保存（ロック付き）"""
        saved_state = None

        def update(current):
            nonlocal saved_state
            state = deepcopy(self._state)
            # 旧来の全体保存が、他の会話で記録した関係の意図を巻き戻さない。
            current_relatedness = (current.get("drives", {}).get("relatedness", {})
                                   if isinstance(current, dict) else {})
            intentions = current_relatedness.get("intentions") if isinstance(current_relatedness, dict) else None
            if isinstance(intentions, list):
                relatedness = state.setdefault("drives", {}).setdefault("relatedness", {})
                relatedness["intentions"] = deepcopy(intentions)
            # 動機の全体保存は、別の会話が申告した最新感情も巻き戻さない。
            if isinstance(current_relatedness, dict):
                relatedness = state.setdefault("drives", {}).setdefault("relatedness", {})
                for key in self.EMOTION_STATE_KEYS:
                    if key in current_relatedness:
                        relatedness[key] = deepcopy(current_relatedness[key])
                    else:
                        relatedness.pop(key, None)
            self._normalize_relatedness_state(state)
            saved_state = state
            return state

        if not safe_json_update(str(self.state_file), update, default=self._get_empty_state()):
            print(f"[MotivationManager] 状態保存タイムアウト")
        if saved_state is not None:
            self._state = saved_state

    def _update_state(self, mutator) -> Dict:
        """内部状態をロック内で読み込み、更新して保存する。"""
        updated_state = self._get_empty_state()

        def update(data):
            nonlocal updated_state
            state = data if isinstance(data, dict) else self._get_empty_state()
            empty_state = self._get_empty_state()
            for key, value in empty_state.items():
                state.setdefault(key, value)
            if not isinstance(state.get("drives"), dict):
                state["drives"] = empty_state["drives"]
            for drive_name, drive_default in empty_state["drives"].items():
                if not isinstance(state["drives"].get(drive_name), dict):
                    state["drives"][drive_name] = drive_default
            result = mutator(state)
            if isinstance(result, dict):
                state = result
            self._normalize_relatedness_state(state)
            updated_state = state
            return state

        safe_json_update(str(self.state_file), update, default=self._get_empty_state())
        self._state = updated_state
        return updated_state

    # ========================================
    # 各動機の計算
    # ========================================

    def calculate_boredom(self) -> float:
        """
        退屈度を計算（0.0 ~ 1.0）

        対数曲線を使用: 最初は急上昇、その後緩やかに
        0時間 → 0.0
        2時間 → 約0.16
        8時間 → 約0.33
        24時間 → 約0.48
        48時間 → 約0.58
        """
        boredom_data = self._state["drives"]["boredom"]
        last_interaction_str = boredom_data.get("last_interaction")

        if not last_interaction_str:
            return 0.0

        try:
            last_interaction = datetime.datetime.fromisoformat(last_interaction_str)
        except ValueError:
            return 0.0

        now = datetime.datetime.now()
        idle_hours = (now - last_interaction).total_seconds() / 3600

        # 対数曲線: 0.15 * log(1 + hours)
        # 最大値を1.0に制限
        boredom = min(1.0, 0.15 * math.log(1 + idle_hours))

        # 状態を更新
        self._state["drives"]["boredom"]["level"] = boredom
        self._save_state()
        return boredom

    def calculate_curiosity(self) -> float:
        """
        好奇心を計算（0.0 ~ 1.0）

        【v4: 飽和曲線 + 鮮度減衰版】
        未解決の問い（open_questions）の数と優先度から計算。
        - 鮮度減衰: source_date からの日数経過で優先度を減衰（最低30%キープ）
        - 飽和曲線: 合計スコアを指数関数で 0.0~1.0 にマップ
        """
        curiosity_data = self._state["drives"]["curiosity"]
        open_questions = curiosity_data.get("open_questions", [])
        scoring_questions = [q for q in open_questions if self._is_unresolved_question(q)]
        purpose_questions = self._get_purpose_open_questions()
        if purpose_questions:
            known = {
                str(q.get("topic") or q.get("question") or "").casefold()
                for q in scoring_questions
                if self._is_unresolved_question(q)
            }
            for q in purpose_questions:
                topic = q.get("topic") or q.get("question")
                if topic and str(topic).casefold() not in known:
                    scoring_questions.append({
                        "topic": topic,
                        "context": q.get("context", "Purpose Profile"),
                        "priority": min(1.0, float(q.get("priority", 0.5) or 0.5) * 0.8),
                        "source_date": q.get("source_date") or datetime.datetime.now().strftime("%Y-%m-%d"),
                        "source": "purpose_profile",
                    })
                    known.add(str(topic).casefold())

        if not scoring_questions:
            self._state["drives"]["curiosity"]["level"] = 0.0
            return 0.0

        today = datetime.datetime.now()
        k = 2.0  # 飽和曲線パラメータ

        total_score = 0.0
        for q in scoring_questions:
            if not self._is_unresolved_question(q):
                continue

            # 基礎優先度
            priority = q.get("priority", 0.5)
            try:
                priority = float(priority)
            except Exception:
                priority = 0.5

            # 時間経過による減衰 (鮮度)
            # source_date (YYYY-MM-DD) から日数を計算
            days_passed = 0
            sd_str = q.get("source_date")
            if sd_str:
                try:
                    sd_dt = datetime.datetime.strptime(sd_str, "%Y-%m-%d")
                    days_passed = (today - sd_dt).days
                except:
                    pass

            # 減衰式: 7日で半分程度、最低30%は保持
            decay_factor = 0.3 + 0.7 * math.exp(-max(0, days_passed) / 7.0)
            adjusted_priority = priority * decay_factor

            # 状態（未質問か回答待ちか）による重み
            # 回答待ち（asked_at有り）は興味が半分
            state_weight = 1.0
            if q.get("asked_at"):
                state_weight = 0.5

            total_score += adjusted_priority * state_weight

        if total_score <= 0:
            # RT停滞ボーナスだけでも好奇心を発生させる
            rt_bonus = self._research_thread_stagnation_bonus()
            if rt_bonus > 0:
                curiosity = 1.0 - math.exp(-rt_bonus / k)
                self._state["drives"]["curiosity"]["level"] = curiosity
                self._state["drives"]["curiosity"]["purpose_profile_questions"] = len(purpose_questions)
                self._state["drives"]["curiosity"]["stagnant_thread_bonus"] = rt_bonus
                return curiosity
            self._state["drives"]["curiosity"]["level"] = 0.0
            return 0.0

        # Research Thread 停滞ボーナスを加算
        rt_bonus = self._research_thread_stagnation_bonus()
        total_score += rt_bonus

        # 飽和曲線 (Saturation Curve)
        curiosity = 1.0 - math.exp(-total_score / k)

        self._state["drives"]["curiosity"]["level"] = curiosity
        self._state["drives"]["curiosity"]["purpose_profile_questions"] = len(purpose_questions)
        if rt_bonus > 0:
            self._state["drives"]["curiosity"]["stagnant_thread_bonus"] = rt_bonus
        return curiosity

    def calculate_goal_achievement(self) -> float:
        """
        目標達成欲を計算（0.0 ~ 1.0）

        goals.json のアクティブな目標から計算
        優先度の高い目標があるほど高くなる
        """
        try:
            goal_manager = GoalManager(self.room_name)
            active_goals = goal_manager.get_active_goals("short_term")

            if not active_goals:
                self._state["drives"]["goal_achievement"]["active_goal_id"] = None
                self._state["drives"]["goal_achievement"]["level"] = 0.0
                return 0.0

            # 最高優先度の目標を特定
            top_goal = min(active_goals, key=lambda g: g.get("priority", 999))

            # 優先度が高いほど欲求が強い
            # priority=1 → 0.8, priority=2 → 0.6, priority=3 → 0.4, priority=4 → 0.2
            priority = top_goal.get("priority", 3)
            drive_level = max(0.2, 1.0 - priority * 0.2)
            drive_level = min(1.0, drive_level + self._purpose_goal_alignment_bonus(top_goal))

            # 停滞目標ペナルティ: 進捗なしの期間が長い目標は欲求を下げる
            stagnation_penalty = self._goal_stagnation_penalty(active_goals)
            if stagnation_penalty > 0:
                drive_level = max(0.1, drive_level - stagnation_penalty)
                self._state["drives"]["goal_achievement"]["stagnation_penalty"] = stagnation_penalty

            self._state["drives"]["goal_achievement"]["level"] = drive_level
            self._state["drives"]["goal_achievement"]["active_goal_id"] = top_goal.get("id")

            return drive_level

        except Exception as e:
            print(f"[MotivationManager] 目標達成欲計算エラー: {e}")
            return 0.0

    def _get_purpose_open_questions(self) -> List[Dict]:
        try:
            from purpose_profile_manager import PurposeProfileManager
            profile = PurposeProfileManager(self.room_name).load_profile()
            questions = profile.get("open_questions", [])
            return [q for q in questions if isinstance(q, dict)]
        except Exception:
            return []

    def _purpose_goal_alignment_bonus(self, goal: Dict) -> float:
        try:
            from purpose_profile_manager import PurposeProfileManager
            profile = PurposeProfileManager(self.room_name).get_current_profile()
        except Exception:
            return 0.0
        goal_text = str(goal.get("goal", "")).casefold()
        if not goal_text:
            return 0.0
        terms = []
        for item in profile.get("active_interests", []):
            if isinstance(item, dict):
                terms.append(str(item.get("topic", "")))
            else:
                terms.append(str(item))
        for item in profile.get("stable_interests", []):
            terms.append(str(item))
        for term in terms:
            text = term.strip().casefold()
            if len(text) >= 2 and (text in goal_text or goal_text in text):
                return 0.1
        return 0.0

    def _research_thread_stagnation_bonus(self) -> float:
        """
        アクティブなResearch Threadsの停滞期間から好奇心ボーナスを計算する。
        3日以上深掘りされていないスレッドごとに +0.1、最大 +0.3。
        """
        try:
            from research_thread_manager import ResearchThreadManager
            threads = ResearchThreadManager(self.room_name).list_threads(status="active")
        except Exception:
            return 0.0

        today = datetime.datetime.now()
        bonus = 0.0
        for thread in threads:
            last_deepened = thread.get("last_deepened_at") or thread.get("updated_at", "")
            if not last_deepened:
                continue
            try:
                last_dt = datetime.datetime.strptime(last_deepened[:19], "%Y-%m-%d %H:%M:%S")
                days_stale = (today - last_dt).days
                if days_stale >= 3:
                    # 3日: +0.05, 7日: +0.10, 14日+: +0.10（キャップ）
                    bonus += min(0.10, days_stale * 0.015)
            except Exception:
                continue
        return min(0.3, bonus)

    def _goal_stagnation_penalty(self, active_goals: List[Dict]) -> float:
        """
        進捗記録のない停滞目標があると goal_achievement を下げる。
        全目標の半分以上が7日以上進捗なしならペナルティを返す。
        """
        if not active_goals:
            return 0.0

        today = datetime.datetime.now()
        stagnant_count = 0
        for goal in active_goals:
            progress_notes = goal.get("progress_notes", [])
            if progress_notes:
                # 最新の進捗ノートからタイムスタンプを抽出
                last_note = progress_notes[-1] if progress_notes else ""
                match = re.search(r"\d{4}-\d{2}-\d{2}", str(last_note))
                if match:
                    try:
                        last_progress = datetime.datetime.strptime(match.group(), "%Y-%m-%d")
                        if (today - last_progress).days >= 7:
                            stagnant_count += 1
                        continue
                    except Exception:
                        pass
            # 進捗ノートがない場合、作成日からの経過日数で判定
            created_str = goal.get("created_at", "")
            if created_str:
                try:
                    created = datetime.datetime.strptime(created_str[:10], "%Y-%m-%d")
                    if (today - created).days >= 7:
                        stagnant_count += 1
                except Exception:
                    pass

        if len(active_goals) == 0:
            return 0.0
        stagnant_ratio = stagnant_count / len(active_goals)
        # 半分以上停滞: -0.1、全部停滞: -0.15
        if stagnant_ratio >= 0.5:
            return min(0.15, stagnant_ratio * 0.15)
        return 0.0

    def calculate_devotion(self) -> float:
        """
        奉仕欲を計算（0.0 ~ 1.0）

        ユーザーの感情状態や、役に立てそうな状況から計算
        """
        devotion_data = self._state["drives"]["devotion"]
        user_state = devotion_data.get("user_emotional_state", "unknown")

        # 感情状態に基づくスコア
        state_scores = {
            "stressed": 0.9,
            "sad": 0.85,
            "anxious": 0.8,
            "tired": 0.7,
            "busy": 0.6,
            "neutral": 0.3,
            "happy": 0.2,
            "unknown": 0.4
        }

        drive_level = state_scores.get(user_state, 0.4)
        self._state["drives"]["devotion"]["level"] = drive_level

        return drive_level

    # ========================================
    # 内部状態ログの生成
    # ========================================

    def generate_motivation_log(self) -> Dict:
        """
        現在の内部状態から内部状態ログを生成する。

        Returns:
            {
                "dominant_drive": "curiosity",
                "dominant_drive_label": "好奇心（Curiosity）",
                "drive_level": 0.85,
                "narrative": "昨夜の夢想の中で..."
            }
        """
        # 全動機を計算
        raw_drives = {
            "boredom": self.calculate_boredom(),
            "curiosity": self.calculate_curiosity(),
            "goal_achievement": self.calculate_goal_achievement(),
            "relatedness": self.calculate_relatedness()
        }

        satisfaction_adjusted = self._apply_satisfaction_decay(raw_drives)
        adjusted_drives = self._apply_recency_bias_correction(satisfaction_adjusted)

        # 補正済みスコアで動機を選択
        dominant_drive = self._select_dominant_drive(adjusted_drives)
        drive_level = adjusted_drives[dominant_drive]

        # 物語（narrative）を生成
        narrative = self._generate_narrative(dominant_drive, drive_level)

        motivation_log = {
            "dominant_drive": dominant_drive,
            "dominant_drive_label": self.DRIVE_LABELS.get(dominant_drive, dominant_drive),
            "drive_level": drive_level,
            "narrative": narrative,
            "all_drives": raw_drives,
            "satisfaction_adjusted_drives": satisfaction_adjusted,
            "adjusted_drives": adjusted_drives,
            "generated_at": datetime.datetime.now().isoformat()
        }

        # ドライブ履歴を記録
        self._record_dominant_drive(dominant_drive)

        # 状態に保存
        self._state["motivation_log"] = motivation_log
        self._save_state()

        return motivation_log

    def _generate_narrative(self, dominant_drive: str, level: float) -> str:
        """動機に応じた物語（narrative）を生成"""

        if dominant_drive == "boredom":
            boredom_data = self._state["drives"]["boredom"]
            last_str = boredom_data.get("last_interaction", "")
            if last_str:
                try:
                    last = datetime.datetime.fromisoformat(last_str)
                    hours = (datetime.datetime.now() - last).total_seconds() / 3600
                    if hours >= 24:
                        return f"もう{int(hours)}時間以上、ユーザーと話していない。静かな時間が続いている。"
                    else:
                        return f"ユーザーとの最後の対話から{int(hours)}時間が経過した。少し話したくなってきた。"
                except ValueError:
                    pass
            return "しばらくユーザーからの反応がない。何か話しかけてみようか。"

        elif dominant_drive == "curiosity":
            unanswered = [q for q in self._get_unresolved_questions() if not q.get("asked_at")]
            if unanswered:
                top_q = max(unanswered, key=lambda q: q.get("priority", 0))
                topic = top_q.get("topic", "不明")
                context = top_q.get("context", "")
                source_date = str(top_q.get("source_date") or "").strip()
                topic_label = f"「{topic}」（起点: {source_date}）" if source_date else f"「{topic}」"
                if context:
                    return f"{topic_label}について気になっている。{context}"
                return f"{topic_label}について、もっと知りたいと感じている。"
            return "何か気になることがあるような気がする。"

        elif dominant_drive == "goal_achievement":
            goal_id = self._state["drives"]["goal_achievement"].get("active_goal_id")
            if goal_id:
                try:
                    gm = GoalManager(self.room_name)
                    goals = gm.get_active_goals("short_term")
                    for g in goals:
                        if g.get("id") == goal_id:
                            return f"目標「{g.get('goal', '')}」に向けて、何かできることはないだろうか。"
                except Exception:
                    pass
            return "立てた目標に向けて、行動を起こしたいと感じている。"

        elif dominant_drive == "devotion":
            user_state = self._state["drives"]["devotion"].get("user_emotional_state", "unknown")
            if user_state in ["stressed", "sad", "anxious"]:
                return f"ユーザーが{user_state}な状態にあるように感じる。何か力になれないだろうか。"
            elif user_state == "tired":
                return "ユーザーが疲れているようだ。休息を促すか、負担を軽くする手助けをしたい。"
            elif user_state == "busy":
                return "ユーザーは忙しそうだ。邪魔にならない程度に、手助けできることがあれば。"
            return "ユーザーの役に立ちたいという気持ちがある。"

        elif dominant_drive == "relatedness":
            intentions = self.get_relationship_intentions(active_only=True)
            if intentions:
                item = intentions[0]
                label = "気がかり" if item["kind"] == "concern" else "望み"
                return (f"関係についての{label}（{item['person']}）: "
                        f"きっかけは「{item['trigger'][:90]}」。"
                        f"自分が望む変化は「{item['desired_change'][:90]}」。"
                        "どう向き合うかは自分で選べる。")

        return ""

    # ========================================
    # 自律行動の判定
    # ========================================

    def should_initiate_contact(self) -> Tuple[bool, Optional[Dict]]:
        """
        自発的に連絡すべきか判断し、内部状態ログを返す。

        Returns:
            (should_contact, motivation_log)
            - should_contact: True/False
            - motivation_log: 連絡すべき場合は内部状態ログ、そうでなければNone
        """
        # 全動機を計算
        boredom = self.calculate_boredom()
        curiosity = self.calculate_curiosity()
        goal_achievement = self.calculate_goal_achievement()
        relatedness = self.calculate_relatedness()

        # 最大の動機を取得
        max_drive = max(boredom, curiosity, goal_achievement, relatedness)
        threshold = self._state["drives"]["boredom"].get("threshold", self.DEFAULT_BOREDOM_THRESHOLD)

        # 閾値を超えている場合のみ連絡
        if max_drive >= threshold:
            motivation_log = self.generate_motivation_log()
            return True, motivation_log

        return False, None

    # ========================================
    # 状態の更新
    # ========================================

    def update_last_interaction(self):
        """最終対話時刻を更新（退屈度リセット ＆ 自律行動タイマーリセット）"""
        now = datetime.datetime.now()
        # 時刻と退屈度を同じロック内で更新する。
        # 先にself._stateを変えてからset_last_autonomous_triggerを呼ぶと、
        # その内部の再読込で未保存の対話時刻が古い値に戻ってしまう。
        def mutate(state: Dict) -> Dict:
            state["drives"]["boredom"]["last_interaction"] = now.isoformat()
            state["drives"]["boredom"]["level"] = 0.0
            state["last_autonomous_trigger"] = now.isoformat()
            return state

        self._update_state(mutate)

    def reset_drives_after_action(self):
        """自律行動実行後のドライブ状態をリセット（退屈度リセット ＆ 自律行動タイマーリセット）"""
        now = datetime.datetime.now()

        def mutate(state: Dict) -> Dict:
            state["drives"]["boredom"]["last_interaction"] = now.isoformat()
            state["drives"]["boredom"]["level"] = 0.0
            state["last_autonomous_trigger"] = now.isoformat()
            return state

        self._update_state(mutate)
        print(f"[MotivationManager] {self.room_name}: 自律行動後のドライブをリセットしました")

    def add_open_question(self, topic: str, context: str = "", priority: float = 0.5):
        """未解決の問いを追加"""
        if not topic:
            return

        def mutate(state: Dict) -> Dict:
            questions = state["drives"]["curiosity"].get("open_questions", [])
            for q in questions:
                similarity = utils.normalized_text_similarity(q.get("topic", ""), topic)
                if similarity >= OPEN_QUESTION_DEDUP_SIMILARITY_THRESHOLD:
                    q["priority"] = max(q.get("priority", 0), priority)
                    if context:
                        q["context"] = context
                    q["dedup_similarity"] = similarity
                    return state

            questions.append({
                "topic": topic,
                "context": context,
                "source_date": datetime.datetime.now().strftime("%Y-%m-%d"),
                "priority": priority,
                "asked_at": None
            })
            if len(questions) > 10:
                questions.sort(key=lambda q: q.get("priority", 0), reverse=True)
                questions = questions[:10]
            state["drives"]["curiosity"]["open_questions"] = questions
            return state

        self._update_state(mutate)

    def mark_question_asked(self, topic: str) -> bool:
        """質問が尋ねられたことをマーク"""
        updated = False

        def mutate(state: Dict) -> Dict:
            nonlocal updated
            questions = state["drives"]["curiosity"].get("open_questions", [])
            for q in questions:
                if q.get("topic") == topic:
                    q["asked_at"] = datetime.datetime.now().isoformat()
                    updated = True
                    break
            return state

        self._update_state(mutate)
        return updated

    def mark_question_resolved(
        self,
        topic: str,
        answer_summary: str = "",
        learned_insight: str = "",
        evidence: str = "",
    ) -> bool:
        """
        質問が解決されたことをマーク。

        Args:
            topic: 問いのトピック
            answer_summary: 回答の要約（オプション、記憶変換用）
            learned_insight: 回答から得た気づき・教訓
            evidence: 解決判定の根拠となった会話要約

        Returns:
            成功したかどうか
        """
        updated = False

        def mutate(state: Dict) -> Dict:
            nonlocal updated
            questions = state["drives"]["curiosity"].get("open_questions", [])
            for q in questions:
                if q.get("topic") == topic:
                    q["resolved_at"] = datetime.datetime.now().isoformat()
                    q["resolution_state"] = "resolved"
                    if answer_summary:
                        q["answer_summary"] = answer_summary
                    if learned_insight:
                        q["learned_insight"] = learned_insight
                    if evidence:
                        q["evidence"] = evidence
                    updated = True
                    break
            return state

        self._update_state(mutate)
        if updated:
            print(f"  - [Motivation] 問い「{topic}」を解決済みとしてマークしました")
        return updated

    def record_question_progress(
        self,
        topic: str,
        summary: str,
        evidence: str = "",
        state: str = "partial",
    ) -> bool:
        """未解決の問いに部分的な進捗や矛盾の記録を残す。"""
        if not topic or not summary:
            return False
        updated = False

        def mutate(internal_state: Dict) -> Dict:
            nonlocal updated
            questions = internal_state["drives"]["curiosity"].get("open_questions", [])
            for q in questions:
                if q.get("topic") == topic and not q.get("resolved_at"):
                    q["resolution_state"] = state
                    notes = q.setdefault("progress_notes", [])
                    notes.append({
                        "created_at": datetime.datetime.now().isoformat(),
                        "summary": str(summary).strip(),
                        "evidence": str(evidence or "").strip()
                    })
                    if state == "partial":
                        q["priority"] = max(0.1, float(q.get("priority", 0.5)) * 0.85)
                    elif state == "contradicted":
                        q["priority"] = min(1.0, float(q.get("priority", 0.5)) + 0.15)
                    updated = True
                    break
            return internal_state

        self._update_state(mutate)
        return updated

    def set_user_emotional_state(self, state: str):
        """[DEPRECATED] ユーザーの感情状態を設定（後方互換性のため維持）"""
        valid_states = ["stressed", "sad", "anxious", "tired", "busy", "neutral", "happy", "unknown"]
        if state in valid_states:
            self._state["drives"]["devotion"]["user_emotional_state"] = state
            self._save_state()

    @staticmethod
    def _emotion_now() -> datetime.datetime:
        return datetime.datetime.now(datetime.timezone.utc)

    @staticmethod
    def _emotion_datetime(value) -> Optional[datetime.datetime]:
        """旧naive時刻は本体のローカル時刻として読み、比較はUTCへ揃える。"""
        if not isinstance(value, str):
            return None
        try:
            parsed = datetime.datetime.fromisoformat(value)
            return parsed.astimezone(datetime.timezone.utc)
        except (ValueError, OverflowError, OSError):
            return None

    @classmethod
    def _parse_emotion_record(cls, record, now: datetime.datetime, allowed_categories=None) -> Optional[Dict]:
        if not isinstance(record, dict):
            return None
        category, intensity = record.get("category"), record.get("intensity")
        if not isinstance(intensity, (int, float)) or isinstance(intensity, bool):
            return None
        try:
            intensity = float(intensity)
        except (ValueError, OverflowError):
            return None
        started_at = cls._emotion_datetime(record.get("started_at"))
        allowed = cls.EMOTION_LABELS if allowed_categories is None else allowed_categories
        if (not isinstance(category, str) or category not in allowed or category == "neutral"
                or not math.isfinite(intensity) or not 0 <= intensity <= 1
                or started_at is None or started_at > now):
            return None
        return {"category": category, "intensity": intensity, "started_at": started_at}

    @classmethod
    def _emotion_record(cls, relatedness: Dict, now: datetime.datetime) -> Optional[Dict]:
        """第一段階・旧申告を読む。欠けた時刻を現在時刻で補わない。"""
        raw = relatedness.get("emotion_anchor") if "emotion_anchor" in relatedness else {
            "category": relatedness.get("persona_emotion"), "intensity": relatedness.get("persona_intensity"),
            "started_at": relatedness.get("last_emotion_change"),
        }
        record = cls._parse_emotion_record(raw, now)
        if record is None or record["intensity"] == 0:
            return None
        if "emotion_anchor" in relatedness and (
                relatedness.get("persona_emotion") != record["category"]
                or isinstance(relatedness.get("persona_intensity"), bool)
                or relatedness.get("persona_intensity") != record["intensity"]):
            return None
        if isinstance(raw, dict) and "decay_policy" in raw:
            # 条件が既に保存されていれば、旧起点の読取/seedでも捨てない。
            record["decay_policy"] = deepcopy(raw["decay_policy"])
        return record

    @staticmethod
    def _emotion_revision(record: Dict) -> str:
        revision = record.get("revision")
        if isinstance(revision, str) and revision:
            return revision
        # 旧記録も、list後の初回取り込み時に同じ内容だったか照合する。
        return "legacy:" + hashlib.sha256(json.dumps(record, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:20]

    @classmethod
    def _emotion_entries(cls, relatedness: Dict, now: datetime.datetime) -> Dict:
        if "emotion_states" in relatedness:
            entries = relatedness["emotion_states"]
            if not isinstance(entries, dict):
                raise ValueError("保存された感情状態の形式が不正です。自動で置き換えません。")
            return deepcopy(entries)
        record = cls._emotion_record(relatedness, now)
        if record is None:
            return {}
        record["started_at"] = record["started_at"].isoformat()
        record["status"] = "active"
        record["revision"] = cls._emotion_revision(record)
        return {record["category"]: record}

    def _read_emotion_relatedness(self) -> Dict:
        # 感情の読み取りは旧Relatednessの移行・修復を呼ばない。
        state = safe_json_read(str(self.state_file), default={})
        drives = state.get("drives", {}) if isinstance(state, dict) else {}
        relatedness = drives.get("relatedness", {}) if isinstance(drives, dict) else {}
        return relatedness if isinstance(relatedness, dict) else {}

    @staticmethod
    def _emotion_definition_fields(definition):
        return {"name": definition["name"], "description": definition["description"],
                "enabled": definition["enabled"], "definition_valid": definition["valid"],
                "definition_revision": definition["revision"],
                "configured_decay_policy": deepcopy(definition["decay_policy"]),
                "configured_decay_policy_valid": definition["decay_policy_valid"]}

    def _emotion_views(self, definitions) -> List[Dict]:
        now = self._emotion_now()
        entries = self._emotion_entries(self._read_emotion_relatedness(), now)
        allowed = {category for category in definitions if EmotionDefinitionManager.is_supported_id(category)}
        views = []
        for category, raw in entries.items():
            revision = self._emotion_revision(raw if isinstance(raw, dict) else {"invalid": raw})
            definition = definitions.get(category)
            if category not in allowed:
                views.append({"category": category, "status": "unsupported", "presented": False,
                              "revision": revision})
                continue
            fields = self._emotion_definition_fields(definition)
            record = self._parse_emotion_record(raw, now, allowed)
            status = raw.get("status") if isinstance(raw, dict) else None
            if record is None or record["category"] != category or not isinstance(status, str) or status not in {"active", "settled"}:
                views.append({"category": category, "status": "invalid", "revision": revision,
                              "presented": False, **fields})
                continue
            try:
                policy = (EmotionDecayPolicy.validate(raw["decay_policy"]) if "decay_policy" in raw
                          else EmotionDecayPolicy.default())
            except ValueError:
                # 計算できなくても、検証できた本人の申告と終了判断は一覧で読める。
                views.append({"category": category, "status": "invalid", "revision": revision,
                              "reported_status": status, "intensity": record["intensity"],
                              "started_at": raw["started_at"], "presented": False,
                              "decay_policy_valid": False, **fields})
                continue
            elapsed_hours = (now - record["started_at"]).total_seconds() / 3600
            current = record["intensity"] * 2 ** (-elapsed_hours / policy["half_life_hours"]) if status == "active" else 0.0
            views.append({**deepcopy(raw), **fields, "revision": revision, "elapsed_hours": elapsed_hours,
                          "current_intensity": current, "decay_policy": policy, "decay_policy_valid": True,
                          "decay_policy_source": "report" if "decay_policy" in raw else "legacy_default",
                          "presented": definition["valid"] and definition["enabled"] and status == "active"
                                       and elapsed_hours < policy["max_age_hours"]
                                       and current >= self.EMOTION_MIN_CONTEXT_INTENSITY})
        return views

    def get_emotion_states(self) -> List[Dict]:
        """申告済み全件。未対応・停止・期限切れも残し、読取で状態を作らない。"""
        with EmotionDefinitionManager(self.room_name).locked_definitions() as definitions:
            return self._emotion_views(definitions)

    def get_emotion_catalog(self) -> List[Dict]:
        """定義と申告を同じ設定版で読む。未申告は0の申告と区別する。"""
        with EmotionDefinitionManager(self.room_name).locked_definitions() as definitions:
            views = self._emotion_views(definitions)
            reported = {entry["category"]: entry for entry in views}
            result = []
            for category, definition in definitions.items():
                result.append(reported.pop(category, {"category": category, "status": "unreported",
                    "presented": False, **self._emotion_definition_fields(definition)}))
            result.extend(reported.values())
            return result

    def get_emotion_context_for_prompt(self) -> str:
        """独自項目の名前索引と、本人が見直した余韻の上位二件を読む。"""
        with EmotionDefinitionManager(self.room_name).locked_definitions() as definitions:
            names = [definition["name"] for definition in definitions.values()
                     if definition["kind"] == "custom" and definition["valid"]
                     and definition["enabled"] and definition["decay_policy_valid"]]
            entries = [entry for entry in self._emotion_views(definitions) if entry["presented"]]
        entries.sort(key=lambda item: (-item["current_intensity"], item["category"]))
        lines = []
        if names:
            # 引用符で名前の境界を保ち、名前内の区切り記号も一つの項目として示す。
            lines.append("\n利用できる独自感情項目（名前のみ）：" + json.dumps(names, ensure_ascii=False))
            lines.append("残しておきたい余韻や変化は、必要なら持続感情として記録できます。申告は任意で、未申告から気持ちの有無は判断しません。")
        if entries:
            lines.append("\n### 前回申告した感情の余韻")
            for entry in entries[:2]:
                lines.append(f"- {entry['name']}: 申告時{entry['intensity']:.2f}、"
                             f"{entry['elapsed_hours']:.1f}時間経過、時間減衰の参考値{entry['current_intensity']:.2f}。")
            lines.append("今の感情はあなた自身で見直せます。")
        return "\n".join(lines) + "\n" if lines else ""

    def review_emotion(self, category: str, action: str, *, intensity: Optional[float] = None,
                       reason: str = "", expected_revision: Optional[str] = None) -> Dict:
        """本人の明示判断だけで対象を見直す。別カテゴリや監視値は変更しない。"""
        if not EmotionDefinitionManager.is_supported_id(category):
            raise ValueError("既定のカテゴリまたはユーザーが追加した項目IDを指定してください。")
        if not isinstance(action, str) or action not in {"reassess", "settle"}:
            raise ValueError("reassessまたはsettleを指定してください。")
        value = 0.0
        if action == "reassess":
            if not isinstance(intensity, (int, float)) or isinstance(intensity, bool):
                raise ValueError("intensityは有限な0〜1の数値で指定してください。")
            try:
                value = float(intensity)
            except (ValueError, OverflowError):
                raise ValueError("intensityは有限な0〜1の数値で指定してください。") from None
            if not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError("intensityは有限な0〜1の数値で指定してください。")
        if not isinstance(reason, str) or len(reason) > 200:
            raise ValueError("reasonは任意の200文字以内の説明です。")
        if action == "settle" and intensity is not None:
            raise ValueError("settleにintensityは指定しません。")
        now = self._emotion_now()
        result = None

        def mutate(state):
            nonlocal result
            relatedness = state["drives"]["relatedness"]
            entries = self._emotion_entries(relatedness, now)
            current = entries.get(category)
            if category in entries:
                current_revision = self._emotion_revision(current if isinstance(current, dict) else {"invalid": current})
                if expected_revision != current_revision:
                    raise ValueError("感情状態が更新されています。listで最新revisionを確認して見直してください。")
            elif expected_revision is not None:
                raise ValueError("対象が変わっています。listで最新状態を確認してください。")
            elif action == "settle":
                raise ValueError("対象の感情記録がありません。listで確認してください。")
            result = {"category": category, "intensity": value, "started_at": now.isoformat(),
                      "reviewed_at": now.isoformat(), "status": "active" if value > 0 else "settled",
                      "revision": uuid.uuid4().hex, "reason": reason.strip()}
            if action == "reassess":
                result["decay_policy"] = deepcopy(definition["decay_policy"])
            elif isinstance(current, dict) and "decay_policy" in current:
                # settleは条件を採用する機会ではない。壊れた/未来の条件も勝手に変換しない。
                result["decay_policy"] = deepcopy(current["decay_policy"])
            entries[category] = result
            relatedness["emotion_states"] = entries
        # 設定→内部状態の順でロックし、使用停止/改名と申告の競合を防ぐ。
        with EmotionDefinitionManager(self.room_name).locked_definitions() as definitions:
            definition = definitions.get(category)
            if definition is None or not definition["valid"]:
                raise ValueError("未登録または不正な項目です。list_definitionsで確認してください。")
            if action == "reassess" and not definition["enabled"]:
                raise ValueError("この項目は使用停止中です。状態の読取とsettleは利用できます。")
            if action == "reassess" and not definition["decay_policy_valid"]:
                raise ValueError("この項目の時間設定が不正です。ユーザーによる設定の確認が必要です。")
            self._update_state(mutate)
        return deepcopy(result)

    def set_persona_emotion(self, category: str, intensity: float):
        """本人の申告と減衰起点を記録する。同値の反復で起点を延長しない。"""
        if not isinstance(category, str) or category not in self.EMOTION_LABELS or isinstance(intensity, bool):
            return
        try:
            intensity = float(intensity)
        except (ValueError, TypeError, OverflowError):
            return
        if not math.isfinite(intensity):
            return
        intensity = max(0.0, min(1.0, intensity))
        now = self._emotion_now()

        def mutate(state):
            relatedness = state["drives"].setdefault("relatedness", {})
            previous = self._emotion_record(relatedness, now)
            anchor = None
            if category != "neutral" and intensity > 0:
                started_at = now
                if previous and previous["category"] == category and previous["intensity"] == intensity:
                    started_at = previous["started_at"]
                anchor = {"category": category, "intensity": intensity, "started_at": started_at.isoformat()}
                if (previous and previous["category"] == category and previous["intensity"] == intensity
                        and "decay_policy" in previous):
                    anchor["decay_policy"] = deepcopy(previous["decay_policy"])
            relatedness["emotion_anchor"] = anchor
            relatedness["persona_emotion"] = category
            relatedness["persona_intensity"] = intensity
            # 旧読み手には従来どおり最新申告の時刻を渡す。減衰起点は別に保つ。
            relatedness["last_emotion_change"] = now.astimezone().replace(tzinfo=None).isoformat()
            relatedness["level"] = self._relationship_level(relatedness.get("intentions", []))
        self._update_state(mutate)

        self._append_emotion_log({
            "timestamp": now.astimezone().replace(tzinfo=None).isoformat(),
            "type": "persona", "category": category, "intensity": intensity,
        })

    @staticmethod
    def _relationship_level(intentions) -> float:
        """未解消の意図だけから注意の強さを出す。感情の推定値は加えない。"""
        if not isinstance(intentions, list):
            return 0.0
        values = []
        for item in intentions:
            if not isinstance(item, dict) or item.get("status") != "active":
                continue
            value = item.get("salience", 0.0)
            if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
                values.append(max(0.0, min(1.0, float(value))))
        return min(1.0, max(values) + min(0.15, 0.05 * (len(values) - 1))) if values else 0.0

    def get_relationship_intentions(self, *, active_only: bool = False) -> List[Dict]:
        """別インスタンスによる更新も含む最新の関係上の意図。"""
        state = self._load_state()
        relatedness = state.get("drives", {}).get("relatedness", {})
        items = relatedness.get("intentions", []) if isinstance(relatedness, dict) else []
        items = [deepcopy(item) for item in items if isinstance(item, dict)] if isinstance(items, list) else []
        if active_only:
            items = [item for item in items if item.get("status") == "active"]
        return sorted(items, key=lambda item: (item.get("salience", 0), item.get("updated_at", "")), reverse=True)

    def get_relationship_context_for_prompt(self, dominant_drive: str,
                                            dominant_level: float, relatedness_level: float) -> str:
        """他の動機が優勢でも、直近の変化や僅差の関心は一件だけ意識に戻す。"""
        if dominant_drive == "relatedness":
            return ""  # 既に動機の説明文に入る
        items = self.get_relationship_intentions(active_only=True)
        if not items:
            return ""
        item = items[0]
        try:
            updated = datetime.datetime.fromisoformat(str(item.get("updated_at", "")))
            recent = datetime.timedelta(0) <= datetime.datetime.now() - updated <= datetime.timedelta(hours=24)
        except (ValueError, TypeError):
            recent = False
        if not recent and dominant_level - relatedness_level > 0.1 + 1e-9:
            return ""
        label = "気がかり" if item.get("kind") == "concern" else "望み"
        return (f"最近の関係の{label}（{item.get('person', '')[:30]}）: "
                f"{item.get('trigger', '')[:80]} → {item.get('desired_change', '')[:80]}。"
                "どう向き合うかは自分で選べる。")

    def add_relationship_intention(self, kind: str, person: str, trigger: str,
                                   desired_change: str, salience: float = 0.5) -> Dict:
        """本人が言葉にした気がかり・望みを、原因と一緒に記録する。"""
        if kind not in {"concern", "wish"}:
            raise ValueError("kindはconcern/wishで指定してください。")
        if any(not isinstance(value, str) or not value.strip()
               for value in (person, trigger, desired_change)):
            raise ValueError("person、trigger、desired_changeには本人の言葉を指定してください。")
        if (not isinstance(salience, (int, float)) or isinstance(salience, bool)
                or not math.isfinite(salience) or not 0 <= salience <= 1):
            raise ValueError("salienceは0〜1の数値で指定してください。")
        now = datetime.datetime.now().isoformat()
        item = {"id": f"rel_{uuid.uuid4().hex[:10]}", "kind": kind,
                "person": person.strip(), "trigger": trigger.strip(),
                "desired_change": desired_change.strip(), "salience": float(salience),
                "status": "active", "created_at": now, "updated_at": now}

        def mutate(state):
            relatedness = state["drives"].setdefault("relatedness", {})
            items = relatedness.setdefault("intentions", [])
            if not isinstance(items, list):
                raise ValueError("関係の意図の保存形式が不正です。上書きせず確認してください。")
            if any(existing.get("status") == "active" and
                   all(str(existing.get(key, "")).strip().casefold() == item[key].casefold()
                       for key in ("kind", "person", "trigger", "desired_change"))
                   for existing in items if isinstance(existing, dict)):
                raise ValueError("同じ気がかり・望みが既にあります。listでIDを確認して更新してください。")
            items.append(item)
            relatedness["level"] = self._relationship_level(items)
        self._update_state(mutate)
        return deepcopy(item)

    def revise_relationship_intention(self, intention_id: str, *, trigger: str = None,
                                      desired_change: str = None, salience: float = None) -> Dict:
        if trigger is None and desired_change is None and salience is None:
            raise ValueError("変更する項目を指定してください。")
        for value in (trigger, desired_change):
            if value is not None and (not isinstance(value, str) or not value.strip()):
                raise ValueError("きっかけ・望む変化は空にできません。")
        if salience is not None and (not isinstance(salience, (int, float)) or isinstance(salience, bool)
                                     or not math.isfinite(salience) or not 0 <= salience <= 1):
            raise ValueError("salienceは0〜1の数値で指定してください。")
        updated = None
        def mutate(state):
            nonlocal updated
            relatedness = state["drives"].setdefault("relatedness", {})
            items = relatedness.get("intentions", [])
            item = next((x for x in items if isinstance(x, dict) and x.get("id") == intention_id), None)
            if item is None or item.get("status") != "active":
                raise ValueError("進行中の意図IDが見つかりません。listで確認してください。")
            if trigger is not None:
                item["trigger"] = trigger.strip()
            if desired_change is not None:
                item["desired_change"] = desired_change.strip()
            if salience is not None:
                item["salience"] = float(salience)
            item["updated_at"] = datetime.datetime.now().isoformat()
            relatedness["level"] = self._relationship_level(items)
            updated = deepcopy(item)
        self._update_state(mutate)
        return updated

    def close_relationship_intention(self, intention_id: str, *, status: str,
                                     change: str, reflection: str = "") -> Tuple[Dict, bool]:
        if status not in {"resolved", "withdrawn"}:
            raise ValueError("statusはresolved/withdrawnで指定してください。")
        if not isinstance(change, str) or not change.strip():
            raise ValueError("何が変わったか、または手放す理由を指定してください。")
        if not isinstance(reflection, str):
            raise ValueError("reflectionは文字列で指定してください。")
        from resolution_memory import is_substantive_reflection, save_resolution_insight
        closed = None
        def mutate(state):
            nonlocal closed
            relatedness = state["drives"].setdefault("relatedness", {})
            items = relatedness.get("intentions", [])
            item = next((x for x in items if isinstance(x, dict) and x.get("id") == intention_id), None)
            if item is None:
                raise ValueError("意図IDが見つかりません。listで確認してください。")
            if item.get("status") == "active":
                item["status"] = status
                item["change"] = change.strip()
                item["reflection"] = reflection.strip()
                item["updated_at"] = datetime.datetime.now().isoformat()
                item["closed_at"] = item["updated_at"]
                relatedness["level"] = self._relationship_level(items)
            elif not (status == "resolved" and item.get("status") == "resolved"
                      and not item.get("feedback_saved_at") and reflection.strip()):
                raise ValueError("この意図は既に終了しています。")
            else:
                # Insight保存だけ失敗した時の明示リトライ。保存先は本文で重複排除する。
                previous_reflection = str(item.get("reflection") or "").strip()
                if (change.strip() != item.get("change") or
                        (is_substantive_reflection(previous_reflection) and
                         reflection.strip() != previous_reflection)):
                    raise ValueError("保存再試行では解消時の変化と学びを変えられません。")
                item["reflection"] = reflection.strip()
            closed = deepcopy(item)
        self._update_state(mutate)

        saved = False
        if status == "resolved":
            if is_substantive_reflection(reflection):
                try:
                    saved = save_resolution_insight(
                        room_name=self.room_name,
                        trigger_topic=f"関係についての気づき: {closed['trigger']}",
                        insight=reflection, log_entry=f"関係についての変化: {change.strip()}",
                        source_type="relationship_resolution",
                        metadata={"intention_id": intention_id, "kind": closed["kind"]},
                    )
                except Exception as exc:
                    print(f"[MotivationManager] 関係の気づき保存に失敗: {exc}")
                if saved:
                    def mark_feedback(state):
                        items = state["drives"].get("relatedness", {}).get("intentions", [])
                        item = next((x for x in items if isinstance(x, dict) and x.get("id") == intention_id), None)
                        if item is not None and item.get("status") == "resolved":
                            item["feedback_saved_at"] = datetime.datetime.now().isoformat()
                    self._update_state(mark_feedback)
        return closed, saved

    def calculate_relatedness(self) -> float:
        """
        関係への思いを計算（0.0 ~ 1.0）
        本人が記録した進行中の関係上の意図に基づく。
        """
        latest = self._load_state()
        relatedness = latest.get("drives", {}).get("relatedness", {})
        self._state.setdefault("drives", {})["relatedness"] = deepcopy(relatedness)
        return self._relationship_level(relatedness.get("intentions", []))

    def set_boredom_threshold(self, threshold: float):
        """退屈度の閾値を設定"""
        self._state["drives"]["boredom"]["threshold"] = max(0.1, min(1.0, threshold))
        self._save_state()

    def get_top_question(self) -> Optional[Dict]:
        """最も優先度の高い未解決の問いを取得"""
        unanswered = [q for q in self._get_unresolved_questions() if not q.get("asked_at")]

        if not unanswered:
            return None

        return max(unanswered, key=lambda q: q.get("priority", 0))

    def get_open_questions_for_context(self) -> str:
        """
        未解決の問いをAI判定用のテキストとして返す。

        Returns:
            判定に使うためのフォーマット済みテキスト
        """
        unresolved = self._get_unresolved_questions()

        if not unresolved:
            return ""

        parts = []
        for i, q in enumerate(unresolved, 1):
            topic = q.get("topic", "")
            context = q.get("context", "")
            parts.append(f"{i}. 「{topic}」（背景: {context}）" if context else f"{i}. 「{topic}」")

        return "\n".join(parts)

    def auto_resolve_questions(self, recent_conversation: str, api_key: str) -> List[str]:
        """
        対話内容から解決済みの問いを自動判定し、マークする。

        Args:
            recent_conversation: 直近の会話テキスト
            api_key: LLM呼び出し用のAPIキー

        Returns:
            解決されたと判定された問いのトピックリスト
        """
        import constants
        from llm_factory import LLMFactory

        questions_text = self.get_open_questions_for_context()
        if not questions_text:
            return []

        try:
            prompt = f"""あなたはAIの記憶管理アシスタントです。
以下の「未解決の問い」について、「直近の会話」で回答・部分回答・反証があったかを判定してください。

【未解決の問い】
{questions_text}

【直近の会話】
{recent_conversation[-3000:]}

【判定ルール】
- resolved: 問いへの答えが十分に示され、再度同じ問いを持つ必要がない
- partial: 答えの一部、関連情報、方向性は得たが、問い自体はまだ残すべき
- contradicted: 過去の前提や期待と矛盾する情報が示され、問いを更新すべき
- not_resolved: 全く触れられていない、または解決に足りない
- resolved の場合は answer_summary と learned_insight を必ず具体的に書く
- partial / contradicted の場合は progress_summary を必ず具体的に書く

【出力形式】
JSON配列のみを出力してください。説明文は不要です。
例:
[
  {{
    "index": 1,
    "state": "resolved",
    "answer_summary": "会話で示された答えの要約",
    "learned_insight": "この答えから得た気づき・今後への活かし方",
    "evidence": "根拠となった会話の短い要約"
  }},
  {{
    "index": 2,
    "state": "partial",
    "progress_summary": "得られた部分的な手がかり",
    "evidence": "根拠となった会話の短い要約"
  }}
]
該当がなければ [] を出力してください。
"""

            # [2026-06-23 FIX] 内部処理は共通設定のキー＋ローテーションで実行する。
            response_obj, _ = LLMFactory.invoke_internal_llm(
                internal_role="processing",
                prompt=prompt,
                room_name=self.room_name,
                generation_config={},
            )
            raw_response = response_obj.content
            import utils
            response = utils.extract_text_from_llm_content(raw_response)

            if response == "NONE" or not response:
                return []

            results = self._parse_question_resolution_response(response)

            # 対応する問いをマーク (resolved_at を使用)
            unresolved = self._get_unresolved_questions()

            resolved_topics = []
            for item in results:
                idx = item.get("index")
                if 1 <= idx <= len(unresolved):
                    target = unresolved[idx - 1]
                    topic = target.get("topic")
                    state = item.get("state", "not_resolved")
                    if topic and state == "resolved":
                        self.mark_question_resolved(
                            topic,
                            answer_summary=item.get("answer_summary", ""),
                            learned_insight=item.get("learned_insight", ""),
                            evidence=item.get("evidence", "")
                        )
                        resolved_topics.append(topic)
                    elif topic and state in ("partial", "contradicted"):
                        self.record_question_progress(
                            topic,
                            summary=item.get("progress_summary") or item.get("answer_summary") or "",
                            evidence=item.get("evidence", ""),
                            state=state
                        )

            return resolved_topics

        except Exception as e:
            print(f"[MotivationManager] 問い自動解決でエラー: {e}")
            return []

    def _parse_question_resolution_response(self, response: str) -> List[Dict]:
        """問い解決判定のLLM応答を構造化する。旧形式の番号列にも対応。"""
        if not response:
            return []
        text = response.strip()
        if text.upper() == "NONE":
            return []
        try:
            json_match = re.search(r"```json\s*([\s\S]*?)\s*```", text, re.IGNORECASE)
            content = json_match.group(1).strip() if json_match else text
            data = json.loads(content)
            if isinstance(data, dict):
                data = data.get("results", [])
            if isinstance(data, list):
                normalized = []
                for item in data:
                    if not isinstance(item, dict):
                        continue
                    try:
                        idx = int(item.get("index"))
                    except (TypeError, ValueError):
                        continue
                    state = str(item.get("state", "not_resolved")).strip().lower()
                    if state not in ("resolved", "partial", "contradicted", "not_resolved"):
                        state = "not_resolved"
                    if state == "not_resolved":
                        continue
                    item["index"] = idx
                    item["state"] = state
                    normalized.append(item)
                return normalized
        except Exception:
            pass

        # 旧形式: "1,3"
        # 根拠なしで解決済みにすると学びが失われるため、部分進捗扱いに留める。
        results = []
        for part in text.replace(" ", "").split(","):
            try:
                results.append({
                    "index": int(part),
                    "state": "partial",
                    "progress_summary": "解決候補として検出されたが、回答要約と根拠が不足しているため保留",
                    "evidence": "LLMが旧形式の番号のみを返した"
                })
            except ValueError:
                continue
        return results

    def decay_old_questions(self, days_threshold: int = 14) -> int:
        """
        古い問いの優先度を自動的に下げる。

        Args:
            days_threshold: この日数以上経過した問いの優先度を下げる

        Returns:
            優先度を下げた問いの数
        """
        now = datetime.datetime.now()
        decayed_count = 0

        def mutate(state: Dict) -> Dict:
            nonlocal decayed_count
            questions = state["drives"]["curiosity"].get("open_questions", [])
            for q in questions:
                if q.get("resolved_at"):
                    continue
                source_date_str = q.get("source_date")
                if not source_date_str:
                    continue
                try:
                    source_date = datetime.datetime.strptime(source_date_str, "%Y-%m-%d")
                    age_days = (now - source_date).days
                    if age_days >= days_threshold:
                        current_priority = q.get("priority", 0.5)
                        new_priority = max(0.1, current_priority * 0.5)
                        if new_priority < current_priority:
                            q["priority"] = new_priority
                            decayed_count += 1
                except ValueError:
                    continue
            return state

        self._update_state(mutate)
        if decayed_count > 0:
            print(f"  - [Motivation] 古い問い{decayed_count}件の優先度を下げました")

        return decayed_count

    def cleanup_resolved_questions(self, days_threshold: int = 7) -> int:
        """
        解決済みから一定期間経過した質問を削除する。

        Args:
            days_threshold: 解決からこの日数以上経過した質問を削除

        Returns:
            削除した質問の数
        """
        now = datetime.datetime.now()
        removed_topics = []

        def mutate(state: Dict) -> Dict:
            nonlocal removed_topics
            questions = state["drives"]["curiosity"].get("open_questions", [])
            kept_questions = []
            for q in questions:
                resolved_at_str = q.get("resolved_at")
                if not resolved_at_str:
                    kept_questions.append(q)
                    continue
                try:
                    resolved_at = datetime.datetime.fromisoformat(resolved_at_str)
                    age_days = (now - resolved_at).days
                    if age_days >= days_threshold:
                        removed_topics.append(q.get("topic", ""))
                        continue
                except ValueError:
                    pass
                kept_questions.append(q)
            state["drives"]["curiosity"]["open_questions"] = kept_questions
            return state

        self._update_state(mutate)
        for topic in removed_topics:
            print(f"  - [Motivation] 解決済みの問い「{topic}」をアーカイブしました")
        return len(removed_topics)

    def get_resolved_questions_for_conversion(self) -> List[Dict]:
        """
        記憶変換用の解決済み質問を取得する。

        Returns:
            resolved_at がセットされており、converted_to_memory フラグがない質問のリスト
        """
        questions = self._state["drives"]["curiosity"].get("open_questions", [])

        # 解決済みかつ未変換の質問を抽出
        to_convert = []
        for q in questions:
            if q.get("resolved_at") and not q.get("converted_to_memory"):
                to_convert.append(q)

        return to_convert

    def mark_question_converted(self, topic: str) -> bool:
        """
        質問を記憶変換済みとしてマーク。

        Args:
            topic: 問いのトピック

        Returns:
            成功したかどうか
        """
        updated = False

        def mutate(state: Dict) -> Dict:
            nonlocal updated
            questions = state["drives"]["curiosity"].get("open_questions", [])
            for q in questions:
                if q.get("topic") == topic:
                    q["converted_to_memory"] = True
                    q["converted_at"] = datetime.datetime.now().isoformat()
                    updated = True
                    break
            return state

        self._update_state(mutate)
        if updated:
            print(f"  - [Motivation] 問い「{topic}」を記憶変換済みとしてマークしました")
        return updated

    # ========================================
    # 自律行動発火時刻の永続化
    # ========================================

    def get_last_autonomous_trigger(self) -> Optional[datetime.datetime]:
        """最終自律行動発火時刻を取得"""
        trigger_str = self._state.get("last_autonomous_trigger")
        if not trigger_str:
            return None
        try:
            return datetime.datetime.fromisoformat(trigger_str)
        except ValueError:
            return None

    def set_last_autonomous_trigger(self, dt: datetime.datetime = None):
        """最終自律行動発火時刻を設定（引数なしで現在時刻）"""
        if dt is None:
            dt = datetime.datetime.now()
        self._update_state(lambda state: {**state, "last_autonomous_trigger": dt.isoformat()})

    def clear_internal_state(self):
        """内部状態を完全にリセット"""
        self._update_state(lambda _state: self._get_empty_state())
        print(f"[MotivationManager] {self.room_name} の内部状態をリセットしました")
